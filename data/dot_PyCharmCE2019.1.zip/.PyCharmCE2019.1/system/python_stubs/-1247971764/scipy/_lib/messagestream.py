# encoding: utf-8
# module scipy._lib.messagestream
# from /usr/local/lib/python3.5/dist-packages/scipy/_lib/messagestream.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import tempfile as tempfile # /usr/lib/python3.5/tempfile.py
import os as os # /usr/lib/python3.5/os.py
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

__path__ = None

# no functions
# classes

class MessageStream(object):
    """
    Capture messages emitted to FILE* streams. Do this by directing them 
        to a temporary file, residing in memory (if possible) or on disk.
    """
    def clear(self, *args, **kwargs): # real signature unknown
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def get(self, *args, **kwargs): # real signature unknown
        pass

    def __del__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f32433dea58>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy._lib.messagestream', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f32433dea58>, origin='/usr/local/lib/python3.5/dist-packages/scipy/_lib/messagestream.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


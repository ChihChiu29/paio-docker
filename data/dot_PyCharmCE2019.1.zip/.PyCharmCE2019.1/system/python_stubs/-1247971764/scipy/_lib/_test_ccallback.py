# encoding: utf-8
# module scipy._lib._test_ccallback
# from /usr/local/lib/python3.5/dist-packages/scipy/_lib/_test_ccallback.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def test_call_nodata(*args, **kwargs): # real signature unknown
    pass

def test_call_nonlocal(*args, **kwargs): # real signature unknown
    pass

def test_call_simple(*args, **kwargs): # real signature unknown
    pass

def test_get_data_capsule(*args, **kwargs): # real signature unknown
    pass

def test_get_plus1bc_capsule(*args, **kwargs): # real signature unknown
    pass

def test_get_plus1b_capsule(*args, **kwargs): # real signature unknown
    pass

def test_get_plus1_capsule(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f39e6057a58>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy._lib._test_ccallback', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f39e6057a58>, origin='/usr/local/lib/python3.5/dist-packages/scipy/_lib/_test_ccallback.cpython-35m-x86_64-linux-gnu.so')"


# encoding: utf-8
# module scipy.interpolate._interpolate
# from /usr/local/lib/python3.5/dist-packages/scipy/interpolate/_interpolate.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def block_average_above_dddd(*args, **kwargs): # real signature unknown
    pass

def linear_dddd(*args, **kwargs): # real signature unknown
    pass

def loginterp_dddd(*args, **kwargs): # real signature unknown
    pass

def window_average_ddddd(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f0957de86d8>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.interpolate._interpolate', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f0957de86d8>, origin='/usr/local/lib/python3.5/dist-packages/scipy/interpolate/_interpolate.cpython-35m-x86_64-linux-gnu.so')"


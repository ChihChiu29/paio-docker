# encoding: utf-8
# module scipy.special._ufuncs_cxx
# from /usr/local/lib/python3.5/dist-packages/scipy/special/_ufuncs_cxx.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values

__path__ = None

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1c46ff97f0>'

__pyx_capi__ = {
    '_export_faddeeva_dawsn': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cc60>'
    '_export_faddeeva_dawsn_complex': None, # (!) real value is '<capsule object "void *" at 0x7f1c474125a0>'
    '_export_faddeeva_erf': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cc30>'
    '_export_faddeeva_erfc': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cb40>'
    '_export_faddeeva_erfcx': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cc90>'
    '_export_faddeeva_erfcx_complex': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703ccc0>'
    '_export_faddeeva_erfi': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cd20>'
    '_export_faddeeva_erfi_complex': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703ccf0>'
    '_export_faddeeva_log_ndtr': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cd50>'
    '_export_faddeeva_ndtr': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cd80>'
    '_export_faddeeva_w': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cdb0>'
    '_export_wrightomega': None, # (!) real value is '<capsule object "void *" at 0x7f1c4703cde0>'
    '_set_action': None, # (!) real value is '<capsule object "void (sf_error_t, sf_action_t)" at 0x7f1c4703ce10>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.special._ufuncs_cxx', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1c46ff97f0>, origin='/usr/local/lib/python3.5/dist-packages/scipy/special/_ufuncs_cxx.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


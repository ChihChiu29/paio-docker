# encoding: utf-8
# module scipy.integrate._test_multivariate
# from /usr/local/lib/python3.5/dist-packages/scipy/integrate/_test_multivariate.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

_multivariate_indefinite = 139664606271936
_multivariate_sin = 139664606271920
_multivariate_typical = 139664606272016

_sin_0 = 139664606271904
_sin_1 = 139664606271888
_sin_2 = 139664606271872
_sin_3 = 139664606271856

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f063eb924e0>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.integrate._test_multivariate', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f063eb924e0>, origin='/usr/local/lib/python3.5/dist-packages/scipy/integrate/_test_multivariate.cpython-35m-x86_64-linux-gnu.so')"


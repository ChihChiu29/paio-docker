# encoding: utf-8
# module scipy.ndimage._cytest
# from /usr/local/lib/python3.5/dist-packages/scipy/ndimage/_cytest.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values

__path__ = None

# functions

def filter1d(*args, **kwargs): # real signature unknown
    pass

def filter1d_capsule(*args, **kwargs): # real signature unknown
    pass

def filter2d(*args, **kwargs): # real signature unknown
    pass

def filter2d_capsule(*args, **kwargs): # real signature unknown
    pass

def transform(*args, **kwargs): # real signature unknown
    pass

def transform_capsule(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f779bf0e080>'

__pyx_capi__ = {
    '_filter1d': None, # (!) real value is '<capsule object "int (double *, npy_intp, double *, npy_intp, void *)" at 0x7f77a56283c0>'
    '_filter2d': None, # (!) real value is '<capsule object "int (double *, npy_intp, double *, void *)" at 0x7f77a5628510>'
    '_transform': None, # (!) real value is '<capsule object "int (npy_intp *, double *, int, int, void *)" at 0x7f779b8061b0>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.ndimage._cytest', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f779bf0e080>, origin='/usr/local/lib/python3.5/dist-packages/scipy/ndimage/_cytest.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module scipy.optimize._group_columns
# from /usr/local/lib/python3.5/dist-packages/scipy/optimize/_group_columns.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
Cython implementation of columns grouping for finite difference Jacobian
estimation. Used by ._numdiff.group_columns.
"""

# imports
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values

__path__ = None

# functions

def group_dense(*args, **kwargs): # real signature unknown
    pass

def group_sparse(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbc8c9045f8>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.optimize._group_columns', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbc8c9045f8>, origin='/usr/local/lib/python3.5/dist-packages/scipy/optimize/_group_columns.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


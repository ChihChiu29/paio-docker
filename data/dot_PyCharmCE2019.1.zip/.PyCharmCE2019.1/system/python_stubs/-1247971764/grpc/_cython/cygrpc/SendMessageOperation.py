# encoding: utf-8
# module grpc._cython.cygrpc
# from /usr/local/lib/python3.5/dist-packages/grpc/_cython/cygrpc.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import threading as threading # /usr/lib/python3.5/threading.py
import grpc as grpc # /usr/local/lib/python3.5/dist-packages/grpc/__init__.py
import logging as logging # /usr/lib/python3.5/logging/__init__.py
import sys as sys # <module 'sys' (built-in)>
import collections as collections # /usr/lib/python3.5/collections/__init__.py
import os as os # /usr/lib/python3.5/os.py
import time as time # <module 'time' (built-in)>
import pkgutil as pkgutil # /usr/lib/python3.5/pkgutil.py
import errno as errno # <module 'errno' (built-in)>
import builtins as __builtins__ # <module 'builtins' (built-in)>

from .Operation import Operation

class SendMessageOperation(Operation):
    # no doc
    def type(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    _flags = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _message = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f93c387a2a0>'



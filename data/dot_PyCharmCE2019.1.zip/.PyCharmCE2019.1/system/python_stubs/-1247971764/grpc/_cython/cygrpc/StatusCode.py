# encoding: utf-8
# module grpc._cython.cygrpc
# from /usr/local/lib/python3.5/dist-packages/grpc/_cython/cygrpc.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import threading as threading # /usr/lib/python3.5/threading.py
import grpc as grpc # /usr/local/lib/python3.5/dist-packages/grpc/__init__.py
import logging as logging # /usr/lib/python3.5/logging/__init__.py
import sys as sys # <module 'sys' (built-in)>
import collections as collections # /usr/lib/python3.5/collections/__init__.py
import os as os # /usr/lib/python3.5/os.py
import time as time # <module 'time' (built-in)>
import pkgutil as pkgutil # /usr/lib/python3.5/pkgutil.py
import errno as errno # <module 'errno' (built-in)>
import builtins as __builtins__ # <module 'builtins' (built-in)>

from .object import object

class StatusCode(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    aborted = 10
    already_exists = 6
    cancelled = 1
    data_loss = 15
    deadline_exceeded = 4
    failed_precondition = 9
    internal = 13
    invalid_argument = 3
    not_found = 5
    ok = 0
    out_of_range = 11
    permission_denied = 7
    resource_exhausted = 8
    unauthenticated = 16
    unavailable = 14
    unimplemented = 12
    unknown = 2
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'grpc._cython.cygrpc', 'not_found': 5, 'unavailable': 14, 'permission_denied': 7, '__doc__': None, 'unauthenticated': 16, 'aborted': 10, 'resource_exhausted': 8, 'already_exists': 6, 'failed_precondition': 9, 'cancelled': 1, 'invalid_argument': 3, 'internal': 13, 'out_of_range': 11, '__dict__': <attribute '__dict__' of 'StatusCode' objects>, 'deadline_exceeded': 4, 'data_loss': 15, 'unimplemented': 12, 'unknown': 2, 'ok': 0, '__weakref__': <attribute '__weakref__' of 'StatusCode' objects>})"



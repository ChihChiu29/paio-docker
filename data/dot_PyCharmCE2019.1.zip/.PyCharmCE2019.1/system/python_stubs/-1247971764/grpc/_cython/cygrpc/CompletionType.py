# encoding: utf-8
# module grpc._cython.cygrpc
# from /usr/local/lib/python3.5/dist-packages/grpc/_cython/cygrpc.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import threading as threading # /usr/lib/python3.5/threading.py
import grpc as grpc # /usr/local/lib/python3.5/dist-packages/grpc/__init__.py
import logging as logging # /usr/lib/python3.5/logging/__init__.py
import sys as sys # <module 'sys' (built-in)>
import collections as collections # /usr/lib/python3.5/collections/__init__.py
import os as os # /usr/lib/python3.5/os.py
import time as time # <module 'time' (built-in)>
import pkgutil as pkgutil # /usr/lib/python3.5/pkgutil.py
import errno as errno # <module 'errno' (built-in)>
import builtins as __builtins__ # <module 'builtins' (built-in)>

from .object import object

class CompletionType(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    operation_complete = 2
    queue_shutdown = 0
    queue_timeout = 1
    __dict__ = None # (!) real value is "mappingproxy({'__dict__': <attribute '__dict__' of 'CompletionType' objects>, '__module__': 'grpc._cython.cygrpc', 'queue_shutdown': 0, 'operation_complete': 2, 'queue_timeout': 1, '__doc__': None, '__weakref__': <attribute '__weakref__' of 'CompletionType' objects>})"



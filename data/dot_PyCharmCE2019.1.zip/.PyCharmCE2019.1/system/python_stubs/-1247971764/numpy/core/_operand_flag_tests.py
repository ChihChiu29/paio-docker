# encoding: utf-8
# module numpy.core._operand_flag_tests
# from /usr/local/lib/python3.5/dist-packages/numpy/core/_operand_flag_tests.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def inplace_add(x1, x2, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    inplace_add(x1, x2, /, out=(), *, where=True, casting='same_kind', order='K', dtype=None, subok=True[, signature, extobj])
    
    inplace_add_docstring
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4fcaadea58>'

__spec__ = None # (!) real value is "ModuleSpec(name='numpy.core._operand_flag_tests', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4fcaadea58>, origin='/usr/local/lib/python3.5/dist-packages/numpy/core/_operand_flag_tests.cpython-35m-x86_64-linux-gnu.so')"


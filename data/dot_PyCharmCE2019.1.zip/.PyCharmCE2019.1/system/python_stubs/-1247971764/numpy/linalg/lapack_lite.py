# encoding: utf-8
# module numpy.linalg.lapack_lite
# from /usr/local/lib/python3.5/dist-packages/numpy/linalg/lapack_lite.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def dgelsd(*args, **kwargs): # real signature unknown
    pass

def dgeqrf(*args, **kwargs): # real signature unknown
    pass

def dorgqr(*args, **kwargs): # real signature unknown
    pass

def xerbla(*args, **kwargs): # real signature unknown
    pass

def zgelsd(*args, **kwargs): # real signature unknown
    pass

def zgeqrf(*args, **kwargs): # real signature unknown
    pass

def zungqr(*args, **kwargs): # real signature unknown
    pass

# classes

class LapackError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f90ff0951d0>'

__spec__ = None # (!) real value is "ModuleSpec(name='numpy.linalg.lapack_lite', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f90ff0951d0>, origin='/usr/local/lib/python3.5/dist-packages/numpy/linalg/lapack_lite.cpython-35m-x86_64-linux-gnu.so')"


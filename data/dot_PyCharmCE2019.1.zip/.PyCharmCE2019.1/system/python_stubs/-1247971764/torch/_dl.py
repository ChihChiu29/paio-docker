# encoding: utf-8
# module torch._dl
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

RTLD_GLOBAL = 256
RTLD_LAZY = 1
RTLD_NOW = 2

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f31c5e53f60>'

__spec__ = None # (!) real value is "ModuleSpec(name='torch._dl', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f31c5e53f60>, origin='/usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so')"


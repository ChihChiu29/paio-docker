# encoding: utf-8
# module torch.nn._VF
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
from torch._C import vf


# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# no classes

# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/spacy/_align.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


from .TreeView import TreeView

class Stmt(TreeView):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass



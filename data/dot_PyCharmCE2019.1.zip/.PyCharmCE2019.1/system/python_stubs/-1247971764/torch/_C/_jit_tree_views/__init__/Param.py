# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


from .TreeView import TreeView

class Param(TreeView):
    # no doc
    def __init__(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ __init__(self: torch._C._jit_tree_views.Param, arg0: torch::jit::script::Expr, arg1: torch._C._jit_tree_views.Ident) -> None """
        pass



# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.5/dist-packages/torch/_C.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import torch._C._jit as _jit # <module 'torch._C._jit'>
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import pybind11_builtins as __pybind11_builtins


class ScriptModule(__pybind11_builtins.pybind11_object):
    # no doc
    def debug_disable_autodiff_subgraph_inlining(self): # real signature unknown; restored from __doc__
        """ debug_disable_autodiff_subgraph_inlining(self: torch._C.ScriptModule) -> None """
        pass

    def forward(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """ forward(*args, **kwargs) -> object """
        return object()

    def get_debug_state(self): # real signature unknown; restored from __doc__
        """ get_debug_state(self: torch._C.ScriptModule) -> torch._C.GraphExecutorState """
        pass

    def graph_for(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """ graph_for(*args, **kwargs) -> torch._C.Graph """
        pass

    def save(self, arg0): # real signature unknown; restored from __doc__
        """ save(self: torch._C.ScriptModule, arg0: str) -> None """
        pass

    def save_to_buffer(self): # real signature unknown; restored from __doc__
        """ save_to_buffer(self: torch._C.ScriptModule) -> bytes """
        return b""

    def _create_methods(self, arg0, torch__C__jit_tree_views_Def=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ _create_methods(self: torch._C.ScriptModule, arg0: List[torch._C._jit_tree_views.Def], arg1: List[Callable[[str], function]], arg2: List[Dict[str, object]]) -> None """
        pass

    def _create_method_from_graph(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ _create_method_from_graph(self: torch._C.ScriptModule, arg0: str, arg1: torch._C.Graph) -> None """
        pass

    def _create_method_from_trace(self, arg0, arg1, arg2, arg3, arg4): # real signature unknown; restored from __doc__
        """ _create_method_from_trace(self: torch._C.ScriptModule, arg0: str, arg1: function, arg2: tuple, arg3: function, arg4: bool) -> None """
        pass

    def _define(self, arg0, arg1, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ _define(self: torch._C.ScriptModule, arg0: str, arg1: Callable[[str], function], arg2: bool) -> None """
        pass

    def _get_method(self, arg0): # real signature unknown; restored from __doc__
        """ _get_method(self: torch._C.ScriptModule, arg0: str) -> torch::jit::script::Method """
        pass

    def _get_module(self, arg0): # real signature unknown; restored from __doc__
        """ _get_module(self: torch._C.ScriptModule, arg0: str) -> torch._C.ScriptModule """
        pass

    def _get_modules(self): # real signature unknown; restored from __doc__
        """ _get_modules(self: torch._C.ScriptModule) -> tuple """
        return ()

    def _get_parameter(self, arg0): # real signature unknown; restored from __doc__
        """ _get_parameter(self: torch._C.ScriptModule, arg0: str) -> torch::autograd::Variable """
        pass

    def _get_parameters(self): # real signature unknown; restored from __doc__
        """ _get_parameters(self: torch._C.ScriptModule) -> tuple """
        return ()

    def _has_buffer(self, arg0): # real signature unknown; restored from __doc__
        """ _has_buffer(self: torch._C.ScriptModule, arg0: str) -> bool """
        return False

    def _has_method(self, arg0): # real signature unknown; restored from __doc__
        """ _has_method(self: torch._C.ScriptModule, arg0: str) -> bool """
        return False

    def _has_module(self, arg0): # real signature unknown; restored from __doc__
        """ _has_module(self: torch._C.ScriptModule, arg0: str) -> bool """
        return False

    def _has_parameter(self, arg0): # real signature unknown; restored from __doc__
        """ _has_parameter(self: torch._C.ScriptModule, arg0: str) -> bool """
        return False

    def _method_names(self): # real signature unknown; restored from __doc__
        """ _method_names(self: torch._C.ScriptModule) -> List[str] """
        return []

    def _python_print(self): # real signature unknown; restored from __doc__
        """ _python_print(self: torch._C.ScriptModule) -> Tuple[str, List[at::Tensor]] """
        pass

    def _register_module(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ _register_module(self: torch._C.ScriptModule, arg0: str, arg1: torch._C.ScriptModule) -> None """
        pass

    def _register_parameter(self, arg0, arg1, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ _register_parameter(self: torch._C.ScriptModule, arg0: str, arg1: torch::autograd::Variable, arg2: bool) -> None """
        pass

    def _set_optimized(self, arg0): # real signature unknown; restored from __doc__
        """ _set_optimized(self: torch._C.ScriptModule, arg0: bool) -> None """
        pass

    def _set_parameter(self, arg0, arg1, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ _set_parameter(self: torch._C.ScriptModule, arg0: str, arg1: at::Tensor) -> None """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: torch._C.ScriptModule) -> None """
        pass

    code = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




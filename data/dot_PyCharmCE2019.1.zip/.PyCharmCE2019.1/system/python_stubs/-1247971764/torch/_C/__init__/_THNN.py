# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.5/dist-packages/torch/_C.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import torch._C._jit as _jit # <module 'torch._C._jit'>
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import pybind11_builtins as __pybind11_builtins


from .object import object

class _THNN(object):
    # no doc
    def DoubleAbsCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleAbsCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleBCECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleBCECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleCol2Im_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleCol2Im_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleELU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleELU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleFeatureLPPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleFeatureLPPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleGatedLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleGatedLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleHardTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleHardTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleIm2Col_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleIm2Col_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleIndexLinear_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleIndexLinear_accUpdateGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleIndexLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleIndexLinear_updateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleLeakyReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleLeakyReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleLogSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleLogSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleMSECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleMSECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleMultiLabelMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleMultiLabelMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleMultiMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleMultiMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleRReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleRReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSmoothL1Criterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSmoothL1Criterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSoftMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSoftMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSoftPlus_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSoftPlus_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSoftShrink_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSoftShrink_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_legacyAccGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_legacyUpdateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_legacyUpdateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_legacyZeroGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_updateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSparseLinear_zeroGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialAdaptiveAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialAdaptiveAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialAdaptiveMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialAdaptiveMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialConvolutionMM_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialConvolutionMM_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialConvolutionMM_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialFractionalMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialFractionalMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialReflectionPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialReflectionPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialReplicationPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialReplicationPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialUpSamplingBilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialUpSamplingBilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleSpatialUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalReflectionPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalReflectionPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalReplicationPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalReplicationPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalRowConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalRowConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalRowConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalUpSamplingLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalUpSamplingLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleTemporalUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def Doubleunfolded_acc(self, *args, **kwargs): # real signature unknown
        pass

    def Doubleunfolded_copy(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricAdaptiveAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricAdaptiveAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricAdaptiveMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricAdaptiveMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricConvolutionMM_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricConvolutionMM_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricConvolutionMM_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricReplicationPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricReplicationPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricUpSamplingTrilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def DoubleVolumetricUpSamplingTrilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatAbsCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatAbsCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatBCECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatBCECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatCol2Im_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatCol2Im_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatELU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatELU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatFeatureLPPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatFeatureLPPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatGatedLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatGatedLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatHardTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatHardTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatIm2Col_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatIm2Col_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatIndexLinear_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatIndexLinear_accUpdateGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatIndexLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatIndexLinear_updateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatLeakyReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatLeakyReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatLogSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatLogSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatMSECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatMSECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatMultiLabelMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatMultiLabelMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatMultiMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatMultiMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatRReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatRReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSmoothL1Criterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSmoothL1Criterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSoftMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSoftMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSoftPlus_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSoftPlus_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSoftShrink_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSoftShrink_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_legacyAccGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_legacyUpdateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_legacyUpdateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_legacyZeroGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_updateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSparseLinear_zeroGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialAdaptiveAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialAdaptiveAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialAdaptiveMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialAdaptiveMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialConvolutionMM_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialConvolutionMM_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialConvolutionMM_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialFractionalMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialFractionalMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialReflectionPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialReflectionPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialReplicationPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialReplicationPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialUpSamplingBilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialUpSamplingBilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatSpatialUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalReflectionPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalReflectionPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalReplicationPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalReplicationPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalRowConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalRowConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalRowConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalUpSamplingLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalUpSamplingLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatTemporalUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def Floatunfolded_acc(self, *args, **kwargs): # real signature unknown
        pass

    def Floatunfolded_copy(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricAdaptiveAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricAdaptiveAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricAdaptiveMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricAdaptiveMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricConvolutionMM_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricConvolutionMM_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricConvolutionMM_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricReplicationPadding_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricReplicationPadding_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricUpSamplingTrilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def FloatVolumetricUpSamplingTrilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass



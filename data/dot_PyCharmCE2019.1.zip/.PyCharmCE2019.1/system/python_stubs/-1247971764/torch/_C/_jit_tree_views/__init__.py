# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/spacy/_align.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def FalseLiteral(arg0): # real signature unknown; restored from __doc__
    """ FalseLiteral(arg0: torch._C._jit_tree_views.SourceRange) -> torch::jit::script::Expr """
    pass

def NoneLiteral(arg0): # real signature unknown; restored from __doc__
    """ NoneLiteral(arg0: torch._C._jit_tree_views.SourceRange) -> torch::jit::script::Expr """
    pass

def TrueLiteral(arg0): # real signature unknown; restored from __doc__
    """ TrueLiteral(arg0: torch._C._jit_tree_views.SourceRange) -> torch::jit::script::Expr """
    pass

# classes

from .TreeView import TreeView
from .Expr import Expr
from .Apply import Apply
from .Stmt import Stmt
from .Assert import Assert
from .Assign import Assign
from .Attribute import Attribute
from .AugAssign import AugAssign
from .BinOp import BinOp
from .Const import Const
from .Decl import Decl
from .Def import Def
from .ExprStmt import ExprStmt
from .For import For
from .Ident import Ident
from .If import If
from .ListLiteral import ListLiteral
from .Param import Param
from .Pass import Pass
from .Raise import Raise
from .Return import Return
from .Select import Select
from .SliceExpr import SliceExpr
from .SourceRange import SourceRange
from .SourceRangeFactory import SourceRangeFactory
from .Starred import Starred
from .StringLiteral import StringLiteral
from .Subscript import Subscript
from .TernaryIf import TernaryIf
from .TupleLiteral import TupleLiteral
from .UnaryOp import UnaryOp
from .Var import Var
from .While import While

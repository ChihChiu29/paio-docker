# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


from .Stmt import Stmt

class If(Stmt):
    # no doc
    def __init__(self, arg0, arg1, arg2, torch__C__jit_tree_views_Stmt=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ __init__(self: torch._C._jit_tree_views.If, arg0: torch._C._jit_tree_views.SourceRange, arg1: torch._C._jit_tree_views.Expr, arg2: List[torch._C._jit_tree_views.Stmt], arg3: List[torch._C._jit_tree_views.Stmt]) -> None """
        pass



# encoding: utf-8
# module torch._C._onnx
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


# Variables with simple values

PYTORCH_ONNX_CAFFE2_BUNDLE = False

__loader__ = None

__spec__ = None

# no functions
# classes

class OperatorExportTypes(__pybind11_builtins.pybind11_object):
    """
    Members:
    
      ONNX_ATEN_FALLBACK
    
      RAW
    
      ONNX_ATEN
    
      ONNX
    """
    def __eq__(self, arg0): # real signature unknown; restored from __doc__
        """ __eq__(self: torch._C._onnx.OperatorExportTypes, arg0: torch._C._onnx.OperatorExportTypes) -> bool """
        return False

    def __getstate__(self): # real signature unknown; restored from __doc__
        """ __getstate__(self: torch._C._onnx.OperatorExportTypes) -> tuple """
        return ()

    def __hash__(self): # real signature unknown; restored from __doc__
        """ __hash__(self: torch._C._onnx.OperatorExportTypes) -> int """
        return 0

    def __init__(self, arg0): # real signature unknown; restored from __doc__
        """ __init__(self: torch._C._onnx.OperatorExportTypes, arg0: int) -> None """
        pass

    def __int__(self): # real signature unknown; restored from __doc__
        """ __int__(self: torch._C._onnx.OperatorExportTypes) -> int """
        return 0

    def __ne__(self, arg0): # real signature unknown; restored from __doc__
        """ __ne__(self: torch._C._onnx.OperatorExportTypes, arg0: torch._C._onnx.OperatorExportTypes) -> bool """
        return False

    def __repr__(self): # real signature unknown; restored from __doc__
        """ __repr__(self: torch._C._onnx.OperatorExportTypes) -> str """
        return ""

    def __setstate__(self, arg0): # real signature unknown; restored from __doc__
        """ __setstate__(self: torch._C._onnx.OperatorExportTypes, arg0: tuple) -> None """
        pass

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    ONNX = OperatorExportTypes.ONNX
    ONNX_ATEN = OperatorExportTypes.ONNX_ATEN
    ONNX_ATEN_FALLBACK = OperatorExportTypes.ONNX_ATEN_FALLBACK
    RAW = OperatorExportTypes.RAW
    __members__ = {
        'ONNX': '<failed to retrieve the value>',
        'ONNX_ATEN': '<failed to retrieve the value>',
        'ONNX_ATEN_FALLBACK': '<failed to retrieve the value>',
        'RAW': '<failed to retrieve the value>',
    }


class TensorProtoDataType(__pybind11_builtins.pybind11_object):
    """
    Members:
    
      UINT64
    
      INT8
    
      STRING
    
      UINT16
    
      FLOAT
    
      INT16
    
      UINT32
    
      COMPLEX128
    
      DOUBLE
    
      INT32
    
      INT64
    
      FLOAT16
    
      UNDEFINED
    
      BOOL
    
      UINT8
    
      COMPLEX64
    """
    def __eq__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __eq__(*args, **kwargs)
        Overloaded function.
        
        1. __eq__(self: torch._C._onnx.TensorProtoDataType, arg0: torch._C._onnx.TensorProtoDataType) -> bool
        
        2. __eq__(self: torch._C._onnx.TensorProtoDataType, arg0: int) -> bool
        """
        pass

    def __getstate__(self): # real signature unknown; restored from __doc__
        """ __getstate__(self: torch._C._onnx.TensorProtoDataType) -> tuple """
        return ()

    def __hash__(self): # real signature unknown; restored from __doc__
        """ __hash__(self: torch._C._onnx.TensorProtoDataType) -> int """
        return 0

    def __init__(self, arg0): # real signature unknown; restored from __doc__
        """ __init__(self: torch._C._onnx.TensorProtoDataType, arg0: int) -> None """
        pass

    def __int__(self): # real signature unknown; restored from __doc__
        """ __int__(self: torch._C._onnx.TensorProtoDataType) -> int """
        return 0

    def __ne__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __ne__(*args, **kwargs)
        Overloaded function.
        
        1. __ne__(self: torch._C._onnx.TensorProtoDataType, arg0: torch._C._onnx.TensorProtoDataType) -> bool
        
        2. __ne__(self: torch._C._onnx.TensorProtoDataType, arg0: int) -> bool
        """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ __repr__(self: torch._C._onnx.TensorProtoDataType) -> str """
        return ""

    def __setstate__(self, arg0): # real signature unknown; restored from __doc__
        """ __setstate__(self: torch._C._onnx.TensorProtoDataType, arg0: tuple) -> None """
        pass

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    BOOL = TensorProtoDataType.BOOL
    COMPLEX128 = TensorProtoDataType.COMPLEX128
    COMPLEX64 = TensorProtoDataType.COMPLEX64
    DOUBLE = TensorProtoDataType.DOUBLE
    FLOAT = TensorProtoDataType.FLOAT
    FLOAT16 = TensorProtoDataType.FLOAT16
    INT16 = TensorProtoDataType.INT16
    INT32 = TensorProtoDataType.INT32
    INT64 = TensorProtoDataType.INT64
    INT8 = TensorProtoDataType.INT8
    STRING = TensorProtoDataType.STRING
    UINT16 = TensorProtoDataType.UINT16
    UINT32 = TensorProtoDataType.UINT32
    UINT64 = TensorProtoDataType.UINT64
    UINT8 = TensorProtoDataType.UINT8
    UNDEFINED = TensorProtoDataType.UNDEFINED
    __members__ = {
        'BOOL': '<failed to retrieve the value>',
        'COMPLEX128': '<failed to retrieve the value>',
        'COMPLEX64': '<failed to retrieve the value>',
        'DOUBLE': '<failed to retrieve the value>',
        'FLOAT': '<failed to retrieve the value>',
        'FLOAT16': '<failed to retrieve the value>',
        'INT16': '<failed to retrieve the value>',
        'INT32': '<failed to retrieve the value>',
        'INT64': '<failed to retrieve the value>',
        'INT8': '<failed to retrieve the value>',
        'STRING': '<failed to retrieve the value>',
        'UINT16': '<failed to retrieve the value>',
        'UINT32': '<failed to retrieve the value>',
        'UINT64': '<failed to retrieve the value>',
        'UINT8': '<failed to retrieve the value>',
        'UNDEFINED': '<failed to retrieve the value>',
    }



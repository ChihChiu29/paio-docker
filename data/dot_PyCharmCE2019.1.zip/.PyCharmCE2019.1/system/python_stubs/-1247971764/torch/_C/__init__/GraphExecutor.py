# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.5/dist-packages/torch/_C.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import torch._C._jit as _jit # <module 'torch._C._jit'>
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import pybind11_builtins as __pybind11_builtins


class GraphExecutor(__pybind11_builtins.pybind11_object):
    # no doc
    def get_debug_state(self): # real signature unknown; restored from __doc__
        """ get_debug_state(self: torch._C.GraphExecutor) -> torch._C.GraphExecutorState """
        pass

    def graph_for(self, *args): # real signature unknown; restored from __doc__
        """ graph_for(self: torch._C.GraphExecutor, *args) -> torch::jit::Graph """
        pass

    def __call__(self, *args): # real signature unknown; restored from __doc__
        """ __call__(self: torch._C.GraphExecutor, *args) -> object """
        return object()

    def __init__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: torch._C.GraphExecutor, func: function, inputs: tuple, var_name_lookup_fn: function, optimize: bool = True, _force_outplace: bool = False) -> None
        
        2. __init__(self: torch._C.GraphExecutor, graph: torch::jit::Graph, optimize: bool = True) -> None
        """
        pass

    graph = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __dict__ = None # (!) real value is "mappingproxy({'get_debug_state': <instancemethod get_debug_state at 0x7f7fdd716828>, '__call__': <instancemethod __call__ at 0x7f7fdd716888>, '__doc__': None, '__dict__': <attribute '__dict__' of 'torch._C.GraphExecutor' objects>, '__module__': 'torch._C', 'graph_for': <instancemethod graph_for at 0x7f7fdd716798>, 'graph': <property object at 0x7f7fdd714e08>, '__init__': <instancemethod __init__ at 0x7f7fdd716768>})"



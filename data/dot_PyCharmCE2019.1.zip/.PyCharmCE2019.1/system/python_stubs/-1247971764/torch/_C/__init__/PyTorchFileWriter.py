# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.5/dist-packages/torch/_C.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import torch._C._jit as _jit # <module 'torch._C._jit'>
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import pybind11_builtins as __pybind11_builtins


class PyTorchFileWriter(__pybind11_builtins.pybind11_object):
    # no doc
    def write_end_of_file(self): # real signature unknown; restored from __doc__
        """ write_end_of_file(self: torch._C.PyTorchFileWriter) -> None """
        pass

    def write_record(self, arg0, arg1, arg2): # real signature unknown; restored from __doc__
        """ write_record(self: torch._C.PyTorchFileWriter, arg0: str, arg1: str, arg2: int) -> None """
        pass

    def __init__(self, arg0): # real signature unknown; restored from __doc__
        """ __init__(self: torch._C.PyTorchFileWriter, arg0: str) -> None """
        pass



# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


from .Expr import Expr

class Apply(Expr):
    # no doc
    def __init__(self, arg0, arg1, torch__C__jit_tree_views_Expr=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ __init__(self: torch._C._jit_tree_views.Apply, arg0: torch._C._jit_tree_views.Expr, arg1: List[torch._C._jit_tree_views.Expr], arg2: List[torch._C._jit_tree_views.Attribute]) -> None """
        pass



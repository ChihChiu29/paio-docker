# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/spacy/_align.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


class TreeView(__pybind11_builtins.pybind11_object):
    # no doc
    def range(self): # real signature unknown; restored from __doc__
        """ range(self: torch._C._jit_tree_views.TreeView) -> torch._C._jit_tree_views.SourceRange """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self): # real signature unknown; restored from __doc__
        """ __str__(self: torch._C._jit_tree_views.TreeView) -> str """
        return ""



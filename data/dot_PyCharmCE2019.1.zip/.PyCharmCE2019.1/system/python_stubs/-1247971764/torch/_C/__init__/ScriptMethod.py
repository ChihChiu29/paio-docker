# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.5/dist-packages/torch/_C.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import torch._C._jit as _jit # <module 'torch._C._jit'>
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import pybind11_builtins as __pybind11_builtins


class ScriptMethod(__pybind11_builtins.pybind11_object):
    # no doc
    def debug_disable_autodiff_subgraph_inlining(self): # real signature unknown; restored from __doc__
        """ debug_disable_autodiff_subgraph_inlining(self: torch._C.ScriptMethod) -> None """
        pass

    def graph_for(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """ graph_for(*args, **kwargs) -> torch._C.Graph """
        pass

    def params(self): # real signature unknown; restored from __doc__
        """ params(self: torch._C.ScriptMethod) -> List[at::Tensor] """
        return []

    def pretty_print_schema(self): # real signature unknown; restored from __doc__
        """ pretty_print_schema(self: torch._C.ScriptMethod) -> str """
        return ""

    def propagate_and_assign_input_and_output_shapes(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ propagate_and_assign_input_and_output_shapes(self: torch._C.ScriptMethod, arg0: List[at::Tensor], arg1: List[at::Tensor], arg2: bool, arg3: bool) -> torch._C.Graph """
        pass

    def propagate_shapes(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ propagate_shapes(self: torch._C.ScriptMethod, arg0: List[at::Tensor], arg1: bool) -> torch._C.Graph """
        pass

    def python_print(self): # real signature unknown; restored from __doc__
        """ python_print(self: torch._C.ScriptMethod) -> Tuple[str, List[at::Tensor]] """
        pass

    def schema(self): # real signature unknown; restored from __doc__
        """ schema(self: torch._C.ScriptMethod) -> torch._C.FunctionSchema """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """ __call__(*args, **kwargs) -> object """
        return object()

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    graph = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __dict__ = None # (!) real value is "mappingproxy({'pretty_print_schema': <instancemethod pretty_print_schema at 0x7f7fdd728858>, '__call__': <instancemethod __call__ at 0x7f7fdd7285e8>, 'schema': <instancemethod schema at 0x7f7fdd7287f8>, 'graph': <property object at 0x7f7fdd727228>, 'python_print': <instancemethod python_print at 0x7f7fdd7288b8>, '__init__': <slot wrapper '__init__' of 'torch._C.ScriptMethod' objects>, 'propagate_shapes': <instancemethod propagate_shapes at 0x7f7fdd728558>, '__doc__': None, '__dict__': <attribute '__dict__' of 'torch._C.ScriptMethod' objects>, '__module__': 'torch._C', 'graph_for': <instancemethod graph_for at 0x7f7fdd728738>, 'propagate_and_assign_input_and_output_shapes': <instancemethod propagate_and_assign_input_and_output_shapes at 0x7f7fdd728678>, 'params': <instancemethod params at 0x7f7fdd7286d8>, 'debug_disable_autodiff_subgraph_inlining': <instancemethod debug_disable_autodiff_subgraph_inlining at 0x7f7fdd728798>})"



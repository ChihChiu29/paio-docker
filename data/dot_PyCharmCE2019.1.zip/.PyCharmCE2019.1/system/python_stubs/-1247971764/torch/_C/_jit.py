# encoding: utf-8
# module torch._C._jit
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# classes

class BatchTensor(__pybind11_builtins.pybind11_object):
    # no doc
    def examples(self): # real signature unknown; restored from __doc__
        """ examples(self: torch._C._jit.BatchTensor) -> List[at::Tensor] """
        return []

    def get_data(self): # real signature unknown; restored from __doc__
        """ get_data(self: torch._C._jit.BatchTensor) -> at::Tensor """
        pass

    def get_dims(self): # real signature unknown; restored from __doc__
        """ get_dims(self: torch._C._jit.BatchTensor) -> at::Tensor """
        pass

    def get_mask(self): # real signature unknown; restored from __doc__
        """ get_mask(self: torch._C._jit.BatchTensor) -> at::Tensor """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: torch._C._jit.BatchTensor, arg0: at::Tensor, arg1: at::Tensor, arg2: at::Tensor) -> None
        
        2. __init__(self: torch._C._jit.BatchTensor, arg0: at::Tensor, arg1: int) -> None
        
        3. __init__(self: torch._C._jit.BatchTensor, arg0: List[at::Tensor], arg1: at::Tensor) -> None
        """
        pass



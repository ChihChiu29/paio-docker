# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/spacy/_align.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


class SourceRangeFactory(__pybind11_builtins.pybind11_object):
    # no doc
    def make_range(self, arg0, arg1, arg2): # real signature unknown; restored from __doc__
        """ make_range(self: torch._C._jit_tree_views.SourceRangeFactory, arg0: int, arg1: int, arg2: int) -> torch._C._jit_tree_views.SourceRange """
        pass

    def make_raw_range(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ make_raw_range(self: torch._C._jit_tree_views.SourceRangeFactory, arg0: int, arg1: int) -> torch._C._jit_tree_views.SourceRange """
        pass

    def __init__(self, arg0): # real signature unknown; restored from __doc__
        """ __init__(self: torch._C._jit_tree_views.SourceRangeFactory, arg0: str) -> None """
        pass

    source = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




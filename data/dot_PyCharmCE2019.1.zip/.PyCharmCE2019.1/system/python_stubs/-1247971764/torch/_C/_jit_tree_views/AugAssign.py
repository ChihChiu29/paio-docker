# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/spacy/_align.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


from .Stmt import Stmt

class AugAssign(Stmt):
    # no doc
    def __init__(self, arg0, arg1, arg2): # real signature unknown; restored from __doc__
        """ __init__(self: torch._C._jit_tree_views.AugAssign, arg0: torch._C._jit_tree_views.Expr, arg1: str, arg2: torch._C._jit_tree_views.Expr) -> None """
        pass



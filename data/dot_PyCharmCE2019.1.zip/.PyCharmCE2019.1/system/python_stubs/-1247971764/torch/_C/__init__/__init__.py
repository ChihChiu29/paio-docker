# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.5/dist-packages/torch/_C.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import torch._C._jit as _jit # <module 'torch._C._jit'>
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import pybind11_builtins as __pybind11_builtins


# Variables with simple values

has_cudnn = True
has_lapack = True
has_mkl = True

_GLIBCXX_USE_CXX11_ABI = False

# functions

def fork(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ fork(arg0: torch::jit::script::Module, *args) -> torch._C.Future """
    pass

def get_default_dtype(): # real signature unknown; restored from __doc__
    """
    get_default_dtype() -> torch.dtype
    
    Get the current default floating point :class:`torch.dtype`.
    
    Example::
    
        >>> torch.get_default_dtype()  # initial default for floating point is torch.float32
        torch.float32
        >>> torch.set_default_dtype(torch.float64)
        >>> torch.get_default_dtype()  # default is now changed to torch.float64
        torch.float64
        >>> torch.set_default_tensor_type(torch.FloatTensor)  # setting tensor type also affects this
        >>> torch.get_default_dtype()  # changed to torch.float32, the dtype for torch.FloatTensor
        torch.float32
    """
    pass

def get_num_threads(): # real signature unknown; restored from __doc__
    """
    get_num_threads() -> int
    
    Gets the number of OpenMP threads used for parallelizing CPU operations
    """
    return 0

def import_ir_module(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ import_ir_module(arg0: Callable[[List[str]], torch._C.ScriptModule], arg1: str, arg2: object) -> None """
    pass

def import_ir_module_from_buffer(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ import_ir_module_from_buffer(arg0: Callable[[List[str]], torch._C.ScriptModule], arg1: str, arg2: object) -> None """
    pass

def is_anomaly_enabled(*args, **kwargs): # real signature unknown
    pass

def is_grad_enabled(*args, **kwargs): # real signature unknown
    pass

def merge_type_from_type_comment(arg0, arg1, arg2): # real signature unknown; restored from __doc__
    """ merge_type_from_type_comment(arg0: torch._C._jit_tree_views.Decl, arg1: torch._C._jit_tree_views.Decl, arg2: bool) -> torch._C._jit_tree_views.Decl """
    pass

def parse_type_comment(arg0): # real signature unknown; restored from __doc__
    """ parse_type_comment(arg0: str) -> torch._C._jit_tree_views.Decl """
    pass

def register_batch_operator(arg0, arg1): # real signature unknown; restored from __doc__
    """ register_batch_operator(arg0: str, arg1: torch._C.Graph) -> None """
    pass

def set_anomaly_enabled(*args, **kwargs): # real signature unknown
    pass

def set_flush_denormal(mode): # real signature unknown; restored from __doc__
    """
    set_flush_denormal(mode) -> bool
    
    Disables denormal floating numbers on CPU.
    
    Returns ``True`` if your system supports flushing denormal numbers and it
    successfully configures flush denormal mode.  :meth:`~torch.set_flush_denormal`
    is only supported on x86 architectures supporting SSE3.
    
    Args:
        mode (bool): Controls whether to enable flush denormal mode or not
    
    Example::
    
        >>> torch.set_flush_denormal(True)
        True
        >>> torch.tensor([1e-323], dtype=torch.float64)
        tensor([ 0.], dtype=torch.float64)
        >>> torch.set_flush_denormal(False)
        True
        >>> torch.tensor([1e-323], dtype=torch.float64)
        tensor(9.88131e-324 *
               [ 1.0000], dtype=torch.float64)
    """
    return False

def set_grad_enabled(*args, **kwargs): # real signature unknown
    pass

def set_num_threads(p_int): # real signature unknown; restored from __doc__
    """
    set_num_threads(int)
    
    Sets the number of OpenMP threads used for parallelizing CPU operations
    """
    pass

def to_batch_graph(arg0): # real signature unknown; restored from __doc__
    """ to_batch_graph(arg0: torch._C.Graph) -> torch._C.Graph """
    pass

def wait(arg0): # real signature unknown; restored from __doc__
    """ wait(arg0: torch._C.Future) -> None """
    pass

def _add_docstr(*args, **kwargs): # real signature unknown
    pass

def _autograd_init(*args, **kwargs): # real signature unknown
    pass

def _broadcast(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _broadcast(arg0: at::Tensor, arg1: List[int]) -> List[at::Tensor] """
    pass

def _broadcast_coalesced(tensors, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _broadcast_coalesced(tensors: List[at::Tensor], devices: List[int], buffer_size: int) -> List[List[at::Tensor]] """
    pass

def _c10d_init(*args, **kwargs): # real signature unknown
    pass

def _crash_if_aten_asan(*args, **kwargs): # real signature unknown
    pass

def _crash_if_csrc_asan(*args, **kwargs): # real signature unknown
    pass

def _crash_if_csrc_ubsan(*args, **kwargs): # real signature unknown
    pass

def _cuda_cudaHostAllocator(*args, **kwargs): # real signature unknown
    pass

def _cuda_emptyCache(*args, **kwargs): # real signature unknown
    pass

def _cuda_getCompiledVersion(*args, **kwargs): # real signature unknown
    pass

def _cuda_getCurrentBlasHandle(*args, **kwargs): # real signature unknown
    pass

def _cuda_getCurrentStream(*args, **kwargs): # real signature unknown
    pass

def _cuda_getDevice(*args, **kwargs): # real signature unknown
    pass

def _cuda_getDeviceCount(*args, **kwargs): # real signature unknown
    pass

def _cuda_getDriverVersion(*args, **kwargs): # real signature unknown
    pass

def _cuda_getRNGState(*args, **kwargs): # real signature unknown
    pass

def _cuda_init(*args, **kwargs): # real signature unknown
    pass

def _cuda_initialSeed(*args, **kwargs): # real signature unknown
    pass

def _cuda_isDriverSufficient(*args, **kwargs): # real signature unknown
    pass

def _cuda_lock_mutex(*args, **kwargs): # real signature unknown
    pass

def _cuda_manualSeed(*args, **kwargs): # real signature unknown
    pass

def _cuda_manualSeedAll(*args, **kwargs): # real signature unknown
    pass

def _cuda_maxMemoryAllocated(*args, **kwargs): # real signature unknown
    pass

def _cuda_maxMemoryCached(*args, **kwargs): # real signature unknown
    pass

def _cuda_memoryAllocated(*args, **kwargs): # real signature unknown
    pass

def _cuda_memoryCached(*args, **kwargs): # real signature unknown
    pass

def _cuda_seed(*args, **kwargs): # real signature unknown
    pass

def _cuda_seedAll(*args, **kwargs): # real signature unknown
    pass

def _cuda_setDevice(*args, **kwargs): # real signature unknown
    pass

def _cuda_setRNGState(*args, **kwargs): # real signature unknown
    pass

def _cuda_setStream(*args, **kwargs): # real signature unknown
    pass

def _cuda_sleep(*args, **kwargs): # real signature unknown
    pass

def _cuda_synchronize(*args, **kwargs): # real signature unknown
    pass

def _cuda_unlock_mutex(*args, **kwargs): # real signature unknown
    pass

def _cudnn_version(*args, **kwargs): # real signature unknown
    pass

def _demangle(arg0): # real signature unknown; restored from __doc__
    """ _demangle(arg0: str) -> str """
    return ""

def _dist_all_gather(*args, **kwargs): # real signature unknown
    pass

def _dist_all_gather_multigpu(*args, **kwargs): # real signature unknown
    pass

def _dist_all_reduce(*args, **kwargs): # real signature unknown
    pass

def _dist_all_reduce_multigpu(*args, **kwargs): # real signature unknown
    pass

def _dist_barrier(*args, **kwargs): # real signature unknown
    pass

def _dist_broadcast(*args, **kwargs): # real signature unknown
    pass

def _dist_broadcast_multigpu(*args, **kwargs): # real signature unknown
    pass

def _dist_clear_group_cache(*args, **kwargs): # real signature unknown
    pass

def _dist_destroy_process_group(*args, **kwargs): # real signature unknown
    pass

def _dist_gather_recv(*args, **kwargs): # real signature unknown
    pass

def _dist_gather_send(*args, **kwargs): # real signature unknown
    pass

def _dist_get_num_processes(*args, **kwargs): # real signature unknown
    pass

def _dist_get_rank(*args, **kwargs): # real signature unknown
    pass

def _dist_init_extension(*args, **kwargs): # real signature unknown
    pass

def _dist_init_process_group(*args, **kwargs): # real signature unknown
    pass

def _dist_irecv(*args, **kwargs): # real signature unknown
    pass

def _dist_isend(*args, **kwargs): # real signature unknown
    pass

def _dist_new_group(*args, **kwargs): # real signature unknown
    pass

def _dist_recv(*args, **kwargs): # real signature unknown
    pass

def _dist_recv_any_source(*args, **kwargs): # real signature unknown
    pass

def _dist_reduce(*args, **kwargs): # real signature unknown
    pass

def _dist_reduce_multigpu(*args, **kwargs): # real signature unknown
    pass

def _dist_register_stream(*args, **kwargs): # real signature unknown
    pass

def _dist_request_is_completed(*args, **kwargs): # real signature unknown
    pass

def _dist_request_wait(*args, **kwargs): # real signature unknown
    pass

def _dist_scatter_recv(*args, **kwargs): # real signature unknown
    pass

def _dist_scatter_send(*args, **kwargs): # real signature unknown
    pass

def _dist_send(*args, **kwargs): # real signature unknown
    pass

def _error_if_any_worker_fails(*args, **kwargs): # real signature unknown
    pass

def _from_dlpack(*args, **kwargs): # real signature unknown
    pass

def _gather(tensors, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _gather(tensors: List[at::Tensor], dim: int, destination_index: Optional[int]) -> at::Tensor """
    pass

def _get_backcompat_broadcast_warn(*args, **kwargs): # real signature unknown
    pass

def _get_backcompat_keepdim_warn(*args, **kwargs): # real signature unknown
    pass

def _get_cudnn_benchmark(*args, **kwargs): # real signature unknown
    pass

def _get_cudnn_deterministic(*args, **kwargs): # real signature unknown
    pass

def _get_cudnn_enabled(*args, **kwargs): # real signature unknown
    pass

def _get_tracing_state(): # real signature unknown; restored from __doc__
    """ _get_tracing_state() -> torch._C.TracingState """
    pass

def _get_value_trace(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _get_value_trace(arg0: torch::autograd::Variable) -> torch._C.Value """
    pass

def _has_distributed(*args, **kwargs): # real signature unknown
    pass

def _infer_size(*args, **kwargs): # real signature unknown
    pass

def _initExtension(*args, **kwargs): # real signature unknown
    pass

def _init_names(*args, **kwargs): # real signature unknown
    pass

def _is_default_type_cuda(*args, **kwargs): # real signature unknown
    pass

def _jit_assert_is_instance(arg0, arg1, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_assert_is_instance(arg0: object, arg1: c10::Type) -> None """
    pass

def _jit_check_alias_annotation(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_check_alias_annotation(arg0: torch::jit::Graph, arg1: tuple, arg2: str) -> None """
    pass

def _jit_differentiate(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_differentiate(arg0: torch::jit::Graph) -> torch::jit::Gradient """
    pass

def _jit_flatten(arg0): # real signature unknown; restored from __doc__
    """ _jit_flatten(arg0: handle) -> Tuple[List[torch::autograd::Variable], torch._C.IODescriptor] """
    pass

def _jit_get_operation(qualified_name): # real signature unknown; restored from __doc__
    """ _jit_get_operation(qualified_name: str) -> cpp_function """
    pass

def _jit_get_schemas_for_operator(arg0): # real signature unknown; restored from __doc__
    """ _jit_get_schemas_for_operator(arg0: str) -> List[torch._C.FunctionSchema] """
    return []

def _jit_import_methods(arg0, arg1, arg2, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_import_methods(arg0: torch._C.ScriptModule, arg1: str, arg2: List[at::Tensor]) -> None """
    pass

def _jit_init(): # real signature unknown; restored from __doc__
    """ _jit_init() -> bool """
    return False

def _jit_override_can_fuse_on_cpu(arg0): # real signature unknown; restored from __doc__
    """ _jit_override_can_fuse_on_cpu(arg0: bool) -> None """
    pass

def _jit_pass_canonicalize(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_canonicalize(arg0: torch::jit::Graph) -> torch::jit::Graph """
    pass

def _jit_pass_canonicalize_ops(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_canonicalize_ops(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_complete_shape_analysis(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_complete_shape_analysis(arg0: torch::jit::Graph, arg1: tuple, arg2: bool) -> None """
    pass

def _jit_pass_constant_pooling(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_constant_pooling(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_constant_propagation(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_constant_propagation(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_create_autodiff_subgraphs(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_create_autodiff_subgraphs(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_cse(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_cse(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_dce(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_dce(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_erase_number_types(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_erase_number_types(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_erase_shape_information(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_erase_shape_information(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_fixup_onnx_loops(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_fixup_onnx_loops(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_fuse(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_fuse(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_lint(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_lint(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_loop_unrolling(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_loop_unrolling(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_lower_all_tuples(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_lower_all_tuples(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_onnx(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_onnx(arg0: torch::jit::Graph, arg1: torch._C._onnx.OperatorExportTypes) -> torch::jit::Graph """
    pass

def _jit_pass_onnx_block(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_onnx_block(arg0: torch::jit::Block, arg1: torch::jit::Block, arg2: torch._C._onnx.OperatorExportTypes, arg3: Dict[torch::jit::Value, torch::jit::Value]) -> None """
    pass

def _jit_pass_onnx_peephole(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_onnx_peephole(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_peephole(graph, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_peephole(graph: torch::jit::Graph, addmm_fusion_enabled: bool = False) -> None """
    pass

def _jit_pass_prepare_division_for_onnx(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_prepare_division_for_onnx(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_remove_expands(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_remove_expands(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_remove_inplace_ops(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_remove_inplace_ops(arg0: torch::jit::Graph) -> None """
    pass

def _jit_pass_shape_analysis(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_shape_analysis(arg0: torch::jit::Graph, arg1: List[at::Tensor], arg2: bool) -> None """
    pass

def _jit_pass_specialize_undef(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_pass_specialize_undef(arg0: torch::jit::Graph) -> None """
    pass

def _jit_run_cpp_tests(): # real signature unknown; restored from __doc__
    """ _jit_run_cpp_tests() -> str """
    return ""

def _jit_script_compile(arg0, arg1, arg2, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_script_compile(arg0: torch._C.ScriptModule, arg1: torch._C._jit_tree_views.Def, arg2: Callable[[str], function], arg3: Dict[str, object]) -> torch._C.ScriptModule """
    pass

def _jit_set_emit_module_hook(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_set_emit_module_hook(arg0: Callable[[torch._C.ScriptModule], None]) -> None """
    pass

def _jit_unflatten(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _jit_unflatten(arg0: List[torch::autograd::Variable], arg1: torch._C.IODescriptor) -> object """
    pass

def _multiprocessing_init(*args, **kwargs): # real signature unknown
    pass

def _nccl_all_gather(*args, **kwargs): # real signature unknown
    pass

def _nccl_all_reduce(*args, **kwargs): # real signature unknown
    pass

def _nccl_broadcast(*args, **kwargs): # real signature unknown
    pass

def _nccl_init_rank(*args, **kwargs): # real signature unknown
    pass

def _nccl_reduce(*args, **kwargs): # real signature unknown
    pass

def _nccl_reduce_scatter(*args, **kwargs): # real signature unknown
    pass

def _nccl_unique_id(*args, **kwargs): # real signature unknown
    pass

def _nccl_version(*args, **kwargs): # real signature unknown
    pass

def _remove_worker_pids(*args, **kwargs): # real signature unknown
    pass

def _safe_call(*args, **kwargs): # real signature unknown
    pass

def _scatter(tensor, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _scatter(tensor: at::Tensor, devices: List[int], chunk_sizes: Optional[List[int]], dim: int, streams: Optional[object]) -> List[at::Tensor] """
    pass

def _set_backcompat_broadcast_warn(*args, **kwargs): # real signature unknown
    pass

def _set_backcompat_keepdim_warn(*args, **kwargs): # real signature unknown
    pass

def _set_cudnn_benchmark(*args, **kwargs): # real signature unknown
    pass

def _set_cudnn_deterministic(*args, **kwargs): # real signature unknown
    pass

def _set_cudnn_enabled(*args, **kwargs): # real signature unknown
    pass

def _set_default_dtype(*args, **kwargs): # real signature unknown
    pass

def _set_default_tensor_type(*args, **kwargs): # real signature unknown
    pass

def _set_tracing_state(arg0): # real signature unknown; restored from __doc__
    """ _set_tracing_state(arg0: torch._C.TracingState) -> None """
    pass

def _set_value_trace(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ _set_value_trace(arg0: torch::autograd::Variable, arg1: torch._C.Value) -> None """
    pass

def _set_worker_signal_handlers(*args, **kwargs): # real signature unknown
    pass

def _to_dlpack(*args, **kwargs): # real signature unknown
    pass

def _tracer_abandon(): # real signature unknown; restored from __doc__
    """ _tracer_abandon() -> None """
    pass

def _tracer_enter(*args): # real signature unknown; restored from __doc__
    """ _tracer_enter(*args) -> Tuple[torch._C.TracingState, List[IValue]] """
    pass

def _tracer_exit(arg0): # real signature unknown; restored from __doc__
    """ _tracer_exit(arg0: tuple) -> None """
    pass

def _tracer_set_force_outplace(arg0): # real signature unknown; restored from __doc__
    """ _tracer_set_force_outplace(arg0: bool) -> None """
    pass

def _tracer_set_get_unique_name_fn(arg0): # real signature unknown; restored from __doc__
    """ _tracer_set_get_unique_name_fn(arg0: function) -> None """
    pass

def _tracer_warn_use_python(): # real signature unknown; restored from __doc__
    """ _tracer_warn_use_python() -> None """
    pass

def _update_worker_pids(*args, **kwargs): # real signature unknown
    pass

# classes

from .Argument import Argument
from .ArgumentSpec import ArgumentSpec
from .Block import Block
from .Type import Type
from .BoolType import BoolType
from .ByteStorageBase import ByteStorageBase
from .CharStorageBase import CharStorageBase
from .Code import Code
from .CompleteArgumentSpec import CompleteArgumentSpec
from .CudaByteStorageBase import CudaByteStorageBase
from .CudaCharStorageBase import CudaCharStorageBase
from .CudaDoubleStorageBase import CudaDoubleStorageBase
from .CudaFloatStorageBase import CudaFloatStorageBase
from .CudaHalfStorageBase import CudaHalfStorageBase
from .CudaIntStorageBase import CudaIntStorageBase
from .CudaLongStorageBase import CudaLongStorageBase
from .CudaShortStorageBase import CudaShortStorageBase
from .device import device
from .DoubleStorageBase import DoubleStorageBase
from .dtype import dtype
from .DynamicType import DynamicType
from .ExecutionPlanState import ExecutionPlanState
from .FatalError import FatalError
from .finfo import finfo
from .FloatStorageBase import FloatStorageBase
from .FloatType import FloatType
from .FunctionSchema import FunctionSchema
from .Future import Future
from .Generator import Generator
from .Gradient import Gradient
from .Graph import Graph
from .GraphExecutor import GraphExecutor
from .GraphExecutorState import GraphExecutorState
from .HalfStorageBase import HalfStorageBase
from .iinfo import iinfo
from .IntStorageBase import IntStorageBase
from .IntType import IntType
from .IODescriptor import IODescriptor
from .JITException import JITException
from .layout import layout
from .ListType import ListType
from .LongStorageBase import LongStorageBase
from .Node import Node
from .NumberType import NumberType
from .PyTorchFileReader import PyTorchFileReader
from .PyTorchFileWriter import PyTorchFileWriter
from .ScriptMethod import ScriptMethod
from .ScriptModule import ScriptModule
from .ShortStorageBase import ShortStorageBase
from .Size import Size
from .TracingState import TracingState
from .TupleType import TupleType
from .Use import Use
from .Value import Value
from ._CudaStreamBase import _CudaStreamBase
from ._FunctionBase import _FunctionBase
from ._ImperativeEngine import _ImperativeEngine
from ._LegacyVariableBase import _LegacyVariableBase
from ._TensorBase import _TensorBase
from ._THCUNN import _THCUNN
from ._THNN import _THNN
from ._VariableFunctions import _VariableFunctions
# variables with complex values

default_generator = None # (!) real value is '<torch._C.Generator object at 0x7f7fdd6b8090>'

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f801ea47390>'

__spec__ = None # (!) real value is "ModuleSpec(name='torch._C', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f801ea47390>, origin='/usr/local/lib/python3.5/dist-packages/torch/_C.cpython-35m-x86_64-linux-gnu.so')"


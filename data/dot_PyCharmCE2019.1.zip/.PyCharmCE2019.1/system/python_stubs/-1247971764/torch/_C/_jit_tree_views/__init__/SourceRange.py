# encoding: utf-8
# module torch._C._jit_tree_views
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pybind11_builtins as __pybind11_builtins


class SourceRange(__pybind11_builtins.pybind11_object):
    # no doc
    def highlight(self): # real signature unknown; restored from __doc__
        """ highlight(self: torch._C._jit_tree_views.SourceRange) -> str """
        return ""

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    end = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    start = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




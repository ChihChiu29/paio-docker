# encoding: utf-8
# module 0786a1d98214c361e2afd2eba57e8c9c
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def resampler(data, warp, name=None): # reliably restored by inspect
    """
    Resampler op.
    
      Args:
        data: A `Tensor`. Must be one of the following types: `half`, `bfloat16`, `float32`, `float64`.
        warp: A `Tensor`. Must have the same type as `data`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor`. Has the same type as `data`.
    """
    pass

def resampler_eager_fallback(data, warp, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function resampler
    """
    pass

def resampler_grad(data, warp, grad_output, name=None): # reliably restored by inspect
    """
    Resampler Grad op.
    
      Args:
        data: A `Tensor`. Must be one of the following types: `half`, `bfloat16`, `float32`, `float64`.
        warp: A `Tensor`. Must have the same type as `data`.
        grad_output: A `Tensor`. Must have the same type as `data`.
        name: A name for the operation (optional).
    
      Returns:
        A tuple of `Tensor` objects (grad_data, grad_warp).
    
        grad_data: A `Tensor`. Has the same type as `data`.
        grad_warp: A `Tensor`. Has the same type as `data`.
    """
    pass

def resampler_grad_eager_fallback(data, warp, grad_output, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function resampler_grad
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# classes

class _ResamplerGradOutput(tuple):
    """ ResamplerGrad(grad_data, grad_warp) """
    def _asdict(self): # reliably restored by inspect
        """ Return a new OrderedDict which maps field names to their values. """
        pass

    @classmethod
    def _make(cls, *args, **kwargs): # real signature unknown
        """ Make a new ResamplerGrad object from a sequence or iterable """
        pass

    def _replace(_self, **kwds): # reliably restored by inspect
        """ Return a new ResamplerGrad object replacing specified fields with new values """
        pass

    def __getnewargs__(self): # reliably restored by inspect
        """ Return self as a plain tuple.  Used by copy and pickle. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(_cls, grad_data, grad_warp): # reliably restored by inspect
        """ Create new instance of ResamplerGrad(grad_data, grad_warp) """
        pass

    def __repr__(self): # reliably restored by inspect
        """ Return a nicely formatted representation string """
        pass

    grad_data = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 0"""

    grad_warp = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 1"""


    _fields = (
        'grad_data',
        'grad_warp',
    )
    _source = "from builtins import property as _property, tuple as _tuple\nfrom operator import itemgetter as _itemgetter\nfrom collections import OrderedDict\n\nclass ResamplerGrad(tuple):\n    'ResamplerGrad(grad_data, grad_warp)'\n\n    __slots__ = ()\n\n    _fields = ('grad_data', 'grad_warp')\n\n    def __new__(_cls, grad_data, grad_warp):\n        'Create new instance of ResamplerGrad(grad_data, grad_warp)'\n        return _tuple.__new__(_cls, (grad_data, grad_warp))\n\n    @classmethod\n    def _make(cls, iterable, new=tuple.__new__, len=len):\n        'Make a new ResamplerGrad object from a sequence or iterable'\n        result = new(cls, iterable)\n        if len(result) != 2:\n            raise TypeError('Expected 2 arguments, got %d' % len(result))\n        return result\n\n    def _replace(_self, **kwds):\n        'Return a new ResamplerGrad object replacing specified fields with new values'\n        result = _self._make(map(kwds.pop, ('grad_data', 'grad_warp'), _self))\n        if kwds:\n            raise ValueError('Got unexpected field names: %r' % list(kwds))\n        return result\n\n    def __repr__(self):\n        'Return a nicely formatted representation string'\n        return self.__class__.__name__ + '(grad_data=%r, grad_warp=%r)' % self\n\n    def _asdict(self):\n        'Return a new OrderedDict which maps field names to their values.'\n        return OrderedDict(zip(self._fields, self))\n\n    def __getnewargs__(self):\n        'Return self as a plain tuple.  Used by copy and pickle.'\n        return tuple(self)\n\n    grad_data = _property(_itemgetter(0), doc='Alias for field number 0')\n\n    grad_warp = _property(_itemgetter(1), doc='Alias for field number 1')\n\n"
    __slots__ = ()


# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7ddde0960>"

_resampler_grad_outputs = [
    'grad_data',
    'grad_warp',
]


# encoding: utf-8
# module typing.re
# from /usr/local/lib/python3.5/dist-packages/torch/_dl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" Wrapper namespace for re type aliases. """
# no imports

# no functions
# no classes
# variables with complex values

Match = None # (!) real value is 'Match[~AnyStr]'

Pattern = None # (!) real value is 'Pattern[~AnyStr]'

__all__ = [
    'Pattern',
    'Match',
]

__weakref__ = None # (!) real value is "<attribute '__weakref__' of 'typing.re' objects>"


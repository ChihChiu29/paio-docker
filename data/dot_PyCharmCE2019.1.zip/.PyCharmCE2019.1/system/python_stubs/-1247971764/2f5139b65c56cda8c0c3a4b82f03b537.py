# encoding: utf-8
# module 2f5139b65c56cda8c0c3a4b82f03b537
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def kmc2_chain_initialization(distances, seed, name=None): # reliably restored by inspect
    """
    Returns the index of a data point that should be added to the seed set.
    
      Entries in distances are assumed to be squared distances of candidate points to
      the already sampled centers in the seed set. The op constructs one Markov chain
      of the k-MC^2 algorithm and returns the index of one candidate point to be added
      as an additional cluster center.
    
      Args:
        distances: A `Tensor` of type `float32`.
          Vector with squared distances to the closest previously sampled
          cluster center for each candidate point.
        seed: A `Tensor` of type `int64`.
          Scalar. Seed for initializing the random number generator.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int64`. Scalar with the index of the sampled point.
    """
    pass

def kmc2_chain_initialization_eager_fallback(distances, seed, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function kmc2_chain_initialization
    """
    pass

def kmeans_plus_plus_initialization(points, num_to_sample, seed, num_retries_per_sample, name=None): # reliably restored by inspect
    """
    Selects num_to_sample rows of input using the KMeans++ criterion.
    
      Rows of points are assumed to be input points. One row is selected at random.
      Subsequent rows are sampled with probability proportional to the squared L2
      distance from the nearest row selected thus far till num_to_sample rows have
      been sampled.
    
      Args:
        points: A `Tensor` of type `float32`.
          Matrix of shape (n, d). Rows are assumed to be input points.
        num_to_sample: A `Tensor` of type `int64`.
          Scalar. The number of rows to sample. This value must not be
          larger than n.
        seed: A `Tensor` of type `int64`.
          Scalar. Seed for initializing the random number generator.
        num_retries_per_sample: A `Tensor` of type `int64`.
          Scalar. For each row that is sampled, this parameter
          specifies the number of additional points to draw from the current
          distribution before selecting the best. If a negative value is specified, a
          heuristic is used to sample O(log(num_to_sample)) additional points.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `float32`.
        Matrix of shape (num_to_sample, d). The sampled rows.
    """
    pass

def kmeans_plus_plus_initialization_eager_fallback(points, num_to_sample, seed, num_retries_per_sample, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function kmeans_plus_plus_initialization
    """
    pass

def nearest_neighbors(points, centers, k, name=None): # reliably restored by inspect
    """
    Selects the k nearest centers for each point.
    
      Rows of points are assumed to be input points. Rows of centers are assumed to be
      the list of candidate centers. For each point, the k centers that have least L2
      distance to it are computed.
    
      Args:
        points: A `Tensor` of type `float32`.
          Matrix of shape (n, d). Rows are assumed to be input points.
        centers: A `Tensor` of type `float32`.
          Matrix of shape (m, d). Rows are assumed to be centers.
        k: A `Tensor` of type `int64`.
          Scalar. Number of nearest centers to return for each point. If k is larger
          than m, then only m centers are returned.
        name: A name for the operation (optional).
    
      Returns:
        A tuple of `Tensor` objects (nearest_center_indices, nearest_center_distances).
    
        nearest_center_indices: A `Tensor` of type `int64`. Matrix of shape (n, min(m, k)). Each row contains the
          indices of the centers closest to the corresponding point, ordered by
          increasing distance.
        nearest_center_distances: A `Tensor` of type `float32`. Matrix of shape (n, min(m, k)). Each row contains the
          squared L2 distance to the corresponding center in nearest_center_indices.
    """
    pass

def nearest_neighbors_eager_fallback(points, centers, k, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function nearest_neighbors
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# classes

class _NearestNeighborsOutput(tuple):
    """ NearestNeighbors(nearest_center_indices, nearest_center_distances) """
    def _asdict(self): # reliably restored by inspect
        """ Return a new OrderedDict which maps field names to their values. """
        pass

    @classmethod
    def _make(cls, *args, **kwargs): # real signature unknown
        """ Make a new NearestNeighbors object from a sequence or iterable """
        pass

    def _replace(_self, **kwds): # reliably restored by inspect
        """ Return a new NearestNeighbors object replacing specified fields with new values """
        pass

    def __getnewargs__(self): # reliably restored by inspect
        """ Return self as a plain tuple.  Used by copy and pickle. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(_cls, nearest_center_indices, nearest_center_distances): # reliably restored by inspect
        """ Create new instance of NearestNeighbors(nearest_center_indices, nearest_center_distances) """
        pass

    def __repr__(self): # reliably restored by inspect
        """ Return a nicely formatted representation string """
        pass

    nearest_center_distances = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 1"""

    nearest_center_indices = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 0"""


    _fields = (
        'nearest_center_indices',
        'nearest_center_distances',
    )
    _source = "from builtins import property as _property, tuple as _tuple\nfrom operator import itemgetter as _itemgetter\nfrom collections import OrderedDict\n\nclass NearestNeighbors(tuple):\n    'NearestNeighbors(nearest_center_indices, nearest_center_distances)'\n\n    __slots__ = ()\n\n    _fields = ('nearest_center_indices', 'nearest_center_distances')\n\n    def __new__(_cls, nearest_center_indices, nearest_center_distances):\n        'Create new instance of NearestNeighbors(nearest_center_indices, nearest_center_distances)'\n        return _tuple.__new__(_cls, (nearest_center_indices, nearest_center_distances))\n\n    @classmethod\n    def _make(cls, iterable, new=tuple.__new__, len=len):\n        'Make a new NearestNeighbors object from a sequence or iterable'\n        result = new(cls, iterable)\n        if len(result) != 2:\n            raise TypeError('Expected 2 arguments, got %d' % len(result))\n        return result\n\n    def _replace(_self, **kwds):\n        'Return a new NearestNeighbors object replacing specified fields with new values'\n        result = _self._make(map(kwds.pop, ('nearest_center_indices', 'nearest_center_distances'), _self))\n        if kwds:\n            raise ValueError('Got unexpected field names: %r' % list(kwds))\n        return result\n\n    def __repr__(self):\n        'Return a nicely formatted representation string'\n        return self.__class__.__name__ + '(nearest_center_indices=%r, nearest_center_distances=%r)' % self\n\n    def _asdict(self):\n        'Return a new OrderedDict which maps field names to their values.'\n        return OrderedDict(zip(self._fields, self))\n\n    def __getnewargs__(self):\n        'Return self as a plain tuple.  Used by copy and pickle.'\n        return tuple(self)\n\n    nearest_center_indices = _property(_itemgetter(0), doc='Alias for field number 0')\n\n    nearest_center_distances = _property(_itemgetter(1), doc='Alias for field number 1')\n\n"
    __slots__ = ()


# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7de2cb180>"

_nearest_neighbors_outputs = [
    'nearest_center_indices',
    'nearest_center_distances',
]


# encoding: utf-8
# module tensorflow.lite.toco.python._tensorflow_wrap_toco
# from /usr/local/lib/python3.5/dist-packages/tensorflow/lite/toco/python/_tensorflow_wrap_toco.so
# by generator 1.147
# no doc
# no imports

# functions

def SWIG_PyInstanceMethod_New(*args, **kwargs): # real signature unknown
    pass

def TocoConvert(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f868eeb6ac8>'

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.lite.toco.python._tensorflow_wrap_toco', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f868eeb6ac8>, origin='/usr/local/lib/python3.5/dist-packages/tensorflow/lite/toco/python/_tensorflow_wrap_toco.so')"


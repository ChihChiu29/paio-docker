# encoding: utf-8
# module tensorflow.include.external.protobuf_archive.python.google.protobuf.pyext
# from /usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext/_message.so
# by generator 1.147
# no doc

# imports
import tensorflow.include.external.protobuf_archive.python.google.protobuf.pyext._message as _message # /usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext/_message.so

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external._NamespaceLoader object at 0x7ff6f259a940>'

__path__ = None # (!) real value is "_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext'])"

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.include.external.protobuf_archive.python.google.protobuf.pyext', loader=None, origin='namespace', submodule_search_locations=_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext']))"


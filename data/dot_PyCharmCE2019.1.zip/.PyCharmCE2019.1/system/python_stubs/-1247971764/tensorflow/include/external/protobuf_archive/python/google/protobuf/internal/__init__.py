# encoding: utf-8
# module tensorflow.include.external.protobuf_archive.python.google.protobuf.internal
# from /usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/internal/_api_implementation.so
# by generator 1.147
# no doc

# imports
import tensorflow.include.external.protobuf_archive.python.google.protobuf.internal._api_implementation as _api_implementation # /usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/internal/_api_implementation.so

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external._NamespaceLoader object at 0x7f360ed28940>'

__path__ = None # (!) real value is "_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/internal'])"

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.include.external.protobuf_archive.python.google.protobuf.internal', loader=None, origin='namespace', submodule_search_locations=_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/internal']))"


# encoding: utf-8
# module tensorflow.include.external.protobuf_archive.python.google
# from /usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext/_message.so
# by generator 1.147
# no doc

# imports
import tensorflow.include.external.protobuf_archive.python.google.protobuf as protobuf # <module 'tensorflow.include.external.protobuf_archive.python.google.protobuf' (namespace)>

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external._NamespaceLoader object at 0x7ff6f259ab70>'

__path__ = None # (!) real value is "_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google'])"

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.include.external.protobuf_archive.python.google', loader=None, origin='namespace', submodule_search_locations=_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google']))"


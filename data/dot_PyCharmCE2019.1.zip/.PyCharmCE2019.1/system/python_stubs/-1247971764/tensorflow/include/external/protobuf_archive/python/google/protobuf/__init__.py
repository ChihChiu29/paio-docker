# encoding: utf-8
# module tensorflow.include.external.protobuf_archive.python.google.protobuf
# from /usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext/_message.so
# by generator 1.147
# no doc

# imports
import tensorflow.include.external.protobuf_archive.python.google.protobuf.pyext as pyext # <module 'tensorflow.include.external.protobuf_archive.python.google.protobuf.pyext' (namespace)>

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external._NamespaceLoader object at 0x7ff6f259aa58>'

__path__ = None # (!) real value is "_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf'])"

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.include.external.protobuf_archive.python.google.protobuf', loader=None, origin='namespace', submodule_search_locations=_NamespacePath(['/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf']))"


# encoding: utf-8
# module tensorflow.include.external.protobuf_archive.python.google.protobuf.pyext._message
# from /usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext/_message.so
# by generator 1.147
"""
python-proto2 is a module that can be used to enhance proto2 Python API
performance.

It provides access to the protocol buffers C++ reflection API that
implements the basic protocol buffer functions.
"""

# imports
from google.protobuf.pyext._message import (Descriptor, DescriptorPool, 
    EnumDescriptor, EnumValueDescriptor, ExtensionDict, FieldDescriptor, 
    FileDescriptor, MapIterator, Message, MessageMapContainer, MessageMeta, 
    MethodDescriptor, OneofDescriptor, RepeatedCompositeContainer, 
    RepeatedScalarContainer, ScalarMapContainer, ServiceDescriptor)


# Variables with simple values

_USE_C_DESCRIPTORS = 1

# functions

def GetPythonProto3PreserveUnknownsDefault(*args, **kwargs): # real signature unknown
    """ Get Proto3 preserve unknowns default. """
    pass

def SetAllowOversizeProtos(*args, **kwargs): # real signature unknown
    """ Enable/disable oversize proto parsing. """
    pass

def SetPythonProto3PreserveUnknownsDefault(*args, **kwargs): # real signature unknown
    """ Enable/disable proto3 unknowns preservation. """
    pass

# no classes
# variables with complex values

default_pool = None # (!) real value is '<google.protobuf.pyext._message.DescriptorPool object at 0x7ff6f24e2378>'

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff6cf904358>'

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.include.external.protobuf_archive.python.google.protobuf.pyext._message', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff6cf904358>, origin='/usr/local/lib/python3.5/dist-packages/tensorflow/include/external/protobuf_archive/python/google/protobuf/pyext/_message.so')"


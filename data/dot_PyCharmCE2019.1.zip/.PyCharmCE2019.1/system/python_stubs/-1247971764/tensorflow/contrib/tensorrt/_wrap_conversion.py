# encoding: utf-8
# module tensorflow.contrib.tensorrt._wrap_conversion
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
# no doc
# no imports

# functions

def add_test_value(*args, **kwargs): # real signature unknown
    pass

def calib_convert(*args, **kwargs): # real signature unknown
    pass

def clear_test_values(*args, **kwargs): # real signature unknown
    pass

def enable_test_value(*args, **kwargs): # real signature unknown
    pass

def get_linked_tensorrt_version(*args, **kwargs): # real signature unknown
    pass

def get_loaded_tensorrt_version(*args, **kwargs): # real signature unknown
    pass

def get_test_value(*args, **kwargs): # real signature unknown
    pass

def is_tensorrt_enabled(*args, **kwargs): # real signature unknown
    pass

def SWIG_PyInstanceMethod_New(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc8070f5a58>'

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.contrib.tensorrt._wrap_conversion', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc8070f5a58>, origin='/usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so')"


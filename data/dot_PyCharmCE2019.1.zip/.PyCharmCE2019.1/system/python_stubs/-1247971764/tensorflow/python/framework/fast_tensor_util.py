# encoding: utf-8
# module tensorflow.python.framework.fast_tensor_util
# from /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/fast_tensor_util.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import tensorflow.python.util.compat as compat # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/compat.py

# functions

def AppendBFloat16ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendBoolArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendComplex128ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendComplex64ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendFloat16ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendFloat32ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendFloat64ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendInt16ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendInt32ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendInt64ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendInt8ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendObjectArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendUInt16ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendUInt32ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendUInt64ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

def AppendUInt8ArrayToTensorProto(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fd944856908>'

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.python.framework.fast_tensor_util', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fd944856908>, origin='/usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/fast_tensor_util.so')"

__test__ = {}


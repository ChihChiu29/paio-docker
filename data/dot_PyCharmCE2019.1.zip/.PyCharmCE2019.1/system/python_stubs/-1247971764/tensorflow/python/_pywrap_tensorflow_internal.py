# encoding: utf-8
# module tensorflow.python._pywrap_tensorflow_internal
# from /usr/local/lib/python3.5/dist-packages/tensorflow/python/_pywrap_tensorflow_internal.so
# by generator 1.147
# no doc
# no imports

# functions

def AddControlInput(*args, **kwargs): # real signature unknown
    pass

def AddStep(*args, **kwargs): # real signature unknown
    pass

def AddWhileInputHack(*args, **kwargs): # real signature unknown
    pass

def AppendToFile(*args, **kwargs): # real signature unknown
    pass

def AssertSameStructure(*args, **kwargs): # real signature unknown
    pass

def AssertSameStructureForData(*args, **kwargs): # real signature unknown
    pass

def Basename(*args, **kwargs): # real signature unknown
    pass

def BufferedInputStream_ReadLineAsString(*args, **kwargs): # real signature unknown
    pass

def BufferedInputStream_Seek(*args, **kwargs): # real signature unknown
    pass

def BufferedInputStream_swigregister(*args, **kwargs): # real signature unknown
    pass

def BufferedInputStream_Tell(*args, **kwargs): # real signature unknown
    pass

def CheckpointReader_debug_string(*args, **kwargs): # real signature unknown
    pass

def CheckpointReader_GetTensor(*args, **kwargs): # real signature unknown
    pass

def CheckpointReader_get_variable_to_shape_map(*args, **kwargs): # real signature unknown
    pass

def CheckpointReader_swigregister(*args, **kwargs): # real signature unknown
    pass

def CheckpointReader__GetVariableToDataTypeMap(*args, **kwargs): # real signature unknown
    pass

def CheckpointReader__HasTensor(*args, **kwargs): # real signature unknown
    pass

def CleanPath(*args, **kwargs): # real signature unknown
    pass

def CopyFile(*args, **kwargs): # real signature unknown
    pass

def CreateBufferedInputStream(*args, **kwargs): # real signature unknown
    pass

def CreateDir(*args, **kwargs): # real signature unknown
    pass

def CreateURI(*args, **kwargs): # real signature unknown
    pass

def CreateWritableFile(*args, **kwargs): # real signature unknown
    pass

def CudaSupportsHalfMatMulAndConv(*args, **kwargs): # real signature unknown
    pass

def DeleteFile(*args, **kwargs): # real signature unknown
    pass

def DeleteProfiler(*args, **kwargs): # real signature unknown
    pass

def DeleteRecursively(*args, **kwargs): # real signature unknown
    pass

def DeleteStatSummarizer(*args, **kwargs): # real signature unknown
    pass

def delete_BufferedInputStream(*args, **kwargs): # real signature unknown
    pass

def delete_CheckpointReader(*args, **kwargs): # real signature unknown
    pass

def delete_EventsWriter(*args, **kwargs): # real signature unknown
    pass

def delete_FileStatistics(*args, **kwargs): # real signature unknown
    pass

def delete_GCluster(*args, **kwargs): # real signature unknown
    pass

def delete_GItem(*args, **kwargs): # real signature unknown
    pass

def delete_PyExceptionRegistry(*args, **kwargs): # real signature unknown
    pass

def delete_PyRecordReader(*args, **kwargs): # real signature unknown
    pass

def delete_PyRecordWriter(*args, **kwargs): # real signature unknown
    pass

def delete_RecordWriterOptions(*args, **kwargs): # real signature unknown
    pass

def delete_StatSummarizer(*args, **kwargs): # real signature unknown
    pass

def delete_Status(*args, **kwargs): # real signature unknown
    pass

def delete_TF_AttrMetadata(*args, **kwargs): # real signature unknown
    pass

def delete_TF_Buffer(*args, **kwargs): # real signature unknown
    pass

def delete_TF_Input(*args, **kwargs): # real signature unknown
    pass

def delete_TF_Output(*args, **kwargs): # real signature unknown
    pass

def delete_WritableFile(*args, **kwargs): # real signature unknown
    pass

def delete_ZlibCompressionOptions(*args, **kwargs): # real signature unknown
    pass

def Dirname(*args, **kwargs): # real signature unknown
    pass

def DoQuantizeTrainingOnGraphDefHelper(*args, **kwargs): # real signature unknown
    pass

def EqualAttrValueWrapper(*args, **kwargs): # real signature unknown
    pass

def EqualGraphDefWrapper(*args, **kwargs): # real signature unknown
    pass

def EventsWriter_Close(*args, **kwargs): # real signature unknown
    pass

def EventsWriter_FileName(*args, **kwargs): # real signature unknown
    pass

def EventsWriter_Flush(*args, **kwargs): # real signature unknown
    pass

def EventsWriter_InitWithSuffix(*args, **kwargs): # real signature unknown
    pass

def EventsWriter_swigregister(*args, **kwargs): # real signature unknown
    pass

def EventsWriter__WriteSerializedEvent(*args, **kwargs): # real signature unknown
    pass

def ExtendSession(*args, **kwargs): # real signature unknown
    pass

def Extension(*args, **kwargs): # real signature unknown
    pass

def FileExists(*args, **kwargs): # real signature unknown
    pass

def FileStatistics_is_directory_get(*args, **kwargs): # real signature unknown
    pass

def FileStatistics_is_directory_set(*args, **kwargs): # real signature unknown
    pass

def FileStatistics_length_get(*args, **kwargs): # real signature unknown
    pass

def FileStatistics_length_set(*args, **kwargs): # real signature unknown
    pass

def FileStatistics_mtime_nsec_get(*args, **kwargs): # real signature unknown
    pass

def FileStatistics_mtime_nsec_set(*args, **kwargs): # real signature unknown
    pass

def FileStatistics_swigregister(*args, **kwargs): # real signature unknown
    pass

def Flatten(*args, **kwargs): # real signature unknown
    """
    Returns a flat list from a given nested structure.
    
    If `nest` is not a sequence, tuple, or dict, then returns a single-element
    list: `[nest]`.
    
    In the case of dict instances, the sequence consists of the values, sorted by
    key to ensure deterministic behavior. This is true also for `OrderedDict`
    instances: their sequence order is ignored, the sorting order of keys is
    used instead. The same convention is followed in `pack_sequence_as`. This
    correctly repacks dicts and `OrderedDict`s after they have been flattened,
    and also allows flattening an `OrderedDict` and then repacking it back using
    a corresponding plain dict, or vice-versa.
    Dictionaries with non-sortable keys cannot be flattened.
    
    Users must not modify any collections used in `nest` while this function is
    running.
    
    Args:
      nest: an arbitrarily nested structure or a scalar object. Note, numpy
          arrays are considered scalars.
    
    Returns:
      A Python list, the flattened version of the input.
    
    Raises:
      TypeError: The nest is or contains a dict with non-sortable keys.
    """
    pass

def FlattenForData(*args, **kwargs): # real signature unknown
    """
    Returns a flat sequence from a given nested structure.
    
    If `nest` is not a sequence, this returns a single-element list: `[nest]`.
    
    Args:
      nest: an arbitrarily nested structure or a scalar object.
        Note, numpy arrays are considered scalars.
    
    Returns:
      A Python list, the flattened version of the input.
    """
    pass

def GCluster_cluster__get(*args, **kwargs): # real signature unknown
    pass

def GCluster_cluster__set(*args, **kwargs): # real signature unknown
    pass

def GCluster_swigregister(*args, **kwargs): # real signature unknown
    pass

def GenerateCostReport(*args, **kwargs): # real signature unknown
    pass

def GenerateModelReport(*args, **kwargs): # real signature unknown
    pass

def GetChildren(*args, **kwargs): # real signature unknown
    pass

def GetHandleShapeAndType(*args, **kwargs): # real signature unknown
    pass

def GetMatchingFiles(*args, **kwargs): # real signature unknown
    pass

def GetOperationInputs(*args, **kwargs): # real signature unknown
    pass

def GetPythonWrappers(*args, **kwargs): # real signature unknown
    pass

def GetTempFilename(*args, **kwargs): # real signature unknown
    pass

def GItem_item__get(*args, **kwargs): # real signature unknown
    pass

def GItem_item__set(*args, **kwargs): # real signature unknown
    pass

def GItem_swigregister(*args, **kwargs): # real signature unknown
    pass

def GraphAnalyzer(*args, **kwargs): # real signature unknown
    pass

def GRAPH_DEF_VERSION_MIN_CONSUMER_swigconstant(*args, **kwargs): # real signature unknown
    pass

def GRAPH_DEF_VERSION_MIN_PRODUCER_swigconstant(*args, **kwargs): # real signature unknown
    pass

def GRAPH_DEF_VERSION_swigconstant(*args, **kwargs): # real signature unknown
    pass

def InitializePyTrampoline(*args, **kwargs): # real signature unknown
    pass

def InstallStacktraceHandler(*args, **kwargs): # real signature unknown
    pass

def IsAbsolutePath(*args, **kwargs): # real signature unknown
    pass

def IsAttrs(*args, **kwargs): # real signature unknown
    """
    Returns True iff `instance` is an instance of an `attr.s` decorated class.
    
    Args:
      instance: An instance of a Python object.
    
    Returns:
      True if `instance` is an instance of an `attr.s` decorated class.
    """
    pass

def IsDirectory(*args, **kwargs): # real signature unknown
    pass

def IsGoogleCudaEnabled(*args, **kwargs): # real signature unknown
    pass

def IsMapping(*args, **kwargs): # real signature unknown
    """
    Returns True iff `instance` is a `collections.Mapping`.
    
    Args:
      instance: An instance of a Python object.
    
    Returns:
      True if `instance` is a `collections.Mapping`.
    """
    pass

def IsMklEnabled(*args, **kwargs): # real signature unknown
    pass

def IsNamedtuple(*args, **kwargs): # real signature unknown
    pass

def IsSequence(*args, **kwargs): # real signature unknown
    """
    Returns a true if its input is a collections.Sequence (except strings).
    
    Args:
      seq: an input sequence.
    
    Returns:
      True if the sequence is a not a string and is a collections.Sequence or a
      dict.
    """
    pass

def IsSequenceForData(*args, **kwargs): # real signature unknown
    """
    Returns a true if `seq` is a Sequence or dict (except strings/lists).
    
    NOTE(mrry): This differs from `tensorflow.python.util.nest.is_sequence()`,
    which *does* treat a Python list as a sequence. For ergonomic
    reasons, `tf.data` users would prefer to treat lists as
    implicit `tf.Tensor` objects, and dicts as (nested) sequences.
    
    Args:
      seq: an input sequence.
    
    Returns:
      True if the sequence is a not a string or list and is a
      collections.Sequence.
    """
    pass

def IsTensor(*args, **kwargs): # real signature unknown
    pass

def ListDevices(*args, **kwargs): # real signature unknown
    pass

def ListDevicesWithSessionConfig(*args, **kwargs): # real signature unknown
    pass

def NewProfiler(*args, **kwargs): # real signature unknown
    pass

def NewStatSummarizer(*args, **kwargs): # real signature unknown
    pass

def new_CheckpointReader(*args, **kwargs): # real signature unknown
    pass

def new_EventsWriter(*args, **kwargs): # real signature unknown
    pass

def new_FileStatistics(*args, **kwargs): # real signature unknown
    pass

def new_GCluster(*args, **kwargs): # real signature unknown
    pass

def new_GItem(*args, **kwargs): # real signature unknown
    pass

def new_RecordWriterOptions(*args, **kwargs): # real signature unknown
    pass

def new_StatSummarizer(*args, **kwargs): # real signature unknown
    pass

def new_Status(*args, **kwargs): # real signature unknown
    pass

def new_TF_AttrMetadata(*args, **kwargs): # real signature unknown
    pass

def new_TF_Buffer(*args, **kwargs): # real signature unknown
    pass

def new_TF_Input(*args, **kwargs): # real signature unknown
    pass

def new_TF_Output(*args, **kwargs): # real signature unknown
    pass

def ParseURI(*args, **kwargs): # real signature unknown
    pass

def PrintModelAnalysis(*args, **kwargs): # real signature unknown
    pass

def Profile(*args, **kwargs): # real signature unknown
    pass

def ProfilerFromFile(*args, **kwargs): # real signature unknown
    pass

def PyExceptionRegistry_Init(*args, **kwargs): # real signature unknown
    pass

def PyExceptionRegistry_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyRecordReader_Close(*args, **kwargs): # real signature unknown
    pass

def PyRecordReader_GetNext(*args, **kwargs): # real signature unknown
    pass

def PyRecordReader_New(*args, **kwargs): # real signature unknown
    pass

def PyRecordReader_offset(*args, **kwargs): # real signature unknown
    pass

def PyRecordReader_record(*args, **kwargs): # real signature unknown
    pass

def PyRecordReader_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyRecordWriter_Close(*args, **kwargs): # real signature unknown
    pass

def PyRecordWriter_Flush(*args, **kwargs): # real signature unknown
    pass

def PyRecordWriter_New(*args, **kwargs): # real signature unknown
    pass

def PyRecordWriter_swigregister(*args, **kwargs): # real signature unknown
    pass

def PyRecordWriter_WriteRecord(*args, **kwargs): # real signature unknown
    pass

def ReadFileToString(*args, **kwargs): # real signature unknown
    pass

def ReadFromStream(*args, **kwargs): # real signature unknown
    pass

def RecordWriterOptions_CreateRecordWriterOptions(*args, **kwargs): # real signature unknown
    pass

def RecordWriterOptions_swigregister(*args, **kwargs): # real signature unknown
    pass

def RecordWriterOptions_zlib_options_get(*args, **kwargs): # real signature unknown
    pass

def RecordWriterOptions_zlib_options_set(*args, **kwargs): # real signature unknown
    pass

def RecursivelyCreateDir(*args, **kwargs): # real signature unknown
    pass

def RegisterType(*args, **kwargs): # real signature unknown
    pass

def RemoveAllControlInputs(*args, **kwargs): # real signature unknown
    pass

def RenameFile(*args, **kwargs): # real signature unknown
    pass

def RunCppShapeInference(*args, **kwargs): # real signature unknown
    pass

def SameNamedtuples(*args, **kwargs): # real signature unknown
    """ Returns True if the two namedtuples have the same name and fields. """
    pass

def SerializeToString(*args, **kwargs): # real signature unknown
    pass

def SetAttr(*args, **kwargs): # real signature unknown
    pass

def SetHandleShapeAndType(*args, **kwargs): # real signature unknown
    pass

def SetRequestedDevice(*args, **kwargs): # real signature unknown
    pass

def SetRequireShapeInferenceFns(*args, **kwargs): # real signature unknown
    pass

def Set_TF_Status_from_Status(*args, **kwargs): # real signature unknown
    pass

def SHARED_PTR_DISOWN_swigconstant(*args, **kwargs): # real signature unknown
    pass

def Stat(*args, **kwargs): # real signature unknown
    pass

def StatSummarizer_GetOutputString(*args, **kwargs): # real signature unknown
    pass

def StatSummarizer_PrintStepStats(*args, **kwargs): # real signature unknown
    pass

def StatSummarizer_ProcessStepStats(*args, **kwargs): # real signature unknown
    pass

def StatSummarizer_ProcessStepStatsStr(*args, **kwargs): # real signature unknown
    pass

def StatSummarizer_swigregister(*args, **kwargs): # real signature unknown
    pass

def StatusFromTF_Status(*args, **kwargs): # real signature unknown
    pass

def Status_code(*args, **kwargs): # real signature unknown
    pass

def Status_error_message(*args, **kwargs): # real signature unknown
    pass

def Status_IgnoreError(*args, **kwargs): # real signature unknown
    pass

def Status_ok(*args, **kwargs): # real signature unknown
    pass

def Status_OK(*args, **kwargs): # real signature unknown
    pass

def Status_swigregister(*args, **kwargs): # real signature unknown
    pass

def Status_ToString(*args, **kwargs): # real signature unknown
    pass

def Status_Update(*args, **kwargs): # real signature unknown
    pass

def Status___eq__(*args, **kwargs): # real signature unknown
    pass

def Status___ne__(*args, **kwargs): # real signature unknown
    pass

def SWIG_PyInstanceMethod_New(*args, **kwargs): # real signature unknown
    pass

def TENSOR_HANDLE_KEY_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TfCheckOpHelper(*args, **kwargs): # real signature unknown
    pass

def TfCheckOpHelperOutOfLine(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextAddFunction(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextAddFunctionDef(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextAsyncClearError(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextAsyncWait(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextClearCaches(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextDisableRunMetadata(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextEnableRunMetadata(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextEndStep(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextExportRunMetadata(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextGetDevicePlacementPolicy(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextListDevices(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextOptionsSetAsync(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextOptionsSetConfig(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextOptionsSetDevicePlacementPolicy(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextSetAsyncForThread(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextSetServerDef(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextSetThreadLocalDevicePlacementPolicy(*args, **kwargs): # real signature unknown
    pass

def TFE_ContextStartStep(*args, **kwargs): # real signature unknown
    pass

def TFE_DeleteContext(*args, **kwargs): # real signature unknown
    pass

def TFE_DeleteContextOptions(*args, **kwargs): # real signature unknown
    pass

def TFE_DEVICE_PLACEMENT_EXPLICIT_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TFE_DEVICE_PLACEMENT_SILENT_FOR_INT32_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TFE_DEVICE_PLACEMENT_SILENT_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TFE_DEVICE_PLACEMENT_WARN_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TFE_NewContext(*args, **kwargs): # real signature unknown
    pass

def TFE_NewContextOptions(*args, **kwargs): # real signature unknown
    pass

def TFE_OpNameGetAttrType(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_EncodeArg(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_Execute(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_FastPathExecute(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_InitEagerTensor(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_RecordGradient(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_RegisterExceptionClass(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_RegisterFallbackExceptionClass(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_RegisterGradientFunction(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_RegisterResourceVariableType(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_RegisterVSpace(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_SetEagerTensorProfiler(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeGradient(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetAdd(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetDeleteTrace(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetIsEmpty(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetNew(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetRecordOperation(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetRemove(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetRestartOnThread(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetShouldRecord(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeSetStopOnThread(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeVariableAccessed(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeWatch(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeWatchedVariables(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TapeWatchVariable(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TensorShapeOnDevice(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_TensorShapeSlice(*args, **kwargs): # real signature unknown
    pass

def TFE_Py_UID(*args, **kwargs): # real signature unknown
    pass

def TF_ABORTED_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_AddControlInput(*args, **kwargs): # real signature unknown
    pass

def TF_AddGradients(*args, **kwargs): # real signature unknown
    pass

def TF_AddGradientsWithPrefix(*args, **kwargs): # real signature unknown
    pass

def TF_AddInput(*args, **kwargs): # real signature unknown
    pass

def TF_AddInputList(*args, **kwargs): # real signature unknown
    pass

def TF_AllocateTensor(*args, **kwargs): # real signature unknown
    pass

def TF_ALREADY_EXISTS_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ApiDefMapGet(*args, **kwargs): # real signature unknown
    pass

def TF_ApiDefMapPut(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_is_list_get(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_is_list_set(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_list_size_get(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_list_size_set(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_swigregister(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_total_size_get(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_total_size_set(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_type_get(*args, **kwargs): # real signature unknown
    pass

def TF_AttrMetadata_type_set(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_BOOL_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_FLOAT_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_FUNC_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_INT_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_PLACEHOLDER_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_SHAPE_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_STRING_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_TENSOR_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ATTR_TYPE_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_BFLOAT16_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_bfloat16_type(*args, **kwargs): # real signature unknown
    pass

def TF_BOOL_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_Buffer_data_deallocator_get(*args, **kwargs): # real signature unknown
    pass

def TF_Buffer_data_deallocator_set(*args, **kwargs): # real signature unknown
    pass

def TF_Buffer_data_get(*args, **kwargs): # real signature unknown
    pass

def TF_Buffer_data_set(*args, **kwargs): # real signature unknown
    pass

def TF_Buffer_length_get(*args, **kwargs): # real signature unknown
    pass

def TF_Buffer_length_set(*args, **kwargs): # real signature unknown
    pass

def TF_Buffer_swigregister(*args, **kwargs): # real signature unknown
    pass

def TF_CANCELLED_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_CloseDeprecatedSession(*args, **kwargs): # real signature unknown
    pass

def TF_CloseSession(*args, **kwargs): # real signature unknown
    pass

def TF_ColocateWith(*args, **kwargs): # real signature unknown
    pass

def TF_COMPLEX128_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_COMPLEX64_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_COMPLEX_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_DataTypeSize(*args, **kwargs): # real signature unknown
    pass

def TF_DATA_LOSS_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_DEADLINE_EXCEEDED_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteApiDefMap(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteBuffer(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteDeprecatedSession(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteDeviceList(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteFunction(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteGraph(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteImportGraphDefOptions(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteImportGraphDefResults(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteLibraryHandle(*args, **kwargs): # real signature unknown
    pass

def TF_DeletePRunHandle(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteServer(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteSession(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteSessionOptions(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteStatus(*args, **kwargs): # real signature unknown
    pass

def TF_DeleteTensor(*args, **kwargs): # real signature unknown
    pass

def TF_DeprecatedSessionListDevices(*args, **kwargs): # real signature unknown
    pass

def TF_DeprecatedSessionMakeCallable(*args, **kwargs): # real signature unknown
    pass

def TF_DeprecatedSessionReleaseCallable(*args, **kwargs): # real signature unknown
    pass

def TF_DeprecatedSessionRunCallable(*args, **kwargs): # real signature unknown
    pass

def TF_DeterminePeakMemoryUsage(*args, **kwargs): # real signature unknown
    pass

def TF_DeviceListCount(*args, **kwargs): # real signature unknown
    pass

def TF_DeviceListIncarnation(*args, **kwargs): # real signature unknown
    pass

def TF_DeviceListMemoryBytes(*args, **kwargs): # real signature unknown
    pass

def TF_DeviceListName(*args, **kwargs): # real signature unknown
    pass

def TF_DeviceListType(*args, **kwargs): # real signature unknown
    pass

def TF_Dim(*args, **kwargs): # real signature unknown
    pass

def TF_DOUBLE_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_EstimatePerformance(*args, **kwargs): # real signature unknown
    pass

def TF_ExtendGraph(*args, **kwargs): # real signature unknown
    pass

def TF_FAILED_PRECONDITION_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_FinishOperation(*args, **kwargs): # real signature unknown
    pass

def TF_FLOAT_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_FunctionGetAttrValueProto(*args, **kwargs): # real signature unknown
    pass

def TF_FunctionImportFunctionDef(*args, **kwargs): # real signature unknown
    pass

def TF_FunctionName(*args, **kwargs): # real signature unknown
    pass

def TF_FunctionSetAttrValueProto(*args, **kwargs): # real signature unknown
    pass

def TF_FunctionToFunctionDef(*args, **kwargs): # real signature unknown
    pass

def TF_GetAllOpList(*args, **kwargs): # real signature unknown
    pass

def TF_GetAllRegisteredKernels(*args, **kwargs): # real signature unknown
    pass

def TF_GetBuffer(*args, **kwargs): # real signature unknown
    pass

def TF_GetCode(*args, **kwargs): # real signature unknown
    pass

def TF_GetColocationGroups(*args, **kwargs): # real signature unknown
    pass

def TF_GetOpList(*args, **kwargs): # real signature unknown
    pass

def TF_GetOpProperties(*args, **kwargs): # real signature unknown
    pass

def TF_GetRegisteredKernelsForOp(*args, **kwargs): # real signature unknown
    pass

def TF_GetSupportedDevices(*args, **kwargs): # real signature unknown
    pass

def TF_GraphCopyFunction(*args, **kwargs): # real signature unknown
    pass

def TF_GraphGetFunctions(*args, **kwargs): # real signature unknown
    pass

def TF_GraphGetOpDef(*args, **kwargs): # real signature unknown
    pass

def TF_GraphGetTensorNumDims(*args, **kwargs): # real signature unknown
    pass

def TF_GraphGetTensorShape(*args, **kwargs): # real signature unknown
    pass

def TF_GraphGetTensorShapeHelper(*args, **kwargs): # real signature unknown
    pass

def TF_GraphImportGraphDef(*args, **kwargs): # real signature unknown
    pass

def TF_GraphImportGraphDefWithResults(*args, **kwargs): # real signature unknown
    pass

def TF_GraphImportGraphDefWithReturnOutputs(*args, **kwargs): # real signature unknown
    pass

def TF_GraphNextOperation(*args, **kwargs): # real signature unknown
    pass

def TF_GraphNumFunctions(*args, **kwargs): # real signature unknown
    pass

def TF_GraphOperationByName(*args, **kwargs): # real signature unknown
    pass

def TF_GraphSetOutputHandleShapesAndTypes_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_GraphSetTensorShape(*args, **kwargs): # real signature unknown
    pass

def TF_GraphSetTensorShape_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_GraphToFunction(*args, **kwargs): # real signature unknown
    pass

def TF_GraphToFunction_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_GraphToGraphDef(*args, **kwargs): # real signature unknown
    pass

def TF_GraphVersions(*args, **kwargs): # real signature unknown
    pass

def TF_HALF_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_IdentifyImportantOps(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsAddControlDependency(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsAddInputMapping(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsAddReturnOperation(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsAddReturnOutput(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsNumReturnOperations(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsNumReturnOutputs(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsRemapControlDependency(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsSetDefaultDevice(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsSetPrefix(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsSetUniquifyNames(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefOptionsSetUniquifyPrefix(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefResultsMissingUnusedInputMappings_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefResultsReturnOperations(*args, **kwargs): # real signature unknown
    pass

def TF_ImportGraphDefResultsReturnOutputs(*args, **kwargs): # real signature unknown
    pass

def TF_Input_index_get(*args, **kwargs): # real signature unknown
    pass

def TF_Input_index_set(*args, **kwargs): # real signature unknown
    pass

def TF_Input_oper_get(*args, **kwargs): # real signature unknown
    pass

def TF_Input_oper_set(*args, **kwargs): # real signature unknown
    pass

def TF_Input_swigregister(*args, **kwargs): # real signature unknown
    pass

def TF_INT16_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_INT32_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_INT64_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_INT8_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_INTERNAL_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_INVALID_ARGUMENT_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_ListAvailableOps(*args, **kwargs): # real signature unknown
    pass

def TF_ListDevices(*args, **kwargs): # real signature unknown
    pass

def TF_LoadLibrary(*args, **kwargs): # real signature unknown
    pass

def TF_LoadSessionFromSavedModel(*args, **kwargs): # real signature unknown
    pass

def TF_MeasureCosts(*args, **kwargs): # real signature unknown
    pass

def TF_Message(*args, **kwargs): # real signature unknown
    pass

def TF_NewApiDefMap(*args, **kwargs): # real signature unknown
    pass

def TF_NewBuffer(*args, **kwargs): # real signature unknown
    pass

def TF_NewBufferFromString(*args, **kwargs): # real signature unknown
    pass

def TF_NewCluster(*args, **kwargs): # real signature unknown
    pass

def TF_NewDeprecatedSession(*args, **kwargs): # real signature unknown
    pass

def TF_NewGraph(*args, **kwargs): # real signature unknown
    pass

def TF_NewImportGraphDefOptions(*args, **kwargs): # real signature unknown
    pass

def TF_NewItem(*args, **kwargs): # real signature unknown
    pass

def TF_NewOperation(*args, **kwargs): # real signature unknown
    pass

def TF_NewServer(*args, **kwargs): # real signature unknown
    pass

def TF_NewSession(*args, **kwargs): # real signature unknown
    pass

def TF_NewSessionRef(*args, **kwargs): # real signature unknown
    pass

def TF_NewStatus(*args, **kwargs): # real signature unknown
    pass

def TF_NewTensor(*args, **kwargs): # real signature unknown
    pass

def TF_NewVirtualCluster(*args, **kwargs): # real signature unknown
    pass

def TF_NOT_FOUND_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_NumDims(*args, **kwargs): # real signature unknown
    pass

def TF_OK_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_OperationDevice(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrBool(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrBoolList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrFloat(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrFloatList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrInt(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrIntList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrMetadata(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrShape(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrShapeList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrString(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrStringList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrTensor(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrTensorList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrTensorShapeProto(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrTensorShapeProtoList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrType(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrTypeList(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetAttrValueProto(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetControlInputs_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_OperationGetControlOutputs_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_OperationInput(*args, **kwargs): # real signature unknown
    pass

def TF_OperationInputListLength(*args, **kwargs): # real signature unknown
    pass

def TF_OperationInputType(*args, **kwargs): # real signature unknown
    pass

def TF_OperationName(*args, **kwargs): # real signature unknown
    pass

def TF_OperationNumControlInputs(*args, **kwargs): # real signature unknown
    pass

def TF_OperationNumControlOutputs(*args, **kwargs): # real signature unknown
    pass

def TF_OperationNumInputs(*args, **kwargs): # real signature unknown
    pass

def TF_OperationNumOutputs(*args, **kwargs): # real signature unknown
    pass

def TF_OperationOpType(*args, **kwargs): # real signature unknown
    pass

def TF_OperationOutputConsumers_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_OperationOutputListLength(*args, **kwargs): # real signature unknown
    pass

def TF_OperationOutputNumConsumers(*args, **kwargs): # real signature unknown
    pass

def TF_OperationOutputType(*args, **kwargs): # real signature unknown
    pass

def TF_OperationToNodeDef(*args, **kwargs): # real signature unknown
    pass

def TF_OptimizeGraph(*args, **kwargs): # real signature unknown
    pass

def TF_Output_index_get(*args, **kwargs): # real signature unknown
    pass

def TF_Output_index_set(*args, **kwargs): # real signature unknown
    pass

def TF_Output_oper_get(*args, **kwargs): # real signature unknown
    pass

def TF_Output_oper_set(*args, **kwargs): # real signature unknown
    pass

def TF_Output_swigregister(*args, **kwargs): # real signature unknown
    pass

def TF_OUT_OF_RANGE_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_PERMISSION_DENIED_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_PRun(*args, **kwargs): # real signature unknown
    pass

def TF_PRunSetup(*args, **kwargs): # real signature unknown
    pass

def TF_QINT16_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_QINT32_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_QINT8_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_QUINT16_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_QUINT8_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_Reset(*args, **kwargs): # real signature unknown
    pass

def TF_Reset_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_RESOURCE_EXHAUSTED_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_RESOURCE_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_Run(*args, **kwargs): # real signature unknown
    pass

def TF_ServerJoin(*args, **kwargs): # real signature unknown
    pass

def TF_ServerStart(*args, **kwargs): # real signature unknown
    pass

def TF_ServerStop(*args, **kwargs): # real signature unknown
    pass

def TF_ServerTarget(*args, **kwargs): # real signature unknown
    pass

def TF_SessionListDevices(*args, **kwargs): # real signature unknown
    pass

def TF_SessionMakeCallable(*args, **kwargs): # real signature unknown
    pass

def TF_SessionPRunSetup_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_SessionPRun_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_SessionReleaseCallable(*args, **kwargs): # real signature unknown
    pass

def TF_SessionRunCallable(*args, **kwargs): # real signature unknown
    pass

def TF_SessionRun_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrBool(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrBoolList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrFloat(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrFloatList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrFuncName(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrInt(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrIntList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrShape(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrShapeList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrString(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrStringList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrTensor(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrTensorList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrTensorShapeProto(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrTensorShapeProtoList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrType(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrTypeList(*args, **kwargs): # real signature unknown
    pass

def TF_SetAttrValueProto(*args, **kwargs): # real signature unknown
    pass

def TF_SetDevice(*args, **kwargs): # real signature unknown
    pass

def TF_SetStatus(*args, **kwargs): # real signature unknown
    pass

def TF_ShutdownCluster(*args, **kwargs): # real signature unknown
    pass

def TF_StringDecode(*args, **kwargs): # real signature unknown
    pass

def TF_StringEncode(*args, **kwargs): # real signature unknown
    pass

def TF_StringEncodedSize(*args, **kwargs): # real signature unknown
    pass

def TF_STRING_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_TensorByteSize(*args, **kwargs): # real signature unknown
    pass

def TF_TensorData(*args, **kwargs): # real signature unknown
    pass

def TF_TensorMaybeMove(*args, **kwargs): # real signature unknown
    pass

def TF_TensorType(*args, **kwargs): # real signature unknown
    pass

def TF_TryEvaluateConstant(*args, **kwargs): # real signature unknown
    pass

def TF_TryEvaluateConstant_wrapper(*args, **kwargs): # real signature unknown
    pass

def TF_UINT16_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_UINT32_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_UINT64_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_UINT8_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_UNAUTHENTICATED_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_UNAVAILABLE_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_UNIMPLEMENTED_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_UNKNOWN_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_VARIANT_swigconstant(*args, **kwargs): # real signature unknown
    pass

def TF_Version(*args, **kwargs): # real signature unknown
    pass

def TransformGraphWithStringInputs(*args, **kwargs): # real signature unknown
    pass

def TryFindKernelClass(*args, **kwargs): # real signature unknown
    pass

def UpdateEdge(*args, **kwargs): # real signature unknown
    pass

def WritableFile_Close(*args, **kwargs): # real signature unknown
    pass

def WritableFile_Flush(*args, **kwargs): # real signature unknown
    pass

def WritableFile_swigregister(*args, **kwargs): # real signature unknown
    pass

def WriteProfile(*args, **kwargs): # real signature unknown
    pass

def WriteStringToFile(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_compression_level_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_compression_level_set(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_compression_method_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_compression_method_set(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_compression_strategy_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_compression_strategy_set(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_flush_mode_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_flush_mode_set(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_input_buffer_size_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_input_buffer_size_set(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_mem_level_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_mem_level_set(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_output_buffer_size_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_output_buffer_size_set(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_swigregister(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_window_bits_get(*args, **kwargs): # real signature unknown
    pass

def ZlibCompressionOptions_window_bits_set(*args, **kwargs): # real signature unknown
    pass

def _TF_NewSessionOptions(*args, **kwargs): # real signature unknown
    pass

def _TF_SetConfig(*args, **kwargs): # real signature unknown
    pass

def _TF_SetTarget(*args, **kwargs): # real signature unknown
    pass

def __compiler_version___swigconstant(*args, **kwargs): # real signature unknown
    pass

def __cxx11_abi_flag___swigconstant(*args, **kwargs): # real signature unknown
    pass

def __git_version___swigconstant(*args, **kwargs): # real signature unknown
    pass

def __lshift__(*args, **kwargs): # real signature unknown
    pass

def __monolithic_build___swigconstant(*args, **kwargs): # real signature unknown
    pass

def __version___swigconstant(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4e902d4a20>'

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.python._pywrap_tensorflow_internal', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4e902d4a20>, origin='/usr/local/lib/python3.5/dist-packages/tensorflow/python/_pywrap_tensorflow_internal.so')"


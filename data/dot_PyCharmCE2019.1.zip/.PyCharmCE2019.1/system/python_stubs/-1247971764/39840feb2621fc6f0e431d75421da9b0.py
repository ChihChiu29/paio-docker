# encoding: utf-8
# module 39840feb2621fc6f0e431d75421da9b0
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def sparse_feature_cross(indices, values, shapes, dense, hashed_output, num_buckets, out_type, internal_type, name=None): # reliably restored by inspect
    """
    Generates sparse cross form a list of sparse tensors.
    
      The op takes two lists, one of 2D `SparseTensor` and one of 2D `Tensor`, each
      representing features of one feature column. It outputs a 2D `SparseTensor` with
      the batchwise crosses of these features.
    
      For example, if the inputs are
    
          inputs[0]: SparseTensor with shape = [2, 2]
          [0, 0]: "a"
          [1, 0]: "b"
          [1, 1]: "c"
    
          inputs[1]: SparseTensor with shape = [2, 1]
          [0, 0]: "d"
          [1, 0]: "e"
    
          inputs[2]: Tensor [["f"], ["g"]]
    
      then the output will be
    
          shape = [2, 2]
          [0, 0]: "a_X_d_X_f"
          [1, 0]: "b_X_e_X_g"
          [1, 1]: "c_X_e_X_g"
    
      if hashed_output=true then the output will be
    
          shape = [2, 2]
          [0, 0]: HashCombine(
                      Fingerprint64("f"), HashCombine(
                          Fingerprint64("d"), Fingerprint64("a")))
          [1, 0]: HashCombine(
                      Fingerprint64("g"), HashCombine(
                          Fingerprint64("e"), Fingerprint64("b")))
          [1, 1]: HashCombine(
                      Fingerprint64("g"), HashCombine(
                          Fingerprint64("e"), Fingerprint64("c")))
    
      Args:
        indices: A list of `Tensor` objects with type `int64`.
          2-D.  Indices of each input `SparseTensor`.
        values: A list of `Tensor` objects with types from: `int64`, `string`.
          1-D.   values of each `SparseTensor`.
        shapes: A list with the same length as `indices` of `Tensor` objects with type `int64`.
          1-D.   Shapes of each `SparseTensor`.
        dense: A list of `Tensor` objects with types from: `int64`, `string`.
          2-D.    Columns represented by dense `Tensor`.
        hashed_output: A `bool`.
        num_buckets: An `int` that is `>= 0`.
        out_type: A `tf.DType` from: `tf.int64, tf.string`.
        internal_type: A `tf.DType` from: `tf.int64, tf.string`.
        name: A name for the operation (optional).
    
      Returns:
        A tuple of `Tensor` objects (output_indices, output_values, output_shape).
    
        output_indices: A `Tensor` of type `int64`. 2-D.  Indices of the concatenated `SparseTensor`.
        output_values: A `Tensor` of type `out_type`. 1-D.  Non-empty values of the concatenated or hashed
          `SparseTensor`.
        output_shape: A `Tensor` of type `int64`. 1-D.  Shape of the concatenated `SparseTensor`.
    """
    pass

def sparse_feature_cross_eager_fallback(indices, values, shapes, dense, hashed_output, num_buckets, out_type, internal_type, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function sparse_feature_cross
    """
    pass

def sparse_feature_cross_v2(indices, values, shapes, dense, hashed_output, num_buckets, hash_key, out_type, internal_type, name=None): # reliably restored by inspect
    """
    Generates sparse cross form a list of sparse tensors.
    
      The op takes two lists, one of 2D `SparseTensor` and one of 2D `Tensor`, each
      representing features of one feature column. It outputs a 2D `SparseTensor` with
      the batchwise crosses of these features.
    
      For example, if the inputs are
    
          inputs[0]: SparseTensor with shape = [2, 2]
          [0, 0]: "a"
          [1, 0]: "b"
          [1, 1]: "c"
    
          inputs[1]: SparseTensor with shape = [2, 1]
          [0, 0]: "d"
          [1, 0]: "e"
    
          inputs[2]: Tensor [["f"], ["g"]]
    
      then the output will be
    
          shape = [2, 2]
          [0, 0]: "a_X_d_X_f"
          [1, 0]: "b_X_e_X_g"
          [1, 1]: "c_X_e_X_g"
    
      if hashed_output=true then the output will be
    
          shape = [2, 2]
          [0, 0]: FingerprintCat64(
                      Fingerprint64("f"), FingerprintCat64(
                          Fingerprint64("d"), Fingerprint64("a")))
          [1, 0]: FingerprintCat64(
                      Fingerprint64("g"), FingerprintCat64(
                          Fingerprint64("e"), Fingerprint64("b")))
          [1, 1]: FingerprintCat64(
                      Fingerprint64("g"), FingerprintCat64(
                          Fingerprint64("e"), Fingerprint64("c")))
    
      Args:
        indices: A list of `Tensor` objects with type `int64`.
          2-D.  Indices of each input `SparseTensor`.
        values: A list of `Tensor` objects with types from: `int64`, `string`.
          1-D.   values of each `SparseTensor`.
        shapes: A list with the same length as `indices` of `Tensor` objects with type `int64`.
          1-D.   Shapes of each `SparseTensor`.
        dense: A list of `Tensor` objects with types from: `int64`, `string`.
          2-D.    Columns represented by dense `Tensor`.
        hashed_output: A `bool`.
        num_buckets: An `int` that is `>= 0`.
        hash_key: An `int`.
        out_type: A `tf.DType` from: `tf.int64, tf.string`.
        internal_type: A `tf.DType` from: `tf.int64, tf.string`.
        name: A name for the operation (optional).
    
      Returns:
        A tuple of `Tensor` objects (output_indices, output_values, output_shape).
    
        output_indices: A `Tensor` of type `int64`. 2-D.  Indices of the concatenated `SparseTensor`.
        output_values: A `Tensor` of type `out_type`. 1-D.  Non-empty values of the concatenated or hashed
          `SparseTensor`.
        output_shape: A `Tensor` of type `int64`. 1-D.  Shape of the concatenated `SparseTensor`.
    """
    pass

def sparse_feature_cross_v2_eager_fallback(indices, values, shapes, dense, hashed_output, num_buckets, hash_key, out_type, internal_type, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function sparse_feature_cross_v2
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# classes

class _SparseFeatureCrossOutput(tuple):
    """ SparseFeatureCross(output_indices, output_values, output_shape) """
    def _asdict(self): # reliably restored by inspect
        """ Return a new OrderedDict which maps field names to their values. """
        pass

    @classmethod
    def _make(cls, *args, **kwargs): # real signature unknown
        """ Make a new SparseFeatureCross object from a sequence or iterable """
        pass

    def _replace(_self, **kwds): # reliably restored by inspect
        """ Return a new SparseFeatureCross object replacing specified fields with new values """
        pass

    def __getnewargs__(self): # reliably restored by inspect
        """ Return self as a plain tuple.  Used by copy and pickle. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(_cls, output_indices, output_values, output_shape): # reliably restored by inspect
        """ Create new instance of SparseFeatureCross(output_indices, output_values, output_shape) """
        pass

    def __repr__(self): # reliably restored by inspect
        """ Return a nicely formatted representation string """
        pass

    output_indices = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 0"""

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 2"""

    output_values = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 1"""


    _fields = (
        'output_indices',
        'output_values',
        'output_shape',
    )
    _source = "from builtins import property as _property, tuple as _tuple\nfrom operator import itemgetter as _itemgetter\nfrom collections import OrderedDict\n\nclass SparseFeatureCross(tuple):\n    'SparseFeatureCross(output_indices, output_values, output_shape)'\n\n    __slots__ = ()\n\n    _fields = ('output_indices', 'output_values', 'output_shape')\n\n    def __new__(_cls, output_indices, output_values, output_shape):\n        'Create new instance of SparseFeatureCross(output_indices, output_values, output_shape)'\n        return _tuple.__new__(_cls, (output_indices, output_values, output_shape))\n\n    @classmethod\n    def _make(cls, iterable, new=tuple.__new__, len=len):\n        'Make a new SparseFeatureCross object from a sequence or iterable'\n        result = new(cls, iterable)\n        if len(result) != 3:\n            raise TypeError('Expected 3 arguments, got %d' % len(result))\n        return result\n\n    def _replace(_self, **kwds):\n        'Return a new SparseFeatureCross object replacing specified fields with new values'\n        result = _self._make(map(kwds.pop, ('output_indices', 'output_values', 'output_shape'), _self))\n        if kwds:\n            raise ValueError('Got unexpected field names: %r' % list(kwds))\n        return result\n\n    def __repr__(self):\n        'Return a nicely formatted representation string'\n        return self.__class__.__name__ + '(output_indices=%r, output_values=%r, output_shape=%r)' % self\n\n    def _asdict(self):\n        'Return a new OrderedDict which maps field names to their values.'\n        return OrderedDict(zip(self._fields, self))\n\n    def __getnewargs__(self):\n        'Return self as a plain tuple.  Used by copy and pickle.'\n        return tuple(self)\n\n    output_indices = _property(_itemgetter(0), doc='Alias for field number 0')\n\n    output_values = _property(_itemgetter(1), doc='Alias for field number 1')\n\n    output_shape = _property(_itemgetter(2), doc='Alias for field number 2')\n\n"
    __slots__ = ()


class _SparseFeatureCrossV2Output(tuple):
    """ SparseFeatureCrossV2(output_indices, output_values, output_shape) """
    def _asdict(self): # reliably restored by inspect
        """ Return a new OrderedDict which maps field names to their values. """
        pass

    @classmethod
    def _make(cls, *args, **kwargs): # real signature unknown
        """ Make a new SparseFeatureCrossV2 object from a sequence or iterable """
        pass

    def _replace(_self, **kwds): # reliably restored by inspect
        """ Return a new SparseFeatureCrossV2 object replacing specified fields with new values """
        pass

    def __getnewargs__(self): # reliably restored by inspect
        """ Return self as a plain tuple.  Used by copy and pickle. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(_cls, output_indices, output_values, output_shape): # reliably restored by inspect
        """ Create new instance of SparseFeatureCrossV2(output_indices, output_values, output_shape) """
        pass

    def __repr__(self): # reliably restored by inspect
        """ Return a nicely formatted representation string """
        pass

    output_indices = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 0"""

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 2"""

    output_values = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 1"""


    _fields = (
        'output_indices',
        'output_values',
        'output_shape',
    )
    _source = "from builtins import property as _property, tuple as _tuple\nfrom operator import itemgetter as _itemgetter\nfrom collections import OrderedDict\n\nclass SparseFeatureCrossV2(tuple):\n    'SparseFeatureCrossV2(output_indices, output_values, output_shape)'\n\n    __slots__ = ()\n\n    _fields = ('output_indices', 'output_values', 'output_shape')\n\n    def __new__(_cls, output_indices, output_values, output_shape):\n        'Create new instance of SparseFeatureCrossV2(output_indices, output_values, output_shape)'\n        return _tuple.__new__(_cls, (output_indices, output_values, output_shape))\n\n    @classmethod\n    def _make(cls, iterable, new=tuple.__new__, len=len):\n        'Make a new SparseFeatureCrossV2 object from a sequence or iterable'\n        result = new(cls, iterable)\n        if len(result) != 3:\n            raise TypeError('Expected 3 arguments, got %d' % len(result))\n        return result\n\n    def _replace(_self, **kwds):\n        'Return a new SparseFeatureCrossV2 object replacing specified fields with new values'\n        result = _self._make(map(kwds.pop, ('output_indices', 'output_values', 'output_shape'), _self))\n        if kwds:\n            raise ValueError('Got unexpected field names: %r' % list(kwds))\n        return result\n\n    def __repr__(self):\n        'Return a nicely formatted representation string'\n        return self.__class__.__name__ + '(output_indices=%r, output_values=%r, output_shape=%r)' % self\n\n    def _asdict(self):\n        'Return a new OrderedDict which maps field names to their values.'\n        return OrderedDict(zip(self._fields, self))\n\n    def __getnewargs__(self):\n        'Return self as a plain tuple.  Used by copy and pickle.'\n        return tuple(self)\n\n    output_indices = _property(_itemgetter(0), doc='Alias for field number 0')\n\n    output_values = _property(_itemgetter(1), doc='Alias for field number 1')\n\n    output_shape = _property(_itemgetter(2), doc='Alias for field number 2')\n\n"
    __slots__ = ()


# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7e388dcf0>"

_sparse_feature_cross_outputs = [
    'output_indices',
    'output_values',
    'output_shape',
]

_sparse_feature_cross_v2_outputs = [
    'output_indices',
    'output_values',
    'output_shape',
]


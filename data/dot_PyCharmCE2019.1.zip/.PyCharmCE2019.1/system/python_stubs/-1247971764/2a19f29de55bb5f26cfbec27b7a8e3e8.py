# encoding: utf-8
# module 2a19f29de55bb5f26cfbec27b7a8e3e8
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def create_tree_variable(tree_handle, tree_config, params, name=None): # reliably restored by inspect
    """
    Creates a tree  model and returns a handle to it.
    
      Args:
        tree_handle: A `Tensor` of type `resource`.
          handle to the tree resource to be created.
        tree_config: A `Tensor` of type `string`. Serialized proto of the tree.
        params: A `string`. A serialized TensorForestParams proto.
        name: A name for the operation (optional).
    
      Returns:
        The created Operation.
    """
    pass

def create_tree_variable_eager_fallback(tree_handle, tree_config, params, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function create_tree_variable
    """
    pass

def decision_tree_resource_handle_op(container=None, shared_name=None, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        container: An optional `string`. Defaults to `""`.
        shared_name: An optional `string`. Defaults to `""`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `resource`.
    """
    pass

def decision_tree_resource_handle_op_eager_fallback(container=None, shared_name=None, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function decision_tree_resource_handle_op
    """
    pass

def feature_usage_counts(tree_handle, params, name=None): # reliably restored by inspect
    """
    Outputs the number of times each feature was used in a split.
    
      Args:
        tree_handle: A `Tensor` of type `resource`. The handle to the tree.
        params: A `string`. A serialized TensorForestParams proto.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int32`.
        `feature_counts[i]` is the number of times feature i was used
        in a split.
    """
    pass

def feature_usage_counts_eager_fallback(tree_handle, params, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function feature_usage_counts
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def traverse_tree_v4(tree_handle, input_data, sparse_input_indices, sparse_input_values, sparse_input_shape, input_spec, params, name=None): # reliably restored by inspect
    """
    Outputs the leaf ids for the given input data.
    
      Args:
        tree_handle: A `Tensor` of type `resource`. The handle to the tree.
        input_data: A `Tensor` of type `float32`.
          The training batch's features as a 2-d tensor; `input_data[i][j]`
          gives the j-th feature of the i-th input.
        sparse_input_indices: A `Tensor` of type `int64`.
          The indices tensor from the SparseTensor input.
        sparse_input_values: A `Tensor` of type `float32`.
          The values tensor from the SparseTensor input.
        sparse_input_shape: A `Tensor` of type `int64`.
          The shape tensor from the SparseTensor input.
        input_spec: A `string`.
        params: A `string`. A serialized TensorForestParams proto.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int32`. `leaf_ids[i]` is the leaf id for input i.
    """
    pass

def traverse_tree_v4_eager_fallback(tree_handle, input_data, sparse_input_indices, sparse_input_values, sparse_input_shape, input_spec, params, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function traverse_tree_v4
    """
    pass

def tree_deserialize(tree_handle, tree_config, params, name=None): # reliably restored by inspect
    """
    Deserializes a serialized tree config and replaces current tree.
    
      Args:
        tree_handle: A `Tensor` of type `resource`. The handle to the tree .
        tree_config: A `Tensor` of type `string`. Serialized proto of the .
        params: A `string`. A serialized TensorForestParams proto.
        name: A name for the operation (optional).
    
      Returns:
        The created Operation.
    """
    pass

def tree_deserialize_eager_fallback(tree_handle, tree_config, params, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function tree_deserialize
    """
    pass

def tree_is_initialized_op(tree_handle, name=None): # reliably restored by inspect
    """
    Checks whether a tree has been initialized.
    
      Args:
        tree_handle: A `Tensor` of type `resource`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `bool`.
    """
    pass

def tree_is_initialized_op_eager_fallback(tree_handle, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function tree_is_initialized_op
    """
    pass

def tree_predictions_v4(tree_handle, input_data, sparse_input_indices, sparse_input_values, sparse_input_shape, input_spec, params, name=None): # reliably restored by inspect
    """
    Outputs the predictions for the given input data.
    
      Args:
        tree_handle: A `Tensor` of type `resource`. The handle to the tree.
        input_data: A `Tensor` of type `float32`.
          The training batch's features as a 2-d tensor; `input_data[i][j]`
          gives the j-th feature of the i-th input.
        sparse_input_indices: A `Tensor` of type `int64`.
          The indices tensor from the SparseTensor input.
        sparse_input_values: A `Tensor` of type `float32`.
          The values tensor from the SparseTensor input.
        sparse_input_shape: A `Tensor` of type `int64`.
          The shape tensor from the SparseTensor input.
        input_spec: A `string`.
        params: A `string`. A serialized TensorForestParams proto.
        name: A name for the operation (optional).
    
      Returns:
        A tuple of `Tensor` objects (predictions, tree_paths).
    
        predictions: A `Tensor` of type `float32`. `predictions[i][j]` is the probability that input i is class j.
        tree_paths: A `Tensor` of type `string`. `tree_paths[i]` is a serialized TreePath proto for example i.
    """
    pass

def tree_predictions_v4_eager_fallback(tree_handle, input_data, sparse_input_indices, sparse_input_values, sparse_input_shape, input_spec, params, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function tree_predictions_v4
    """
    pass

def tree_serialize(tree_handle, name=None): # reliably restored by inspect
    """
    Serializes the tree  to a proto.
    
      Args:
        tree_handle: A `Tensor` of type `resource`. The handle to the tree.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `string`. Serialized proto of the tree.
    """
    pass

def tree_serialize_eager_fallback(tree_handle, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function tree_serialize
    """
    pass

def tree_size(tree_handle, name=None): # reliably restored by inspect
    """
    Outputs the size of the tree, including leaves.
    
      Args:
        tree_handle: A `Tensor` of type `resource`. The handle to the tree.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int32`. Size scalar.
    """
    pass

def tree_size_eager_fallback(tree_handle, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function tree_size
    """
    pass

def update_model_v4(tree_handle, leaf_ids, input_labels, input_weights, params, name=None): # reliably restored by inspect
    """
    Updates the given leaves for each example with the new labels.
    
      Args:
        tree_handle: A `Tensor` of type `resource`. The handle to the tree.
        leaf_ids: A `Tensor` of type `int32`.
          `leaf_ids[i]` is the leaf id for input i.
        input_labels: A `Tensor` of type `float32`.
          The training batch's labels as a 1 or 2-d tensor.
          'input_labels[i][j]' gives the j-th label/target for the i-th input.
        input_weights: A `Tensor` of type `float32`.
          The training batch's weights as a 1-d tensor.
          'input_weights[i]' gives the weight for the i-th input.
        params: A `string`. A serialized TensorForestParams proto.
        name: A name for the operation (optional).
    
      Returns:
        The created Operation.
    """
    pass

def update_model_v4_eager_fallback(tree_handle, leaf_ids, input_labels, input_weights, params, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function update_model_v4
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# classes

class _TreePredictionsV4Output(tuple):
    """ TreePredictionsV4(predictions, tree_paths) """
    def _asdict(self): # reliably restored by inspect
        """ Return a new OrderedDict which maps field names to their values. """
        pass

    @classmethod
    def _make(cls, *args, **kwargs): # real signature unknown
        """ Make a new TreePredictionsV4 object from a sequence or iterable """
        pass

    def _replace(_self, **kwds): # reliably restored by inspect
        """ Return a new TreePredictionsV4 object replacing specified fields with new values """
        pass

    def __getnewargs__(self): # reliably restored by inspect
        """ Return self as a plain tuple.  Used by copy and pickle. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(_cls, predictions, tree_paths): # reliably restored by inspect
        """ Create new instance of TreePredictionsV4(predictions, tree_paths) """
        pass

    def __repr__(self): # reliably restored by inspect
        """ Return a nicely formatted representation string """
        pass

    predictions = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 0"""

    tree_paths = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 1"""


    _fields = (
        'predictions',
        'tree_paths',
    )
    _source = "from builtins import property as _property, tuple as _tuple\nfrom operator import itemgetter as _itemgetter\nfrom collections import OrderedDict\n\nclass TreePredictionsV4(tuple):\n    'TreePredictionsV4(predictions, tree_paths)'\n\n    __slots__ = ()\n\n    _fields = ('predictions', 'tree_paths')\n\n    def __new__(_cls, predictions, tree_paths):\n        'Create new instance of TreePredictionsV4(predictions, tree_paths)'\n        return _tuple.__new__(_cls, (predictions, tree_paths))\n\n    @classmethod\n    def _make(cls, iterable, new=tuple.__new__, len=len):\n        'Make a new TreePredictionsV4 object from a sequence or iterable'\n        result = new(cls, iterable)\n        if len(result) != 2:\n            raise TypeError('Expected 2 arguments, got %d' % len(result))\n        return result\n\n    def _replace(_self, **kwds):\n        'Return a new TreePredictionsV4 object replacing specified fields with new values'\n        result = _self._make(map(kwds.pop, ('predictions', 'tree_paths'), _self))\n        if kwds:\n            raise ValueError('Got unexpected field names: %r' % list(kwds))\n        return result\n\n    def __repr__(self):\n        'Return a nicely formatted representation string'\n        return self.__class__.__name__ + '(predictions=%r, tree_paths=%r)' % self\n\n    def _asdict(self):\n        'Return a new OrderedDict which maps field names to their values.'\n        return OrderedDict(zip(self._fields, self))\n\n    def __getnewargs__(self):\n        'Return self as a plain tuple.  Used by copy and pickle.'\n        return tuple(self)\n\n    predictions = _property(_itemgetter(0), doc='Alias for field number 0')\n\n    tree_paths = _property(_itemgetter(1), doc='Alias for field number 1')\n\n"
    __slots__ = ()


# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7ddc645a0>"

_tree_predictions_v4_outputs = [
    'predictions',
    'tree_paths',
]


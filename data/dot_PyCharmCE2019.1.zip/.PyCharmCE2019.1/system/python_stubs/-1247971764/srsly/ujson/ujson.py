# encoding: utf-8
# module srsly.ujson.ujson
# from /usr/local/lib/python3.5/dist-packages/srsly/ujson/ujson.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__version__ = '1.35'

# functions

def decode(*args, **kwargs): # real signature unknown
    """ Converts JSON as string to dict object structure. Use precise_float=True to use high precision float decoder. """
    pass

def dump(*args, **kwargs): # real signature unknown
    """ Converts arbitrary object recursively into JSON file. Use ensure_ascii=false to output UTF-8. Pass in double_precision to alter the maximum digit precision of doubles. Set encode_html_chars=True to encode < > & as unicode escape sequences. Set escape_forward_slashes=False to prevent escaping / characters. """
    pass

def dumps(*args, **kwargs): # real signature unknown
    """ Converts arbitrary object recursively into JSON. Use ensure_ascii=false to output UTF-8. Pass in double_precision to alter the maximum digit precision of doubles. Set encode_html_chars=True to encode < > & as unicode escape sequences. Set escape_forward_slashes=False to prevent escaping / characters. """
    pass

def encode(*args, **kwargs): # real signature unknown
    """ Converts arbitrary object recursively into JSON. Use ensure_ascii=false to output UTF-8. Pass in double_precision to alter the maximum digit precision of doubles. Set encode_html_chars=True to encode < > & as unicode escape sequences. Set escape_forward_slashes=False to prevent escaping / characters. """
    pass

def load(*args, **kwargs): # real signature unknown
    """ Converts JSON as file to dict object structure. Use precise_float=True to use high precision float decoder. """
    pass

def loads(*args, **kwargs): # real signature unknown
    """ Converts JSON as string to dict object structure. Use precise_float=True to use high precision float decoder. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f759fd76710>'

__spec__ = None # (!) real value is "ModuleSpec(name='srsly.ujson.ujson', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f759fd76710>, origin='/usr/local/lib/python3.5/dist-packages/srsly/ujson/ujson.cpython-35m-x86_64-linux-gnu.so')"


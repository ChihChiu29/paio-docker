# encoding: utf-8
# module srsly.msgpack._packer
# from /usr/local/lib/python3.5/dist-packages/srsly/msgpack/_packer.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import srsly.msgpack._ext_type as __srsly_msgpack__ext_type


# functions

def ensure_bytes(string): # reliably restored by inspect
    """ Ensure a string is returned as a bytes object, encoded as utf8. """
    pass

# classes

class ExtType(__srsly_msgpack__ext_type.ExtType):
    """ ExtType represents ext type in msgpack. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(cls, code, data): # reliably restored by inspect
        # no doc
        pass

    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'srsly.msgpack._ext_type', '__dict__': <attribute '__dict__' of 'ExtType' objects>, '__doc__': 'ExtType represents ext type in msgpack.', '__new__': <staticmethod object at 0x7fa9591a1da0>})"


class Packer(object):
    """
    MessagePack Packer
    
        usage::
    
            packer = Packer()
            astream.write(packer.pack(a))
            astream.write(packer.pack(b))
    
        Packer's constructor has some keyword arguments:
    
        :param callable default:
            Convert user type to builtin type that Packer supports.
            See also simplejson's document.
    
        :param bool use_single_float:
            Use single precision float type for float. (default: False)
    
        :param bool autoreset:
            Reset buffer after each pack and return its content as `bytes`. (default: True).
            If set this to false, use `bytes()` to get content and `.reset()` to clear buffer.
    
        :param bool use_bin_type:
            Use bin type introduced in msgpack spec 2.0 for bytes.
            It also enables str8 type for unicode.
            Current default value is false, but it will be changed to true
            in future version.  You should specify it explicitly.
    
        :param bool strict_types:
            If set to true, types will be checked to be exact. Derived classes
            from serializeable types will not be serialized and will be
            treated as unsupported type and forwarded to default.
            Additionally tuples will not be serialized as lists.
            This is useful when trying to implement accurate serialization
            for python types.
    
        :param str unicode_errors:
            Error handler for encoding unicode. (default: 'strict')
    
        :param str encoding:
            (deprecated) Convert unicode to bytes with this encoding. (default: 'utf-8')
    """
    def bytes(self, *args, **kwargs): # real signature unknown
        """ Return internal buffer contents as bytes object """
        pass

    def getbuffer(self, *args, **kwargs): # real signature unknown
        """ Return view of internal buffer. """
        pass

    def pack(self, *args, **kwargs): # real signature unknown
        pass

    def pack_array_header(self, *args, **kwargs): # real signature unknown
        pass

    def pack_ext_type(self, *args, **kwargs): # real signature unknown
        pass

    def pack_map_header(self, *args, **kwargs): # real signature unknown
        pass

    def pack_map_pairs(self, *args, **kwargs): # real signature unknown
        """
        Pack *pairs* as msgpack map type.
        
                *pairs* should be a sequence of pairs.
                (`len(pairs)` and `for k, v in pairs:` should be supported.)
        """
        pass

    def reset(self, *args, **kwargs): # real signature unknown
        """
        Reset internal buffer.
        
                This method is usaful only when autoreset=False.
        """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fa95918d5a0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa9591a1710>'

__spec__ = None # (!) real value is "ModuleSpec(name='srsly.msgpack._packer', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa9591a1710>, origin='/usr/local/lib/python3.5/dist-packages/srsly/msgpack/_packer.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module pandas._libs.indexing
# from /usr/local/lib/python3.5/dist-packages/pandas/_libs/indexing.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def __pyx_unpickle__NDFrameIndexerBase(*args, **kwargs): # real signature unknown
    pass

# classes

class _NDFrameIndexerBase(object):
    """
    A base class for _NDFrameIndexer for fast instantiation and attribute
        access.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ndim = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    obj = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _ndim = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f2059a9bdd8>'

__spec__ = None # (!) real value is "ModuleSpec(name='pandas._libs.indexing', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f2059a9bdd8>, origin='/usr/local/lib/python3.5/dist-packages/pandas/_libs/indexing.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


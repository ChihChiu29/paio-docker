# encoding: utf-8
# module pandas._libs.writers
# from /usr/local/lib/python3.5/dist-packages/pandas/_libs/writers.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def convert_json_to_lines(*args, **kwargs): # real signature unknown
    """
    replace comma separated json with line feeds, paying special attention
        to quotes & brackets
    """
    pass

def max_len_string_array(*args, **kwargs): # real signature unknown
    """ return the maximum size of elements in a 1-dim string array """
    pass

def string_array_replace_from_nan_rep(*args, **kwargs): # real signature unknown
    """
    Replace the values in the array with 'replacement' if
        they are 'nan_rep'. Return the same array.
    """
    pass

def write_csv_rows(*args, **kwargs): # real signature unknown
    """
    Write the given data to the writer object, pre-allocating where possible
        for performance improvements.
    
        Parameters
        ----------
        data : list
        data_index : ndarray
        nlevels : int
        cols : ndarray
        writer : object
    """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f587e4a2080>'

__spec__ = None # (!) real value is "ModuleSpec(name='pandas._libs.writers', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f587e4a2080>, origin='/usr/local/lib/python3.5/dist-packages/pandas/_libs/writers.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


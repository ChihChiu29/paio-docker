# encoding: utf-8
# module pandas._libs.reshape
# from /usr/local/lib/python3.5/dist-packages/pandas/_libs/reshape.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def unstack(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_float32(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_float64(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_int16(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_int32(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_int64(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_int8(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_object(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_uint16(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_uint32(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_uint64(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def unstack_uint8(*args, **kwargs): # real signature unknown
    """
    transform long sorted_values to wide new_values
    
        Parameters
        ----------
        values : typed ndarray
        mask : boolean ndarray
        stride : int
        length : int
        width : int
        new_values : typed ndarray
            result array
        new_mask : boolean ndarray
            result mask
    """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f2a9fa211d0>'

__spec__ = None # (!) real value is "ModuleSpec(name='pandas._libs.reshape', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f2a9fa211d0>, origin='/usr/local/lib/python3.5/dist-packages/pandas/_libs/reshape.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


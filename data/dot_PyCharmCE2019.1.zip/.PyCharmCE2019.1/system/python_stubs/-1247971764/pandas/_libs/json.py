# encoding: utf-8
# module pandas._libs.json calls itself _libjson
# from /usr/local/lib/python3.5/dist-packages/pandas/_libs/json.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__version__ = '1.33'

# functions

def decode(*args, **kwargs): # real signature unknown
    """ Converts JSON as string to dict object structure. Use precise_float=True to use high precision float decoder. """
    pass

def dump(*args, **kwargs): # real signature unknown
    """ Converts arbitrary object recursively into JSON file. Use ensure_ascii=false to output UTF-8. Pass in double_precision to alter the maximum digit precision of doubles. Set encode_html_chars=True to encode < > & as unicode escape sequences. """
    pass

def dumps(*args, **kwargs): # real signature unknown
    """ Converts arbitrary object recursively into JSON. Use ensure_ascii=false to output UTF-8. Pass in double_precision to alter the maximum digit precision of doubles. Set encode_html_chars=True to encode < > & as unicode escape sequences. """
    pass

def encode(*args, **kwargs): # real signature unknown
    """ Converts arbitrary object recursively into JSON. Use ensure_ascii=false to output UTF-8. Pass in double_precision to alter the maximum digit precision of doubles. Set encode_html_chars=True to encode < > & as unicode escape sequences. """
    pass

def load(*args, **kwargs): # real signature unknown
    """ Converts JSON as file to dict object structure. Use precise_float=True to use high precision float decoder. """
    pass

def loads(*args, **kwargs): # real signature unknown
    """ Converts JSON as string to dict object structure. Use precise_float=True to use high precision float decoder. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8cf223c160>'

__spec__ = None # (!) real value is "ModuleSpec(name='pandas._libs.json', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8cf223c160>, origin='/usr/local/lib/python3.5/dist-packages/pandas/_libs/json.cpython-35m-x86_64-linux-gnu.so')"


# encoding: utf-8
# module pandas.io.sas._sas
# from /usr/local/lib/python3.5/dist-packages/pandas/io/sas/_sas.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import pandas.io.sas.sas_constants as const # /usr/local/lib/python3.5/dist-packages/pandas/io/sas/sas_constants.py
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Parser(object):
    # no doc
    def read(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fc1787003c0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc178227b00>'

__spec__ = None # (!) real value is "ModuleSpec(name='pandas.io.sas._sas', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc178227b00>, origin='/usr/local/lib/python3.5/dist-packages/pandas/io/sas/_sas.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


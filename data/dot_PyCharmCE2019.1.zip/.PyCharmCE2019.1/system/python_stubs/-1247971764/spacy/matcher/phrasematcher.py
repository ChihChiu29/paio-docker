# encoding: utf-8
# module spacy.matcher.phrasematcher
# from /usr/local/lib/python3.5/dist-packages/spacy/matcher/phrasematcher.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values

B2_ENT = 60

B3_ENT = 59

B4_ENT = 58

I3_ENT = 42

I4_ENT = 41

L2_ENT = 43

L3_ENT = 42

L4_ENT = 41

U_ENT = 61

# functions

def deprecation_warning(message): # reliably restored by inspect
    # no doc
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_bilou(*args, **kwargs): # real signature unknown
    pass

def unpickle_matcher(*args, **kwargs): # real signature unknown
    pass

def user_warning(message): # reliably restored by inspect
    # no doc
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class PhraseMatcher(object):
    """
    Efficiently match large terminology lists. While the `Matcher` matches
        sequences based on lists of token descriptions, the `PhraseMatcher` accepts
        match patterns in the form of `Doc` objects.
    
        DOCS: https://spacy.io/api/phrasematcher
        USAGE: https://spacy.io/usage/rule-based-matching#phrasematcher
    """
    def accept_match(self, *args, **kwargs): # real signature unknown
        pass

    def add(self, *args, **kwargs): # real signature unknown
        """
        Add a match-rule to the phrase-matcher. A match-rule consists of: an ID
                key, an on_match callback, and one or more patterns.
        
                key (unicode): The match ID.
                on_match (callable): Callback executed on match.
                *docs (Doc): `Doc` objects representing match patterns.
        
                DOCS: https://spacy.io/api/phrasematcher#add
        """
        pass

    def get_lex_value(self, *args, **kwargs): # real signature unknown
        pass

    def pipe(self, *args, **kwargs): # real signature unknown
        """
        Match a stream of documents, yielding them in turn.
        
                docs (iterable): A stream of documents.
                batch_size (int): Number of documents to accumulate into a working set.
                return_matches (bool): Yield the match lists along with the docs, making
                    results (doc, matches) tuples.
                as_tuples (bool): Interpret the input stream as (doc, context) tuples,
                    and yield (result, context) tuples out.
                    If both return_matches and as_tuples are True, the output will
                    be a sequence of ((doc, matches), context) tuples.
                YIELDS (Doc): Documents, in order.
        
                DOCS: https://spacy.io/api/phrasematcher#pipe
        """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """
        Find all sequences matching the supplied patterns on the `Doc`.
        
                doc (Doc): The document to match over.
                RETURNS (list): A list of `(key, start, end)` tuples,
                    describing the matches. A match tuple describes a span
                    `doc[start:end]`. The `label_id` and `key` are both integers.
        
                DOCS: https://spacy.io/api/phrasematcher#call
        """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """
        Check whether the matcher contains rules for a match ID.
        
                key (unicode): The match ID.
                RETURNS (bool): Whether the matcher contains rules for this match ID.
        
                DOCS: https://spacy.io/api/phrasematcher#contains
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initialize the PhraseMatcher.
        
                vocab (Vocab): The shared vocabulary.
                attr (int / unicode): Token attribute to match on.
                validate (bool): Perform additional validation when patterns are added.
                RETURNS (PhraseMatcher): The newly constructed object.
        
                DOCS: https://spacy.io/api/phrasematcher#init
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        Get the number of rules added to the matcher. Note that this only
                returns the number of rules (identical with the number of IDs), not the
                number of individual patterns.
        
                RETURNS (int): The number of rules.
        
                DOCS: https://spacy.io/api/phrasematcher#len
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    _callbacks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _docs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _patterns = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _validate = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f02273a04e0>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.matcher.phrasematcher', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f02273a04e0>, origin='/usr/local/lib/python3.5/dist-packages/spacy/matcher/phrasematcher.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


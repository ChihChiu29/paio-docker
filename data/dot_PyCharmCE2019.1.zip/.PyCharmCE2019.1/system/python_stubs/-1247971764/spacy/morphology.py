# encoding: utf-8
# module spacy.morphology
# from /usr/local/lib/python3.5/dist-packages/spacy/morphology.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
from spacy.attrs import intify_attrs


# Variables with simple values

Abbr_yes  = 224

AdpType_circ  = 229
AdpType_comprep  = 228
AdpType_post  = 226
AdpType_prep  = 225
AdpType_voc  = 227

AdvType_adadj = 238
AdvType_cau = 234
AdvType_deg = 233
AdvType_ex = 237
AdvType_loc = 231
AdvType_man = 230
AdvType_mod = 235
AdvType_sta = 236
AdvType_tim = 232

Animacy_anim = 104
Animacy_hum = 106
Animacy_inan = 105
Animacy_nhum = 107

Aspect_freq = 108
Aspect_imp = 109
Aspect_mod = 110
Aspect_none = 111
Aspect_perf = 112

Case_abe = 113
Case_abl = 114
Case_abs = 115
Case_acc = 116
Case_ade = 117
Case_all = 118
Case_cau = 119
Case_com = 120
Case_dat = 121
Case_del = 122
Case_dis = 123
Case_ela = 124
Case_ess = 125
Case_gen = 126
Case_ill = 127
Case_ine = 128
Case_ins = 129
Case_lat = 131
Case_loc = 130
Case_nom = 132
Case_par = 133
Case_sub = 134
Case_sup = 135
Case_tem = 136
Case_ter = 137
Case_tra = 138
Case_voc = 139

ConjType_comp  = 240
ConjType_oper  = 239

Connegative_yes  = 241

Definite_cons = 143
Definite_def = 141
Definite_ind = 144
Definite_red = 142
Definite_two = 140

Degree_abs = 150
Degree_cmp = 145
Degree_com = 151
Degree_comp = 146
Degree_dim  = 152
Degree_none = 147
Degree_pos = 148
Degree_sup = 149

Derivation_inen  = 244
Derivation_ja  = 246
Derivation_lainen  = 245
Derivation_minen  = 242
Derivation_sti  = 243
Derivation_ton  = 247
Derivation_ttaa  = 250
Derivation_ttain  = 249
Derivation_vs  = 248

Echo_ech  = 252
Echo_rdp  = 251

Foreign_foreign  = 253
Foreign_fscript  = 254
Foreign_tscript  = 255
Foreign_yes  = 256

Gender_com = 153

Gender_dat_fem  = 258
Gender_dat_masc  = 257

Gender_erg_fem  = 260
Gender_erg_masc  = 259

Gender_fem = 154
Gender_masc = 155
Gender_neut = 156

Gender_psor_fem  = 262
Gender_psor_masc  = 261
Gender_psor_neut  = 263

Hyph_yes  = 264

InfForm_one  = 265
InfForm_three  = 267
InfForm_two  = 266

key = 'VerbType_light '

LEMMA = 73

Mood_cnd = 157
Mood_imp = 158
Mood_ind = 159
Mood_n = 160
Mood_opt = 163
Mood_pot = 161
Mood_sub = 162

NameType_com  = 273
NameType_geo  = 268
NameType_giv  = 270
NameType_nat  = 272
NameType_oth  = 275
NameType_pro  = 274
NameType_prs  = 269
NameType_sur  = 271

Negative_neg = 164
Negative_pos = 165
Negative_yes = 166

NounType_class  = 278
NounType_com  = 276
NounType_prop  = 277

Number_abs_plur  = 280
Number_abs_sing  = 279

Number_com = 169
Number_count  = 175

Number_dat_plur  = 282
Number_dat_sing  = 281

Number_dual = 170

Number_erg_plur  = 284
Number_erg_sing  = 283

Number_none = 171
Number_plur = 172

Number_psee_plur  = 286
Number_psee_sing  = 285

Number_psor_plur  = 288
Number_psor_sing  = 287

Number_ptan  = 174
Number_sing = 173

NumForm_digit  = 289
NumForm_roman  = 290
NumForm_word  = 291

NumType_card = 176
NumType_dist = 177
NumType_frac = 178
NumType_gen = 179
NumType_mult = 180
NumType_none = 181
NumType_ord = 182
NumType_sets = 183

NumValue_one  = 292
NumValue_three  = 294
NumValue_two  = 293

PartForm_agt  = 297
PartForm_neg  = 298
PartForm_past  = 296
PartForm_pres  = 295

PartType_emp  = 300
PartType_inf  = 302
PartType_mod  = 299
PartType_res  = 301
PartType_vbp  = 303

Person_abs_one  = 304
Person_abs_three  = 306
Person_abs_two  = 305

Person_dat_one  = 307
Person_dat_three  = 309
Person_dat_two  = 308

Person_erg_one  = 310
Person_erg_three  = 312
Person_erg_two  = 311

Person_none = 187
Person_one = 184

Person_psor_one  = 313
Person_psor_three  = 315
Person_psor_two  = 314

Person_three = 186
Person_two = 185

Polarity_neg = 167
Polarity_pos = 168

Polite_abs_inf  = 318
Polite_abs_pol  = 319

Polite_dat_inf  = 322
Polite_dat_pol  = 323

Polite_erg_inf  = 320
Polite_erg_pol  = 321

Polite_inf  = 316
Polite_pol  = 317

Poss_yes = 188

Prefix_yes  = 324

PrepCase_npr  = 325
PrepCase_pre  = 326

PronType_advPart = 189
PronType_art = 190
PronType_clit = 200
PronType_default = 191
PronType_dem = 192
PronType_exc  = 201
PronType_ind = 193
PronType_int = 194
PronType_neg = 195
PronType_prs = 196
PronType_rcp = 197
PronType_rel = 198
PronType_tot = 199

PunctSide_fin  = 328
PunctSide_ini  = 327

PunctType_brck  = 333
PunctType_colo  = 335
PunctType_comm  = 334
PunctType_dash  = 337
PunctType_excl  = 331
PunctType_peri  = 329
PunctType_qest  = 330
PunctType_quot  = 332
PunctType_semi  = 336

Reflex_yes = 202

StyleVariant_styleBound  = 350
StyleVariant_styleShort  = 349

Style_arch  = 338
Style_coll  = 342
Style_derg  = 346
Style_expr  = 345
Style_norm  = 341
Style_poet  = 340
Style_rare  = 339
Style_sing  = 344
Style_vrnc  = 343
Style_vulg  = 347
Style_yes  = 348

Tense_fut = 203
Tense_imp = 204
Tense_past = 205
Tense_pres = 206

value = 354

VerbForm_conv = 217
VerbForm_fin = 207
VerbForm_gdv  = 218
VerbForm_ger = 208
VerbForm_inf = 209
VerbForm_none = 210
VerbForm_part = 211
VerbForm_partFut = 212
VerbForm_partPast = 213
VerbForm_partPres = 214
VerbForm_sup = 215
VerbForm_trans = 216

VerbType_aux  = 351
VerbType_cop  = 352
VerbType_light  = 354
VerbType_mod  = 353

Voice_act = 219
Voice_cau = 220
Voice_int  = 223
Voice_mid  = 222
Voice_pass = 221

# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def _normalize_props(*args, **kwargs): # real signature unknown
    """ Transform deprecated string keys to correct names. """
    pass

# classes

class Morphology(object):
    # no doc
    def add_special_case(self, *args, **kwargs): # real signature unknown
        """
        Add a special-case rule to the morphological analyser. Tokens whose
                tag and orth match the rule will receive the specified properties.
        
                tag (unicode): The part-of-speech tag to key the exception.
                orth (unicode): The word-form to key the exception.
        """
        pass

    def lemmatize(self, *args, **kwargs): # real signature unknown
        pass

    def load_morph_exceptions(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    exc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    lemmatizer = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    mem = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    n_tags = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    reverse_index = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    strings = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tag_map = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tag_names = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f4a91d39570>'


# variables with complex values

IDS = {
    'Abbr_yes ': 224,
    'AdpType_circ ': 229,
    'AdpType_comprep ': 228,
    'AdpType_post ': 226,
    'AdpType_prep ': 225,
    'AdpType_voc ': 227,
    'AdvType_adadj': 238,
    'AdvType_cau': 234,
    'AdvType_deg': 233,
    'AdvType_ex': 237,
    'AdvType_loc': 231,
    'AdvType_man': 230,
    'AdvType_mod': 235,
    'AdvType_sta': 236,
    'AdvType_tim': 232,
    'Animacy_anim': 104,
    'Animacy_hum': 106,
    'Animacy_inan': 105,
    'Animacy_nhum': 107,
    'Aspect_freq': 108,
    'Aspect_imp': 109,
    'Aspect_mod': 110,
    'Aspect_none': 111,
    'Aspect_perf': 112,
    'Case_abe': 113,
    'Case_abl': 114,
    'Case_abs': 115,
    'Case_acc': 116,
    'Case_ade': 117,
    'Case_all': 118,
    'Case_cau': 119,
    'Case_com': 120,
    'Case_dat': 121,
    'Case_del': 122,
    'Case_dis': 123,
    'Case_ela': 124,
    'Case_ess': 125,
    'Case_gen': 126,
    'Case_ill': 127,
    'Case_ine': 128,
    'Case_ins': 129,
    'Case_lat': 131,
    'Case_loc': 130,
    'Case_nom': 132,
    'Case_par': 133,
    'Case_sub': 134,
    'Case_sup': 135,
    'Case_tem': 136,
    'Case_ter': 137,
    'Case_tra': 138,
    'Case_voc': 139,
    'ConjType_comp ': 240,
    'ConjType_oper ': 239,
    'Connegative_yes ': 241,
    'Definite_cons': 143,
    'Definite_def': 141,
    'Definite_ind': 144,
    'Definite_red': 142,
    'Definite_two': 140,
    'Degree_abs': 150,
    'Degree_cmp': 145,
    'Degree_com': 151,
    'Degree_comp': 146,
    'Degree_dim ': 152,
    'Degree_none': 147,
    'Degree_pos': 148,
    'Degree_sup': 149,
    'Derivation_inen ': 244,
    'Derivation_ja ': 246,
    'Derivation_lainen ': 245,
    'Derivation_minen ': 242,
    'Derivation_sti ': 243,
    'Derivation_ton ': 247,
    'Derivation_ttaa ': 250,
    'Derivation_ttain ': 249,
    'Derivation_vs ': 248,
    'Echo_ech ': 252,
    'Echo_rdp ': 251,
    'Foreign_foreign ': 253,
    'Foreign_fscript ': 254,
    'Foreign_tscript ': 255,
    'Foreign_yes ': 256,
    'Gender_com': 153,
    'Gender_dat_fem ': 258,
    'Gender_dat_masc ': 257,
    'Gender_erg_fem ': 260,
    'Gender_erg_masc ': 259,
    'Gender_fem': 154,
    'Gender_masc': 155,
    'Gender_neut': 156,
    'Gender_psor_fem ': 262,
    'Gender_psor_masc ': 261,
    'Gender_psor_neut ': 263,
    'Hyph_yes ': 264,
    'InfForm_one ': 265,
    'InfForm_three ': 267,
    'InfForm_two ': 266,
    'Mood_cnd': 157,
    'Mood_imp': 158,
    'Mood_ind': 159,
    'Mood_n': 160,
    'Mood_opt': 163,
    'Mood_pot': 161,
    'Mood_sub': 162,
    'NameType_com ': 273,
    'NameType_geo ': 268,
    'NameType_giv ': 270,
    'NameType_nat ': 272,
    'NameType_oth ': 275,
    'NameType_pro ': 274,
    'NameType_prs ': 269,
    'NameType_sur ': 271,
    'Negative_neg': 164,
    'Negative_pos': 165,
    'Negative_yes': 166,
    'NounType_class ': 278,
    'NounType_com ': 276,
    'NounType_prop ': 277,
    'NumForm_digit ': 289,
    'NumForm_roman ': 290,
    'NumForm_word ': 291,
    'NumType_card': 176,
    'NumType_dist': 177,
    'NumType_frac': 178,
    'NumType_gen': 179,
    'NumType_mult': 180,
    'NumType_none': 181,
    'NumType_ord': 182,
    'NumType_sets': 183,
    'NumValue_one ': 292,
    'NumValue_three ': 294,
    'NumValue_two ': 293,
    'Number_abs_plur ': 280,
    'Number_abs_sing ': 279,
    'Number_com': 169,
    'Number_count ': 175,
    'Number_dat_plur ': 282,
    'Number_dat_sing ': 281,
    'Number_dual': 170,
    'Number_erg_plur ': 284,
    'Number_erg_sing ': 283,
    'Number_none': 171,
    'Number_plur': 172,
    'Number_psee_plur ': 286,
    'Number_psee_sing ': 285,
    'Number_psor_plur ': 288,
    'Number_psor_sing ': 287,
    'Number_ptan ': 174,
    'Number_sing': 173,
    'PartForm_agt ': 297,
    'PartForm_neg ': 298,
    'PartForm_past ': 296,
    'PartForm_pres ': 295,
    'PartType_emp ': 300,
    'PartType_inf ': 302,
    'PartType_mod ': 299,
    'PartType_res ': 301,
    'PartType_vbp ': 303,
    'Person_abs_one ': 304,
    'Person_abs_three ': 306,
    'Person_abs_two ': 305,
    'Person_dat_one ': 307,
    'Person_dat_three ': 309,
    'Person_dat_two ': 308,
    'Person_erg_one ': 310,
    'Person_erg_three ': 312,
    'Person_erg_two ': 311,
    'Person_none': 187,
    'Person_one': 184,
    'Person_psor_one ': 313,
    'Person_psor_three ': 315,
    'Person_psor_two ': 314,
    'Person_three': 186,
    'Person_two': 185,
    'Polarity_neg': 167,
    'Polarity_pos': 168,
    'Polite_abs_inf ': 318,
    'Polite_abs_pol ': 319,
    'Polite_dat_inf ': 322,
    'Polite_dat_pol ': 323,
    'Polite_erg_inf ': 320,
    'Polite_erg_pol ': 321,
    'Polite_inf ': 316,
    'Polite_pol ': 317,
    'Poss_yes': 188,
    'Prefix_yes ': 324,
    'PrepCase_npr ': 325,
    'PrepCase_pre ': 326,
    'PronType_advPart': 189,
    'PronType_art': 190,
    'PronType_clit': 200,
    'PronType_default': 191,
    'PronType_dem': 192,
    'PronType_exc ': 201,
    'PronType_ind': 193,
    'PronType_int': 194,
    'PronType_neg': 195,
    'PronType_prs': 196,
    'PronType_rcp': 197,
    'PronType_rel': 198,
    'PronType_tot': 199,
    'PunctSide_fin ': 328,
    'PunctSide_ini ': 327,
    'PunctType_brck ': 333,
    'PunctType_colo ': 335,
    'PunctType_comm ': 334,
    'PunctType_dash ': 337,
    'PunctType_excl ': 331,
    'PunctType_peri ': 329,
    'PunctType_qest ': 330,
    'PunctType_quot ': 332,
    'PunctType_semi ': 336,
    'Reflex_yes': 202,
    'StyleVariant_styleBound ': 350,
    'StyleVariant_styleShort ': 349,
    'Style_arch ': 338,
    'Style_coll ': 342,
    'Style_derg ': 346,
    'Style_expr ': 345,
    'Style_norm ': 341,
    'Style_poet ': 340,
    'Style_rare ': 339,
    'Style_sing ': 344,
    'Style_vrnc ': 343,
    'Style_vulg ': 347,
    'Style_yes ': 348,
    'Tense_fut': 203,
    'Tense_imp': 204,
    'Tense_past': 205,
    'Tense_pres': 206,
    'VerbForm_conv': 217,
    'VerbForm_fin': 207,
    'VerbForm_gdv ': 218,
    'VerbForm_ger': 208,
    'VerbForm_inf': 209,
    'VerbForm_none': 210,
    'VerbForm_part': 211,
    'VerbForm_partFut': 212,
    'VerbForm_partPast': 213,
    'VerbForm_partPres': 214,
    'VerbForm_sup': 215,
    'VerbForm_trans': 216,
    'VerbType_aux ': 351,
    'VerbType_cop ': 352,
    'VerbType_light ': 354,
    'VerbType_mod ': 353,
    'Voice_act': 219,
    'Voice_cau': 220,
    'Voice_int ': 223,
    'Voice_mid ': 222,
    'Voice_pass': 221,
}

NAMES = [
    'Animacy_anim',
    'Animacy_inan',
    'Animacy_hum',
    'Animacy_nhum',
    'Aspect_freq',
    'Aspect_imp',
    'Aspect_mod',
    'Aspect_none',
    'Aspect_perf',
    'Case_abe',
    'Case_abl',
    'Case_abs',
    'Case_acc',
    'Case_ade',
    'Case_all',
    'Case_cau',
    'Case_com',
    'Case_dat',
    'Case_del',
    'Case_dis',
    'Case_ela',
    'Case_ess',
    'Case_gen',
    'Case_ill',
    'Case_ine',
    'Case_ins',
    'Case_loc',
    'Case_lat',
    'Case_nom',
    'Case_par',
    'Case_sub',
    'Case_sup',
    'Case_tem',
    'Case_ter',
    'Case_tra',
    'Case_voc',
    'Definite_two',
    'Definite_def',
    'Definite_red',
    'Definite_cons',
    'Definite_ind',
    'Degree_cmp',
    'Degree_comp',
    'Degree_none',
    'Degree_pos',
    'Degree_sup',
    'Degree_abs',
    'Degree_com',
    'Degree_dim ',
    'Gender_com',
    'Gender_fem',
    'Gender_masc',
    'Gender_neut',
    'Mood_cnd',
    'Mood_imp',
    'Mood_ind',
    'Mood_n',
    'Mood_pot',
    'Mood_sub',
    'Mood_opt',
    'Negative_neg',
    'Negative_pos',
    'Negative_yes',
    'Polarity_neg',
    'Polarity_pos',
    'Number_com',
    'Number_dual',
    'Number_none',
    'Number_plur',
    'Number_sing',
    'Number_ptan ',
    'Number_count ',
    'NumType_card',
    'NumType_dist',
    'NumType_frac',
    'NumType_gen',
    'NumType_mult',
    'NumType_none',
    'NumType_ord',
    'NumType_sets',
    'Person_one',
    'Person_two',
    'Person_three',
    'Person_none',
    'Poss_yes',
    'PronType_advPart',
    'PronType_art',
    'PronType_default',
    'PronType_dem',
    'PronType_ind',
    'PronType_int',
    'PronType_neg',
    'PronType_prs',
    'PronType_rcp',
    'PronType_rel',
    'PronType_tot',
    'PronType_clit',
    'PronType_exc ',
    'Reflex_yes',
    'Tense_fut',
    'Tense_imp',
    'Tense_past',
    'Tense_pres',
    'VerbForm_fin',
    'VerbForm_ger',
    'VerbForm_inf',
    'VerbForm_none',
    'VerbForm_part',
    'VerbForm_partFut',
    'VerbForm_partPast',
    'VerbForm_partPres',
    'VerbForm_sup',
    'VerbForm_trans',
    'VerbForm_conv',
    'VerbForm_gdv ',
    'Voice_act',
    'Voice_cau',
    'Voice_pass',
    'Voice_mid ',
    'Voice_int ',
    'Abbr_yes ',
    'AdpType_prep ',
    'AdpType_post ',
    'AdpType_voc ',
    'AdpType_comprep ',
    'AdpType_circ ',
    'AdvType_man',
    'AdvType_loc',
    'AdvType_tim',
    'AdvType_deg',
    'AdvType_cau',
    'AdvType_mod',
    'AdvType_sta',
    'AdvType_ex',
    'AdvType_adadj',
    'ConjType_oper ',
    'ConjType_comp ',
    'Connegative_yes ',
    'Derivation_minen ',
    'Derivation_sti ',
    'Derivation_inen ',
    'Derivation_lainen ',
    'Derivation_ja ',
    'Derivation_ton ',
    'Derivation_vs ',
    'Derivation_ttain ',
    'Derivation_ttaa ',
    'Echo_rdp ',
    'Echo_ech ',
    'Foreign_foreign ',
    'Foreign_fscript ',
    'Foreign_tscript ',
    'Foreign_yes ',
    'Gender_dat_masc ',
    'Gender_dat_fem ',
    'Gender_erg_masc ',
    'Gender_erg_fem ',
    'Gender_psor_masc ',
    'Gender_psor_fem ',
    'Gender_psor_neut ',
    'Hyph_yes ',
    'InfForm_one ',
    'InfForm_two ',
    'InfForm_three ',
    'NameType_geo ',
    'NameType_prs ',
    'NameType_giv ',
    'NameType_sur ',
    'NameType_nat ',
    'NameType_com ',
    'NameType_pro ',
    'NameType_oth ',
    'NounType_com ',
    'NounType_prop ',
    'NounType_class ',
    'Number_abs_sing ',
    'Number_abs_plur ',
    'Number_dat_sing ',
    'Number_dat_plur ',
    'Number_erg_sing ',
    'Number_erg_plur ',
    'Number_psee_sing ',
    'Number_psee_plur ',
    'Number_psor_sing ',
    'Number_psor_plur ',
    'NumForm_digit ',
    'NumForm_roman ',
    'NumForm_word ',
    'NumValue_one ',
    'NumValue_two ',
    'NumValue_three ',
    'PartForm_pres ',
    'PartForm_past ',
    'PartForm_agt ',
    'PartForm_neg ',
    'PartType_mod ',
    'PartType_emp ',
    'PartType_res ',
    'PartType_inf ',
    'PartType_vbp ',
    'Person_abs_one ',
    'Person_abs_two ',
    'Person_abs_three ',
    'Person_dat_one ',
    'Person_dat_two ',
    'Person_dat_three ',
    'Person_erg_one ',
    'Person_erg_two ',
    'Person_erg_three ',
    'Person_psor_one ',
    'Person_psor_two ',
    'Person_psor_three ',
    'Polite_inf ',
    'Polite_pol ',
    'Polite_abs_inf ',
    'Polite_abs_pol ',
    'Polite_erg_inf ',
    'Polite_erg_pol ',
    'Polite_dat_inf ',
    'Polite_dat_pol ',
    'Prefix_yes ',
    'PrepCase_npr ',
    'PrepCase_pre ',
    'PunctSide_ini ',
    'PunctSide_fin ',
    'PunctType_peri ',
    'PunctType_qest ',
    'PunctType_excl ',
    'PunctType_quot ',
    'PunctType_brck ',
    'PunctType_comm ',
    'PunctType_colo ',
    'PunctType_semi ',
    'PunctType_dash ',
    'Style_arch ',
    'Style_rare ',
    'Style_poet ',
    'Style_norm ',
    'Style_coll ',
    'Style_vrnc ',
    'Style_sing ',
    'Style_expr ',
    'Style_derg ',
    'Style_vulg ',
    'Style_yes ',
    'StyleVariant_styleShort ',
    'StyleVariant_styleBound ',
    'VerbType_aux ',
    'VerbType_cop ',
    'VerbType_mod ',
    'VerbType_light ',
]

POS_IDS = {
    '': 0,
    'ADJ': 84,
    'ADP': 85,
    'ADV': 86,
    'AUX': 87,
    'CCONJ': 89,
    'CONJ': 88,
    'DET': 90,
    'EOL': 102,
    'INTJ': 91,
    'NOUN': 92,
    'NUM': 93,
    'PART': 94,
    'PRON': 95,
    'PROPN': 96,
    'PUNCT': 97,
    'SCONJ': 98,
    'SPACE': 103,
    'SYM': 99,
    'VERB': 100,
    'X': 101,
}

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4a4bdde0f0>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.morphology', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4a4bdde0f0>, origin='/usr/local/lib/python3.5/dist-packages/spacy/morphology.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


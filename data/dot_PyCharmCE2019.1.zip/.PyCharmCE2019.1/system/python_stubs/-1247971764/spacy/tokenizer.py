# encoding: utf-8
# module spacy.tokenizer
# from /usr/local/lib/python3.5/dist-packages/spacy/tokenizer.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import re as re # /usr/lib/python3.5/re.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
import spacy.util as util # /usr/local/lib/python3.5/dist-packages/spacy/util.py

# functions

def deprecation_warning(message): # reliably restored by inspect
    # no doc
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def unescape_unicode(string): # reliably restored by inspect
    """
    Python2.7's re module chokes when compiling patterns that have ranges
        between escaped unicode codepoints if the two codepoints are unrecognised
        in the unicode database. For instance:
    
            re.compile('[\uAA77-\uAA79]').findall("hello")
    
        Ends up matching every character (on Python 2). This problem doesn't occur
        if we're dealing with unicode literals.
    """
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def _get_regex_pattern(regex): # real signature unknown; restored from __doc__
    """
    _get_regex_pattern(regex)
    Get a pattern string for a regex, or None if the pattern is None.
    """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class OrderedDict(dict):
    """ Dictionary that remembers insertion order """
    def clear(self): # real signature unknown; restored from __doc__
        """ od.clear() -> None.  Remove all items from od. """
        pass

    def copy(self): # real signature unknown; restored from __doc__
        """ od.copy() -> a shallow copy of od """
        pass

    @classmethod
    def fromkeys(cls, S, v=None): # real signature unknown; restored from __doc__
        """
        OD.fromkeys(S[, v]) -> New ordered dictionary with keys from S.
                If not specified, the value defaults to None.
        """
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def move_to_end(self, *args, **kwargs): # real signature unknown
        """
        Move an existing element to the end (or beginning if last==False).
        
                Raises KeyError if the element does not exist.
                When last=True, acts like a fast version of self[key]=self.pop(key).
        """
        pass

    def pop(self, k, d=None): # real signature unknown; restored from __doc__
        """
        od.pop(k[,d]) -> v, remove specified key and return the corresponding
                value.  If key is not found, d is returned if given, otherwise KeyError
                is raised.
        """
        pass

    def popitem(self): # real signature unknown; restored from __doc__
        """
        od.popitem() -> (k, v), return and remove a (key, value) pair.
                Pairs are returned in LIFO order if last is true or FIFO order if false.
        """
        pass

    def setdefault(self, k, d=None): # real signature unknown; restored from __doc__
        """ od.setdefault(k[,d]) -> od.get(k,d), also set od[k]=d if k not in od """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __reversed__(self): # real signature unknown; restored from __doc__
        """ od.__reversed__() <==> reversed(od) """
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """ Set self[key] to value. """
        pass

    def __sizeof__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is "mappingproxy({'__init__': <slot wrapper '__init__' of 'collections.OrderedDict' objects>, '__ge__': <slot wrapper '__ge__' of 'collections.OrderedDict' objects>, 'fromkeys': <method 'fromkeys' of 'collections.OrderedDict' objects>, 'keys': <method 'keys' of 'collections.OrderedDict' objects>, '__hash__': None, 'values': <method 'values' of 'collections.OrderedDict' objects>, 'move_to_end': <method 'move_to_end' of 'collections.OrderedDict' objects>, '__reduce__': <method '__reduce__' of 'collections.OrderedDict' objects>, '__iter__': <slot wrapper '__iter__' of 'collections.OrderedDict' objects>, '__gt__': <slot wrapper '__gt__' of 'collections.OrderedDict' objects>, '__eq__': <slot wrapper '__eq__' of 'collections.OrderedDict' objects>, '__le__': <slot wrapper '__le__' of 'collections.OrderedDict' objects>, '__delitem__': <slot wrapper '__delitem__' of 'collections.OrderedDict' objects>, '__lt__': <slot wrapper '__lt__' of 'collections.OrderedDict' objects>, '__repr__': <slot wrapper '__repr__' of 'collections.OrderedDict' objects>, 'update': <method 'update' of 'collections.OrderedDict' objects>, '__ne__': <slot wrapper '__ne__' of 'collections.OrderedDict' objects>, 'clear': <method 'clear' of 'collections.OrderedDict' objects>, '__sizeof__': <method '__sizeof__' of 'collections.OrderedDict' objects>, 'popitem': <method 'popitem' of 'collections.OrderedDict' objects>, 'copy': <method 'copy' of 'collections.OrderedDict' objects>, 'items': <method 'items' of 'collections.OrderedDict' objects>, '__doc__': 'Dictionary that remembers insertion order', 'setdefault': <method 'setdefault' of 'collections.OrderedDict' objects>, '__reversed__': <method '__reversed__' of 'collections.OrderedDict' objects>, 'pop': <method 'pop' of 'collections.OrderedDict' objects>, '__setitem__': <slot wrapper '__setitem__' of 'collections.OrderedDict' objects>, '__dict__': <member '__dict__' of 'collections.OrderedDict' objects>, '__new__': <built-in method __new__ of type object at 0xa36940>})"
    __hash__ = None


class Tokenizer(object):
    """
    Tokenizer(Vocab vocab, rules=None, prefix_search=None, suffix_search=None, infix_finditer=None, token_match=None)
    Segment text, and create Doc objects with the discovered segment
        boundaries.
    
        DOCS: https://spacy.io/api/tokenizer
    """
    def add_special_case(self, unicode_string, substrings): # real signature unknown; restored from __doc__
        """
        Tokenizer.add_special_case(self, unicode string, substrings)
        Add a special-case tokenization rule.
        
                string (unicode): The string to specially tokenize.
                token_attrs (iterable): A sequence of dicts, where each dict describes
                    a token and its attributes. The `ORTH` fields of the attributes
                    must exactly match the string when they are concatenated.
        
                DOCS: https://spacy.io/api/tokenizer#add_special_case
        """
        pass

    def find_infix(self, unicode_string): # real signature unknown; restored from __doc__
        """
        Tokenizer.find_infix(self, unicode string)
        Find internal split points of the string, such as hyphens.
        
                string (unicode): The string to segment.
                RETURNS (list): A list of `re.MatchObject` objects that have `.start()`
                    and `.end()` methods, denoting the placement of internal segment
                    separators, e.g. hyphens.
        
                DOCS: https://spacy.io/api/tokenizer#find_infix
        """
        pass

    def find_prefix(self, unicode_string): # real signature unknown; restored from __doc__
        """
        Tokenizer.find_prefix(self, unicode string)
        Find the length of a prefix that should be segmented from the
                string, or None if no prefix rules match.
        
                string (unicode): The string to segment.
                RETURNS (int): The length of the prefix if present, otherwise `None`.
        
                DOCS: https://spacy.io/api/tokenizer#find_prefix
        """
        pass

    def find_suffix(self, unicode_string): # real signature unknown; restored from __doc__
        """
        Tokenizer.find_suffix(self, unicode string)
        Find the length of a suffix that should be segmented from the
                string, or None if no suffix rules match.
        
                string (unicode): The string to segment.
                Returns (int): The length of the suffix if present, otherwise `None`.
        
                DOCS: https://spacy.io/api/tokenizer#find_suffix
        """
        pass

    def from_bytes(self, bytes_data, exclude=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        Tokenizer.from_bytes(self, bytes_data, exclude=tuple(), **kwargs)
        Load state from a binary string.
        
                bytes_data (bytes): The data to load from.
                exclude (list): String names of serialization fields to exclude.
                RETURNS (Tokenizer): The `Tokenizer` object.
        
                DOCS: https://spacy.io/api/tokenizer#from_bytes
        """
        pass

    def from_disk(self, path, **kwargs): # real signature unknown; restored from __doc__
        """
        Tokenizer.from_disk(self, path, **kwargs)
        Loads state from a directory. Modifies the object in place and
                returns it.
        
                path (unicode or Path): A path to a directory.
                exclude (list): String names of serialization fields to exclude.
                RETURNS (Tokenizer): The modified `Tokenizer` object.
        
                DOCS: https://spacy.io/api/tokenizer#from_disk
        """
        pass

    def pipe(self, texts, batch_size=1000, n_threads=-1): # real signature unknown; restored from __doc__
        """
        Tokenizer.pipe(self, texts, batch_size=1000, n_threads=-1)
        Tokenize a stream of texts.
        
                texts: A sequence of unicode texts.
                batch_size (int): Number of texts to accumulate in an internal buffer.
                YIELDS (Doc): A sequence of Doc objects, in order.
        
                DOCS: https://spacy.io/api/tokenizer#pipe
        """
        pass

    def tokens_from_list(self, list_strings): # real signature unknown; restored from __doc__
        """ Tokenizer.tokens_from_list(self, list strings) -> Doc """
        pass

    def to_bytes(self, exclude=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        Tokenizer.to_bytes(self, exclude=tuple(), **kwargs)
        Serialize the current state to a binary string.
        
                exclude (list): String names of serialization fields to exclude.
                RETURNS (bytes): The serialized form of the `Tokenizer` object.
        
                DOCS: https://spacy.io/api/tokenizer#to_bytes
        """
        pass

    def to_disk(self, path, **kwargs): # real signature unknown; restored from __doc__
        """
        Tokenizer.to_disk(self, path, **kwargs)
        Save the current state to a directory.
        
                path (unicode or Path): A path to a directory, which will be created if
                    it doesn't exist.
                exclude (list): String names of serialization fields to exclude.
        
                DOCS: https://spacy.io/api/tokenizer#to_disk
        """
        pass

    def _load_special_tokenization(self, special_cases): # real signature unknown; restored from __doc__
        """
        Tokenizer._load_special_tokenization(self, special_cases)
        Add special-case tokenization rules.
        """
        pass

    def _reset_cache(self, keys): # real signature unknown; restored from __doc__
        """ Tokenizer._reset_cache(self, keys) """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """
        Tokenize a string.
        
                string (unicode): The string to tokenize.
                RETURNS (Doc): A container for linguistic annotations.
        
                DOCS: https://spacy.io/api/tokenizer#call
        """
        pass

    def __init__(self, nlp_vocab): # real signature unknown; restored from __doc__
        """
        Create a `Tokenizer`, to create `Doc` objects given unicode text.
        
                vocab (Vocab): A storage container for lexical types.
                rules (dict): Exceptions and special-cases for the tokenizer.
                prefix_search (callable): A function matching the signature of
                    `re.compile(string).search` to match prefixes.
                suffix_search (callable): A function matching the signature of
                    `re.compile(string).search` to match suffixes.
                `infix_finditer` (callable): A function matching the signature of
                    `re.compile(string).finditer` to find infixes.
                token_match (callable): A boolean function matching strings to be
                    recognised as tokens.
                RETURNS (Tokenizer): The newly constructed object.
        
                EXAMPLE:
                    >>> tokenizer = Tokenizer(nlp.vocab)
                    >>> tokenizer = English().Defaults.create_tokenizer(nlp)
        
                DOCS: https://spacy.io/api/tokenizer#init
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self): # real signature unknown; restored from __doc__
        """ Tokenizer.__reduce__(self) """
        pass

    infix_finditer = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """infix_finditer: object"""

    prefix_search = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """prefix_search: object"""

    suffix_search = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """suffix_search: object"""

    token_match = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """token_match: object"""

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f3d4eabc3c0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3d4eb5fd68>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.tokenizer', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3d4eb5fd68>, origin='/usr/local/lib/python3.5/dist-packages/spacy/tokenizer.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {
    'Tokenizer.__init__ (line 29)': 'Create a `Tokenizer`, to create `Doc` objects given unicode text.\n\n        vocab (Vocab): A storage container for lexical types.\n        rules (dict): Exceptions and special-cases for the tokenizer.\n        prefix_search (callable): A function matching the signature of\n            `re.compile(string).search` to match prefixes.\n        suffix_search (callable): A function matching the signature of\n            `re.compile(string).search` to match suffixes.\n        `infix_finditer` (callable): A function matching the signature of\n            `re.compile(string).finditer` to find infixes.\n        token_match (callable): A boolean function matching strings to be\n            recognised as tokens.\n        RETURNS (Tokenizer): The newly constructed object.\n\n        EXAMPLE:\n            >>> tokenizer = Tokenizer(nlp.vocab)\n            >>> tokenizer = English().Defaults.create_tokenizer(nlp)\n\n        DOCS: https://spacy.io/api/tokenizer#init\n        ',
}


# encoding: utf-8
# module spacy.attrs
# from /usr/local/lib/python3.5/dist-packages/spacy/attrs.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values
 = 0

CLUSTER = 72

DEP = 76

ENT_IOB = 77
ENT_TYPE = 78

FLAG19 = 19
FLAG20 = 20
FLAG21 = 21
FLAG22 = 22
FLAG23 = 23
FLAG24 = 24
FLAG25 = 25
FLAG26 = 26
FLAG27 = 27
FLAG28 = 28
FLAG29 = 29
FLAG30 = 30
FLAG31 = 31
FLAG32 = 32
FLAG33 = 33
FLAG34 = 34
FLAG35 = 35
FLAG36 = 36
FLAG37 = 37
FLAG38 = 38
FLAG39 = 39
FLAG40 = 40
FLAG41 = 41
FLAG42 = 42
FLAG43 = 43
FLAG44 = 44
FLAG45 = 45
FLAG46 = 46
FLAG47 = 47
FLAG48 = 48
FLAG49 = 49
FLAG50 = 50
FLAG51 = 51
FLAG52 = 52
FLAG53 = 53
FLAG54 = 54
FLAG55 = 55
FLAG56 = 56
FLAG57 = 57
FLAG58 = 58
FLAG59 = 59
FLAG60 = 60
FLAG61 = 61
FLAG62 = 62
FLAG63 = 63

HEAD = 79

ID = 64

IS_ALPHA = 1
IS_ASCII = 2
IS_BRACKET = 14
IS_CURRENCY = 18
IS_DIGIT = 3

IS_LEFT_PUNCT = 16

IS_LOWER = 4
IS_OOV = 13
IS_PUNCT = 5
IS_QUOTE = 15

IS_RIGHT_PUNCT = 17

IS_SPACE = 6
IS_STOP = 12
IS_TITLE = 7
IS_UPPER = 8

key = 'LANG'

LANG = 83

LEMMA = 73
LENGTH = 71

LIKE_EMAIL = 11
LIKE_NUM = 10
LIKE_URL = 9

LOWER = 66

NORM = 67

ORTH = 65

POS = 74

PREFIX = 69
PROB = 82

SENT_START = 80

SHAPE = 68

SPACY = 81

SUFFIX = 70

TAG = 75

value = 83

# functions

def intify_attrs(*args, **kwargs): # real signature unknown
    """
    Normalize a dictionary of attributes, converting them to ints.
    
        stringy_attrs (dict): Dictionary keyed by attribute string names. Values
            can be ints or strings.
        strings_map (StringStore): Defaults to None. If provided, encodes string
            values into ints.
        RETURNS (dict): Attributes dictionary with keys and optionally values
            converted to ints.
    """
    pass

# no classes
# variables with complex values

IDS = {
    '': 0,
    'CLUSTER': 72,
    'DEP': 76,
    'ENT_IOB': 77,
    'ENT_TYPE': 78,
    'FLAG19': 19,
    'FLAG20': 20,
    'FLAG21': 21,
    'FLAG22': 22,
    'FLAG23': 23,
    'FLAG24': 24,
    'FLAG25': 25,
    'FLAG26': 26,
    'FLAG27': 27,
    'FLAG28': 28,
    'FLAG29': 29,
    'FLAG30': 30,
    'FLAG31': 31,
    'FLAG32': 32,
    'FLAG33': 33,
    'FLAG34': 34,
    'FLAG35': 35,
    'FLAG36': 36,
    'FLAG37': 37,
    'FLAG38': 38,
    'FLAG39': 39,
    'FLAG40': 40,
    'FLAG41': 41,
    'FLAG42': 42,
    'FLAG43': 43,
    'FLAG44': 44,
    'FLAG45': 45,
    'FLAG46': 46,
    'FLAG47': 47,
    'FLAG48': 48,
    'FLAG49': 49,
    'FLAG50': 50,
    'FLAG51': 51,
    'FLAG52': 52,
    'FLAG53': 53,
    'FLAG54': 54,
    'FLAG55': 55,
    'FLAG56': 56,
    'FLAG57': 57,
    'FLAG58': 58,
    'FLAG59': 59,
    'FLAG60': 60,
    'FLAG61': 61,
    'FLAG62': 62,
    'FLAG63': 63,
    'HEAD': 79,
    'ID': 64,
    'IS_ALPHA': 1,
    'IS_ASCII': 2,
    'IS_BRACKET': 14,
    'IS_CURRENCY': 18,
    'IS_DIGIT': 3,
    'IS_LEFT_PUNCT': 16,
    'IS_LOWER': 4,
    'IS_OOV': 13,
    'IS_PUNCT': 5,
    'IS_QUOTE': 15,
    'IS_RIGHT_PUNCT': 17,
    'IS_SPACE': 6,
    'IS_STOP': 12,
    'IS_TITLE': 7,
    'IS_UPPER': 8,
    'LANG': 83,
    'LEMMA': 73,
    'LENGTH': 71,
    'LIKE_EMAIL': 11,
    'LIKE_NUM': 10,
    'LIKE_URL': 9,
    'LOWER': 66,
    'NORM': 67,
    'ORTH': 65,
    'POS': 74,
    'PREFIX': 69,
    'PROB': 82,
    'SENT_START': 80,
    'SHAPE': 68,
    'SPACY': 81,
    'SUFFIX': 70,
    'TAG': 75,
}

NAMES = [
    '',
    'IS_ALPHA',
    'IS_ASCII',
    'IS_DIGIT',
    'IS_LOWER',
    'IS_PUNCT',
    'IS_SPACE',
    'IS_TITLE',
    'IS_UPPER',
    'LIKE_URL',
    'LIKE_NUM',
    'LIKE_EMAIL',
    'IS_STOP',
    'IS_OOV',
    'IS_BRACKET',
    'IS_QUOTE',
    'IS_LEFT_PUNCT',
    'IS_RIGHT_PUNCT',
    'IS_CURRENCY',
    'FLAG19',
    'FLAG20',
    'FLAG21',
    'FLAG22',
    'FLAG23',
    'FLAG24',
    'FLAG25',
    'FLAG26',
    'FLAG27',
    'FLAG28',
    'FLAG29',
    'FLAG30',
    'FLAG31',
    'FLAG32',
    'FLAG33',
    'FLAG34',
    'FLAG35',
    'FLAG36',
    'FLAG37',
    'FLAG38',
    'FLAG39',
    'FLAG40',
    'FLAG41',
    'FLAG42',
    'FLAG43',
    'FLAG44',
    'FLAG45',
    'FLAG46',
    'FLAG47',
    'FLAG48',
    'FLAG49',
    'FLAG50',
    'FLAG51',
    'FLAG52',
    'FLAG53',
    'FLAG54',
    'FLAG55',
    'FLAG56',
    'FLAG57',
    'FLAG58',
    'FLAG59',
    'FLAG60',
    'FLAG61',
    'FLAG62',
    'FLAG63',
    'ID',
    'ORTH',
    'LOWER',
    'NORM',
    'SHAPE',
    'PREFIX',
    'SUFFIX',
    'LENGTH',
    'CLUSTER',
    'LEMMA',
    'POS',
    'TAG',
    'DEP',
    'ENT_IOB',
    'ENT_TYPE',
    'HEAD',
    'SENT_START',
    'SPACY',
    'PROB',
    'LANG',
]

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3f9fad5cc0>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.attrs', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3f9fad5cc0>, origin='/usr/local/lib/python3.5/dist-packages/spacy/attrs.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


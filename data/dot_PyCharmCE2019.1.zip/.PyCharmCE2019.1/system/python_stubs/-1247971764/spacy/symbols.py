# encoding: utf-8
# module spacy.symbols
# from /usr/local/lib/python3.5/dist-packages/spacy/symbols.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values
 = 0

Abbr_yes = 239

acl = 451
acomp = 398

ADJ = 84
ADP = 85

AdpType_circ = 244
AdpType_comprep = 243
AdpType_post = 241
AdpType_prep = 240
AdpType_voc = 242

ADV = 86

advcl = 399
advmod = 400

AdvType_adadj = 253
AdvType_cau = 249
AdvType_deg = 248
AdvType_ex = 252
AdvType_loc = 246
AdvType_man = 245
AdvType_mod = 250
AdvType_sta = 251
AdvType_tim = 247

agent = 401

amod = 402

Animacy_anim = 104
Animacy_hum = 106
Animacy_inam = 105
Animacy_nhum = 107

appos = 403

Aspect_freq = 108
Aspect_hab = 114
Aspect_imp = 109
Aspect_iter = 113
Aspect_mod = 110
Aspect_none = 111
Aspect_perf = 112

attr = 404

AUX = 87

aux = 405
auxpass = 406

CARDINAL = 397

Case_abe = 115
Case_abl = 116
Case_abs = 117
Case_acc = 118
Case_ade = 119
Case_all = 120
Case_cau = 121
Case_cmp = 123
Case_com = 122
Case_dat = 124
Case_del = 125
Case_dis = 126
Case_ela = 127
Case_equ = 128
Case_ess = 129
Case_gen = 130
Case_ill = 131
Case_ine = 132
Case_ins = 133
Case_lat = 135
Case_loc = 134
Case_nom = 136
Case_par = 137
Case_sub = 138
Case_sup = 139
Case_tem = 140
Case_ter = 141
Case_tra = 142
Case_voc = 143

cc = 407
ccomp = 408

CCONJ = 89

CLUSTER = 72

complm = 409

CONJ = 88

conj = 410

ConjType_comp = 255
ConjType_oper = 254

Connegative_yes = 256

cop = 411

csubj = 412
csubjpass = 413

DATE = 391

Definite_cons = 147
Definite_def = 145
Definite_ind = 148
Definite_red = 146
Definite_spec = 149
Definite_two = 144

Degree_abs = 155
Degree_cmp = 150
Degree_com = 156
Degree_comp = 151
Degree_dim = 157
Degree_equ = 158
Degree_none = 152
Degree_pos = 153
Degree_sup = 154

dep = 414

DEP = 76

Derivation_inen = 259
Derivation_ja = 261
Derivation_lainen = 260
Derivation_minen = 257
Derivation_sti = 258
Derivation_ton = 262
Derivation_ttaa = 265
Derivation_ttain = 264
Derivation_vs = 263

DET = 90

det = 415

dobj = 416

Echo_ech = 267
Echo_rdp = 266

ENT_IOB = 77
ENT_TYPE = 78

EOL = 102

EVENT = 387

Evident_nfh = 159

expl = 417

FACILITY = 382

FLAG19 = 19
FLAG20 = 20
FLAG21 = 21
FLAG22 = 22
FLAG23 = 23
FLAG24 = 24
FLAG25 = 25
FLAG26 = 26
FLAG27 = 27
FLAG28 = 28
FLAG29 = 29
FLAG30 = 30
FLAG31 = 31
FLAG32 = 32
FLAG33 = 33
FLAG34 = 34
FLAG35 = 35
FLAG36 = 36
FLAG37 = 37
FLAG38 = 38
FLAG39 = 39
FLAG40 = 40
FLAG41 = 41
FLAG42 = 42
FLAG43 = 43
FLAG44 = 44
FLAG45 = 45
FLAG46 = 46
FLAG47 = 47
FLAG48 = 48
FLAG49 = 49
FLAG50 = 50
FLAG51 = 51
FLAG52 = 52
FLAG53 = 53
FLAG54 = 54
FLAG55 = 55
FLAG56 = 56
FLAG57 = 57
FLAG58 = 58
FLAG59 = 59
FLAG60 = 60
FLAG61 = 61
FLAG62 = 62
FLAG63 = 63

Foreign_foreign = 268
Foreign_fscript = 269
Foreign_tscript = 270
Foreign_yes = 271

Gender_com = 160

Gender_dat_fem = 273
Gender_dat_masc = 272

Gender_erg_fem = 275
Gender_erg_masc = 274

Gender_fem = 161
Gender_masc = 162
Gender_neut = 163

Gender_psor_fem = 277
Gender_psor_masc = 276
Gender_psor_neut = 278

GPE = 384

HEAD = 79

hmod = 418

hyph = 419

Hyph_yes = 279

ID = 64

InfForm_one = 280
InfForm_three = 282
InfForm_two = 281

infmod = 420
intj = 421

INTJ = 91

iobj = 422

IS_ALPHA = 1
IS_ASCII = 2
IS_BRACKET = 14
IS_CURRENCY = 18
IS_DIGIT = 3

IS_LEFT_PUNCT = 16

IS_LOWER = 4
IS_OOV = 13
IS_PUNCT = 5
IS_QUOTE = 15

IS_RIGHT_PUNCT = 17

IS_SPACE = 6
IS_STOP = 12
IS_TITLE = 7
IS_UPPER = 8

LANG = 83
LANGUAGE = 389
LAW = 390

LEMMA = 73
LENGTH = 71

LIKE_EMAIL = 11
LIKE_NUM = 10
LIKE_URL = 9

LOC = 385
LOWER = 66

mark = 423

meta = 424

MONEY = 394

Mood_adm = 172
Mood_cnd = 164
Mood_imp = 165
Mood_ind = 166
Mood_n = 167
Mood_opt = 170
Mood_pot = 168
Mood_prp = 171
Mood_sub = 169

NameType_com = 288
NameType_geo = 283
NameType_giv = 285
NameType_nat = 287
NameType_oth = 290
NameType_pro = 289
NameType_prs = 284
NameType_sur = 286

neg = 425

Negative_neg = 173
Negative_pos = 174
Negative_yes = 175

nmod = 426

nn = 427

NORM = 67
NORP = 381
NOUN = 92

NounType_class = 293
NounType_com = 291
NounType_prop = 292

npadvmod = 428

nsubj = 429
nsubjpass = 430

num = 431

NUM = 93

number = 432

Number_abs_plur = 295
Number_abs_sing = 294

Number_com = 178
Number_count = 184

Number_dat_plur = 297
Number_dat_sing = 296

Number_dual = 179

Number_erg_plur = 299
Number_erg_sing = 298

Number_grpa = 305
Number_grpl = 306
Number_inv = 307
Number_none = 180
Number_pauc = 304
Number_plur = 181

Number_psee_plur = 301
Number_psee_sing = 300

Number_psor_plur = 303
Number_psor_sing = 302

Number_ptan = 183
Number_sing = 182
Number_tri = 185

NumForm_digit = 308
NumForm_roman = 309
NumForm_word = 310

NumType_card = 186
NumType_dist = 187
NumType_frac = 188
NumType_gen = 189
NumType_mult = 190
NumType_none = 191
NumType_ord = 192
NumType_sets = 193

NumValue_one = 311
NumValue_three = 313
NumValue_two = 312

obj = 434
obl = 435

oprd = 433

ORDINAL = 396
ORG = 383
ORTH = 65

parataxis = 436

PART = 94

PartForm_agt = 316
PartForm_neg = 317
PartForm_past = 315
PartForm_pres = 314

partmod = 437

PartType_emp = 319
PartType_inf = 321
PartType_mod = 318
PartType_res = 320
PartType_vbp = 322

pcomp = 438

PERCENT = 393
PERSON = 380

Person_abs_one = 323
Person_abs_three = 325
Person_abs_two = 324

Person_dat_one = 326
Person_dat_three = 328
Person_dat_two = 327

Person_erg_one = 329
Person_erg_three = 331
Person_erg_two = 330

Person_four = 336
Person_none = 197
Person_one = 194

Person_psor_one = 332
Person_psor_three = 334
Person_psor_two = 333

Person_three = 196
Person_two = 195
Person_zero = 335

pobj = 439

Polarity_neg = 176
Polarity_pos = 177

Polite_abs_inf = 339
Polite_abs_pol = 340

Polite_dat_inf = 343
Polite_dat_pol = 344

Polite_erg_inf = 341
Polite_erg_pol = 342

Polite_form = 346

Polite_form_elev = 347
Polite_form_humb = 348

Polite_inf = 337
Polite_infm = 345
Polite_pol = 338

POS = 74

poss = 440
possessive = 441

Poss_yes = 198

preconj = 442

PREFIX = 69

Prefix_yes = 349

prep = 443

PrepCase_npr = 350
PrepCase_pre = 351

PROB = 82
PRODUCT = 386
PRON = 95

PronType_advPart = 199
PronType_art = 200
PronType_clit = 210
PronType_default = 201
PronType_dem = 202
PronType_emp = 212
PronType_exc = 211
PronType_ind = 203
PronType_int = 204
PronType_neg = 205
PronType_prs = 206
PronType_rcp = 207
PronType_rel = 208
PronType_tot = 209

PRON_LEMMA = '-PRON-'

PROPN = 96

prt = 444

punct = 445

PUNCT = 97

PunctSide_fin = 353
PunctSide_ini = 352

PunctType_brck = 358
PunctType_colo = 360
PunctType_comm = 359
PunctType_dash = 362
PunctType_excl = 356
PunctType_peri = 354
PunctType_qest = 355
PunctType_quot = 357
PunctType_semi = 361

QUANTITY = 395

quantmod = 446

rcmod = 448

Reflex_yes = 213

relcl = 447

root = 449

SCONJ = 98

SENT_START = 80

SHAPE = 68

SPACE = 103
SPACY = 81

StyleVariant_styleBound = 375
StyleVariant_styleShort = 374

Style_arch = 363
Style_coll = 367
Style_derg = 371
Style_expr = 370
Style_norm = 366
Style_poet = 365
Style_rare = 364
Style_sing = 369
Style_vrnc = 368
Style_vulg = 372
Style_yes = 373

SUFFIX = 70

SYM = 99

TAG = 75

Tense_fut = 214
Tense_imp = 215
Tense_past = 216
Tense_pres = 217

TIME = 392

VERB = 100

VerbForm_conv = 228
VerbForm_fin = 218
VerbForm_gdv = 229
VerbForm_ger = 219
VerbForm_inf = 220
VerbForm_none = 221
VerbForm_part = 222
VerbForm_partFut = 223
VerbForm_partPast = 224
VerbForm_partPres = 225
VerbForm_sup = 226
VerbForm_trans = 227
VerbForm_vnoun = 230

VerbType_aux = 376
VerbType_cop = 377
VerbType_light = 379
VerbType_mod = 378

Voice_act = 231
Voice_antip = 236
Voice_cau = 232
Voice_dir = 237
Voice_int = 235
Voice_inv = 238
Voice_mid = 234
Voice_pass = 233

WORK_OF_ART = 388
X = 101

xcomp = 450

# functions

def sort_nums(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

IDS = {
    '': 0,
    'ADJ': 84,
    'ADP': 85,
    'ADV': 86,
    'AUX': 87,
    'Abbr_yes': 239,
    'AdpType_circ': 244,
    'AdpType_comprep': 243,
    'AdpType_post': 241,
    'AdpType_prep': 240,
    'AdpType_voc': 242,
    'AdvType_adadj': 253,
    'AdvType_cau': 249,
    'AdvType_deg': 248,
    'AdvType_ex': 252,
    'AdvType_loc': 246,
    'AdvType_man': 245,
    'AdvType_mod': 250,
    'AdvType_sta': 251,
    'AdvType_tim': 247,
    'Animacy_anim': 104,
    'Animacy_hum': 106,
    'Animacy_inam': 105,
    'Animacy_nhum': 107,
    'Aspect_freq': 108,
    'Aspect_hab': 114,
    'Aspect_imp': 109,
    'Aspect_iter': 113,
    'Aspect_mod': 110,
    'Aspect_none': 111,
    'Aspect_perf': 112,
    'CARDINAL': 397,
    'CCONJ': 89,
    'CLUSTER': 72,
    'CONJ': 88,
    'Case_abe': 115,
    'Case_abl': 116,
    'Case_abs': 117,
    'Case_acc': 118,
    'Case_ade': 119,
    'Case_all': 120,
    'Case_cau': 121,
    'Case_cmp': 123,
    'Case_com': 122,
    'Case_dat': 124,
    'Case_del': 125,
    'Case_dis': 126,
    'Case_ela': 127,
    'Case_equ': 128,
    'Case_ess': 129,
    'Case_gen': 130,
    'Case_ill': 131,
    'Case_ine': 132,
    'Case_ins': 133,
    'Case_lat': 135,
    'Case_loc': 134,
    'Case_nom': 136,
    'Case_par': 137,
    'Case_sub': 138,
    'Case_sup': 139,
    'Case_tem': 140,
    'Case_ter': 141,
    'Case_tra': 142,
    'Case_voc': 143,
    'ConjType_comp': 255,
    'ConjType_oper': 254,
    'Connegative_yes': 256,
    'DATE': 391,
    'DEP': 76,
    'DET': 90,
    'Definite_cons': 147,
    'Definite_def': 145,
    'Definite_ind': 148,
    'Definite_red': 146,
    'Definite_spec': 149,
    'Definite_two': 144,
    'Degree_abs': 155,
    'Degree_cmp': 150,
    'Degree_com': 156,
    'Degree_comp': 151,
    'Degree_dim': 157,
    'Degree_equ': 158,
    'Degree_none': 152,
    'Degree_pos': 153,
    'Degree_sup': 154,
    'Derivation_inen': 259,
    'Derivation_ja': 261,
    'Derivation_lainen': 260,
    'Derivation_minen': 257,
    'Derivation_sti': 258,
    'Derivation_ton': 262,
    'Derivation_ttaa': 265,
    'Derivation_ttain': 264,
    'Derivation_vs': 263,
    'ENT_IOB': 77,
    'ENT_TYPE': 78,
    'EOL': 102,
    'EVENT': 387,
    'Echo_ech': 267,
    'Echo_rdp': 266,
    'Evident_nfh': 159,
    'FACILITY': 382,
    'FLAG19': 19,
    'FLAG20': 20,
    'FLAG21': 21,
    'FLAG22': 22,
    'FLAG23': 23,
    'FLAG24': 24,
    'FLAG25': 25,
    'FLAG26': 26,
    'FLAG27': 27,
    'FLAG28': 28,
    'FLAG29': 29,
    'FLAG30': 30,
    'FLAG31': 31,
    'FLAG32': 32,
    'FLAG33': 33,
    'FLAG34': 34,
    'FLAG35': 35,
    'FLAG36': 36,
    'FLAG37': 37,
    'FLAG38': 38,
    'FLAG39': 39,
    'FLAG40': 40,
    'FLAG41': 41,
    'FLAG42': 42,
    'FLAG43': 43,
    'FLAG44': 44,
    'FLAG45': 45,
    'FLAG46': 46,
    'FLAG47': 47,
    'FLAG48': 48,
    'FLAG49': 49,
    'FLAG50': 50,
    'FLAG51': 51,
    'FLAG52': 52,
    'FLAG53': 53,
    'FLAG54': 54,
    'FLAG55': 55,
    'FLAG56': 56,
    'FLAG57': 57,
    'FLAG58': 58,
    'FLAG59': 59,
    'FLAG60': 60,
    'FLAG61': 61,
    'FLAG62': 62,
    'FLAG63': 63,
    'Foreign_foreign': 268,
    'Foreign_fscript': 269,
    'Foreign_tscript': 270,
    'Foreign_yes': 271,
    'GPE': 384,
    'Gender_com': 160,
    'Gender_dat_fem': 273,
    'Gender_dat_masc': 272,
    'Gender_erg_fem': 275,
    'Gender_erg_masc': 274,
    'Gender_fem': 161,
    'Gender_masc': 162,
    'Gender_neut': 163,
    'Gender_psor_fem': 277,
    'Gender_psor_masc': 276,
    'Gender_psor_neut': 278,
    'HEAD': 79,
    'Hyph_yes': 279,
    'ID': 64,
    'INTJ': 91,
    'IS_ALPHA': 1,
    'IS_ASCII': 2,
    'IS_BRACKET': 14,
    'IS_CURRENCY': 18,
    'IS_DIGIT': 3,
    'IS_LEFT_PUNCT': 16,
    'IS_LOWER': 4,
    'IS_OOV': 13,
    'IS_PUNCT': 5,
    'IS_QUOTE': 15,
    'IS_RIGHT_PUNCT': 17,
    'IS_SPACE': 6,
    'IS_STOP': 12,
    'IS_TITLE': 7,
    'IS_UPPER': 8,
    'InfForm_one': 280,
    'InfForm_three': 282,
    'InfForm_two': 281,
    'LANG': 83,
    'LANGUAGE': 389,
    'LAW': 390,
    'LEMMA': 73,
    'LENGTH': 71,
    'LIKE_EMAIL': 11,
    'LIKE_NUM': 10,
    'LIKE_URL': 9,
    'LOC': 385,
    'LOWER': 66,
    'MONEY': 394,
    'Mood_adm': 172,
    'Mood_cnd': 164,
    'Mood_imp': 165,
    'Mood_ind': 166,
    'Mood_n': 167,
    'Mood_opt': 170,
    'Mood_pot': 168,
    'Mood_prp': 171,
    'Mood_sub': 169,
    'NORM': 67,
    'NORP': 381,
    'NOUN': 92,
    'NUM': 93,
    'NameType_com': 288,
    'NameType_geo': 283,
    'NameType_giv': 285,
    'NameType_nat': 287,
    'NameType_oth': 290,
    'NameType_pro': 289,
    'NameType_prs': 284,
    'NameType_sur': 286,
    'Negative_neg': 173,
    'Negative_pos': 174,
    'Negative_yes': 175,
    'NounType_class': 293,
    'NounType_com': 291,
    'NounType_prop': 292,
    'NumForm_digit': 308,
    'NumForm_roman': 309,
    'NumForm_word': 310,
    'NumType_card': 186,
    'NumType_dist': 187,
    'NumType_frac': 188,
    'NumType_gen': 189,
    'NumType_mult': 190,
    'NumType_none': 191,
    'NumType_ord': 192,
    'NumType_sets': 193,
    'NumValue_one': 311,
    'NumValue_three': 313,
    'NumValue_two': 312,
    'Number_abs_plur': 295,
    'Number_abs_sing': 294,
    'Number_com': 178,
    'Number_count': 184,
    'Number_dat_plur': 297,
    'Number_dat_sing': 296,
    'Number_dual': 179,
    'Number_erg_plur': 299,
    'Number_erg_sing': 298,
    'Number_grpa': 305,
    'Number_grpl': 306,
    'Number_inv': 307,
    'Number_none': 180,
    'Number_pauc': 304,
    'Number_plur': 181,
    'Number_psee_plur': 301,
    'Number_psee_sing': 300,
    'Number_psor_plur': 303,
    'Number_psor_sing': 302,
    'Number_ptan': 183,
    'Number_sing': 182,
    'Number_tri': 185,
    'ORDINAL': 396,
    'ORG': 383,
    'ORTH': 65,
    'PART': 94,
    'PERCENT': 393,
    'PERSON': 380,
    'POS': 74,
    'PREFIX': 69,
    'PROB': 82,
    'PRODUCT': 386,
    'PRON': 95,
    'PROPN': 96,
    'PUNCT': 97,
    'PartForm_agt': 316,
    'PartForm_neg': 317,
    'PartForm_past': 315,
    'PartForm_pres': 314,
    'PartType_emp': 319,
    'PartType_inf': 321,
    'PartType_mod': 318,
    'PartType_res': 320,
    'PartType_vbp': 322,
    'Person_abs_one': 323,
    'Person_abs_three': 325,
    'Person_abs_two': 324,
    'Person_dat_one': 326,
    'Person_dat_three': 328,
    'Person_dat_two': 327,
    'Person_erg_one': 329,
    'Person_erg_three': 331,
    'Person_erg_two': 330,
    'Person_four': 336,
    'Person_none': 197,
    'Person_one': 194,
    'Person_psor_one': 332,
    'Person_psor_three': 334,
    'Person_psor_two': 333,
    'Person_three': 196,
    'Person_two': 195,
    'Person_zero': 335,
    'Polarity_neg': 176,
    'Polarity_pos': 177,
    'Polite_abs_inf': 339,
    'Polite_abs_pol': 340,
    'Polite_dat_inf': 343,
    'Polite_dat_pol': 344,
    'Polite_erg_inf': 341,
    'Polite_erg_pol': 342,
    'Polite_form': 346,
    'Polite_form_elev': 347,
    'Polite_form_humb': 348,
    'Polite_inf': 337,
    'Polite_infm': 345,
    'Polite_pol': 338,
    'Poss_yes': 198,
    'Prefix_yes': 349,
    'PrepCase_npr': 350,
    'PrepCase_pre': 351,
    'PronType_advPart': 199,
    'PronType_art': 200,
    'PronType_clit': 210,
    'PronType_default': 201,
    'PronType_dem': 202,
    'PronType_emp': 212,
    'PronType_exc': 211,
    'PronType_ind': 203,
    'PronType_int': 204,
    'PronType_neg': 205,
    'PronType_prs': 206,
    'PronType_rcp': 207,
    'PronType_rel': 208,
    'PronType_tot': 209,
    'PunctSide_fin': 353,
    'PunctSide_ini': 352,
    'PunctType_brck': 358,
    'PunctType_colo': 360,
    'PunctType_comm': 359,
    'PunctType_dash': 362,
    'PunctType_excl': 356,
    'PunctType_peri': 354,
    'PunctType_qest': 355,
    'PunctType_quot': 357,
    'PunctType_semi': 361,
    'QUANTITY': 395,
    'Reflex_yes': 213,
    'SCONJ': 98,
    'SENT_START': 80,
    'SHAPE': 68,
    'SPACE': 103,
    'SPACY': 81,
    'SUFFIX': 70,
    'SYM': 99,
    'StyleVariant_styleBound': 375,
    'StyleVariant_styleShort': 374,
    'Style_arch': 363,
    'Style_coll': 367,
    'Style_derg': 371,
    'Style_expr': 370,
    'Style_norm': 366,
    'Style_poet': 365,
    'Style_rare': 364,
    'Style_sing': 369,
    'Style_vrnc': 368,
    'Style_vulg': 372,
    'Style_yes': 373,
    'TAG': 75,
    'TIME': 392,
    'Tense_fut': 214,
    'Tense_imp': 215,
    'Tense_past': 216,
    'Tense_pres': 217,
    'VERB': 100,
    'VerbForm_conv': 228,
    'VerbForm_fin': 218,
    'VerbForm_gdv': 229,
    'VerbForm_ger': 219,
    'VerbForm_inf': 220,
    'VerbForm_none': 221,
    'VerbForm_part': 222,
    'VerbForm_partFut': 223,
    'VerbForm_partPast': 224,
    'VerbForm_partPres': 225,
    'VerbForm_sup': 226,
    'VerbForm_trans': 227,
    'VerbForm_vnoun': 230,
    'VerbType_aux': 376,
    'VerbType_cop': 377,
    'VerbType_light': 379,
    'VerbType_mod': 378,
    'Voice_act': 231,
    'Voice_antip': 236,
    'Voice_cau': 232,
    'Voice_dir': 237,
    'Voice_int': 235,
    'Voice_inv': 238,
    'Voice_mid': 234,
    'Voice_pass': 233,
    'WORK_OF_ART': 388,
    'X': 101,
    'acl': 451,
    'acomp': 398,
    'advcl': 399,
    'advmod': 400,
    'agent': 401,
    'amod': 402,
    'appos': 403,
    'attr': 404,
    'aux': 405,
    'auxpass': 406,
    'cc': 407,
    'ccomp': 408,
    'complm': 409,
    'conj': 410,
    'cop': 411,
    'csubj': 412,
    'csubjpass': 413,
    'dep': 414,
    'det': 415,
    'dobj': 416,
    'expl': 417,
    'hmod': 418,
    'hyph': 419,
    'infmod': 420,
    'intj': 421,
    'iobj': 422,
    'mark': 423,
    'meta': 424,
    'neg': 425,
    'nmod': 426,
    'nn': 427,
    'npadvmod': 428,
    'nsubj': 429,
    'nsubjpass': 430,
    'num': 431,
    'number': 432,
    'obj': 434,
    'obl': 435,
    'oprd': 433,
    'parataxis': 436,
    'partmod': 437,
    'pcomp': 438,
    'pobj': 439,
    'poss': 440,
    'possessive': 441,
    'preconj': 442,
    'prep': 443,
    'prt': 444,
    'punct': 445,
    'quantmod': 446,
    'rcmod': 448,
    'relcl': 447,
    'root': 449,
    'xcomp': 450,
}

it = (
    'acl',
    451,
)

NAMES = [
    '',
    'IS_ALPHA',
    'IS_ASCII',
    'IS_DIGIT',
    'IS_LOWER',
    'IS_PUNCT',
    'IS_SPACE',
    'IS_TITLE',
    'IS_UPPER',
    'LIKE_URL',
    'LIKE_NUM',
    'LIKE_EMAIL',
    'IS_STOP',
    'IS_OOV',
    'IS_BRACKET',
    'IS_QUOTE',
    'IS_LEFT_PUNCT',
    'IS_RIGHT_PUNCT',
    'IS_CURRENCY',
    'FLAG19',
    'FLAG20',
    'FLAG21',
    'FLAG22',
    'FLAG23',
    'FLAG24',
    'FLAG25',
    'FLAG26',
    'FLAG27',
    'FLAG28',
    'FLAG29',
    'FLAG30',
    'FLAG31',
    'FLAG32',
    'FLAG33',
    'FLAG34',
    'FLAG35',
    'FLAG36',
    'FLAG37',
    'FLAG38',
    'FLAG39',
    'FLAG40',
    'FLAG41',
    'FLAG42',
    'FLAG43',
    'FLAG44',
    'FLAG45',
    'FLAG46',
    'FLAG47',
    'FLAG48',
    'FLAG49',
    'FLAG50',
    'FLAG51',
    'FLAG52',
    'FLAG53',
    'FLAG54',
    'FLAG55',
    'FLAG56',
    'FLAG57',
    'FLAG58',
    'FLAG59',
    'FLAG60',
    'FLAG61',
    'FLAG62',
    'FLAG63',
    'ID',
    'ORTH',
    'LOWER',
    'NORM',
    'SHAPE',
    'PREFIX',
    'SUFFIX',
    'LENGTH',
    'CLUSTER',
    'LEMMA',
    'POS',
    'TAG',
    'DEP',
    'ENT_IOB',
    'ENT_TYPE',
    'HEAD',
    'SENT_START',
    'SPACY',
    'PROB',
    'LANG',
    'ADJ',
    'ADP',
    'ADV',
    'AUX',
    'CONJ',
    'CCONJ',
    'DET',
    'INTJ',
    'NOUN',
    'NUM',
    'PART',
    'PRON',
    'PROPN',
    'PUNCT',
    'SCONJ',
    'SYM',
    'VERB',
    'X',
    'EOL',
    'SPACE',
    'Animacy_anim',
    'Animacy_inam',
    'Animacy_hum',
    'Animacy_nhum',
    'Aspect_freq',
    'Aspect_imp',
    'Aspect_mod',
    'Aspect_none',
    'Aspect_perf',
    'Aspect_iter',
    'Aspect_hab',
    'Case_abe',
    'Case_abl',
    'Case_abs',
    'Case_acc',
    'Case_ade',
    'Case_all',
    'Case_cau',
    'Case_com',
    'Case_cmp',
    'Case_dat',
    'Case_del',
    'Case_dis',
    'Case_ela',
    'Case_equ',
    'Case_ess',
    'Case_gen',
    'Case_ill',
    'Case_ine',
    'Case_ins',
    'Case_loc',
    'Case_lat',
    'Case_nom',
    'Case_par',
    'Case_sub',
    'Case_sup',
    'Case_tem',
    'Case_ter',
    'Case_tra',
    'Case_voc',
    'Definite_two',
    'Definite_def',
    'Definite_red',
    'Definite_cons',
    'Definite_ind',
    'Definite_spec',
    'Degree_cmp',
    'Degree_comp',
    'Degree_none',
    'Degree_pos',
    'Degree_sup',
    'Degree_abs',
    'Degree_com',
    'Degree_dim',
    'Degree_equ',
    'Evident_nfh',
    'Gender_com',
    'Gender_fem',
    'Gender_masc',
    'Gender_neut',
    'Mood_cnd',
    'Mood_imp',
    'Mood_ind',
    'Mood_n',
    'Mood_pot',
    'Mood_sub',
    'Mood_opt',
    'Mood_prp',
    'Mood_adm',
    'Negative_neg',
    'Negative_pos',
    'Negative_yes',
    'Polarity_neg',
    'Polarity_pos',
    'Number_com',
    'Number_dual',
    'Number_none',
    'Number_plur',
    'Number_sing',
    'Number_ptan',
    'Number_count',
    'Number_tri',
    'NumType_card',
    'NumType_dist',
    'NumType_frac',
    'NumType_gen',
    'NumType_mult',
    'NumType_none',
    'NumType_ord',
    'NumType_sets',
    'Person_one',
    'Person_two',
    'Person_three',
    'Person_none',
    'Poss_yes',
    'PronType_advPart',
    'PronType_art',
    'PronType_default',
    'PronType_dem',
    'PronType_ind',
    'PronType_int',
    'PronType_neg',
    'PronType_prs',
    'PronType_rcp',
    'PronType_rel',
    'PronType_tot',
    'PronType_clit',
    'PronType_exc',
    'PronType_emp',
    'Reflex_yes',
    'Tense_fut',
    'Tense_imp',
    'Tense_past',
    'Tense_pres',
    'VerbForm_fin',
    'VerbForm_ger',
    'VerbForm_inf',
    'VerbForm_none',
    'VerbForm_part',
    'VerbForm_partFut',
    'VerbForm_partPast',
    'VerbForm_partPres',
    'VerbForm_sup',
    'VerbForm_trans',
    'VerbForm_conv',
    'VerbForm_gdv',
    'VerbForm_vnoun',
    'Voice_act',
    'Voice_cau',
    'Voice_pass',
    'Voice_mid',
    'Voice_int',
    'Voice_antip',
    'Voice_dir',
    'Voice_inv',
    'Abbr_yes',
    'AdpType_prep',
    'AdpType_post',
    'AdpType_voc',
    'AdpType_comprep',
    'AdpType_circ',
    'AdvType_man',
    'AdvType_loc',
    'AdvType_tim',
    'AdvType_deg',
    'AdvType_cau',
    'AdvType_mod',
    'AdvType_sta',
    'AdvType_ex',
    'AdvType_adadj',
    'ConjType_oper',
    'ConjType_comp',
    'Connegative_yes',
    'Derivation_minen',
    'Derivation_sti',
    'Derivation_inen',
    'Derivation_lainen',
    'Derivation_ja',
    'Derivation_ton',
    'Derivation_vs',
    'Derivation_ttain',
    'Derivation_ttaa',
    'Echo_rdp',
    'Echo_ech',
    'Foreign_foreign',
    'Foreign_fscript',
    'Foreign_tscript',
    'Foreign_yes',
    'Gender_dat_masc',
    'Gender_dat_fem',
    'Gender_erg_masc',
    'Gender_erg_fem',
    'Gender_psor_masc',
    'Gender_psor_fem',
    'Gender_psor_neut',
    'Hyph_yes',
    'InfForm_one',
    'InfForm_two',
    'InfForm_three',
    'NameType_geo',
    'NameType_prs',
    'NameType_giv',
    'NameType_sur',
    'NameType_nat',
    'NameType_com',
    'NameType_pro',
    'NameType_oth',
    'NounType_com',
    'NounType_prop',
    'NounType_class',
    'Number_abs_sing',
    'Number_abs_plur',
    'Number_dat_sing',
    'Number_dat_plur',
    'Number_erg_sing',
    'Number_erg_plur',
    'Number_psee_sing',
    'Number_psee_plur',
    'Number_psor_sing',
    'Number_psor_plur',
    'Number_pauc',
    'Number_grpa',
    'Number_grpl',
    'Number_inv',
    'NumForm_digit',
    'NumForm_roman',
    'NumForm_word',
    'NumValue_one',
    'NumValue_two',
    'NumValue_three',
    'PartForm_pres',
    'PartForm_past',
    'PartForm_agt',
    'PartForm_neg',
    'PartType_mod',
    'PartType_emp',
    'PartType_res',
    'PartType_inf',
    'PartType_vbp',
    'Person_abs_one',
    'Person_abs_two',
    'Person_abs_three',
    'Person_dat_one',
    'Person_dat_two',
    'Person_dat_three',
    'Person_erg_one',
    'Person_erg_two',
    'Person_erg_three',
    'Person_psor_one',
    'Person_psor_two',
    'Person_psor_three',
    'Person_zero',
    'Person_four',
    'Polite_inf',
    'Polite_pol',
    'Polite_abs_inf',
    'Polite_abs_pol',
    'Polite_erg_inf',
    'Polite_erg_pol',
    'Polite_dat_inf',
    'Polite_dat_pol',
    'Polite_infm',
    'Polite_form',
    'Polite_form_elev',
    'Polite_form_humb',
    'Prefix_yes',
    'PrepCase_npr',
    'PrepCase_pre',
    'PunctSide_ini',
    'PunctSide_fin',
    'PunctType_peri',
    'PunctType_qest',
    'PunctType_excl',
    'PunctType_quot',
    'PunctType_brck',
    'PunctType_comm',
    'PunctType_colo',
    'PunctType_semi',
    'PunctType_dash',
    'Style_arch',
    'Style_rare',
    'Style_poet',
    'Style_norm',
    'Style_coll',
    'Style_vrnc',
    'Style_sing',
    'Style_expr',
    'Style_derg',
    'Style_vulg',
    'Style_yes',
    'StyleVariant_styleShort',
    'StyleVariant_styleBound',
    'VerbType_aux',
    'VerbType_cop',
    'VerbType_mod',
    'VerbType_light',
    'PERSON',
    'NORP',
    'FACILITY',
    'ORG',
    'GPE',
    'LOC',
    'PRODUCT',
    'EVENT',
    'WORK_OF_ART',
    'LANGUAGE',
    'LAW',
    'DATE',
    'TIME',
    'PERCENT',
    'MONEY',
    'QUANTITY',
    'ORDINAL',
    'CARDINAL',
    'acomp',
    'advcl',
    'advmod',
    'agent',
    'amod',
    'appos',
    'attr',
    'aux',
    'auxpass',
    'cc',
    'ccomp',
    'complm',
    'conj',
    'cop',
    'csubj',
    'csubjpass',
    'dep',
    'det',
    'dobj',
    'expl',
    'hmod',
    'hyph',
    'infmod',
    'intj',
    'iobj',
    'mark',
    'meta',
    'neg',
    'nmod',
    'nn',
    'npadvmod',
    'nsubj',
    'nsubjpass',
    'num',
    'number',
    'oprd',
    'obj',
    'obl',
    'parataxis',
    'partmod',
    'pcomp',
    'pobj',
    'poss',
    'possessive',
    'preconj',
    'prep',
    'prt',
    'punct',
    'quantmod',
    'relcl',
    'rcmod',
    'root',
    'xcomp',
    'acl',
]

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f983bab91d0>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.symbols', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f983bab91d0>, origin='/usr/local/lib/python3.5/dist-packages/spacy/symbols.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module spacy.syntax._state
# from /usr/local/lib/python3.5/dist-packages/spacy/syntax/_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb678caaef0>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.syntax._state', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb678caaef0>, origin='/usr/local/lib/python3.5/dist-packages/spacy/syntax/_state.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


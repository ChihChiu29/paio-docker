# encoding: utf-8
# module spacy.syntax._parser_model
# from /usr/local/lib/python3.5/dist-packages/spacy/syntax/_parser_model.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import spacy.util as util # /usr/local/lib/python3.5/dist-packages/spacy/util.py
import spacy.syntax.nonproj as nonproj # /usr/local/lib/python3.5/dist-packages/spacy/syntax/nonproj.cpython-35m-x86_64-linux-gnu.so
import spacy.syntax._beam_utils as _beam_utils # /usr/local/lib/python3.5/dist-packages/spacy/syntax/_beam_utils.cpython-35m-x86_64-linux-gnu.so
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
from thinc.neural.ops import CupyOps

import thinc.neural._classes.model as __thinc_neural__classes_model


# functions

def chain(*layers): # reliably restored by inspect
    """
    Compose two models `f` and `g` such that they become layers of a single
        feed-forward model that computes `g(f(x))`.
    
        Raises exception if their dimensions don't match.
    """
    pass

def clone(orig, n): # reliably restored by inspect
    """
    Construct `n` copies of a layer, with distinct weights.
    
        i.e. `clone(f, 3)(x)` computes `f(f'(f''(x)))`.
    """
    pass

def copy_array(dst, src, casting=None, where=None): # reliably restored by inspect
    # no doc
    pass

def create_default_optimizer(ops, **cfg): # reliably restored by inspect
    # no doc
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def flatten(*args, **kwargs): # real signature unknown
    """
    Wrap functions into weightless Model instances, for use as network
        components.
    """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def link_vectors_to_models(vocab): # reliably restored by inspect
    # no doc
    pass

def TempErrors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def Tok2Vec(width, embed_size, **kwargs): # reliably restored by inspect
    # no doc
    pass

def zero_init(model): # reliably restored by inspect
    # no doc
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_precompute_hiddens(*args, **kwargs): # real signature unknown
    pass

# classes

class Model(object):
    """ Model base class. """
    def begin_training(self, train_X, train_y=None, **trainer_cfg): # reliably restored by inspect
        # no doc
        pass

    def begin_update(self, X, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def define_operators(cls, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        Bind operators to specified functions for the scope of the context:
        
                Example
                -------
        
                    model = Model()
                    other = Model()
                    with Model.define_operators({"+": lambda self, other: "plus"}):
                        print(model + other)
                        # "plus"
                    print(model + other)
                    # Raises TypeError --- binding limited to scope of with block.
        """
        pass

    def evaluate(self, X, y): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
                y
                    Must match expected type
        """
        pass

    def evaluate_logloss(self, X, y, minimum=None, maximum=None): # reliably restored by inspect
        # no doc
        pass

    def from_bytes(self, bytes_data): # reliably restored by inspect
        # no doc
        pass

    def from_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def pipe(self, stream, batch_size=128): # reliably restored by inspect
        # no doc
        pass

    def predict(self, X): # reliably restored by inspect
        # no doc
        pass

    def predict_one(self, x): # reliably restored by inspect
        # no doc
        pass

    def set_id(self): # reliably restored by inspect
        # no doc
        pass

    def to_bytes(self): # reliably restored by inspect
        # no doc
        pass

    def to_cpu(self): # reliably restored by inspect
        # no doc
        pass

    def to_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def to_gpu(self, device_num): # reliably restored by inspect
        # no doc
        pass

    def update(self, stream, batch_size=1000): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def use_device(cls, *args, **kwargs): # real signature unknown
        """ Change the device to execute on for the scope of the block. """
        pass

    def use_params(*args, **kwds): # reliably restored by inspect
        # no doc
        pass

    def _update_defaults(self, args, kwargs): # reliably restored by inspect
        # no doc
        pass

    def __add__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '+' operator. """
        pass

    def __and__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '&' operator. """
        pass

    def __call__(self, x): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
        """
        pass

    def __div__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __floordiv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '//' operator. """
        pass

    def __getstate__(self): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    def __lshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '<<' operator. """
        pass

    def __matmul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '@' operator. """
        pass

    def __mod__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '%' operator. """
        pass

    def __mul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '*' operator. """
        pass

    def __or__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '|' operator. """
        pass

    def __pow__(self, other, modulo=None): # reliably restored by inspect
        """ Apply the function bound to the '**' operator. """
        pass

    def __rshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '>>' operator. """
        pass

    def __setstate__(self, state_data): # reliably restored by inspect
        # no doc
        pass

    def __sub__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '-' operator. """
        pass

    def __truediv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __xor__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '^' operator. """
        pass

    input_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    descriptions = []
    drop_factor = 1.0
    id = 10
    lsuv = False
    name = 'model'
    on_data_hooks = []
    on_init_hooks = []
    Ops = util.NumpyOps
    ops = None # (!) real value is '<thinc.neural.ops.NumpyOps object at 0x7ffa9387cf60>'
    Trainer = None # (!) real value is "<class 'thinc.neural.train.Trainer'>"
    _operators = {}
    __dict__ = None # (!) real value is "mappingproxy({'on_data_hooks': [], 'Ops': <class 'thinc.neural.ops.NumpyOps'>, 'output_shape': <property object at 0x7ffa8c2a6958>, 'predict': <function Model.predict at 0x7ffa8c2ad8c8>, 'evaluate': <function Model.evaluate at 0x7ffa8c2add90>, '__getstate__': <function Model.__getstate__ at 0x7ffa8c2ad400>, '__rshift__': <FunctionWrapper at 0x7ffa8c2af3f0 for function at 0x7ffa8c2aeb70>, '__doc__': 'Model base class.', '__matmul__': <FunctionWrapper at 0x7ffa8c2af118 for function at 0x7ffa8c2ae400>, 'from_bytes': <function Model.from_bytes at 0x7ffa8c2ae048>, 'drop_factor': 1.0, '__init__': <function Model.__init__ at 0x7ffa8c2ad378>, 'begin_update': <FunctionWrapper at 0x7ffa8c9c3f50 for function at 0x7ffa8c2adbf8>, '_operators': {}, 'input_shape': <property object at 0x7ffa938ae188>, 'name': 'model', 'predict_one': <function Model.predict_one at 0x7ffa8c2ad6a8>, 'set_id': <function Model.set_id at 0x7ffa8c2ad598>, 'evaluate_logloss': <function Model.evaluate_logloss at 0x7ffa8c2ade18>, '__and__': <FunctionWrapper at 0x7ffa8c2af458 for function at 0x7ffa8c2aec80>, '__pow__': <FunctionWrapper at 0x7ffa8c2af320 for function at 0x7ffa8c2ae950>, 'begin_training': <FunctionWrapper at 0x7ffa8c9c3e80 for function at 0x7ffa8c2ad840>, '__xor__': <FunctionWrapper at 0x7ffa8c2af4c0 for function at 0x7ffa8c2aed90>, '__setstate__': <function Model.__setstate__ at 0x7ffa8c2ad488>, '__truediv__': <FunctionWrapper at 0x7ffa8c2af1e8 for function at 0x7ffa8c2ae620>, 'update': <function Model.update at 0x7ffa8c2ada60>, '__call__': <function Model.__call__ at 0x7ffa8c2adb70>, '__lshift__': <FunctionWrapper at 0x7ffa8c2af388 for function at 0x7ffa8c2aea60>, 'from_disk': <function Model.from_disk at 0x7ffa8c2b0048>, 'ops': <thinc.neural.ops.NumpyOps object at 0x7ffa9387cf60>, '__div__': <FunctionWrapper at 0x7ffa8c2af180 for function at 0x7ffa8c2ae510>, '__mod__': <FunctionWrapper at 0x7ffa8c2af2b8 for function at 0x7ffa8c2ae840>, 'to_bytes': <function Model.to_bytes at 0x7ffa8c2aee18>, 'to_disk': <function Model.to_disk at 0x7ffa8c2aef28>, '__weakref__': <attribute '__weakref__' of 'Model' objects>, 'lsuv': False, '__add__': <FunctionWrapper at 0x7ffa8c9c3ee8 for function at 0x7ffa8c2ae0d0>, '__sub__': <FunctionWrapper at 0x7ffa8c2af048 for function at 0x7ffa8c2ae1e0>, 'pipe': <function Model.pipe at 0x7ffa8c2adae8>, '__dict__': <attribute '__dict__' of 'Model' objects>, '__mul__': <FunctionWrapper at 0x7ffa8c2af0b0 for function at 0x7ffa8c2ae2f0>, 'to_gpu': <function Model.to_gpu at 0x7ffa8c2adc80>, 'to_cpu': <function Model.to_cpu at 0x7ffa8c2add08>, 'use_params': <function Model.use_params at 0x7ffa8c2ad7b8>, 'Trainer': <class 'thinc.neural.train.Trainer'>, 'descriptions': [], 'use_device': <classmethod object at 0x7ffa93882198>, 'on_init_hooks': [], '__module__': 'thinc.neural._classes.model', 'define_operators': <classmethod object at 0x7ffa9387cfd0>, '__or__': <FunctionWrapper at 0x7ffa8c2af528 for function at 0x7ffa8c2aeea0>, '_update_defaults': <function Model._update_defaults at 0x7ffa8c2ad510>, 'id': 10, '__floordiv__': <FunctionWrapper at 0x7ffa8c2af250 for function at 0x7ffa8c2ae730>})"


class Affine(__thinc_neural__classes_model.Model):
    """ Computes the linear transform Y = (W @ X) + b. """
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, input__BI, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def nB(self, *args, **kwargs): # real signature unknown
        pass

    def nI(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, input__BI): # reliably restored by inspect
        # no doc
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, nO=None, nI=None, **kwargs): # reliably restored by inspect
        # no doc
        pass

    input_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7ffa93b55748>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7ffa93b55780>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa93b55828>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa93b55cf8>'
        'nB': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa93b555f8>'
        'nI': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa93b55630>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa93b556d8>'
    }
    name = 'affine'
    on_data_hooks = [
        None, # (!) real value is '<function _set_dimensions_if_needed at 0x7ffa93b40c80>'
    ]


class LayerNorm(__thinc_neural__classes_model.Model):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, X, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_G(self, *args, **kwargs): # real signature unknown
        pass

    def G(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, X): # reliably restored by inspect
        # no doc
        pass

    def _begin_update_scale_shift(self, input__BI): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, child, **kwargs): # reliably restored by inspect
        # no doc
        pass

    descriptions = {
        'G': None, # (!) real value is '<thinc.describe.Weights object at 0x7ffa93b0be80>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7ffa93b0beb8>'
        'd_G': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa93b0bf28>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa93b0bf60>'
    }
    name = 'layernorm'
    on_data_hooks = [
        None, # (!) real value is '<function _run_child_hooks at 0x7ffa93b10730>'
    ]


class Maxout(__thinc_neural__classes_model.Model):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, X__bi, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def nI(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def nP(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, X__BI): # reliably restored by inspect
        # no doc
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, nO=None, nI=None, pieces=2, **kwargs): # reliably restored by inspect
        # no doc
        pass

    describe_input = (
        'nI',
    )
    describe_output = (
        'nO',
    )
    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7ffa93b5be10>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7ffa93b5be48>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa93b5be80>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa93b5beb8>'
        'nI': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa93b5bd68>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa93b5bdd8>'
        'nP': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa93b5bda0>'
    }
    name = 'maxout'
    on_data_hooks = [
        None, # (!) real value is '<function _set_dimensions_if_needed at 0x7ffa93b5e378>'
    ]


class OrderedDict(dict):
    """ Dictionary that remembers insertion order """
    def clear(self): # real signature unknown; restored from __doc__
        """ od.clear() -> None.  Remove all items from od. """
        pass

    def copy(self): # real signature unknown; restored from __doc__
        """ od.copy() -> a shallow copy of od """
        pass

    @classmethod
    def fromkeys(cls, S, v=None): # real signature unknown; restored from __doc__
        """
        OD.fromkeys(S[, v]) -> New ordered dictionary with keys from S.
                If not specified, the value defaults to None.
        """
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def move_to_end(self, *args, **kwargs): # real signature unknown
        """
        Move an existing element to the end (or beginning if last==False).
        
                Raises KeyError if the element does not exist.
                When last=True, acts like a fast version of self[key]=self.pop(key).
        """
        pass

    def pop(self, k, d=None): # real signature unknown; restored from __doc__
        """
        od.pop(k[,d]) -> v, remove specified key and return the corresponding
                value.  If key is not found, d is returned if given, otherwise KeyError
                is raised.
        """
        pass

    def popitem(self): # real signature unknown; restored from __doc__
        """
        od.popitem() -> (k, v), return and remove a (key, value) pair.
                Pairs are returned in LIFO order if last is true or FIFO order if false.
        """
        pass

    def setdefault(self, k, d=None): # real signature unknown; restored from __doc__
        """ od.setdefault(k[,d]) -> od.get(k,d), also set od[k]=d if k not in od """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __reversed__(self): # real signature unknown; restored from __doc__
        """ od.__reversed__() <==> reversed(od) """
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """ Set self[key] to value. """
        pass

    def __sizeof__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is "mappingproxy({'clear': <method 'clear' of 'collections.OrderedDict' objects>, '__delitem__': <slot wrapper '__delitem__' of 'collections.OrderedDict' objects>, 'move_to_end': <method 'move_to_end' of 'collections.OrderedDict' objects>, '__sizeof__': <method '__sizeof__' of 'collections.OrderedDict' objects>, 'update': <method 'update' of 'collections.OrderedDict' objects>, 'pop': <method 'pop' of 'collections.OrderedDict' objects>, 'fromkeys': <method 'fromkeys' of 'collections.OrderedDict' objects>, 'keys': <method 'keys' of 'collections.OrderedDict' objects>, 'popitem': <method 'popitem' of 'collections.OrderedDict' objects>, 'setdefault': <method 'setdefault' of 'collections.OrderedDict' objects>, '__ge__': <slot wrapper '__ge__' of 'collections.OrderedDict' objects>, '__reversed__': <method '__reversed__' of 'collections.OrderedDict' objects>, '__doc__': 'Dictionary that remembers insertion order', '__reduce__': <method '__reduce__' of 'collections.OrderedDict' objects>, '__iter__': <slot wrapper '__iter__' of 'collections.OrderedDict' objects>, '__repr__': <slot wrapper '__repr__' of 'collections.OrderedDict' objects>, '__new__': <built-in method __new__ of type object at 0xa36940>, '__dict__': <member '__dict__' of 'collections.OrderedDict' objects>, '__eq__': <slot wrapper '__eq__' of 'collections.OrderedDict' objects>, '__gt__': <slot wrapper '__gt__' of 'collections.OrderedDict' objects>, '__hash__': None, '__init__': <slot wrapper '__init__' of 'collections.OrderedDict' objects>, '__le__': <slot wrapper '__le__' of 'collections.OrderedDict' objects>, '__lt__': <slot wrapper '__lt__' of 'collections.OrderedDict' objects>, 'items': <method 'items' of 'collections.OrderedDict' objects>, '__ne__': <slot wrapper '__ne__' of 'collections.OrderedDict' objects>, 'copy': <method 'copy' of 'collections.OrderedDict' objects>, 'values': <method 'values' of 'collections.OrderedDict' objects>, '__setitem__': <slot wrapper '__setitem__' of 'collections.OrderedDict' objects>})"
    __hash__ = None


class ParserModel(__thinc_neural__classes_model.Model):
    # no doc
    def begin_training(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, *args, **kwargs): # real signature unknown
        pass

    def resize_output(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    lower = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tok2vec = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    upper = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class ParserStepModel(__thinc_neural__classes_model.Model):
    # no doc
    def begin_update(self, *args, **kwargs): # real signature unknown
        pass

    def class_is_unseen(self, *args, **kwargs): # real signature unknown
        pass

    def get_token_ids(self, *args, **kwargs): # real signature unknown
        pass

    def make_updates(self, *args, **kwargs): # real signature unknown
        pass

    def mark_class_seen(self, *args, **kwargs): # real signature unknown
        pass

    def mark_class_unseen(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    nO = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class PrecomputableAffine(__thinc_neural__classes_model.Model):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, X, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_pad(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def init_weights(model): # reliably restored by inspect
        """
        This is like the 'layer sequential unit variance', but instead
                of taking the actual inputs, we randomly generate whitened data.
        
                Why's this all so complicated? We have a huge number of inputs,
                and the maxout unit makes guessing the dynamics tricky. Instead
                we set the maxout weights to values that empirically result in
                whitened outputs given whitened inputs.
        """
        pass

    def nF(self, *args, **kwargs): # real signature unknown
        pass

    def nI(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def nP(self, *args, **kwargs): # real signature unknown
        pass

    def pad(self, *args, **kwargs): # real signature unknown
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def _add_padding(self, Yf): # reliably restored by inspect
        # no doc
        pass

    def _backprop_padding(self, dY, ids): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, nO=None, nI=None, nF=None, nP=None, **kwargs): # reliably restored by inspect
        # no doc
        pass

    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7ffa4df42710>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7ffa4df42860>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa4df42940>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa4df429b0>'
        'd_pad': None, # (!) real value is '<thinc.describe.Gradient object at 0x7ffa4df42978>'
        'nF': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa4df38fd0>'
        'nI': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa4e534f28>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa4df427f0>'
        'nP': None, # (!) real value is '<thinc.describe.Dimension object at 0x7ffa4df42828>'
        'pad': None, # (!) real value is '<thinc.describe.Synapses object at 0x7ffa4df42898>'
    }
    on_data_hooks = [
        None, # (!) real value is '<function _set_dimensions_if_needed at 0x7ffa93b40c80>'
        None, # (!) real value is '<function <lambda> at 0x7ffa4df46ea0>'
    ]


class precompute_hiddens(object):
    """
    Allow a model to be "primed" by pre-computing input features in bulk.
    
        This is used for the parser, where we want to take a batch of documents,
        and compute vectors for each (token, position) pair. These vectors can then
        be reused, especially for beam-search.
    
        Let's say we're using 12 features for each state, e.g. word at start of
        buffer, three words on stack, their children, etc. In the normal arc-eager
        system, a document of length N is processed in 2*N states. This means we'll
        create 2*N*12 feature vectors --- but if we pre-compute, we only need
        N*12 vector computations. The saving for beam-search is much better:
        if we have a beam of k, we'll normally make 2*N*12*K computations --
        so we can save the factor k. This also gives a nice CPU/GPU division:
        we can do all our hard maths up front, packed into large multiplications,
        and do the hard-to-program parsing on the CPU.
    """
    def begin_update(self, *args, **kwargs): # real signature unknown
        pass

    def _nonlinearity(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    nF = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nO = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nP = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ops = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7ffa4bec9e10>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7ffa93d48a58>'

__pyx_capi__ = {
    'arg_max_if_valid': None, # (!) real value is '<capsule object "int (__pyx_t_5thinc_8typedefs_weight_t const *, int const *, int)" at 0x7ffa8c517d80>'
    'cpu_log_loss': None, # (!) real value is '<capsule object "void (float *, float const *, int const *, float const *, int)" at 0x7ffa4bec9b10>'
    'get_c_sizes': None, # (!) real value is '<capsule object "struct __pyx_t_5spacy_6syntax_13_parser_model_SizesC (PyObject *, int)" at 0x7ffa93ca5510>'
    'get_c_weights': None, # (!) real value is '<capsule object "struct __pyx_t_5spacy_6syntax_13_parser_model_WeightsC (PyObject *)" at 0x7ffa93ca53c0>'
    'predict_states': None, # (!) real value is '<capsule object "void (struct __pyx_t_5spacy_6syntax_13_parser_model_ActivationsC *, __pyx_t_5spacy_6syntax_6_state_StateC **, struct __pyx_t_5spacy_6syntax_13_parser_model_WeightsC const *, struct __pyx_t_5spacy_6syntax_13_parser_model_SizesC)" at 0x7ffa93ca5570>'
    'resize_activations': None, # (!) real value is '<capsule object "void (struct __pyx_t_5spacy_6syntax_13_parser_model_ActivationsC *, struct __pyx_t_5spacy_6syntax_13_parser_model_SizesC)" at 0x7ffa93ca55d0>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.syntax._parser_model', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7ffa93d48a58>, origin='/usr/local/lib/python3.5/dist-packages/spacy/syntax/_parser_model.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module spacy.gold
# from /usr/local/lib/python3.5/dist-packages/spacy/gold.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import random as random # /usr/lib/python3.5/random.py
import re as re # /usr/lib/python3.5/re.py
import srsly as srsly # /usr/local/lib/python3.5/dist-packages/srsly/__init__.py
import tempfile as tempfile # /usr/lib/python3.5/tempfile.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
import spacy.util as util # /usr/local/lib/python3.5/dist-packages/spacy/util.py
import shutil as shutil # /usr/lib/python3.5/shutil.py
import spacy.syntax.nonproj as nonproj # /usr/local/lib/python3.5/dist-packages/spacy/syntax/nonproj.cpython-35m-x86_64-linux-gnu.so
import spacy._align as _align # /usr/local/lib/python3.5/dist-packages/spacy/_align.cpython-35m-x86_64-linux-gnu.so
import numpy as numpy # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
from spacy.tokens.doc import Doc

from spacy.tokens.span import Span

import pathlib as __pathlib


# functions

def add_noise(*args, **kwargs): # real signature unknown
    pass

def align(*args, **kwargs): # real signature unknown
    pass

def biluo_tags_from_offsets(doc, entities): # real signature unknown; restored from __doc__
    """
    Encode labelled spans into per-token tags, using the
        Begin/In/Last/Unit/Out scheme (BILUO).
    
        doc (Doc): The document that the entity offsets refer to. The output tags
            will refer to the token boundaries within the document.
        entities (iterable): A sequence of `(start, end, label)` triples. `start`
            and `end` should be character-offset integers denoting the slice into
            the original string.
        RETURNS (list): A list of unicode strings, describing the tags. Each tag
            string will be of the form either "", "O" or "{action}-{label}", where
            action is one of "B", "I", "L", "U". The string "-" is used where the
            entity offsets don't align with the tokenization in the `Doc` object.
            The training algorithm will view these as missing values. "O" denotes a
            non-entity token. "B" denotes the beginning of a multi-token entity,
            "I" the inside of an entity of three or more tokens, and "L" the end
            of an entity of two or more tokens. "U" denotes a single-token entity.
    
        EXAMPLE:
            >>> text = 'I like London.'
            >>> entities = [(len('I like '), len('I like London'), 'LOC')]
            >>> doc = nlp.tokenizer(text)
            >>> tags = biluo_tags_from_offsets(doc, entities)
            >>> assert tags == ["O", "O", 'U-LOC', "O"]
    """
    pass

def docs_to_json(*args, **kwargs): # real signature unknown
    """
    Convert a list of Doc objects into the JSON-serializable format used by
        the spacy train command.
    
        docs (iterable / Doc): The Doc object(s) to convert.
        id (int): Id for the JSON.
        RETURNS (list): The data in spaCy's JSON format.
    """
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def iob_to_biluo(*args, **kwargs): # real signature unknown
    pass

def is_punct_label(*args, **kwargs): # real signature unknown
    pass

def itershuffle(iterable, bufsize=1000): # reliably restored by inspect
    """
    Shuffle an iterator. This works by holding `bufsize` items back
        and yielding them sometime later. Obviously, this is not unbiased –
        but should be good enough for batching. Larger bufsize means less bias.
        From https://gist.github.com/andres-erbsen/1307752
    
        iterable (iterable): Iterator to shuffle.
        bufsize (int): Items to hold back.
        YIELDS (iterable): The shuffled iterator.
    """
    pass

def json_to_tuple(*args, **kwargs): # real signature unknown
    """
    Convert an item in the JSON-formatted training data to the tuple format
        used by GoldParse.
    
        doc (dict): One entry in the training data.
        YIELDS (tuple): The reformatted data.
    """
    pass

def merge_sents(*args, **kwargs): # real signature unknown
    pass

def minibatch(items, size=8): # reliably restored by inspect
    """
    Iterate over batches of items. `size` may be an iterator,
        so that batch-size can vary on each step.
    """
    pass

def offsets_from_biluo_tags(*args, **kwargs): # real signature unknown
    """
    Encode per-token tags following the BILUO scheme into entity offsets.
    
        doc (Doc): The document that the BILUO tags refer to.
        entities (iterable): A sequence of BILUO tags with each tag describing one
            token. Each tags string will be of the form of either "", "O" or
            "{action}-{label}", where action is one of "B", "I", "L", "U".
        RETURNS (list): A sequence of `(start, end, label)` triples. `start` and
            `end` will be character-offset integers denoting the slice into the
            original string.
    """
    pass

def path2str(path): # reliably restored by inspect
    # no doc
    pass

def read_json_file(*args, **kwargs): # real signature unknown
    pass

def read_json_object(*args, **kwargs): # real signature unknown
    """
    Take a list of JSON-formatted documents (e.g. from an already loaded
        training data file) and yield tuples in the GoldParse format.
    
        json_corpus_section (list): The data.
        YIELDS (tuple): The reformatted data.
    """
    pass

def spans_from_biluo_tags(*args, **kwargs): # real signature unknown
    """
    Encode per-token tags following the BILUO scheme into Span object, e.g.
        to overwrite the doc.ents.
    
        doc (Doc): The document that the BILUO tags refer to.
        entities (iterable): A sequence of BILUO tags with each tag describing one
            token. Each tags string will be of the form of either "", "O" or
            "{action}-{label}", where action is one of "B", "I", "L", "U".
        RETURNS (list): A sequence of Span objects.
    """
    pass

def tags_to_entities(*args, **kwargs): # real signature unknown
    pass

def _consume_ent(*args, **kwargs): # real signature unknown
    pass

def _consume_os(*args, **kwargs): # real signature unknown
    pass

def _corrupt(*args, **kwargs): # real signature unknown
    pass

def _json_iterate(*args, **kwargs): # real signature unknown
    pass

# classes

class GoldCorpus(object):
    """
    An annotated corpus, using the JSON file format. Manages
        annotations for tagging, dependency parsing and NER.
    
        DOCS: https://spacy.io/api/goldcorpus
    """
    def count_train(self, *args, **kwargs): # real signature unknown
        pass

    def dev_docs(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def iter_gold_docs(cls, *args, **kwargs): # real signature unknown
        pass

    def read_tuples(self, *args, **kwargs): # real signature unknown
        pass

    def train_docs(self, *args, **kwargs): # real signature unknown
        pass

    def walk_corpus(self, *args, **kwargs): # real signature unknown
        pass

    def write_msgpack(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def _make_docs(cls, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def _make_golds(cls, *args, **kwargs): # real signature unknown
        pass

    def __del__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create a GoldCorpus.
        
                train_path (unicode or Path): File or directory of training data.
                dev_path (unicode or Path): File or directory of development data.
                RETURNS (GoldCorpus): The newly created object.
        """
        pass

    dev_tuples = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    train_tuples = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.gold', '__dict__': <attribute '__dict__' of 'GoldCorpus' objects>, '__del__': <cyfunction GoldCorpus.__del__ at 0x7fb489ac76c0>, 'iter_gold_docs': <classmethod object at 0x7fb48982fda0>, '_make_docs': <classmethod object at 0x7fb487a73fd0>, 'walk_corpus': <staticmethod object at 0x7fb489af9cf8>, 'train_docs': <cyfunction GoldCorpus.train_docs at 0x7fb489ac7df0>, '__weakref__': <attribute '__weakref__' of 'GoldCorpus' objects>, 'read_tuples': <staticmethod object at 0x7fb489af9c50>, '__init__': <cyfunction GoldCorpus.__init__ at 0x7fb489ac7608>, 'dev_tuples': <property object at 0x7fb489835778>, 'write_msgpack': <staticmethod object at 0x7fb4ca4d02b0>, 'dev_docs': <cyfunction GoldCorpus.dev_docs at 0x7fb489ac7ea8>, 'train_tuples': <property object at 0x7fb487a72f48>, '__doc__': 'An annotated corpus, using the JSON file format. Manages\\n    annotations for tagging, dependency parsing and NER.\\n\\n    DOCS: https://spacy.io/api/goldcorpus\\n    ', '_make_golds': <classmethod object at 0x7fb487a79080>, 'count_train': <cyfunction GoldCorpus.count_train at 0x7fb489ac7d38>})"


class GoldParse(object):
    """
    Collection for training annotations.
    
        DOCS: https://spacy.io/api/goldparse
    """
    @classmethod
    def from_annot_tuples(cls, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create a GoldParse.
        
                doc (Doc): The document the annotations refer to.
                words (iterable): A sequence of unicode word strings.
                tags (iterable): A sequence of strings, representing tag annotations.
                heads (iterable): A sequence of integers, representing syntactic
                    head offsets.
                deps (iterable): A sequence of strings, representing the syntactic
                    relation types.
                entities (iterable): A sequence of named entity annotations, either as
                    BILUO tag strings, or as `(start_char, end_char, label)` tuples,
                    representing the entity positions.
                cats (dict): Labels for text classification. Each key in the dictionary
                    may be a string or an int, or a `(start_char, end_char, label)`
                    tuple, indicating that the label is applied to only part of the
                    document (usually a sentence). Unlike entity annotations, label
                    annotations can overlap, i.e. a single word can be covered by
                    multiple labelled spans. The TextCategorizer component expects
                    true examples of a label to have the value 1.0, and negative
                    examples of a label to have the value 0.0. Labels not in the
                    dictionary are treated as missing - the gradient for those labels
                    will be zero.
                RETURNS (GoldParse): The newly constructed object.
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        Get the number of gold-standard tokens.
        
                RETURNS (int): The number of gold-standard tokens.
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    brackets = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    cand_to_gold = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    cats = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ents = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    gold_to_cand = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    heads = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    is_projective = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Whether the provided syntactic annotations form a projective
        dependency tree.
        """

    labels = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loss = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ner = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    orig_annot = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    orths = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    sent_starts = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tags = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    words = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class Path(__pathlib.PurePath):
    # no doc
    def absolute(self): # reliably restored by inspect
        """
        Return an absolute version of this path.  This function works
                even if the path doesn't point to anything.
        
                No normalization is done, i.e. all '.' and '..' will be kept along.
                Use resolve() to get the canonical path to a file.
        """
        pass

    def chmod(self, mode): # reliably restored by inspect
        """ Change the permissions of the path, like os.chmod(). """
        pass

    @classmethod
    def cwd(cls): # real signature unknown; restored from __doc__
        """
        Return a new path pointing to the current working directory
                (as returned by os.getcwd()).
        """
        pass

    def exists(self): # reliably restored by inspect
        """ Whether this path exists. """
        pass

    def expanduser(self): # reliably restored by inspect
        """
        Return a new path with expanded ~ and ~user constructs
                (as returned by os.path.expanduser)
        """
        pass

    def glob(self, pattern): # reliably restored by inspect
        """
        Iterate over this subtree and yield all existing files (of any
                kind, including directories) matching the given pattern.
        """
        pass

    def group(self): # reliably restored by inspect
        """ Return the group name of the file gid. """
        pass

    @classmethod
    def home(cls, *args, **kwargs): # real signature unknown
        """
        Return a new path pointing to the user's home directory (as
                returned by os.path.expanduser('~')).
        """
        pass

    def is_block_device(self): # reliably restored by inspect
        """ Whether this path is a block device. """
        pass

    def is_char_device(self): # reliably restored by inspect
        """ Whether this path is a character device. """
        pass

    def is_dir(self): # reliably restored by inspect
        """ Whether this path is a directory. """
        pass

    def is_fifo(self): # reliably restored by inspect
        """ Whether this path is a FIFO. """
        pass

    def is_file(self): # reliably restored by inspect
        """
        Whether this path is a regular file (also True for symlinks pointing
                to regular files).
        """
        pass

    def is_socket(self): # reliably restored by inspect
        """ Whether this path is a socket. """
        pass

    def is_symlink(self): # reliably restored by inspect
        """ Whether this path is a symbolic link. """
        pass

    def iterdir(self): # reliably restored by inspect
        """
        Iterate over the files in this directory.  Does not yield any
                result for the special paths '.' and '..'.
        """
        pass

    def lchmod(self, mode): # reliably restored by inspect
        """
        Like chmod(), except if the path points to a symlink, the symlink's
                permissions are changed, rather than its target's.
        """
        pass

    def lstat(self): # reliably restored by inspect
        """
        Like stat(), except if the path points to a symlink, the symlink's
                status information is returned, rather than its target's.
        """
        pass

    def mkdir(self, mode=511, parents=False, exist_ok=False): # reliably restored by inspect
        # no doc
        pass

    def open(self, mode=None, buffering=-1, encoding=None, errors=None, newline=None): # reliably restored by inspect
        """
        Open the file pointed by this path and return a file object, as
                the built-in open() function does.
        """
        pass

    def owner(self): # reliably restored by inspect
        """ Return the login name of the file owner. """
        pass

    def read_bytes(self): # reliably restored by inspect
        """ Open the file in bytes mode, read it, and close the file. """
        pass

    def read_text(self, encoding=None, errors=None): # reliably restored by inspect
        """ Open the file in text mode, read it, and close the file. """
        pass

    def rename(self, target): # reliably restored by inspect
        """ Rename this path to the given path. """
        pass

    def replace(self, target): # reliably restored by inspect
        """
        Rename this path to the given path, clobbering the existing
                destination if it exists.
        """
        pass

    def resolve(self): # reliably restored by inspect
        """
        Make the path absolute, resolving all symlinks on the way and also
                normalizing it (for example turning slashes into backslashes under
                Windows).
        """
        pass

    def rglob(self, pattern): # reliably restored by inspect
        """
        Recursively yield all existing files (of any kind, including
                directories) matching the given pattern, anywhere in this subtree.
        """
        pass

    def rmdir(self): # reliably restored by inspect
        """ Remove this directory.  The directory must be empty. """
        pass

    def samefile(self, other_path): # reliably restored by inspect
        """
        Return whether other_path is the same or not as this file
                (as returned by os.path.samefile()).
        """
        pass

    def stat(self): # reliably restored by inspect
        """
        Return the result of the stat() system call on this path, like
                os.stat() does.
        """
        pass

    def symlink_to(self, target, target_is_directory=False): # reliably restored by inspect
        """
        Make this path a symlink pointing to the given path.
                Note the order of arguments (self, target) is the reverse of os.symlink's.
        """
        pass

    def touch(self, mode=438, exist_ok=True): # reliably restored by inspect
        """ Create this file with the given access mode, if it doesn't exist. """
        pass

    def unlink(self): # reliably restored by inspect
        """
        Remove this file or link.
                If the path is a directory, use rmdir() instead.
        """
        pass

    def write_bytes(self, data): # reliably restored by inspect
        """ Open the file in bytes mode, write to it, and close the file. """
        pass

    def write_text(self, data, encoding=None, errors=None): # reliably restored by inspect
        """ Open the file in text mode, write to it, and close the file. """
        pass

    def _init(self, template=None): # reliably restored by inspect
        # no doc
        pass

    def _make_child_relpath(self, part): # reliably restored by inspect
        # no doc
        pass

    def _opener(self, name, flags, mode=438): # reliably restored by inspect
        # no doc
        pass

    def _raise_closed(self): # reliably restored by inspect
        # no doc
        pass

    def _raw_open(self, flags, mode=511): # reliably restored by inspect
        """
        Open the file pointed by this path and return a file descriptor,
                as os.open() does.
        """
        pass

    def __enter__(self): # reliably restored by inspect
        # no doc
        pass

    def __exit__(self, t, v, tb): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(cls, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    _accessor = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _closed = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __slots__ = (
        '_accessor',
        '_closed',
    )


# variables with complex values

punct_re = None # (!) real value is "re.compile('\\\\W')"

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb489aedf60>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.gold', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb489aedf60>, origin='/usr/local/lib/python3.5/dist-packages/spacy/gold.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {
    'biluo_tags_from_offsets (line 632)': 'Encode labelled spans into per-token tags, using the\n    Begin/In/Last/Unit/Out scheme (BILUO).\n\n    doc (Doc): The document that the entity offsets refer to. The output tags\n        will refer to the token boundaries within the document.\n    entities (iterable): A sequence of `(start, end, label)` triples. `start`\n        and `end` should be character-offset integers denoting the slice into\n        the original string.\n    RETURNS (list): A list of unicode strings, describing the tags. Each tag\n        string will be of the form either "", "O" or "{action}-{label}", where\n        action is one of "B", "I", "L", "U". The string "-" is used where the\n        entity offsets don\'t align with the tokenization in the `Doc` object.\n        The training algorithm will view these as missing values. "O" denotes a\n        non-entity token. "B" denotes the beginning of a multi-token entity,\n        "I" the inside of an entity of three or more tokens, and "L" the end\n        of an entity of two or more tokens. "U" denotes a single-token entity.\n\n    EXAMPLE:\n        >>> text = \'I like London.\'\n        >>> entities = [(len(\'I like \'), len(\'I like London\'), \'LOC\')]\n        >>> doc = nlp.tokenizer(text)\n        >>> tags = biluo_tags_from_offsets(doc, entities)\n        >>> assert tags == ["O", "O", \'U-LOC\', "O"]\n    ',
}


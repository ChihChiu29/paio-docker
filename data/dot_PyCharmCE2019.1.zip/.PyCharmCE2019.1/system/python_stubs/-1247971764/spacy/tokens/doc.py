# encoding: utf-8
# module spacy.tokens.doc
# from /usr/local/lib/python3.5/dist-packages/spacy/tokens/doc.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import pickle as pickle # /usr/lib/python3.5/pickle.py
import copyreg as copy_reg # /usr/lib/python3.5/copyreg.py
import spacy.util as util # /usr/local/lib/python3.5/dist-packages/spacy/util.py
import srsly as srsly # /usr/local/lib/python3.5/dist-packages/srsly/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
import struct as struct # /usr/lib/python3.5/struct.py
import numpy as numpy # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
from spacy.attrs import intify_attrs

from spacy.tokens._retokenize import Retokenizer


# functions

def copy_array(dst, src, casting=None, where=None): # reliably restored by inspect
    # no doc
    pass

def deprecation_warning(message): # reliably restored by inspect
    # no doc
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def fix_attributes(*args, **kwargs): # real signature unknown
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def get_entity_info(*args, **kwargs): # real signature unknown
    pass

def get_ext_args(**kwargs): # reliably restored by inspect
    """ Validate and convert arguments. Reused in Doc, Token and Span. """
    pass

def is_config(python2=None, python3=None, windows=None, linux=None, osx=None): # reliably restored by inspect
    """
    Check if a specific configuration of Python version and operating system
        matches the user's setup. Mostly used to display targeted error messages.
    
        python2 (bool): spaCy is executed with Python 2.x.
        python3 (bool): spaCy is executed with Python 3.x.
        windows (bool): spaCy is executed on Windows.
        linux (bool): spaCy is executed on Linux.
        osx (bool): spaCy is executed on OS X or macOS.
        RETURNS (bool): Whether the configuration matches the user's platform.
    
        DOCS: https://spacy.io/api/top-level#compat.is_config
    """
    pass

def models_warning(message): # reliably restored by inspect
    # no doc
    pass

def normalize_slice(length, start, stop, step=None): # reliably restored by inspect
    # no doc
    pass

def pickle_doc(*args, **kwargs): # real signature unknown
    pass

def remove_label_if_necessary(*args, **kwargs): # real signature unknown
    pass

def unpickle_doc(*args, **kwargs): # real signature unknown
    pass

def user_warning(message): # reliably restored by inspect
    # no doc
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def _get_chunker(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class basestring_(object):
    """
    str(object='') -> str
    str(bytes_or_buffer[, encoding[, errors]]) -> str
    
    Create a new string object from the given object. If encoding or
    errors is specified, then the object must expose a data buffer
    that will be decoded using the given encoding and error handler.
    Otherwise, returns the result of object.__str__() (if defined)
    or repr(object).
    encoding defaults to sys.getdefaultencoding().
    errors defaults to 'strict'.
    """
    def capitalize(self): # real signature unknown; restored from __doc__
        """
        S.capitalize() -> str
        
        Return a capitalized version of S, i.e. make the first character
        have upper case and the rest lower case.
        """
        return ""

    def casefold(self): # real signature unknown; restored from __doc__
        """
        S.casefold() -> str
        
        Return a version of S suitable for caseless comparisons.
        """
        return ""

    def center(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.center(width[, fillchar]) -> str
        
        Return S centered in a string of length width. Padding is
        done using the specified fill character (default is a space)
        """
        return ""

    def count(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.count(sub[, start[, end]]) -> int
        
        Return the number of non-overlapping occurrences of substring sub in
        string S[start:end].  Optional arguments start and end are
        interpreted as in slice notation.
        """
        return 0

    def encode(self, encoding='utf-8', errors='strict'): # real signature unknown; restored from __doc__
        """
        S.encode(encoding='utf-8', errors='strict') -> bytes
        
        Encode S using the codec registered for encoding. Default encoding
        is 'utf-8'. errors may be given to set a different error
        handling scheme. Default is 'strict' meaning that encoding errors raise
        a UnicodeEncodeError. Other possible values are 'ignore', 'replace' and
        'xmlcharrefreplace' as well as any other name registered with
        codecs.register_error that can handle UnicodeEncodeErrors.
        """
        return b""

    def endswith(self, suffix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.endswith(suffix[, start[, end]]) -> bool
        
        Return True if S ends with the specified suffix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        suffix can also be a tuple of strings to try.
        """
        return False

    def expandtabs(self, tabsize=8): # real signature unknown; restored from __doc__
        """
        S.expandtabs(tabsize=8) -> str
        
        Return a copy of S where all tab characters are expanded using spaces.
        If tabsize is not given, a tab size of 8 characters is assumed.
        """
        return ""

    def find(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.find(sub[, start[, end]]) -> int
        
        Return the lowest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def format(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        S.format(*args, **kwargs) -> str
        
        Return a formatted version of S, using substitutions from args and kwargs.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def format_map(self, mapping): # real signature unknown; restored from __doc__
        """
        S.format_map(mapping) -> str
        
        Return a formatted version of S, using substitutions from mapping.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def index(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.index(sub[, start[, end]]) -> int
        
        Like S.find() but raise ValueError when the substring is not found.
        """
        return 0

    def isalnum(self): # real signature unknown; restored from __doc__
        """
        S.isalnum() -> bool
        
        Return True if all characters in S are alphanumeric
        and there is at least one character in S, False otherwise.
        """
        return False

    def isalpha(self): # real signature unknown; restored from __doc__
        """
        S.isalpha() -> bool
        
        Return True if all characters in S are alphabetic
        and there is at least one character in S, False otherwise.
        """
        return False

    def isdecimal(self): # real signature unknown; restored from __doc__
        """
        S.isdecimal() -> bool
        
        Return True if there are only decimal characters in S,
        False otherwise.
        """
        return False

    def isdigit(self): # real signature unknown; restored from __doc__
        """
        S.isdigit() -> bool
        
        Return True if all characters in S are digits
        and there is at least one character in S, False otherwise.
        """
        return False

    def isidentifier(self): # real signature unknown; restored from __doc__
        """
        S.isidentifier() -> bool
        
        Return True if S is a valid identifier according
        to the language definition.
        
        Use keyword.iskeyword() to test for reserved identifiers
        such as "def" and "class".
        """
        return False

    def islower(self): # real signature unknown; restored from __doc__
        """
        S.islower() -> bool
        
        Return True if all cased characters in S are lowercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def isnumeric(self): # real signature unknown; restored from __doc__
        """
        S.isnumeric() -> bool
        
        Return True if there are only numeric characters in S,
        False otherwise.
        """
        return False

    def isprintable(self): # real signature unknown; restored from __doc__
        """
        S.isprintable() -> bool
        
        Return True if all characters in S are considered
        printable in repr() or S is empty, False otherwise.
        """
        return False

    def isspace(self): # real signature unknown; restored from __doc__
        """
        S.isspace() -> bool
        
        Return True if all characters in S are whitespace
        and there is at least one character in S, False otherwise.
        """
        return False

    def istitle(self): # real signature unknown; restored from __doc__
        """
        S.istitle() -> bool
        
        Return True if S is a titlecased string and there is at least one
        character in S, i.e. upper- and titlecase characters may only
        follow uncased characters and lowercase characters only cased ones.
        Return False otherwise.
        """
        return False

    def isupper(self): # real signature unknown; restored from __doc__
        """
        S.isupper() -> bool
        
        Return True if all cased characters in S are uppercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def join(self, iterable): # real signature unknown; restored from __doc__
        """
        S.join(iterable) -> str
        
        Return a string which is the concatenation of the strings in the
        iterable.  The separator between elements is S.
        """
        return ""

    def ljust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.ljust(width[, fillchar]) -> str
        
        Return S left-justified in a Unicode string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def lower(self): # real signature unknown; restored from __doc__
        """
        S.lower() -> str
        
        Return a copy of the string S converted to lowercase.
        """
        return ""

    def lstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.lstrip([chars]) -> str
        
        Return a copy of the string S with leading whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def maketrans(self, *args, **kwargs): # real signature unknown
        """
        Return a translation table usable for str.translate().
        
        If there is only one argument, it must be a dictionary mapping Unicode
        ordinals (integers) or characters to Unicode ordinals, strings or None.
        Character keys will be then converted to ordinals.
        If there are two arguments, they must be strings of equal length, and
        in the resulting dictionary, each character in x will be mapped to the
        character at the same position in y. If there is a third argument, it
        must be a string, whose characters will be mapped to None in the result.
        """
        pass

    def partition(self, sep): # real signature unknown; restored from __doc__
        """
        S.partition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, and return the part before it,
        the separator itself, and the part after it.  If the separator is not
        found, return S and two empty strings.
        """
        pass

    def replace(self, old, new, count=None): # real signature unknown; restored from __doc__
        """
        S.replace(old, new[, count]) -> str
        
        Return a copy of S with all occurrences of substring
        old replaced by new.  If the optional argument count is
        given, only the first count occurrences are replaced.
        """
        return ""

    def rfind(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rfind(sub[, start[, end]]) -> int
        
        Return the highest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def rindex(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rindex(sub[, start[, end]]) -> int
        
        Like S.rfind() but raise ValueError when the substring is not found.
        """
        return 0

    def rjust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.rjust(width[, fillchar]) -> str
        
        Return S right-justified in a string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def rpartition(self, sep): # real signature unknown; restored from __doc__
        """
        S.rpartition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, starting at the end of S, and return
        the part before it, the separator itself, and the part after it.  If the
        separator is not found, return two empty strings and S.
        """
        pass

    def rsplit(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.rsplit(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string, starting at the end of the string and
        working to the front.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified, any whitespace string
        is a separator.
        """
        return []

    def rstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.rstrip([chars]) -> str
        
        Return a copy of the string S with trailing whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def split(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.split(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified or is None, any
        whitespace string is a separator and empty strings are
        removed from the result.
        """
        return []

    def splitlines(self, keepends=None): # real signature unknown; restored from __doc__
        """
        S.splitlines([keepends]) -> list of strings
        
        Return a list of the lines in S, breaking at line boundaries.
        Line breaks are not included in the resulting list unless keepends
        is given and true.
        """
        return []

    def startswith(self, prefix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.startswith(prefix[, start[, end]]) -> bool
        
        Return True if S starts with the specified prefix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        prefix can also be a tuple of strings to try.
        """
        return False

    def strip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.strip([chars]) -> str
        
        Return a copy of the string S with leading and trailing
        whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def swapcase(self): # real signature unknown; restored from __doc__
        """
        S.swapcase() -> str
        
        Return a copy of S with uppercase characters converted to lowercase
        and vice versa.
        """
        return ""

    def title(self): # real signature unknown; restored from __doc__
        """
        S.title() -> str
        
        Return a titlecased version of S, i.e. words start with title case
        characters, all remaining cased characters have lower case.
        """
        return ""

    def translate(self, table): # real signature unknown; restored from __doc__
        """
        S.translate(table) -> str
        
        Return a copy of the string S in which each character has been mapped
        through the given translation table. The table must implement
        lookup/indexing via __getitem__, for instance a dictionary or list,
        mapping Unicode ordinals to Unicode ordinals, strings, or None. If
        this operation raises LookupError, the character is left untouched.
        Characters mapped to None are deleted.
        """
        return ""

    def upper(self): # real signature unknown; restored from __doc__
        """
        S.upper() -> str
        
        Return a copy of S converted to uppercase.
        """
        return ""

    def zfill(self, width): # real signature unknown; restored from __doc__
        """
        S.zfill(width) -> str
        
        Pad a numeric string S with zeros on the left, to fill a field
        of the specified width. The string S is never truncated.
        """
        return ""

    def __add__(self, *args, **kwargs): # real signature unknown
        """ Return self+value. """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """ Return key in self. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __format__(self, format_spec): # real signature unknown; restored from __doc__
        """
        S.__format__(format_spec) -> str
        
        Return a formatted version of S as described by format_spec.
        """
        return ""

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __getnewargs__(self, *args, **kwargs): # real signature unknown
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __mod__(self, *args, **kwargs): # real signature unknown
        """ Return self%value. """
        pass

    def __mul__(self, *args, **kwargs): # real signature unknown
        """ Return self*value.n """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __rmod__(self, *args, **kwargs): # real signature unknown
        """ Return value%self. """
        pass

    def __rmul__(self, *args, **kwargs): # real signature unknown
        """ Return self*value. """
        pass

    def __sizeof__(self): # real signature unknown; restored from __doc__
        """ S.__sizeof__() -> size of S in memory, in bytes """
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """ Return str(self). """
        pass


class Doc(object):
    """
    A sequence of Token objects. Access sentences and named entities, export
        annotations to numpy arrays, losslessly serialize to compressed binary
        strings. The `Doc` object holds an array of `TokenC` structs. The
        Python-level `Token` and `Span` objects are views of this array, i.e.
        they don't own the data themselves.
    
        EXAMPLE: Construction 1
            >>> doc = nlp(u'Some text')
    
            Construction 2
            >>> from spacy.tokens import Doc
            >>> doc = Doc(nlp.vocab, words=[u'hello', u'world', u'!'],
                          spaces=[True, False, False])
    
        DOCS: https://spacy.io/api/doc
    """
    def char_span(self, *args, **kwargs): # real signature unknown
        """
        Create a `Span` object from the slice `doc.text[start : end]`.
        
                doc (Doc): The parent document.
                start (int): The index of the first character of the span.
                end (int): The index of the first character after the span.
                label (uint64 or string): A label to attach to the Span, e.g. for
                    named entities.
                vector (ndarray[ndim=1, dtype='float32']): A meaning representation of
                    the span.
                RETURNS (Span): The newly constructed object.
        
                DOCS: https://spacy.io/api/doc#char_span
        """
        pass

    def count_by(self, *args, **kwargs): # real signature unknown
        """
        Count the frequencies of a given attribute. Produces a dict of
                `{attribute (int): count (ints)}` frequencies, keyed by the values of
                the given attribute ID.
        
                attr_id (int): The attribute ID to key the counts.
                RETURNS (dict): A dictionary mapping attributes to integer counts.
        
                DOCS: https://spacy.io/api/doc#count_by
        """
        pass

    def extend_tensor(self, *args, **kwargs): # real signature unknown
        """
        Concatenate a new tensor onto the doc.tensor object.
        
                The doc.tensor attribute holds dense feature vectors
                computed by the models in the pipeline. Let's say a
                document with 30 words has a tensor with 128 dimensions
                per word. doc.tensor.shape will be (30, 128). After
                calling doc.extend_tensor with an array of shape (30, 64),
                doc.tensor == (30, 192).
        """
        pass

    def from_array(self, *args, **kwargs): # real signature unknown
        """
        Load attributes from a numpy array. Write to a `Doc` object, from an
                `(M, N)` array of attributes.
        
                attrs (list) A list of attribute ID ints.
                array (numpy.ndarray[ndim=2, dtype='int32']): The attribute values.
                RETURNS (Doc): Itself.
        
                DOCS: https://spacy.io/api/doc#from_array
        """
        pass

    def from_bytes(self, *args, **kwargs): # real signature unknown
        """
        Deserialize, i.e. import the document contents from a binary string.
        
                data (bytes): The string to load from.
                exclude (list): String names of serialization fields to exclude.
                RETURNS (Doc): Itself.
        
                DOCS: https://spacy.io/api/doc#from_bytes
        """
        pass

    def from_disk(self, *args, **kwargs): # real signature unknown
        """
        Loads state from a directory. Modifies the object in place and
                returns it.
        
                path (unicode or Path): A path to a directory. Paths may be either
                    strings or `Path`-like objects.
                exclude (list): String names of serialization fields to exclude.
                RETURNS (Doc): The modified `Doc` object.
        
                DOCS: https://spacy.io/api/doc#from_disk
        """
        pass

    @classmethod
    def get_extension(cls, *args, **kwargs): # real signature unknown
        """
        Look up a previously registered extension by name.
        
                name (unicode): Name of the extension.
                RETURNS (tuple): A `(default, method, getter, setter)` tuple.
        
                DOCS: https://spacy.io/api/doc#get_extension
        """
        pass

    def get_lca_matrix(self, *args, **kwargs): # real signature unknown
        """
        Calculates a matrix of Lowest Common Ancestors (LCA) for a given
                `Doc`, where LCA[i, j] is the index of the lowest common ancestor among
                token i and j.
        
                RETURNS (np.array[ndim=2, dtype=numpy.int32]): LCA matrix with shape
                    (n, n), where n = len(self).
        
                DOCS: https://spacy.io/api/doc#get_lca_matrix
        """
        pass

    @classmethod
    def has_extension(cls, *args, **kwargs): # real signature unknown
        """
        Check whether an extension has been registered.
        
                name (unicode): Name of the extension.
                RETURNS (bool): Whether the extension has been registered.
        
                DOCS: https://spacy.io/api/doc#has_extension
        """
        pass

    def merge(self, *args, **kwargs): # real signature unknown
        """
        Retokenize the document, such that the span at
                `doc.text[start_idx : end_idx]` is merged into a single token. If
                `start_idx` and `end_idx `do not mark start and end token boundaries,
                the document remains unchanged.
        
                start_idx (int): Character index of the start of the slice to merge.
                end_idx (int): Character index after the end of the slice to merge.
                **attributes: Attributes to assign to the merged token. By default,
                    attributes are inherited from the syntactic root of the span.
                RETURNS (Token): The newly merged token, or `None` if the start and end
                    indices did not fall at token boundaries.
        """
        pass

    def print_tree(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def remove_extension(cls, *args, **kwargs): # real signature unknown
        """
        Remove a previously registered extension.
        
                name (unicode): Name of the extension.
                RETURNS (tuple): A `(default, method, getter, setter)` tuple of the
                    removed extension.
        
                DOCS: https://spacy.io/api/doc#remove_extension
        """
        pass

    def retokenize(self, *args, **kwargs): # real signature unknown
        """
        Context manager to handle retokenization of the Doc.
                Modifications to the Doc's tokenization are stored, and then
                made all at once when the context manager exits. This is
                much more efficient, and less error-prone.
        
                All views of the Doc (Span and Token) created before the
                retokenization are invalidated, although they may accidentally
                continue to work.
        
                DOCS: https://spacy.io/api/doc#retokenize
                USAGE: https://spacy.io/usage/linguistic-features#retokenization
        """
        pass

    @classmethod
    def set_extension(cls, *args, **kwargs): # real signature unknown
        """
        Define a custom attribute which becomes available as `Doc._`.
        
                name (unicode): Name of the attribute to set.
                default: Optional default value of the attribute.
                getter (callable): Optional getter function.
                setter (callable): Optional setter function.
                method (callable): Optional method for method extension.
                force (bool): Force overwriting existing attribute.
        
                DOCS: https://spacy.io/api/doc#set_extension
                USAGE: https://spacy.io/usage/processing-pipelines#custom-components-attributes
        """
        pass

    def similarity(self, *args, **kwargs): # real signature unknown
        """
        Make a semantic similarity estimate. The default estimate is cosine
                similarity using an average of word vectors.
        
                other (object): The object to compare with. By default, accepts `Doc`,
                    `Span`, `Token` and `Lexeme` objects.
                RETURNS (float): A scalar similarity score. Higher is more similar.
        
                DOCS: https://spacy.io/api/doc#similarity
        """
        pass

    def to_array(self, LOWER=None, POS=None, ENT_TYPE=None, IS_ALPHA=None): # real signature unknown; restored from __doc__
        """
        Export given token attributes to a numpy `ndarray`.
                If `attr_ids` is a sequence of M attributes, the output array will be
                of shape `(N, M)`, where N is the length of the `Doc` (in tokens). If
                `attr_ids` is a single attribute, the output shape will be (N,). You
                can specify attributes by integer ID (e.g. spacy.attrs.LEMMA) or
                string name (e.g. 'LEMMA' or 'lemma').
        
                attr_ids (list[]): A list of attributes (int IDs or string names).
                RETURNS (numpy.ndarray[long, ndim=2]): A feature matrix, with one row
                    per word, and one column per attribute indicated in the input
                    `attr_ids`.
        
                EXAMPLE:
                    >>> from spacy.attrs import LOWER, POS, ENT_TYPE, IS_ALPHA
                    >>> doc = nlp(text)
                    >>> # All strings mapped to integers, for easy export to numpy
                    >>> np_array = doc.to_array([LOWER, POS, ENT_TYPE, IS_ALPHA])
        """
        pass

    def to_bytes(self, *args, **kwargs): # real signature unknown
        """
        Serialize, i.e. export the document contents to a binary string.
        
                exclude (list): String names of serialization fields to exclude.
                RETURNS (bytes): A losslessly serialized copy of the `Doc`, including
                    all annotations.
        
                DOCS: https://spacy.io/api/doc#to_bytes
        """
        pass

    def to_disk(self, *args, **kwargs): # real signature unknown
        """
        Save the current state to a directory.
        
                path (unicode or Path): A path to a directory, which will be created if
                    it doesn't exist. Paths may be either strings or Path-like objects.
                exclude (list): String names of serialization fields to exclude.
        
                DOCS: https://spacy.io/api/doc#to_disk
        """
        pass

    def to_json(self, *args, **kwargs): # real signature unknown
        """
        Convert a Doc to JSON. The format it produces will be the new format
                for the `spacy train` command (not implemented yet).
        
                underscore (list): Optional list of string names of custom doc._.
                attributes. Attribute values need to be JSON-serializable. Values will
                be added to an "_" key in the data, e.g. "_": {"foo": "bar"}.
                RETURNS (dict): The data in spaCy's JSON format.
        
                DOCS: https://spacy.io/api/doc#to_json
        """
        pass

    def _bulk_merge(self, *args, **kwargs): # real signature unknown
        """
        Retokenize the document, such that the spans given as arguments
                 are merged into single tokens. The spans need to be in document
                 order, and no span intersection is allowed.
        
                spans (Span[]): Spans to merge, in document order, with all span
                    intersections empty. Cannot be emty.
                attributes (Dictionary[]): Attributes to assign to the merged tokens. By default,
                    must be the same lenghth as spans, emty dictionaries are allowed.
                    attributes are inherited from the syntactic root of the span.
                RETURNS (Token): The first newly merged token.
        """
        pass

    def _realloc(self, *args, **kwargs): # real signature unknown
        pass

    def __bytes__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """
        Get a `Token` or `Span` object.
        
                i (int or tuple) The index of the token, or the slice of the document
                    to get.
                RETURNS (Token or Span): The token at `doc[i]]`, or the span at
                    `doc[start : end]`.
        
                EXAMPLE:
                    >>> doc[i]
                    Get the `Token` object at position `i`, where `i` is an integer.
                    Negative indexing is supported, and follows the usual Python
                    semantics, i.e. `doc[-2]` is `doc[len(doc) - 2]`.
        
                    >>> doc[start : end]]
                    Get a `Span` object, starting at position `start` and ending at
                    position `end`, where `start` and `end` are token indices. For
                    instance, `doc[2:5]` produces a span consisting of tokens 2, 3 and
                    4. Stepped slices (e.g. `doc[start : end : step]`) are not
                    supported, as `Span` objects must be contiguous (cannot have gaps).
                    You can use negative indices and open-ended ranges, which have
                    their normal Python semantics.
        
                DOCS: https://spacy.io/api/doc#getitem
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create a Doc object.
        
                vocab (Vocab): A vocabulary object, which must match any models you
                    want to use (e.g. tokenizer, parser, entity recognizer).
                words (list or None): A list of unicode strings to add to the document
                    as words. If `None`, defaults to empty list.
                spaces (list or None): A list of boolean values, of the same length as
                    words. True means that the word is followed by a space, False means
                    it is not. If `None`, defaults to `[True]*len(words)`
                user_data (dict or None): Optional extra data to attach to the Doc.
                RETURNS (Doc): The newly constructed object.
        
                DOCS: https://spacy.io/api/doc#init
        """
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """
        Iterate over `Token`  objects, from which the annotations can be
                easily accessed. This is the main way of accessing `Token` objects,
                which are the main way annotations are accessed from Python. If faster-
                than-Python speeds are required, you can instead access the annotations
                as a numpy array, or access the underlying C data directly from Cython.
        
                DOCS: https://spacy.io/api/doc#iter
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        The number of tokens in the document.
        
                RETURNS (int): The number of tokens in the document.
        
                DOCS: https://spacy.io/api/doc#len
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """ Return str(self). """
        pass

    def __unicode__(self, *args, **kwargs): # real signature unknown
        pass

    cats = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ents = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The named entities in the document. Returns a tuple of named entity
        `Span` objects, if the entity recognizer has been applied.

        RETURNS (tuple): Entities in the document, one `Span` per entity.

        DOCS: https://spacy.io/api/doc#ents
        """

    has_vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A boolean value indicating whether a word vector is associated with
        the object.

        RETURNS (bool): Whether a word vector is associated with the object.

        DOCS: https://spacy.io/api/doc#has_vector
        """

    is_nered = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Check if the document has named entities set. Will return True if
        *any* of the tokens has a named entity tag set (even if the others are
        uknown values).
        """

    is_parsed = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    is_sentenced = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Check if the document has sentence boundaries assigned. This is
        defined as having at least one of the following:

        a) An entry "sents" in doc.user_hooks";
        b) Doc.is_parsed is set to True;
        c) At least one token other than the first where sent_start is not None.
        """

    is_tagged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    lang = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the language of the doc's vocabulary."""

    lang_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Language of the doc's vocabulary, e.g. 'en'."""

    mem = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    noun_chunks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Iterate over the base noun phrases in the document. Yields base
        noun-phrase #[code Span] objects, if the document has been
        syntactically parsed. A base noun phrase, or "NP chunk", is a noun
        phrase that does not permit other NPs to be nested within it – so no
        NP-level coordination, no prepositional phrases, and no relative
        clauses.

        YIELDS (Span): Noun chunks in the document.

        DOCS: https://spacy.io/api/doc#noun_chunks
        """

    noun_chunks_iterator = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    sentiment = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    sents = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Iterate over the sentences in the document. Yields sentence `Span`
        objects. Sentence spans have no label. To improve accuracy on informal
        texts, spaCy calculates sentence boundaries from the syntactic
        dependency parse. If the parser is disabled, the `sents` iterator will
        be unavailable.

        YIELDS (Span): Sentences in the document.

        DOCS: https://spacy.io/api/doc#sents
        """

    tensor = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    text = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A unicode representation of the document text.

        RETURNS (unicode): The original verbatim text of the document.
        """

    text_with_ws = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """An alias of `Doc.text`, provided for duck-type compatibility with
        `Span` and `Token`.

        RETURNS (unicode): The original verbatim text of the document.
        """

    user_data = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    user_hooks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    user_span_hooks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    user_token_hooks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A real-valued meaning representation. Defaults to an average of the
        token vectors.

        RETURNS (numpy.ndarray[ndim=1, dtype='float32']): A 1D numpy array
            representing the document's semantics.

        DOCS: https://spacy.io/api/doc#vector
        """

    vector_norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The L2 norm of the document's vector representation.

        RETURNS (float): The L2 norm of the vector representation.

        DOCS: https://spacy.io/api/doc#vector_norm
        """

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Custom extension attributes registered via `set_extension`."""

    _py_tokens = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _vector_norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f197f173f90>'


class Underscore(object):
    # no doc
    def get(self, name): # reliably restored by inspect
        # no doc
        pass

    def has(self, name): # reliably restored by inspect
        # no doc
        pass

    def set(self, name, value): # reliably restored by inspect
        # no doc
        pass

    def _get_key(self, name): # reliably restored by inspect
        # no doc
        pass

    def __getattr__(self, name): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, extensions, obj, start=None, end=None): # reliably restored by inspect
        # no doc
        pass

    def __setattr__(self, name, value): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    doc_extensions = {}
    mutable_types = (
        dict,
        list,
        set,
    )
    span_extensions = {}
    token_extensions = {}
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.tokens.underscore', 'set': <function Underscore.set at 0x7f197f18ae18>, 'span_extensions': {}, 'doc_extensions': {}, '__weakref__': <attribute '__weakref__' of 'Underscore' objects>, 'mutable_types': (<class 'dict'>, <class 'list'>, <class 'set'>), '__doc__': None, '__init__': <function Underscore.__init__ at 0x7f197f18ac80>, '_get_key': <function Underscore._get_key at 0x7f197eebb048>, '__dict__': <attribute '__dict__' of 'Underscore' objects>, 'get': <function Underscore.get at 0x7f197f18aea0>, '__getattr__': <function Underscore.__getattr__ at 0x7f197f18ad08>, '__setattr__': <function Underscore.__setattr__ at 0x7f197f18ad90>, 'token_extensions': {}, 'has': <function Underscore.has at 0x7f197f18af28>})"


# variables with complex values

IDS = {
    '': 0,
    'CLUSTER': 72,
    'DEP': 76,
    'ENT_IOB': 77,
    'ENT_TYPE': 78,
    'FLAG19': 19,
    'FLAG20': 20,
    'FLAG21': 21,
    'FLAG22': 22,
    'FLAG23': 23,
    'FLAG24': 24,
    'FLAG25': 25,
    'FLAG26': 26,
    'FLAG27': 27,
    'FLAG28': 28,
    'FLAG29': 29,
    'FLAG30': 30,
    'FLAG31': 31,
    'FLAG32': 32,
    'FLAG33': 33,
    'FLAG34': 34,
    'FLAG35': 35,
    'FLAG36': 36,
    'FLAG37': 37,
    'FLAG38': 38,
    'FLAG39': 39,
    'FLAG40': 40,
    'FLAG41': 41,
    'FLAG42': 42,
    'FLAG43': 43,
    'FLAG44': 44,
    'FLAG45': 45,
    'FLAG46': 46,
    'FLAG47': 47,
    'FLAG48': 48,
    'FLAG49': 49,
    'FLAG50': 50,
    'FLAG51': 51,
    'FLAG52': 52,
    'FLAG53': 53,
    'FLAG54': 54,
    'FLAG55': 55,
    'FLAG56': 56,
    'FLAG57': 57,
    'FLAG58': 58,
    'FLAG59': 59,
    'FLAG60': 60,
    'FLAG61': 61,
    'FLAG62': 62,
    'FLAG63': 63,
    'HEAD': 79,
    'ID': 64,
    'IS_ALPHA': 1,
    'IS_ASCII': 2,
    'IS_BRACKET': 14,
    'IS_CURRENCY': 18,
    'IS_DIGIT': 3,
    'IS_LEFT_PUNCT': 16,
    'IS_LOWER': 4,
    'IS_OOV': 13,
    'IS_PUNCT': 5,
    'IS_QUOTE': 15,
    'IS_RIGHT_PUNCT': 17,
    'IS_SPACE': 6,
    'IS_STOP': 12,
    'IS_TITLE': 7,
    'IS_UPPER': 8,
    'LANG': 83,
    'LEMMA': 73,
    'LENGTH': 71,
    'LIKE_EMAIL': 11,
    'LIKE_NUM': 10,
    'LIKE_URL': 9,
    'LOWER': 66,
    'NORM': 67,
    'ORTH': 65,
    'POS': 74,
    'PREFIX': 69,
    'PROB': 82,
    'SENT_START': 80,
    'SHAPE': 68,
    'SPACY': 81,
    'SUFFIX': 70,
    'TAG': 75,
}

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f197eea3470>'

__pyx_capi__ = {
    '_get_lca_matrix': None, # (!) real value is '<capsule object "__Pyx_memviewslice (struct __pyx_obj_5spacy_6tokens_3doc_Doc *, int, int)" at 0x7f197f173f60>'
    'get_token_attr': None, # (!) real value is '<capsule object "__pyx_t_5spacy_8typedefs_attr_t (struct __pyx_t_5spacy_7structs_TokenC const *, enum __pyx_t_5spacy_5attrs_attr_id_t)" at 0x7f197f173ea0>'
    'set_children_from_heads': None, # (!) real value is '<capsule object "int (struct __pyx_t_5spacy_7structs_TokenC *, int)" at 0x7f197f173ed0>'
    'token_by_end': None, # (!) real value is '<capsule object "int (struct __pyx_t_5spacy_7structs_TokenC const *, int, int)" at 0x7f197f173f30>'
    'token_by_start': None, # (!) real value is '<capsule object "int (struct __pyx_t_5spacy_7structs_TokenC const *, int, int)" at 0x7f197f173f00>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.tokens.doc', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f197eea3470>, origin='/usr/local/lib/python3.5/dist-packages/spacy/tokens/doc.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {
    'Doc.__getitem__ (line 256)': 'Get a `Token` or `Span` object.\n\n        i (int or tuple) The index of the token, or the slice of the document\n            to get.\n        RETURNS (Token or Span): The token at `doc[i]]`, or the span at\n            `doc[start : end]`.\n\n        EXAMPLE:\n            >>> doc[i]\n            Get the `Token` object at position `i`, where `i` is an integer.\n            Negative indexing is supported, and follows the usual Python\n            semantics, i.e. `doc[-2]` is `doc[len(doc) - 2]`.\n\n            >>> doc[start : end]]\n            Get a `Span` object, starting at position `start` and ending at\n            position `end`, where `start` and `end` are token indices. For\n            instance, `doc[2:5]` produces a span consisting of tokens 2, 3 and\n            4. Stepped slices (e.g. `doc[start : end : step]`) are not\n            supported, as `Span` objects must be contiguous (cannot have gaps).\n            You can use negative indices and open-ended ranges, which have\n            their normal Python semantics.\n\n        DOCS: https://spacy.io/api/doc#getitem\n        ',
    'Doc.to_array (line 639)': "Export given token attributes to a numpy `ndarray`.\n        If `attr_ids` is a sequence of M attributes, the output array will be\n        of shape `(N, M)`, where N is the length of the `Doc` (in tokens). If\n        `attr_ids` is a single attribute, the output shape will be (N,). You\n        can specify attributes by integer ID (e.g. spacy.attrs.LEMMA) or\n        string name (e.g. 'LEMMA' or 'lemma').\n\n        attr_ids (list[]): A list of attributes (int IDs or string names).\n        RETURNS (numpy.ndarray[long, ndim=2]): A feature matrix, with one row\n            per word, and one column per attribute indicated in the input\n            `attr_ids`.\n\n        EXAMPLE:\n            >>> from spacy.attrs import LOWER, POS, ENT_TYPE, IS_ALPHA\n            >>> doc = nlp(text)\n            >>> # All strings mapped to integers, for easy export to numpy\n            >>> np_array = doc.to_array([LOWER, POS, ENT_TYPE, IS_ALPHA])\n        ",
}


# encoding: utf-8
# module spacy.tokens.token
# from /usr/local/lib/python3.5/dist-packages/spacy/tokens/token.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import spacy.util as util # /usr/local/lib/python3.5/dist-packages/spacy/util.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
import spacy.parts_of_speech as parts_of_speech # /usr/local/lib/python3.5/dist-packages/spacy/parts_of_speech.cpython-35m-x86_64-linux-gnu.so
import numpy as numpy # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def get_ext_args(**kwargs): # reliably restored by inspect
    """ Validate and convert arguments. Reused in Doc, Token and Span. """
    pass

def is_config(python2=None, python3=None, windows=None, linux=None, osx=None): # reliably restored by inspect
    """
    Check if a specific configuration of Python version and operating system
        matches the user's setup. Mostly used to display targeted error messages.
    
        python2 (bool): spaCy is executed with Python 2.x.
        python3 (bool): spaCy is executed with Python 3.x.
        windows (bool): spaCy is executed on Windows.
        linux (bool): spaCy is executed on Linux.
        osx (bool): spaCy is executed on OS X or macOS.
        RETURNS (bool): Whether the configuration matches the user's platform.
    
        DOCS: https://spacy.io/api/top-level#compat.is_config
    """
    pass

def models_warning(message): # reliably restored by inspect
    # no doc
    pass

def user_warning(message): # reliably restored by inspect
    # no doc
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Token(object):
    """
    An individual token – i.e. a word, punctuation symbol, whitespace,
        etc.
    
        DOCS: https://spacy.io/api/token
    """
    def check_flag(self, *args, **kwargs): # real signature unknown
        """
        Check the value of a boolean flag.
        
                flag_id (int): The ID of the flag attribute.
                RETURNS (bool): Whether the flag is set.
        
                DOCS: https://spacy.io/api/token#check_flag
        """
        pass

    @classmethod
    def get_extension(cls, *args, **kwargs): # real signature unknown
        """
        Look up a previously registered extension by name.
        
                name (unicode): Name of the extension.
                RETURNS (tuple): A `(default, method, getter, setter)` tuple.
        
                DOCS: https://spacy.io/api/token#get_extension
        """
        pass

    @classmethod
    def has_extension(cls, *args, **kwargs): # real signature unknown
        """
        Check whether an extension has been registered.
        
                name (unicode): Name of the extension.
                RETURNS (bool): Whether the extension has been registered.
        
                DOCS: https://spacy.io/api/token#has_extension
        """
        pass

    def is_ancestor(self, *args, **kwargs): # real signature unknown
        """
        Check whether this token is a parent, grandparent, etc. of another
                in the dependency tree.
        
                descendant (Token): Another token.
                RETURNS (bool): Whether this token is the ancestor of the descendant.
        
                DOCS: https://spacy.io/api/token#is_ancestor
        """
        pass

    def nbor(self, *args, **kwargs): # real signature unknown
        """
        Get a neighboring token.
        
                i (int): The relative position of the token to get. Defaults to 1.
                RETURNS (Token): The token at position `self.doc[self.i+i]`.
        
                DOCS: https://spacy.io/api/token#nbor
        """
        pass

    @classmethod
    def remove_extension(cls, *args, **kwargs): # real signature unknown
        """
        Remove a previously registered extension.
        
                name (unicode): Name of the extension.
                RETURNS (tuple): A `(default, method, getter, setter)` tuple of the
                    removed extension.
        
                DOCS: https://spacy.io/api/token#remove_extension
        """
        pass

    @classmethod
    def set_extension(cls, *args, **kwargs): # real signature unknown
        """
        Define a custom attribute which becomes available as `Token._`.
        
                name (unicode): Name of the attribute to set.
                default: Optional default value of the attribute.
                getter (callable): Optional getter function.
                setter (callable): Optional setter function.
                method (callable): Optional method for method extension.
                force (bool): Force overwriting existing attribute.
        
                DOCS: https://spacy.io/api/token#set_extension
                USAGE: https://spacy.io/usage/processing-pipelines#custom-components-attributes
        """
        pass

    def similarity(self, *args, **kwargs): # real signature unknown
        """
        Make a semantic similarity estimate. The default estimate is cosine
                similarity using an average of word vectors.
        
                other (object): The object to compare with. By default, accepts `Doc`,
                    `Span`, `Token` and `Lexeme` objects.
                RETURNS (float): A scalar similarity score. Higher is more similar.
        
                DOCS: https://spacy.io/api/token#similarity
        """
        pass

    def __bytes__(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        The number of unicode characters in the token, i.e. `token.text`.
        
                RETURNS (int): The number of unicode characters in the token.
        
                DOCS: https://spacy.io/api/token#len
        """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """ Return str(self). """
        pass

    def __unicode__(self, *args, **kwargs): # real signature unknown
        pass

    ancestors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A sequence of this token's syntactic ancestors.

        YIELDS (Token): A sequence of ancestor tokens such that
            `ancestor.is_ancestor(self)`.

        DOCS: https://spacy.io/api/token#ancestors
        """

    children = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A sequence of the token's immediate syntactic children.

        YIELDS (Token): A child token such that `child.head==self`.

        DOCS: https://spacy.io/api/token#children
        """

    cluster = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (int): Brown cluster ID."""

    conjuncts = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A sequence of coordinated tokens, including the token itself.

        RETURNS (tuple): The coordinated tokens.

        DOCS: https://spacy.io/api/token#conjuncts
        """

    dep = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of syntactic dependency label."""

    dep_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The syntactic dependency label."""

    doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ent_id = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the entity the token is an instance of,
            if any.
        """

    ent_id_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): ID of the entity the token is an instance of,
            if any.
        """

    ent_iob = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """IOB code of named entity tag. `1="I", 2="O", 3="B"`. 0 means no tag
        is assigned.

        RETURNS (uint64): IOB code of named entity tag.
        """

    ent_iob_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """IOB code of named entity tag. "B" means the token begins an entity,
        "I" means it is inside an entity, "O" means it is outside an entity,
        and "" means no entity tag is set.

        RETURNS (unicode): IOB code of named entity tag.
        """

    ent_type = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): Named entity type."""

    ent_type_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Named entity type."""

    has_vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A boolean value indicating whether a word vector is associated with
        the object.

        RETURNS (bool): Whether a word vector is associated with the object.

        DOCS: https://spacy.io/api/token#has_vector
        """

    head = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The syntactic parent, or "governor", of this token.

        RETURNS (Token): The token predicted by the parser to be the head of
            the current token.
        """

    i = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    idx = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (int): The character offset of the token within the parent
            document.
        """

    is_alpha = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token consists of alpha characters.
            Equivalent to `token.text.isalpha()`.
        """

    is_ascii = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token consists of ASCII characters.
            Equivalent to `[any(ord(c) >= 128 for c in token.text)]`.
        """

    is_bracket = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is a bracket."""

    is_currency = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is a currency symbol."""

    is_digit = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token consists of digits. Equivalent to
            `token.text.isdigit()`.
        """

    is_left_punct = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is a left punctuation mark."""

    is_lower = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is in lowercase. Equivalent to
            `token.text.islower()`.
        """

    is_oov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is out-of-vocabulary."""

    is_punct = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is punctuation."""

    is_quote = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is a quotation mark."""

    is_right_punct = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is a right punctuation mark."""

    is_sent_start = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A boolean value indicating whether the token starts a sentence.
        `None` if unknown. Defaults to `True` for the first token in the `Doc`.

        RETURNS (bool / None): Whether the token starts a sentence.
            None if unknown.

        DOCS: https://spacy.io/api/token#is_sent_start
        """

    is_space = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token consists of whitespace characters.
            Equivalent to `token.text.isspace()`.
        """

    is_stop = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is a stop word, i.e. part of a
            "stop list" defined by the language data.
        """

    is_title = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is in titlecase. Equivalent to
            `token.text.istitle()`.
        """

    is_upper = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token is in uppercase. Equivalent to
            `token.text.isupper()`
        """

    lang = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the language of the parent document's
            vocabulary.
        """

    lang_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Language of the parent document's vocabulary,
            e.g. 'en'.
        """

    lefts = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The leftward immediate children of the word, in the syntactic
        dependency parse.

        YIELDS (Token): A left-child of the token.

        DOCS: https://spacy.io/api/token#lefts
        """

    left_edge = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The leftmost token of this token's syntactic descendents.

        RETURNS (Token): The first token such that `self.is_ancestor(token)`.
        """

    lemma = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the base form of the word, with no
            inflectional suffixes.
        """

    lemma_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The token lemma, i.e. the base form of the word,
            with no inflectional suffixes.
        """

    lex_id = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (int): Sequential ID of the token's lexical type."""

    like_email = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token resembles an email address."""

    like_num = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token resembles a number, e.g. "10.9",
            "10", "ten", etc.
        """

    like_url = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the token resembles a URL."""

    lower = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the lowercase token text."""

    lower_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The lowercase token text. Equivalent to
            `Token.text.lower()`.
        """

    norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the token's norm, i.e. a normalised form of
            the token text. Usually set in the language's tokenizer exceptions
            or norm exceptions.
        """

    norm_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The token's norm, i.e. a normalised form of the
            token text. Usually set in the language's tokenizer exceptions or
            norm exceptions.
        """

    n_lefts = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The number of leftward immediate children of the word, in the
        syntactic dependency parse.

        RETURNS (int): The number of leftward immediate children of the
            word, in the syntactic dependency parse.

        DOCS: https://spacy.io/api/token#n_lefts
        """

    n_rights = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The number of rightward immediate children of the word, in the
        syntactic dependency parse.

        RETURNS (int): The number of rightward immediate children of the
            word, in the syntactic dependency parse.

        DOCS: https://spacy.io/api/token#n_rights
        """

    orth = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the verbatim text content."""

    orth_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Verbatim text content (identical to
            `Token.text`). Exists mostly for consistency with the other
            attributes.
        """

    pos = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of coarse-grained part-of-speech tag."""

    pos_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Coarse-grained part-of-speech tag."""

    prefix = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of a length-N substring from the start of the
            token. Defaults to `N=1`.
        """

    prefix_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): A length-N substring from the start of the token.
            Defaults to `N=1`.
        """

    prob = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (float): Smoothed log probability estimate of token type."""

    rank = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (int): Sequential ID of the token's lexical type, used to
        index into tables, e.g. for word vectors."""

    rights = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The rightward immediate children of the word, in the syntactic
        dependency parse.

        YIELDS (Token): A right-child of the token.

        DOCS: https://spacy.io/api/token#rights
        """

    right_edge = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The rightmost token of this token's syntactic descendents.

        RETURNS (Token): The last token such that `self.is_ancestor(token)`.
        """

    sent = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (Span): The sentence span that the token is a part of."""

    sentiment = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (float): A scalar value indicating the positivity or
            negativity of the token."""

    sent_start = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of the token's shape, a transform of the
            tokens's string, to show orthographic features (e.g. "Xxxx", "dd").
        """

    shape_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Transform of the tokens's string, to show
            orthographic features. For example, "Xxxx" or "dd".
        """

    string = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Deprecated: Use Token.text_with_ws instead."""

    subtree = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A sequence containing the token and all the token's syntactic
        descendants.

        YIELDS (Token): A descendent token such that
            `self.is_ancestor(descendent) or token == self`.

        DOCS: https://spacy.io/api/token#subtree
        """

    suffix = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of a length-N substring from the end of the
            token. Defaults to `N=3`.
        """

    suffix_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): A length-N substring from the end of the token.
            Defaults to `N=3`.
        """

    tag = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): ID of fine-grained part-of-speech tag."""

    tag_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Fine-grained part-of-speech tag."""

    text = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The original verbatim text of the token."""

    text_with_ws = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The text content of the span (with trailing
            whitespace).
        """

    vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A real-valued meaning representation.

        RETURNS (numpy.ndarray[ndim=1, dtype='float32']): A 1D numpy array
            representing the token's semantics.

        DOCS: https://spacy.io/api/token#vector
        """

    vector_norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The L2 norm of the token's vector representation.

        RETURNS (float): The L2 norm of the vector representation.

        DOCS: https://spacy.io/api/token#vector_norm
        """

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    whitespace_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The trailing whitespace character, if present."""

    _ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Custom extension attributes registered via `set_extension`."""


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fd4c70e51b0>'


class Underscore(object):
    # no doc
    def get(self, name): # reliably restored by inspect
        # no doc
        pass

    def has(self, name): # reliably restored by inspect
        # no doc
        pass

    def set(self, name, value): # reliably restored by inspect
        # no doc
        pass

    def _get_key(self, name): # reliably restored by inspect
        # no doc
        pass

    def __getattr__(self, name): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, extensions, obj, start=None, end=None): # reliably restored by inspect
        # no doc
        pass

    def __setattr__(self, name, value): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    doc_extensions = {}
    mutable_types = (
        dict,
        list,
        set,
    )
    span_extensions = {}
    token_extensions = {}
    __dict__ = None # (!) real value is "mappingproxy({'__setattr__': <function Underscore.__setattr__ at 0x7fd4c73c8d08>, 'set': <function Underscore.set at 0x7fd4c73c8d90>, 'token_extensions': {}, 'has': <function Underscore.has at 0x7fd4c73c8ea0>, 'mutable_types': (<class 'dict'>, <class 'list'>, <class 'set'>), 'get': <function Underscore.get at 0x7fd4c73c8e18>, '__module__': 'spacy.tokens.underscore', '__doc__': None, '__dict__': <attribute '__dict__' of 'Underscore' objects>, 'doc_extensions': {}, '__weakref__': <attribute '__weakref__' of 'Underscore' objects>, '__init__': <function Underscore.__init__ at 0x7fd4c73c8bf8>, '__getattr__': <function Underscore.__getattr__ at 0x7fd4c73c8c80>, '_get_key': <function Underscore._get_key at 0x7fd4c73c8f28>, 'span_extensions': {}})"


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fd4c70e6fd0>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.tokens.token', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fd4c70e6fd0>, origin='/usr/local/lib/python3.5/dist-packages/spacy/tokens/token.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module spacy.tokens._retokenize
# from /usr/local/lib/python3.5/dist-packages/spacy/tokens/_retokenize.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import numpy as numpy # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
from spacy.attrs import intify_attrs

from spacy.strings import get_string_id


# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def is_writable_attr(ext): # reliably restored by inspect
    """
    Check if an extension attribute is writable.
        ext (tuple): The (default, getter, setter, method) tuple available  via
            {Doc,Span,Token}.get_extension.
        RETURNS (bool): Whether the attribute is writable.
    """
    pass

def _bulk_merge(*args, **kwargs): # real signature unknown
    """
    Retokenize the document, such that the spans described in 'merges'
         are merged into a single token. This method assumes that the merges
         are in the same order at which they appear in the doc, and that merges
         do not intersect each other in any way.
    
        merges: Tokens to merge, and corresponding attributes to assign to the
            merged token. By default, attributes are inherited from the
            syntactic root of the span.
        RETURNS (Token): The first newly merged token.
    """
    pass

def _merge(*args, **kwargs): # real signature unknown
    """
    Retokenize the document, such that the span at
        `doc.text[start_idx : end_idx]` is merged into a single token. If
        `start_idx` and `end_idx `do not mark start and end token boundaries,
        the document remains unchanged.
        start_idx (int): Character index of the start of the slice to merge.
        end_idx (int): Character index after the end of the slice to merge.
        **attributes: Attributes to assign to the merged token. By default,
            attributes are inherited from the syntactic root of the span.
        RETURNS (Token): The newly merged token, or `None` if the start and end
            indices did not fall at token boundaries.
    """
    pass

def _resize_tensor(*args, **kwargs): # real signature unknown
    pass

def _split(*args, **kwargs): # real signature unknown
    """
    Retokenize the document, such that the token at
        `doc[token_index]` is split into tokens with the orth 'orths'
        token_index(int): token index of the token to split.
        orths: IDs of the verbatim text content of the tokens to create
        **attributes: Attributes to assign to each of the newly created tokens. By default,
            attributes are inherited from the original token.
        RETURNS (Token): The first newly created token.
    """
    pass

def _validate_extensions(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Retokenizer(*args, **kwargs): # real signature unknown
    pass

# classes

class Retokenizer(object):
    """
    Helper class for doc.retokenize() context manager.
    
        DOCS: https://spacy.io/api/doc#retokenize
        USAGE: https://spacy.io/usage/linguistic-features#retokenization
    """
    def merge(self, *args, **kwargs): # real signature unknown
        """
        Mark a span for merging. The attrs will be applied to the resulting
                token.
        
                span (Span): The span to merge.
                attrs (dict): Attributes to set on the merged token.
        
                DOCS: https://spacy.io/api/doc#retokenizer.merge
        """
        pass

    def split(self, *args, **kwargs): # real signature unknown
        """
        Mark a Token for splitting, into the specified orths. The attrs
                will be applied to each subtoken.
        
                token (Token): The token to split.
                orths (list): The verbatim text of the split tokens. Needs to match the
                    text of the original token.
                heads (list): List of token or `(token, subtoken)` tuples specifying the
                    tokens to attach the newly split subtokens to.
                attrs (dict): Attributes to set on all split tokens. Attribute names
                    mapped to list of per-token attribute values.
        
                DOCS: https://spacy.io/api/doc#retokenizer.split
        """
        pass

    def __enter__(self, *args, **kwargs): # real signature unknown
        pass

    def __exit__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass


class SimpleFrozenDict(dict):
    """
    Simplified implementation of a frozen dict, mainly used as default
        function or method argument (for arguments that should default to empty
        dictionary). Will raise an error if user or spaCy attempts to add to dict.
    """
    def pop(self, key, default=None): # reliably restored by inspect
        # no doc
        pass

    def update(self, other): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, key, value): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.util', '__dict__': <attribute '__dict__' of 'SimpleFrozenDict' objects>, 'update': <function SimpleFrozenDict.update at 0x7f48b2dea8c8>, 'pop': <function SimpleFrozenDict.pop at 0x7f48b2dea840>, '__setitem__': <function SimpleFrozenDict.__setitem__ at 0x7f48b2dea7b8>, '__doc__': 'Simplified implementation of a frozen dict, mainly used as default\\n    function or method argument (for arguments that should default to empty\\n    dictionary). Will raise an error if user or spaCy attempts to add to dict.\\n    ', '__weakref__': <attribute '__weakref__' of 'SimpleFrozenDict' objects>})"


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f486ced7ef0>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.tokens._retokenize', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f486ced7ef0>, origin='/usr/local/lib/python3.5/dist-packages/spacy/tokens/_retokenize.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module _codecs_hk
# from /usr/lib/python3.5/lib-dynload/_codecs_hk.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa2d8212748>'

__map_big5hkscs = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fa2d816f510>'

__map_big5hkscs_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fa2d816f5a0>'

__map_big5hkscs_nonbmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7fa2d816f5d0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_codecs_hk', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa2d8212748>, origin='/usr/lib/python3.5/lib-dynload/_codecs_hk.cpython-35m-x86_64-linux-gnu.so')"


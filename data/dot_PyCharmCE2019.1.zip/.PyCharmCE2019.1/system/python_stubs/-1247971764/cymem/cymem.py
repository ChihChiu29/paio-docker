# encoding: utf-8
# module cymem.cymem
# from /usr/local/lib/python3.5/dist-packages/cymem/cymem.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# classes

class Address(object):
    """
    Address(size_t number, size_t elem_size)
    A block of number * size-bytes of 0-initialized memory, tied to a Python
        ref-counted object. When the object is garbage collected, the memory is freed.
    
        >>> from cymem.cymem cimport Address
        >>> cdef Address address = Address(10, sizeof(double))
        >>> d10 = <double*>address.ptr
    
        Args:
            number (size_t): The number of elements in the memory block.
            elem_size (size_t): The size of each element.
    
        Attributes:
            ptr (void*): Pointer to the memory block.
            addr (size_t): Read-only size_t cast of the pointer.
            pymalloc (PyMalloc): The allocator to use (default uses PyMem_Malloc).
            pyfree (PyFree): The free to use (default uses PyMem_Free).
    """
    def __init__(self, size_t_number, size_t_elem_size): # real signature unknown; restored from __doc__
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Address.__reduce_cython__(self) """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        """ Address.__setstate_cython__(self, __pyx_state) """
        pass

    addr = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    pyfree = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    pymalloc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class Pool(object):
    """
    Track allocated memory addresses, and free them all when the Pool is
        garbage collected.  This provides an easy way to avoid memory leaks, and
        removes the need for deallocation functions for complicated structs.
    
        >>> from cymem.cymem cimport Pool
        >>> cdef Pool mem = Pool()
        >>> data1 = <int*>mem.alloc(10, sizeof(int))
        >>> data2 = <float*>mem.alloc(12, sizeof(float))
    
        Attributes:
            size (size_t): The current size (in bytes) allocated by the pool.
            addresses (dict): The currently allocated addresses and their sizes. Read-only.
            pymalloc (PyMalloc): The allocator to use (default uses PyMem_Malloc).
            pyfree (PyFree): The free to use (default uses PyMem_Free).
    """
    def own_pyref(self, py_ref): # real signature unknown; restored from __doc__
        """ Pool.own_pyref(self, py_ref) """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Pool.__reduce_cython__(self) """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        """ Pool.__setstate_cython__(self, __pyx_state) """
        pass

    addresses = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    pyfree = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    pymalloc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    refs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    size = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f749012e570>'


class PyFree(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ PyFree.__reduce_cython__(self) """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        """ PyFree.__setstate_cython__(self, __pyx_state) """
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f749012e5d0>'


class PyMalloc(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ PyMalloc.__reduce_cython__(self) """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        """ PyMalloc.__setstate_cython__(self, __pyx_state) """
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f749012e5a0>'


# variables with complex values

Default_Free = None # (!) real value is '<cymem.cymem.PyFree object at 0x7f74901d02b0>'

Default_Malloc = None # (!) real value is '<cymem.cymem.PyMalloc object at 0x7f74901d0290>'

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f74901d1b00>'

__pyx_capi__ = {
    'WrapFree': None, # (!) real value is '<capsule object "struct __pyx_obj_5cymem_5cymem_PyFree *(__pyx_t_5cymem_5cymem_free_t)" at 0x7f749012e510>'
    'WrapMalloc': None, # (!) real value is '<capsule object "struct __pyx_obj_5cymem_5cymem_PyMalloc *(__pyx_t_5cymem_5cymem_malloc_t)" at 0x7f749012e3c0>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='cymem.cymem', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f74901d1b00>, origin='/usr/local/lib/python3.5/dist-packages/cymem/cymem.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module 067017595bd79933725bf9ab3dadebd5
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def pmf_to_quantized_cdf(pmf, precision, name=None): # reliably restored by inspect
    """
    Converts PMF to quantized CDF. This op uses floating-point operations
    
      internally. Therefore the quantized output may not be consistent across multiple
      platforms. For entropy encoders and decoders to have the same quantized CDF on
      different platforms, the quantized CDF should be produced once and saved, then
      the saved quantized CDF should be used everywhere.
    
      After quantization, if PMF does not sum to 2^precision, then some values of PMF
      are increased or decreased to adjust the sum to equal to 2^precision.
    
      Note that the input PMF is pre-quantization. The input PMF is not normalized
      by this op prior to quantization. Therefore the user is responsible for
      normalizing PMF if necessary.
    
      Args:
        pmf: A `Tensor` of type `float32`.
        precision: An `int` that is `>= 1`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int32`.
    """
    pass

def pmf_to_quantized_cdf_eager_fallback(pmf, precision, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function pmf_to_quantized_cdf
    """
    pass

def range_decode(encoded, shape, cdf, precision, name=None): # reliably restored by inspect
    """
    Decodes a range-coded `code` into an int32 tensor of shape `shape`.
    
      This is the reverse op of RangeEncode. The shape of the tensor that was encoded
      should be known by the caller.
    
      Implementation notes:
    
      - If wrong input was given (e.g., corrupt `encoded` string, or `cdf` or
      `precision` do not match encoder), the decode is unsuccessful. Because of
      potential performance issues, the decoder does not return error status.
    
      Args:
        encoded: A `Tensor` of type `string`.
          A scalar string tensor from RangeEncode.
        shape: A `Tensor` of type `int32`.
          An int32 1-D tensor representing the shape of the data encoded by
          RangeEncode.
        cdf: A `Tensor` of type `int32`.
        precision: An `int` that is `>= 1`.
          The number of bits for probability quantization. Must be <= 16, and
          must match the precision used by RangeEncode that produced `encoded`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int16`. An int16 tensor with shape equal to `shape`.
    """
    pass

def range_decode_eager_fallback(encoded, shape, cdf, precision, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function range_decode
    """
    pass

def range_encode(data, cdf, precision, name=None): # reliably restored by inspect
    """
    Using the provided cumulative distribution functions (CDF) inside `cdf`, returns
    
      a range-code of `data`.
    
      The shape of `cdf` should have one more axis than the shape of `data`, and the
      prefix `cdf.shape[:-1]` should be broadcastable to `data.shape`. That is, for
      every `i = 0,...,rank(data) - 1`, the op requires that either
      `cdf.shape[i] == 1` or `cdf.shape[i] == data.shape[i]`. Note that this
      broadcasting is limited in the sense that the number of axes must match, and
      broadcasts only `cdf` but not `data`.
    
      `data` should have an upper bound `m > 0` such that each element is an integer
      in range `[0, m)`. Then the last dimension size of `cdf` must be `m + 1`. For
      each element of `data`, the innermost strip of `cdf` is a vector representing a
      CDF. For each k = 0,...,m, `cdf[..., k] / 2^precision` is the probability that
      an outcome is less than `k` (not less than or equal to).
    
      ```
         cdf[..., 0] / 2^precision = Pr(data[...] < 0)
         cdf[..., 1] / 2^precision = Pr(data[...] < 1) = Pr(data[...] <= 0)
         cdf[..., 2] / 2^precision = Pr(data[...] < 2) = Pr(data[...] <= 1)
         ...
         cdf[..., m] / 2^precision = Pr(data[...] < m) = 1
      ```
    
      Therefore each element of `cdf` must be in `[0, 2^precision]`.
    
      Ideally `cdf[..., m]` should equal to `2^precision` but this is not a hard
      requirement as long as `cdf[..., m] <= 2^precision`.
    
      The encoded string neither contains the shape information of the encoded data
      nor a termination symbol. Therefore the shape of the encoded data must be
      explicitly provided to the decoder.
    
      Implementation notes:
    
      - Because of potential performance issues, the op does not check whether
      elements of `data` is in the correct range `[0, m)`, or if `cdf` satisfies
      monotonic increase property.
    
      - For the range coder to decode the encoded string correctly, the decoder should
      be able to reproduce the internal states of the encoder precisely. Otherwise,
      the decoding would fail and once an error occur, all subsequent decoded values
      are incorrect. For this reason, the range coder uses integer arithmetics and
      avoids using any floating point operations internally, and `cdf` should contain
      integers representing quantized probability mass rather than floating points.
    
      Args:
        data: A `Tensor` of type `int16`. An int16 tensor.
        cdf: A `Tensor` of type `int32`.
          An int32 tensor representing the CDF's of `data`. Each integer is divided
          by `2^precision` to represent a fraction.
        precision: An `int` that is `>= 1`.
          The number of bits for probability quantization. Must be <= 16.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `string`. A range-coded scalar string.
    """
    pass

def range_encode_eager_fallback(data, cdf, precision, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function range_encode
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# no classes
# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7e443e9f0>"


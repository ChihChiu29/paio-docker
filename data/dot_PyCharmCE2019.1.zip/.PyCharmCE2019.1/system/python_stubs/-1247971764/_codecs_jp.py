# encoding: utf-8
# module _codecs_jp
# from /usr/lib/python3.5/lib-dynload/_codecs_jp.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f45eb62e748>'

__map_cp932ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b6f0>'

__map_jisx0208 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b510>'

__map_jisx0212 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b5a0>'

__map_jisx0213_1_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b570>'

__map_jisx0213_1_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b600>'

__map_jisx0213_2_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b630>'

__map_jisx0213_2_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b660>'

__map_jisx0213_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b540>'

__map_jisx0213_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b690>'

__map_jisx0213_pair = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b6c0>'

__map_jisxcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f45eb58b5d0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_codecs_jp', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f45eb62e748>, origin='/usr/lib/python3.5/lib-dynload/_codecs_jp.cpython-35m-x86_64-linux-gnu.so')"


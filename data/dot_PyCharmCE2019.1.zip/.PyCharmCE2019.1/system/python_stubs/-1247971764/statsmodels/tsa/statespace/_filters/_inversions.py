# encoding: utf-8
# module statsmodels.tsa.statespace._filters._inversions
# from /usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_filters/_inversions.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
State Space Models

Author: Chad Fulton  
License: Simplified-BSD
"""

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb99af42550>'

__pyx_capi__ = {
    'cfactorize_cholesky': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7fb99af24660>'
    'cfactorize_lu': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7fb99af24690>'
    'cinverse_cholesky': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7fb99af246c0>'
    'cinverse_lu': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7fb99af246f0>'
    'cinverse_univariate': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7fb99af24630>'
    'csolve_cholesky': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7fb99af24720>'
    'csolve_lu': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7fb99af24750>'
    'dfactorize_cholesky': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7fb99af24510>'
    'dfactorize_lu': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7fb99af24540>'
    'dinverse_cholesky': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7fb99af24570>'
    'dinverse_lu': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7fb99af245a0>'
    'dinverse_univariate': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7fb99bc42a80>'
    'dsolve_cholesky': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7fb99af245d0>'
    'dsolve_lu': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7fb99af24600>'
    'sfactorize_cholesky': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7fb9a95b55a0>'
    'sfactorize_lu': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7fb9a95b55d0>'
    'sinverse_cholesky': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7fb9a95b5630>'
    'sinverse_lu': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7fb9a95b57b0>'
    'sinverse_univariate': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7fb9a95b5510>'
    'ssolve_cholesky': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7fb9a95b5720>'
    'ssolve_lu': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7fb99bc42a20>'
    'zfactorize_cholesky': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7fb99af247b0>'
    'zfactorize_lu': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7fb99af247e0>'
    'zinverse_cholesky': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7fb99af24810>'
    'zinverse_lu': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7fb99af24840>'
    'zinverse_univariate': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7fb99af24780>'
    'zsolve_cholesky': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7fb99af24870>'
    'zsolve_lu': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7fb99af248a0>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='statsmodels.tsa.statespace._filters._inversions', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb99af42550>, origin='/usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_filters/_inversions.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


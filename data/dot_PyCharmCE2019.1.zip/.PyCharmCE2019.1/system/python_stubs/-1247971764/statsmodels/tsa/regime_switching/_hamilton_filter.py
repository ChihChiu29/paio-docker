# encoding: utf-8
# module statsmodels.tsa.regime_switching._hamilton_filter
# from /usr/local/lib/python3.5/dist-packages/statsmodels/tsa/regime_switching/_hamilton_filter.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
Hamilton filter

Author: Chad Fulton
License: Simplified-BSD
"""

# imports
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import warnings as warnings # /usr/lib/python3.5/warnings.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def chamilton_filter(*args, **kwargs): # real signature unknown
    pass

def dhamilton_filter(*args, **kwargs): # real signature unknown
    pass

def shamilton_filter(*args, **kwargs): # real signature unknown
    pass

def zhamilton_filter(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f870a8e3438>'

__pyx_capi__ = {
    'chamilton_filter_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f8718f525a0>'
    'dhamilton_filter_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f8718f52510>'
    'shamilton_filter_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f8718f523c0>'
    'zhamilton_filter_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f8718f52570>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='statsmodels.tsa.regime_switching._hamilton_filter', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f870a8e3438>, origin='/usr/local/lib/python3.5/dist-packages/statsmodels/tsa/regime_switching/_hamilton_filter.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


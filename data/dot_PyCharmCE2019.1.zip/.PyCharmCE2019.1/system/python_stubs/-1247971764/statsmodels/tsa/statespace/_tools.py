# encoding: utf-8
# module statsmodels.tsa.statespace._tools
# from /usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_tools.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
State Space Model - Cython tools

Author: Chad Fulton  
License: Simplified-BSD
"""

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def ccopy_index_matrix(*args, **kwargs): # real signature unknown
    pass

def ccopy_index_vector(*args, **kwargs): # real signature unknown
    pass

def ccopy_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def ccopy_missing_vector(*args, **kwargs): # real signature unknown
    pass

def cldl(*args, **kwargs): # real signature unknown
    pass

def creorder_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def creorder_missing_vector(*args, **kwargs): # real signature unknown
    pass

def dcopy_index_matrix(*args, **kwargs): # real signature unknown
    pass

def dcopy_index_vector(*args, **kwargs): # real signature unknown
    pass

def dcopy_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def dcopy_missing_vector(*args, **kwargs): # real signature unknown
    pass

def dldl(*args, **kwargs): # real signature unknown
    pass

def dreorder_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def dreorder_missing_vector(*args, **kwargs): # real signature unknown
    pass

def scopy_index_matrix(*args, **kwargs): # real signature unknown
    pass

def scopy_index_vector(*args, **kwargs): # real signature unknown
    pass

def scopy_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def scopy_missing_vector(*args, **kwargs): # real signature unknown
    pass

def sldl(*args, **kwargs): # real signature unknown
    pass

def sreorder_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def sreorder_missing_vector(*args, **kwargs): # real signature unknown
    pass

def zcopy_index_matrix(*args, **kwargs): # real signature unknown
    pass

def zcopy_index_vector(*args, **kwargs): # real signature unknown
    pass

def zcopy_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def zcopy_missing_vector(*args, **kwargs): # real signature unknown
    pass

def zldl(*args, **kwargs): # real signature unknown
    pass

def zreorder_missing_matrix(*args, **kwargs): # real signature unknown
    pass

def zreorder_missing_vector(*args, **kwargs): # real signature unknown
    pass

def _ccompute_coefficients_from_multivariate_pacf(*args, **kwargs): # real signature unknown
    """
    Notes
        -----
    
        This uses the ?trmm BLAS functions which are not available in
        Scipy v0.11.0
    """
    pass

def _cconstrain_sv_less_than_one(*args, **kwargs): # real signature unknown
    """
    Transform arbitrary matrices to matrices with singular values less than
        one.
    
        Corresponds to Lemma 2.2 in Ansley and Kohn (1986). See
        `constrain_stationary_multivariate` for more details.
    """
    pass

def _dcompute_coefficients_from_multivariate_pacf(*args, **kwargs): # real signature unknown
    """
    Notes
        -----
    
        This uses the ?trmm BLAS functions which are not available in
        Scipy v0.11.0
    """
    pass

def _dconstrain_sv_less_than_one(*args, **kwargs): # real signature unknown
    """
    Transform arbitrary matrices to matrices with singular values less than
        one.
    
        Corresponds to Lemma 2.2 in Ansley and Kohn (1986). See
        `constrain_stationary_multivariate` for more details.
    """
    pass

def _scompute_coefficients_from_multivariate_pacf(*args, **kwargs): # real signature unknown
    """
    Notes
        -----
    
        This uses the ?trmm BLAS functions which are not available in
        Scipy v0.11.0
    """
    pass

def _sconstrain_sv_less_than_one(*args, **kwargs): # real signature unknown
    """
    Transform arbitrary matrices to matrices with singular values less than
        one.
    
        Corresponds to Lemma 2.2 in Ansley and Kohn (1986). See
        `constrain_stationary_multivariate` for more details.
    """
    pass

def _zcompute_coefficients_from_multivariate_pacf(*args, **kwargs): # real signature unknown
    """
    Notes
        -----
    
        This uses the ?trmm BLAS functions which are not available in
        Scipy v0.11.0
    """
    pass

def _zconstrain_sv_less_than_one(*args, **kwargs): # real signature unknown
    """
    Transform arbitrary matrices to matrices with singular values less than
        one.
    
        Corresponds to Lemma 2.2 in Ansley and Kohn (1986). See
        `constrain_stationary_multivariate` for more details.
    """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f70739394a8>'

__pyx_capi__ = {
    '_ccopy_index_cols': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int, int)" at 0x7f70739421e0>'
    '_ccopy_index_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int)" at 0x7f7073917f60>'
    '_ccopy_index_rows': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int, int)" at 0x7f7073942120>'
    '_ccopy_index_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int)" at 0x7f7073942060>'
    '_ccopy_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int, int)" at 0x7f7073917d20>'
    '_ccopy_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int)" at 0x7f7073917ae0>'
    '_ccopy_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int, int)" at 0x7f7073917c60>'
    '_ccopy_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int *, int)" at 0x7f7073917ba0>'
    '_cldl': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, int)" at 0x7f70739174e0>'
    '_creorder_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, int *, int, int)" at 0x7f70739178a0>'
    '_creorder_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, int *, int)" at 0x7f7073917660>'
    '_creorder_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, int *, int, int)" at 0x7f70739177e0>'
    '_creorder_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, int *, int)" at 0x7f7073917720>'
    '_csolve_discrete_lyapunov': None, # (!) real value is '<capsule object "int (__pyx_t_float_complex *, __pyx_t_float_complex *, int, struct __pyx_opt_args_11statsmodels_3tsa_10statespace_6_tools__csolve_discrete_lyapunov *__pyx_optional_args)" at 0x7f7081fa8780>'
    '_dcopy_index_cols': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int, int)" at 0x7f70739421b0>'
    '_dcopy_index_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int)" at 0x7f7073917f30>'
    '_dcopy_index_rows': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int, int)" at 0x7f70739420f0>'
    '_dcopy_index_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int)" at 0x7f7073942030>'
    '_dcopy_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int, int)" at 0x7f7073917cf0>'
    '_dcopy_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int)" at 0x7f7073917ab0>'
    '_dcopy_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int, int)" at 0x7f7073917c30>'
    '_dcopy_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int *, int)" at 0x7f7073917b70>'
    '_dldl': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, int)" at 0x7f7074636a50>'
    '_dreorder_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, int *, int, int)" at 0x7f7073917870>'
    '_dreorder_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, int *, int)" at 0x7f7073917630>'
    '_dreorder_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, int *, int, int)" at 0x7f70739177b0>'
    '_dreorder_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, int *, int)" at 0x7f70739176f0>'
    '_dsolve_discrete_lyapunov': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float64_t *, __pyx_t_5numpy_float64_t *, int, struct __pyx_opt_args_11statsmodels_3tsa_10statespace_6_tools__dsolve_discrete_lyapunov *__pyx_optional_args)" at 0x7f7081fa8570>'
    '_scopy_index_cols': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int, int)" at 0x7f7073942180>'
    '_scopy_index_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int)" at 0x7f7073917f00>'
    '_scopy_index_rows': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int, int)" at 0x7f70739420c0>'
    '_scopy_index_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int)" at 0x7f7073917fc0>'
    '_scopy_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int, int)" at 0x7f7073917cc0>'
    '_scopy_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int)" at 0x7f7073917a80>'
    '_scopy_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int, int)" at 0x7f7073917c00>'
    '_scopy_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int *, int)" at 0x7f7073917b40>'
    '_sldl': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, int)" at 0x7f70746369f0>'
    '_sreorder_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, int *, int, int)" at 0x7f7073917840>'
    '_sreorder_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, int *, int)" at 0x7f7073917600>'
    '_sreorder_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, int *, int, int)" at 0x7f7073917780>'
    '_sreorder_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, int *, int)" at 0x7f70739176c0>'
    '_ssolve_discrete_lyapunov': None, # (!) real value is '<capsule object "int (__pyx_t_5numpy_float32_t *, __pyx_t_5numpy_float32_t *, int, struct __pyx_opt_args_11statsmodels_3tsa_10statespace_6_tools__ssolve_discrete_lyapunov *__pyx_optional_args)" at 0x7f7081fa85a0>'
    '_zcopy_index_cols': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int, int)" at 0x7f7073942210>'
    '_zcopy_index_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int)" at 0x7f7073917f90>'
    '_zcopy_index_rows': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int, int)" at 0x7f7073942150>'
    '_zcopy_index_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int)" at 0x7f7073942090>'
    '_zcopy_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int, int)" at 0x7f7073917d50>'
    '_zcopy_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int)" at 0x7f7073917b10>'
    '_zcopy_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int, int)" at 0x7f7073917c90>'
    '_zcopy_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int *, int)" at 0x7f7073917bd0>'
    '_zldl': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, int)" at 0x7f7073917510>'
    '_zreorder_missing_cols': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, int *, int, int)" at 0x7f70739178d0>'
    '_zreorder_missing_diagonal': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, int *, int)" at 0x7f7073917690>'
    '_zreorder_missing_rows': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, int *, int, int)" at 0x7f7073917810>'
    '_zreorder_missing_submatrix': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, int *, int)" at 0x7f7073917750>'
    '_zsolve_discrete_lyapunov': None, # (!) real value is '<capsule object "int (__pyx_t_double_complex *, __pyx_t_double_complex *, int, struct __pyx_opt_args_11statsmodels_3tsa_10statespace_6_tools__zsolve_discrete_lyapunov *__pyx_optional_args)" at 0x7f7081fa86f0>'
    'ccopy_index_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f70739422a0>'
    'ccopy_index_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073942360>'
    'ccopy_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917de0>'
    'ccopy_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917ea0>'
    'cldl': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f70739175a0>'
    'creorder_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917960>'
    'creorder_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917a20>'
    'dcopy_index_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073942270>'
    'dcopy_index_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073942330>'
    'dcopy_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917db0>'
    'dcopy_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917e70>'
    'dldl': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917570>'
    'dreorder_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917930>'
    'dreorder_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f70739179f0>'
    'scopy_index_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073942240>'
    'scopy_index_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073942300>'
    'scopy_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917d80>'
    'scopy_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917e40>'
    'sldl': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917540>'
    'sreorder_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917900>'
    'sreorder_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f70739179c0>'
    'validate_matrix_shape': None, # (!) real value is '<capsule object "PyObject *(PyObject *, Py_ssize_t *, int, int, struct __pyx_opt_args_11statsmodels_3tsa_10statespace_6_tools_validate_matrix_shape *__pyx_optional_args)" at 0x7f7081fa83c0>'
    'validate_vector_shape': None, # (!) real value is '<capsule object "PyObject *(PyObject *, Py_ssize_t *, int, struct __pyx_opt_args_11statsmodels_3tsa_10statespace_6_tools_validate_vector_shape *__pyx_optional_args)" at 0x7f7081fa8510>'
    'zcopy_index_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f70739422d0>'
    'zcopy_index_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073942390>'
    'zcopy_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917e10>'
    'zcopy_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917ed0>'
    'zldl': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f70739175d0>'
    'zreorder_missing_matrix': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int, int, int, int __pyx_skip_dispatch)" at 0x7f7073917990>'
    'zreorder_missing_vector': None, # (!) real value is '<capsule object "int (__Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f7073917a50>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='statsmodels.tsa.statespace._tools', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f70739394a8>, origin='/usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_tools.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


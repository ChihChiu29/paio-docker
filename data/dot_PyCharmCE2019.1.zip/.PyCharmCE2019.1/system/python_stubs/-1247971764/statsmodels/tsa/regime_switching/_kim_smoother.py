# encoding: utf-8
# module statsmodels.tsa.regime_switching._kim_smoother
# from /usr/local/lib/python3.5/dist-packages/statsmodels/tsa/regime_switching/_kim_smoother.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
Kim smoother

Author: Chad Fulton  
License: Simplified-BSD
"""

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import warnings as warnings # /usr/lib/python3.5/warnings.py
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def ckim_smoother(*args, **kwargs): # real signature unknown
    pass

def dkim_smoother(*args, **kwargs): # real signature unknown
    pass

def skim_smoother(*args, **kwargs): # real signature unknown
    pass

def zkim_smoother(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1734e1d438>'

__pyx_capi__ = {
    'ckim_smoother': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f174348f570>'
    'ckim_smoother_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f1735b1ba50>'
    'dkim_smoother': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f174348f5a0>'
    'dkim_smoother_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f1735b1b9f0>'
    'skim_smoother': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f174348f510>'
    'skim_smoother_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f174348f6f0>'
    'zkim_smoother': None, # (!) real value is '<capsule object "PyObject *(int, int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, int __pyx_skip_dispatch)" at 0x7f174348f780>'
    'zkim_smoother_iteration': None, # (!) real value is '<capsule object "PyObject *(int, int, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice, __Pyx_memviewslice)" at 0x7f1734dfd4e0>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='statsmodels.tsa.regime_switching._kim_smoother', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1734e1d438>, origin='/usr/local/lib/python3.5/dist-packages/statsmodels/tsa/regime_switching/_kim_smoother.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module statsmodels.tsa.statespace._filters._univariate
# from /usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_filters/_univariate.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
State Space Models

Author: Chad Fulton  
License: Simplified-BSD
"""

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f60afff3550>'

__pyx_capi__ = {
    'cfiltered_state': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, int, __pyx_t_float_complex)" at 0x7f60affd5930>'
    'cfiltered_state_cov': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, int, __pyx_t_float_complex)" at 0x7f60affd5960>'
    'cforecast_error': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, int)" at 0x7f60affd58a0>'
    'cforecast_error_cov': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, int)" at 0x7f60affd58d0>'
    'cforecast_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *)" at 0x7f60affd57b0>'
    'cinverse_noop_univariate': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7f60affd5840>'
    'cloglikelihood': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, int, __pyx_t_float_complex, __pyx_t_float_complex)" at 0x7f60affd5990>'
    'cloglikelihood_univariate': None, # (!) real value is '<capsule object "__pyx_t_float_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, __pyx_t_float_complex)" at 0x7f60affd5870>'
    'cprediction_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *)" at 0x7f60affd5810>'
    'ctemp_arrays': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *, int, __pyx_t_float_complex)" at 0x7f60affd5900>'
    'cupdating_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_cKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_cStatespace *)" at 0x7f60affd57e0>'
    'dfiltered_state': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, int, __pyx_t_5numpy_float64_t)" at 0x7f60affd5720>'
    'dfiltered_state_cov': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, int, __pyx_t_5numpy_float64_t)" at 0x7f60affd5750>'
    'dforecast_error': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, int)" at 0x7f60affd5690>'
    'dforecast_error_cov': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, int)" at 0x7f60affd56c0>'
    'dforecast_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *)" at 0x7f60affd55a0>'
    'dinverse_noop_univariate': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7f60affd5630>'
    'dloglikelihood': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, int, __pyx_t_5numpy_float64_t, __pyx_t_5numpy_float64_t)" at 0x7f60affd5780>'
    'dloglikelihood_univariate': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float64_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, __pyx_t_5numpy_float64_t)" at 0x7f60affd5660>'
    'dprediction_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *)" at 0x7f60affd5600>'
    'dtemp_arrays': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *, int, __pyx_t_5numpy_float64_t)" at 0x7f60affd56f0>'
    'dupdating_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_dKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_dStatespace *)" at 0x7f60affd55d0>'
    'sfiltered_state': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, int, __pyx_t_5numpy_float32_t)" at 0x7f60affd5510>'
    'sfiltered_state_cov': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, int, __pyx_t_5numpy_float32_t)" at 0x7f60affd5540>'
    'sforecast_error': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, int)" at 0x7f60be665720>'
    'sforecast_error_cov': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, int)" at 0x7f60b0cf3a20>'
    'sforecast_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *)" at 0x7f60be665510>'
    'sinverse_noop_univariate': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7f60be665630>'
    'sloglikelihood': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, int, __pyx_t_5numpy_float32_t, __pyx_t_5numpy_float32_t)" at 0x7f60affd5570>'
    'sloglikelihood_univariate': None, # (!) real value is '<capsule object "__pyx_t_5numpy_float32_t (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, __pyx_t_5numpy_float32_t)" at 0x7f60be6657b0>'
    'sprediction_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *)" at 0x7f60be6655d0>'
    'stemp_arrays': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *, int, __pyx_t_5numpy_float32_t)" at 0x7f60b0cf3a80>'
    'supdating_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_sKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_sStatespace *)" at 0x7f60be6655a0>'
    'zfiltered_state': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, int, __pyx_t_double_complex)" at 0x7f60affd5b40>'
    'zfiltered_state_cov': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, int, __pyx_t_double_complex)" at 0x7f60affd5b70>'
    'zforecast_error': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, int)" at 0x7f60affd5ab0>'
    'zforecast_error_cov': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, int)" at 0x7f60affd5ae0>'
    'zforecast_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *)" at 0x7f60affd59c0>'
    'zinverse_noop_univariate': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7f60affd5a50>'
    'zloglikelihood': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, int, __pyx_t_double_complex, __pyx_t_double_complex)" at 0x7f60affd5ba0>'
    'zloglikelihood_univariate': None, # (!) real value is '<capsule object "__pyx_t_double_complex (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, __pyx_t_double_complex)" at 0x7f60affd5a80>'
    'zprediction_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *)" at 0x7f60affd5a20>'
    'ztemp_arrays': None, # (!) real value is '<capsule object "void (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *, int, __pyx_t_double_complex)" at 0x7f60affd5b10>'
    'zupdating_univariate': None, # (!) real value is '<capsule object "int (struct __pyx_obj_11statsmodels_3tsa_10statespace_14_kalman_filter_zKalmanFilter *, struct __pyx_obj_11statsmodels_3tsa_10statespace_15_representation_zStatespace *)" at 0x7f60affd59f0>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='statsmodels.tsa.statespace._filters._univariate', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f60afff3550>, origin='/usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_filters/_univariate.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


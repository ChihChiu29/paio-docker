# encoding: utf-8
# module statsmodels.tsa.statespace._kalman_filter
# from /usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_kalman_filter.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
Kalman Filter

Author: Chad Fulton  
License: Simplified-BSD
"""

# imports
import warnings as warnings # /usr/lib/python3.5/warnings.py
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class cKalmanFilter(object):
    """
    cKalmanFilter(model, filter_method=FILTER_CONVENTIONAL, inversion_method=INVERT_UNIVARIATE | SOLVE_CHOLESKY, stability_method=STABILITY_FORCE_SYMMETRY, filter_timing=TIMING_INIT_PREDICTED, tolerance=1e-19)
    
        A representation of the Kalman filter recursions.
    
        While the filter is mathematically represented as a recursion, it is here
        translated into Python as a stateful iterator.
    
        Because there are actually several types of Kalman filter depending on the
        state space model of interest, this class only handles the *iteration*
        aspect of filtering, and delegates the actual operations to four general
        workhorse routines, which can be implemented separately for each type of
        Kalman filter.
    
        In order to maintain a consistent interface, and because these four general
        routines may be quite different across filter types, their argument is only
        the stateful ?KalmanFilter object. Furthermore, in order to allow the
        different types of filter to substitute alternate matrices, this class
        defines a set of pointers to the various state space arrays and the
        filtering output arrays.
    
        For example, handling missing observations requires not only substituting
        `obs`, `design`, and `obs_cov` matrices, but the new matrices actually have
        different dimensions than the originals. This can be flexibly accomodated
        simply by replacing e.g. the `obs` pointer to the substituted `obs` array
        and replacing `k_endog` for that iteration. Then in the next iteration, when
        the `obs` vector may be missing different elements (or none at all), it can
        again be redefined.
    
        Each iteration of the filter (see `__next__`) proceeds in a number of
        steps.
    
        `initialize_object_pointers` initializes pointers to current-iteration
        objects (i.e. the state space arrays and filter output arrays).  
    
        `initialize_function_pointers` initializes pointers to the appropriate
        Kalman filtering routines (i.e. `forecast_conventional` or
        `forecast_exact_initial`, etc.).  
    
        `select_arrays` converts the base arrays into "selected" arrays using
        selection matrices. In particular, it handles the state covariance matrix
        and redefined matrices based on missing values.  
    
        `post_convergence` handles copying arrays from time $t-1$ to time $t$ when
        the Kalman filter has converged and they don't need to be re-calculated.  
    
        `forecasting` calls the Kalman filter `forcasting_<filter type>` routine
    
        `inversion` calls the appropriate function to invert the forecast error
        covariance matrix.  
    
        `updating` calls the Kalman filter `updating_<filter type>` routine
    
        `loglikelihood` calls the Kalman filter `loglikelihood_<filter type>` routine
    
        `prediction` calls the Kalman filter `prediction_<filter type>` routine
    
        `numerical_stability` performs end-of-iteration tasks to improve the numerical
        stability of the filter 
    
        `check_convergence` checks for convergence of the filter to steady-state.
    """
    def seek(self, t, reset_convergence=True): # real signature unknown; restored from __doc__
        """
        seek(self, t, reset_convergence = True)
        
                Change the time-state of the filter
        
                Is usually called to reset the filter to the beginning.
        """
        pass

    def set_filter_method(self, filter_method, force_reset=True): # real signature unknown; restored from __doc__
        """
        set_filter_method(self, filter_method, force_reset=True)
        
                Change the filter method.
        """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Iterate the filter across the entire set of observations. """
        pass

    def __init__(self, model, filter_method=None, inversion_method=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __next__(self, *args, **kwargs): # real signature unknown
        """ Perform an iteration of the Kalman filter """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    conserve_memory = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_timing = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_fac = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_ipiv = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_work = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    inversion_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endogstates = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_statesposdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ldwork = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood_burn = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    model = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    period_converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    stability_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    standardized_forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    t = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    time_invariant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp0 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp00 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp1 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp3 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp4 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tolerance = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f0392087900>'


class dKalmanFilter(object):
    """
    dKalmanFilter(model, filter_method=FILTER_CONVENTIONAL, inversion_method=INVERT_UNIVARIATE | SOLVE_CHOLESKY, stability_method=STABILITY_FORCE_SYMMETRY, filter_timing=TIMING_INIT_PREDICTED, tolerance=1e-19)
    
        A representation of the Kalman filter recursions.
    
        While the filter is mathematically represented as a recursion, it is here
        translated into Python as a stateful iterator.
    
        Because there are actually several types of Kalman filter depending on the
        state space model of interest, this class only handles the *iteration*
        aspect of filtering, and delegates the actual operations to four general
        workhorse routines, which can be implemented separately for each type of
        Kalman filter.
    
        In order to maintain a consistent interface, and because these four general
        routines may be quite different across filter types, their argument is only
        the stateful ?KalmanFilter object. Furthermore, in order to allow the
        different types of filter to substitute alternate matrices, this class
        defines a set of pointers to the various state space arrays and the
        filtering output arrays.
    
        For example, handling missing observations requires not only substituting
        `obs`, `design`, and `obs_cov` matrices, but the new matrices actually have
        different dimensions than the originals. This can be flexibly accomodated
        simply by replacing e.g. the `obs` pointer to the substituted `obs` array
        and replacing `k_endog` for that iteration. Then in the next iteration, when
        the `obs` vector may be missing different elements (or none at all), it can
        again be redefined.
    
        Each iteration of the filter (see `__next__`) proceeds in a number of
        steps.
    
        `initialize_object_pointers` initializes pointers to current-iteration
        objects (i.e. the state space arrays and filter output arrays).  
    
        `initialize_function_pointers` initializes pointers to the appropriate
        Kalman filtering routines (i.e. `forecast_conventional` or
        `forecast_exact_initial`, etc.).  
    
        `select_arrays` converts the base arrays into "selected" arrays using
        selection matrices. In particular, it handles the state covariance matrix
        and redefined matrices based on missing values.  
    
        `post_convergence` handles copying arrays from time $t-1$ to time $t$ when
        the Kalman filter has converged and they don't need to be re-calculated.  
    
        `forecasting` calls the Kalman filter `forcasting_<filter type>` routine
    
        `inversion` calls the appropriate function to invert the forecast error
        covariance matrix.  
    
        `updating` calls the Kalman filter `updating_<filter type>` routine
    
        `loglikelihood` calls the Kalman filter `loglikelihood_<filter type>` routine
    
        `prediction` calls the Kalman filter `prediction_<filter type>` routine
    
        `numerical_stability` performs end-of-iteration tasks to improve the numerical
        stability of the filter 
    
        `check_convergence` checks for convergence of the filter to steady-state.
    """
    def seek(self, t, reset_convergence=True): # real signature unknown; restored from __doc__
        """
        seek(self, t, reset_convergence = True)
        
                Change the time-state of the filter
        
                Is usually called to reset the filter to the beginning.
        """
        pass

    def set_filter_method(self, filter_method, force_reset=True): # real signature unknown; restored from __doc__
        """
        set_filter_method(self, filter_method, force_reset=True)
        
                Change the filter method.
        """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Iterate the filter across the entire set of observations. """
        pass

    def __init__(self, model, filter_method=None, inversion_method=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __next__(self, *args, **kwargs): # real signature unknown
        """ Perform an iteration of the Kalman filter """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    conserve_memory = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_timing = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_fac = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_ipiv = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_work = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    inversion_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endogstates = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_statesposdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ldwork = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood_burn = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    model = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    period_converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    stability_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    standardized_forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    t = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    time_invariant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp0 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp00 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp1 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp3 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp4 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tolerance = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f03920878d0>'


class sKalmanFilter(object):
    """
    sKalmanFilter(model, filter_method=FILTER_CONVENTIONAL, inversion_method=INVERT_UNIVARIATE | SOLVE_CHOLESKY, stability_method=STABILITY_FORCE_SYMMETRY, filter_timing=TIMING_INIT_PREDICTED, tolerance=1e-19)
    
        A representation of the Kalman filter recursions.
    
        While the filter is mathematically represented as a recursion, it is here
        translated into Python as a stateful iterator.
    
        Because there are actually several types of Kalman filter depending on the
        state space model of interest, this class only handles the *iteration*
        aspect of filtering, and delegates the actual operations to four general
        workhorse routines, which can be implemented separately for each type of
        Kalman filter.
    
        In order to maintain a consistent interface, and because these four general
        routines may be quite different across filter types, their argument is only
        the stateful ?KalmanFilter object. Furthermore, in order to allow the
        different types of filter to substitute alternate matrices, this class
        defines a set of pointers to the various state space arrays and the
        filtering output arrays.
    
        For example, handling missing observations requires not only substituting
        `obs`, `design`, and `obs_cov` matrices, but the new matrices actually have
        different dimensions than the originals. This can be flexibly accomodated
        simply by replacing e.g. the `obs` pointer to the substituted `obs` array
        and replacing `k_endog` for that iteration. Then in the next iteration, when
        the `obs` vector may be missing different elements (or none at all), it can
        again be redefined.
    
        Each iteration of the filter (see `__next__`) proceeds in a number of
        steps.
    
        `initialize_object_pointers` initializes pointers to current-iteration
        objects (i.e. the state space arrays and filter output arrays).  
    
        `initialize_function_pointers` initializes pointers to the appropriate
        Kalman filtering routines (i.e. `forecast_conventional` or
        `forecast_exact_initial`, etc.).  
    
        `select_arrays` converts the base arrays into "selected" arrays using
        selection matrices. In particular, it handles the state covariance matrix
        and redefined matrices based on missing values.  
    
        `post_convergence` handles copying arrays from time $t-1$ to time $t$ when
        the Kalman filter has converged and they don't need to be re-calculated.  
    
        `forecasting` calls the Kalman filter `forcasting_<filter type>` routine
    
        `inversion` calls the appropriate function to invert the forecast error
        covariance matrix.  
    
        `updating` calls the Kalman filter `updating_<filter type>` routine
    
        `loglikelihood` calls the Kalman filter `loglikelihood_<filter type>` routine
    
        `prediction` calls the Kalman filter `prediction_<filter type>` routine
    
        `numerical_stability` performs end-of-iteration tasks to improve the numerical
        stability of the filter 
    
        `check_convergence` checks for convergence of the filter to steady-state.
    """
    def seek(self, t, reset_convergence=True): # real signature unknown; restored from __doc__
        """
        seek(self, t, reset_convergence = True)
        
                Change the time-state of the filter
        
                Is usually called to reset the filter to the beginning.
        """
        pass

    def set_filter_method(self, filter_method, force_reset=True): # real signature unknown; restored from __doc__
        """
        set_filter_method(self, filter_method, force_reset=True)
        
                Change the filter method.
        """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Iterate the filter across the entire set of observations. """
        pass

    def __init__(self, model, filter_method=None, inversion_method=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __next__(self, *args, **kwargs): # real signature unknown
        """ Perform an iteration of the Kalman filter """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    conserve_memory = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_timing = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_fac = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_ipiv = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_work = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    inversion_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endogstates = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_statesposdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ldwork = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood_burn = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    model = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    period_converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    stability_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    standardized_forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    t = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    time_invariant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp0 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp00 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp1 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp3 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp4 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tolerance = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f03920878a0>'


class zKalmanFilter(object):
    """
    zKalmanFilter(model, filter_method=FILTER_CONVENTIONAL, inversion_method=INVERT_UNIVARIATE | SOLVE_CHOLESKY, stability_method=STABILITY_FORCE_SYMMETRY, filter_timing=TIMING_INIT_PREDICTED, tolerance=1e-19)
    
        A representation of the Kalman filter recursions.
    
        While the filter is mathematically represented as a recursion, it is here
        translated into Python as a stateful iterator.
    
        Because there are actually several types of Kalman filter depending on the
        state space model of interest, this class only handles the *iteration*
        aspect of filtering, and delegates the actual operations to four general
        workhorse routines, which can be implemented separately for each type of
        Kalman filter.
    
        In order to maintain a consistent interface, and because these four general
        routines may be quite different across filter types, their argument is only
        the stateful ?KalmanFilter object. Furthermore, in order to allow the
        different types of filter to substitute alternate matrices, this class
        defines a set of pointers to the various state space arrays and the
        filtering output arrays.
    
        For example, handling missing observations requires not only substituting
        `obs`, `design`, and `obs_cov` matrices, but the new matrices actually have
        different dimensions than the originals. This can be flexibly accomodated
        simply by replacing e.g. the `obs` pointer to the substituted `obs` array
        and replacing `k_endog` for that iteration. Then in the next iteration, when
        the `obs` vector may be missing different elements (or none at all), it can
        again be redefined.
    
        Each iteration of the filter (see `__next__`) proceeds in a number of
        steps.
    
        `initialize_object_pointers` initializes pointers to current-iteration
        objects (i.e. the state space arrays and filter output arrays).  
    
        `initialize_function_pointers` initializes pointers to the appropriate
        Kalman filtering routines (i.e. `forecast_conventional` or
        `forecast_exact_initial`, etc.).  
    
        `select_arrays` converts the base arrays into "selected" arrays using
        selection matrices. In particular, it handles the state covariance matrix
        and redefined matrices based on missing values.  
    
        `post_convergence` handles copying arrays from time $t-1$ to time $t$ when
        the Kalman filter has converged and they don't need to be re-calculated.  
    
        `forecasting` calls the Kalman filter `forcasting_<filter type>` routine
    
        `inversion` calls the appropriate function to invert the forecast error
        covariance matrix.  
    
        `updating` calls the Kalman filter `updating_<filter type>` routine
    
        `loglikelihood` calls the Kalman filter `loglikelihood_<filter type>` routine
    
        `prediction` calls the Kalman filter `prediction_<filter type>` routine
    
        `numerical_stability` performs end-of-iteration tasks to improve the numerical
        stability of the filter 
    
        `check_convergence` checks for convergence of the filter to steady-state.
    """
    def seek(self, t, reset_convergence=True): # real signature unknown; restored from __doc__
        """
        seek(self, t, reset_convergence = True)
        
                Change the time-state of the filter
        
                Is usually called to reset the filter to the beginning.
        """
        pass

    def set_filter_method(self, filter_method, force_reset=True): # real signature unknown; restored from __doc__
        """
        set_filter_method(self, filter_method, force_reset=True)
        
                Change the filter method.
        """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Iterate the filter across the entire set of observations. """
        pass

    def __init__(self, model, filter_method=None, inversion_method=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __next__(self, *args, **kwargs): # real signature unknown
        """ Perform an iteration of the Kalman filter """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    conserve_memory = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    converged_predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    determinant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filtered_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    filter_timing = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_fac = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_ipiv = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    forecast_error_work = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    inversion_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    kalman_gain = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endog2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_endogstates = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_posdef2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_states2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    k_statesposdef = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ldwork = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loglikelihood_burn = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    model = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    period_converged = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    predicted_state_cov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    stability_method = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    standardized_forecast_error = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    t = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    time_invariant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp0 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp00 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp1 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp3 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tmp4 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tolerance = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f0392087930>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f03920a8470>'

__pyx_capi__ = {
    'FILTER_AUGMENTED': None, # (!) real value is '<capsule object "int" at 0x7f03a0719570>'
    'FILTER_COLLAPSED': None, # (!) real value is '<capsule object "int" at 0x7f0392da79f0>'
    'FILTER_CONVENTIONAL': None, # (!) real value is '<capsule object "int" at 0x7f03a0719510>'
    'FILTER_EXACT_INITIAL': None, # (!) real value is '<capsule object "int" at 0x7f03a07195a0>'
    'FILTER_EXTENDED': None, # (!) real value is '<capsule object "int" at 0x7f0392da7a50>'
    'FILTER_SQUARE_ROOT': None, # (!) real value is '<capsule object "int" at 0x7f03a0719780>'
    'FILTER_UNIVARIATE': None, # (!) real value is '<capsule object "int" at 0x7f03a07196f0>'
    'FILTER_UNSCENTED': None, # (!) real value is '<capsule object "int" at 0x7f03920874e0>'
    'INVERT_CHOLESKY': None, # (!) real value is '<capsule object "int" at 0x7f0392087630>'
    'INVERT_LU': None, # (!) real value is '<capsule object "int" at 0x7f03920875d0>'
    'INVERT_UNIVARIATE': None, # (!) real value is '<capsule object "int" at 0x7f0392087570>'
    'MEMORY_CONSERVE': None, # (!) real value is '<capsule object "int" at 0x7f0392087810>'
    'MEMORY_NO_FILTERED': None, # (!) real value is '<capsule object "int" at 0x7f0392087720>'
    'MEMORY_NO_FORECAST': None, # (!) real value is '<capsule object "int" at 0x7f03920876c0>'
    'MEMORY_NO_GAIN': None, # (!) real value is '<capsule object "int" at 0x7f0392087780>'
    'MEMORY_NO_LIKELIHOOD': None, # (!) real value is '<capsule object "int" at 0x7f0392087750>'
    'MEMORY_NO_PREDICTED': None, # (!) real value is '<capsule object "int" at 0x7f03920876f0>'
    'MEMORY_NO_SMOOTHING': None, # (!) real value is '<capsule object "int" at 0x7f03920877b0>'
    'MEMORY_NO_STD_FORECAST': None, # (!) real value is '<capsule object "int" at 0x7f03920877e0>'
    'MEMORY_STORE_ALL': None, # (!) real value is '<capsule object "int" at 0x7f0392087690>'
    'SMOOTHER_ALTERNATIVE': None, # (!) real value is '<capsule object "int" at 0x7f0392087540>'
    'SMOOTHER_CLASSICAL': None, # (!) real value is '<capsule object "int" at 0x7f0392087510>'
    'SOLVE_CHOLESKY': None, # (!) real value is '<capsule object "int" at 0x7f0392087600>'
    'SOLVE_LU': None, # (!) real value is '<capsule object "int" at 0x7f03920875a0>'
    'STABILITY_FORCE_SYMMETRY': None, # (!) real value is '<capsule object "int" at 0x7f0392087660>'
    'TIMING_INIT_FILTERED': None, # (!) real value is '<capsule object "int" at 0x7f0392087840>'
    'TIMING_INIT_PREDICTED': None, # (!) real value is '<capsule object "int" at 0x7f0392087870>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='statsmodels.tsa.statespace._kalman_filter', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f03920a8470>, origin='/usr/local/lib/python3.5/dist-packages/statsmodels/tsa/statespace/_kalman_filter.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


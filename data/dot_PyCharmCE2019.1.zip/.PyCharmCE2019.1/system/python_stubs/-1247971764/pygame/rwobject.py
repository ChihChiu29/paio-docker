# encoding: utf-8
# module pygame.rwobject
# from /usr/local/lib/python3.5/dist-packages/pygame/rwobject.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" SDL_RWops support """
# no imports

# functions

def encode_file_path(obj=None, etype=None): # real signature unknown; restored from __doc__
    """
    encode_file_path([obj [, etype]]) -> bytes or None
    Encode a Unicode or bytes object as a file system path
    """
    return b""

def encode_string(obj=None, encoding=None, errors=None, etype=None): # real signature unknown; restored from __doc__
    """
    encode_string([obj [, encoding [, errors [, etype]]]]) -> bytes or None
    Encode a Unicode or bytes object
    """
    return b""

# no classes
# variables with complex values

_PYGAME_C_API = None # (!) real value is '<capsule object "pygame.rwobject._PYGAME_C_API" at 0x7fdee0a89720>'

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fdee0b42048>'

__spec__ = None # (!) real value is "ModuleSpec(name='pygame.rwobject', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fdee0b42048>, origin='/usr/local/lib/python3.5/dist-packages/pygame/rwobject.cpython-35m-x86_64-linux-gnu.so')"


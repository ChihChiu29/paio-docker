# encoding: utf-8
# module pygame.surflock
# from /usr/local/lib/python3.5/dist-packages/pygame/surflock.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" Surface locking support """
# no imports

# no functions
# no classes
# variables with complex values

_PYGAME_C_API = None # (!) real value is '<capsule object "pygame.surflock._PYGAME_C_API" at 0x7fa4671dc720>'

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa467295358>'

__spec__ = None # (!) real value is "ModuleSpec(name='pygame.surflock', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa467295358>, origin='/usr/local/lib/python3.5/dist-packages/pygame/surflock.cpython-35m-x86_64-linux-gnu.so')"


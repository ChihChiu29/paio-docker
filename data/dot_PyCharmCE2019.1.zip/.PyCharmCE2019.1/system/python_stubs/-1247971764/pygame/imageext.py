# encoding: utf-8
# module pygame.imageext
# from /usr/local/lib/python3.5/dist-packages/pygame/imageext.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" additional image loaders """
# no imports

# functions

def load_extended(*args, **kwargs): # real signature unknown
    """ pygame module for image transfer """
    pass

def save_extended(*args, **kwargs): # real signature unknown
    """ pygame module for image transfer """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1d4205a400>'

__spec__ = None # (!) real value is "ModuleSpec(name='pygame.imageext', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1d4205a400>, origin='/usr/local/lib/python3.5/dist-packages/pygame/imageext.cpython-35m-x86_64-linux-gnu.so')"


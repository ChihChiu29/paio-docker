# encoding: utf-8
# module pygame.time
# from /usr/local/lib/python3.5/dist-packages/pygame/time.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pygame module for monitoring time """
# no imports

# functions

def Clock(): # real signature unknown; restored from __doc__
    """
    Clock() -> Clock
    create an object to help track time
    """
    pass

def delay(milliseconds): # real signature unknown; restored from __doc__
    """
    delay(milliseconds) -> time
    pause the program for an amount of time
    """
    pass

def get_ticks(): # real signature unknown; restored from __doc__
    """
    get_ticks() -> milliseconds
    get the time in milliseconds
    """
    pass

def set_timer(eventid, milliseconds): # real signature unknown; restored from __doc__
    """
    set_timer(eventid, milliseconds) -> None
    repeatedly create an event on the event queue
    """
    pass

def wait(milliseconds): # real signature unknown; restored from __doc__
    """
    wait(milliseconds) -> time
    pause the program for an amount of time
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3a33b0fa58>'

__spec__ = None # (!) real value is "ModuleSpec(name='pygame.time', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3a33b0fa58>, origin='/usr/local/lib/python3.5/dist-packages/pygame/time.cpython-35m-x86_64-linux-gnu.so')"


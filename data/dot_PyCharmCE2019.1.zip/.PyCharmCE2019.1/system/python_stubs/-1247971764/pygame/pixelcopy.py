# encoding: utf-8
# module pygame.pixelcopy
# from /usr/local/lib/python3.5/dist-packages/pygame/pixelcopy.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pygame module for general pixel array copying """
# no imports

# functions

def array_to_surface(*args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    array_to_surface(<surface>, <array>) -> None
    copy an array object to a surface
    """
    pass

def make_surface(array): # real signature unknown; restored from __doc__
    """
    pygame.pixelcopy.make_surface(array) -> Surface
    Copy an array to a new surface
    """
    pass

def map_array(*args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    map_array(<array>, <array>, <surface>) -> None
    copy an array to another array, using surface format
    """
    pass

def surface_to_array(array, surface, kind='P', opaque=255, clear=0): # real signature unknown; restored from __doc__
    """
    surface_to_array(array, surface, kind='P', opaque=255, clear=0) -> None
    copy surface pixels to an array object
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4b56095a90>'

__spec__ = None # (!) real value is "ModuleSpec(name='pygame.pixelcopy', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f4b56095a90>, origin='/usr/local/lib/python3.5/dist-packages/pygame/pixelcopy.cpython-35m-x86_64-linux-gnu.so')"


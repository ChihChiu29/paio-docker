# encoding: utf-8
# module matplotlib._path
# from /usr/local/lib/python3.5/dist-packages/matplotlib/_path.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def affine_transform(points, trans): # real signature unknown; restored from __doc__
    """ affine_transform(points, trans) """
    pass

def cleanup_path(path, trans, remove_nans, clip_rect, snap_mode, stroke_width, simplify, return_curves, sketch): # real signature unknown; restored from __doc__
    """ cleanup_path(path, trans, remove_nans, clip_rect, snap_mode, stroke_width, simplify, return_curves, sketch) """
    pass

def clip_path_to_rect(path, rect, inside): # real signature unknown; restored from __doc__
    """ clip_path_to_rect(path, rect, inside) """
    pass

def convert_path_to_polygons(path, trans, width=0, height=0): # real signature unknown; restored from __doc__
    """ convert_path_to_polygons(path, trans, width=0, height=0) """
    pass

def convert_to_string(path, trans, clip_rect, simplify, sketch, precision, codes, postfix): # real signature unknown; restored from __doc__
    """ convert_to_string(path, trans, clip_rect, simplify, sketch, precision, codes, postfix) """
    pass

def count_bboxes_overlapping_bbox(bbox, bboxes): # real signature unknown; restored from __doc__
    """ count_bboxes_overlapping_bbox(bbox, bboxes) """
    pass

def get_path_collection_extents(*args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ get_path_collection_extents( """
    pass

def get_path_extents(path, trans): # real signature unknown; restored from __doc__
    """ get_path_extents(path, trans) """
    pass

def is_sorted(array): # real signature unknown; restored from __doc__
    """
    is_sorted(array)
    
    Returns True if 1-D array is monotonically increasing, ignoring NaNs
    """
    pass

def path_intersects_path(path1, path2, filled=False): # real signature unknown; restored from __doc__
    """ path_intersects_path(path1, path2, filled=False) """
    pass

def path_intersects_rectangle(path, rect_x1, rect_y1, rect_x2, rect_y2, filled=False): # real signature unknown; restored from __doc__
    """ path_intersects_rectangle(path, rect_x1, rect_y1, rect_x2, rect_y2, filled=False) """
    pass

def path_in_path(path_a, trans_a, path_b, trans_b): # real signature unknown; restored from __doc__
    """ path_in_path(path_a, trans_a, path_b, trans_b) """
    pass

def points_in_path(points, radius, path, trans): # real signature unknown; restored from __doc__
    """ points_in_path(points, radius, path, trans) """
    pass

def points_on_path(points, radius, path, trans): # real signature unknown; restored from __doc__
    """ points_on_path(points, radius, path, trans) """
    pass

def point_in_path(x, y, radius, path, trans): # real signature unknown; restored from __doc__
    """ point_in_path(x, y, radius, path, trans) """
    pass

def point_in_path_collection(x, y, radius, master_transform, paths, transforms, offsets, offset_trans, filled, offset_position): # real signature unknown; restored from __doc__
    """ point_in_path_collection(x, y, radius, master_transform, paths, transforms, offsets, offset_trans, filled, offset_position) """
    pass

def point_on_path(x, y, radius, path, trans): # real signature unknown; restored from __doc__
    """ point_on_path(x, y, radius, path, trans) """
    pass

def update_path_extents(path, trans, rect, minpos, ignore): # real signature unknown; restored from __doc__
    """ update_path_extents(path, trans, rect, minpos, ignore) """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f792fe3a320>'

__spec__ = None # (!) real value is "ModuleSpec(name='matplotlib._path', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f792fe3a320>, origin='/usr/local/lib/python3.5/dist-packages/matplotlib/_path.cpython-35m-x86_64-linux-gnu.so')"


# encoding: utf-8
# module matplotlib.backends._tkagg
# from /usr/local/lib/python3.5/dist-packages/matplotlib/backends/_tkagg.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def blit(*args, **kwargs): # real signature unknown
    pass

def tkinit(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3912658748>'

__spec__ = None # (!) real value is "ModuleSpec(name='matplotlib.backends._tkagg', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3912658748>, origin='/usr/local/lib/python3.5/dist-packages/matplotlib/backends/_tkagg.cpython-35m-x86_64-linux-gnu.so')"


# encoding: utf-8
# module matplotlib.backends._backend_agg
# from /usr/local/lib/python3.5/dist-packages/matplotlib/backends/_backend_agg.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# no functions
# classes

class RendererAgg(object):
    # no doc
    def buffer_rgba(self, *args, **kwargs): # real signature unknown
        pass

    def clear(self, *args, **kwargs): # real signature unknown
        pass

    def copy_from_bbox(self, *args, **kwargs): # real signature unknown
        pass

    def draw_gouraud_triangle(self, *args, **kwargs): # real signature unknown
        pass

    def draw_gouraud_triangles(self, *args, **kwargs): # real signature unknown
        pass

    def draw_image(self, *args, **kwargs): # real signature unknown
        pass

    def draw_markers(self, *args, **kwargs): # real signature unknown
        pass

    def draw_path(self, *args, **kwargs): # real signature unknown
        pass

    def draw_path_collection(self, *args, **kwargs): # real signature unknown
        pass

    def draw_quad_mesh(self, *args, **kwargs): # real signature unknown
        pass

    def draw_text_image(self, *args, **kwargs): # real signature unknown
        pass

    def get_content_extents(self, *args, **kwargs): # real signature unknown
        pass

    def restore_region(self, *args, **kwargs): # real signature unknown
        pass

    def tostring_argb(self, *args, **kwargs): # real signature unknown
        pass

    def tostring_rgb(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f77d392a710>'

__spec__ = None # (!) real value is "ModuleSpec(name='matplotlib.backends._backend_agg', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f77d392a710>, origin='/usr/local/lib/python3.5/dist-packages/matplotlib/backends/_backend_agg.cpython-35m-x86_64-linux-gnu.so')"


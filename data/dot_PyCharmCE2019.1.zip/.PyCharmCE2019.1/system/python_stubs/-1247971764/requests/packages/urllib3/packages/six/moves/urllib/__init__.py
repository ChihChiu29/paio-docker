# encoding: utf-8
# module requests.packages.urllib3.packages.six.moves.urllib calls itself urllib3.packages.six.moves.urllib
# from /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/fast_tensor_util.so
# by generator 1.147
# no doc
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<urllib3.packages.six._SixMetaPathImporter object at 0x7fd92ec68828>'

__spec__ = None # (!) real value is "ModuleSpec(name='urllib3.packages.six.moves.urllib', loader=<urllib3.packages.six._SixMetaPathImporter object at 0x7fd92ec68828>, submodule_search_locations=[])"


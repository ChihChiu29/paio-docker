# encoding: utf-8
# module requests.packages.urllib3.packages.six.moves.urllib.parse calls itself urllib3.packages.six.moves.urllib_parse
# from /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/fast_tensor_util.so
# by generator 1.147
""" Lazy loading of moved objects in six.moves.urllib_parse """
# no imports

# functions

def urlencode(query, doseq=False, safe=None, encoding=None, errors=None, quote_via='<function quote_plus at 0x7fd944889048>'): # reliably restored by inspect
    """
    Encode a dict or sequence of two-element tuples into a URL query string.
    
        If any values in the query arg are sequences and doseq is true, each
        sequence element is converted to a separate parameter.
    
        If the query arg is a sequence of two-element tuples, the order of the
        parameters in the output will match the order of parameters in the
        input.
    
        The components of a query arg may each be either a string or a bytes type.
    
        The safe, encoding, and errors parameters are passed down to the function
        specified by quote_via (encoding and errors only if a component is a str).
    """
    pass

def urljoin(base, url, allow_fragments=True): # reliably restored by inspect
    """
    Join a base URL and a possibly relative URL to form an absolute
        interpretation of the latter.
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<urllib3.packages.six._SixMetaPathImporter object at 0x7fd92ec68828>'

__spec__ = None # (!) real value is "ModuleSpec(name='urllib3.packages.six.moves.urllib.parse', loader=<urllib3.packages.six._SixMetaPathImporter object at 0x7fd92ec68828>)"


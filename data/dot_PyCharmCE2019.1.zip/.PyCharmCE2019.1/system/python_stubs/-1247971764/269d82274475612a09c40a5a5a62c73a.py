# encoding: utf-8
# module 269d82274475612a09c40a5a5a62c73a
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def masked_matmul(a, b, mask_indices, transpose_a, transpose_b, name=None): # reliably restored by inspect
    """
    Computes the product a * b, but only for indices (i, j) in mask_indices. The
    
      result is stored in prod_values, a rank 1 tensor, such that for all i,
      prod_values[i] = (a * b)[mask_indices[i, 0], mask_indices[i, 1]].
      Note that the shapes of the input matrices a, b should be compatible (after
      transposing as specified by the arguments transpose_a and transpose_b).
    
      Input arguments:
    
      Args:
        a: A `Tensor` of type `float32`. A rank 2 tensor of shape [m, n].
        b: A `Tensor` of type `float32`.
          A rank 2 tensor of shape [s, t]. The inner dimensions of a and b should match
          after transposition.
        mask_indices: A `Tensor` of type `int64`.
          A rank 2 tensor, of shape [nnz, 2] where nnz is the number of
          non-zero elements in the output. The indices are not assumed to be in
          lexicographic, or any particular order.
          For all i, mask_indices[i, :] should represent a valid index of the product
          matrix (a * b) (after transposition). That is:
          mask_indices[i, 0] should be in [0, m) if !transpose_a, and in [0, n)
            otherwise.
          mask_indices[i, 1] should be in [0, t) if !transpose_b, and in [0, s)
            otherwise.
        transpose_a: A `Tensor` of type `bool`.
          A boolean, specifies whether to transpose the matrix a.
        transpose_b: A `Tensor` of type `bool`.
          A boolean, specifies whether to transpose the matrix b.
    
          Output arguments:
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `float32`.
        A rank 1 tensor of shape [nnz], representing the values of the
        non-zero elements in the product, such that for all i,
        prod_values[i] = (a * b)[mask_indices[i, 0], mask_indices[i, 1]].
    """
    pass

def masked_matmul_eager_fallback(a, b, mask_indices, transpose_a, transpose_b, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function masked_matmul
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def wals_compute_partial_lhs_and_rhs(factors, factor_weights, unobserved_weights, input_weights, input_indices, input_values, entry_weights, input_block_size, input_is_transpose, name=None): # reliably restored by inspect
    """
    Computes the partial left-hand side and right-hand side of WALS update. For
    
      observed entry input_indices[i]=[m, n] with value input_values[i]=v, the weight
      should be specified either through (1) entry_weights[i] or (2) through
      input_weights[m] * factor_weights[n] (if input_is_transpose is false) or
      input_weights[n] * factor_weights[m] (if input_is_transpose is true). Note it is
      not allowed to have both (1) and (2) specified at the same time: when one
      approach is used, the input tensors related to the other approach must be kept
      completely empty.
    
      Args:
        factors: A `Tensor` of type `float32`. Matrix of size m * k.
        factor_weights: A `Tensor` of type `float32`.
          Vector of size m. Corresponds to column weights. Should be empty
          if entry_weights is used.
        unobserved_weights: A `Tensor` of type `float32`.
          Scalar. Weight for unobserved input entries.
        input_weights: A `Tensor` of type `float32`.
          Vector of size n. Corresponds to row weights. Should be empty if
          entry_weights is used.
        input_indices: A `Tensor` of type `int64`.
          Indices for the input SparseTensor.
        input_values: A `Tensor` of type `float32`.
          Values for the input SparseTensor.
        entry_weights: A `Tensor` of type `float32`.
          If not empty, this must be same length as input_vaues and is used
          as the per-entry non-zero weight. If this is used, input_weights and
          factor_weights must be empty.
        input_block_size: A `Tensor` of type `int64`.
          Scalar. Number of rows spanned by input.
        input_is_transpose: A `Tensor` of type `bool`.
          If true, logically transposes the input for processing.
        name: A name for the operation (optional).
    
      Returns:
        A tuple of `Tensor` objects (partial_lhs, partial_rhs).
    
        partial_lhs: A `Tensor` of type `float32`. 3-D tensor with size input_block_size x k x k.
        partial_rhs: A `Tensor` of type `float32`. Matrix with size input_block_size x k.
    """
    pass

def wals_compute_partial_lhs_and_rhs_eager_fallback(factors, factor_weights, unobserved_weights, input_weights, input_indices, input_values, entry_weights, input_block_size, input_is_transpose, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function wals_compute_partial_lhs_and_rhs
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# classes

class _WALSComputePartialLhsAndRhsOutput(tuple):
    """ WALSComputePartialLhsAndRhs(partial_lhs, partial_rhs) """
    def _asdict(self): # reliably restored by inspect
        """ Return a new OrderedDict which maps field names to their values. """
        pass

    @classmethod
    def _make(cls, *args, **kwargs): # real signature unknown
        """ Make a new WALSComputePartialLhsAndRhs object from a sequence or iterable """
        pass

    def _replace(_self, **kwds): # reliably restored by inspect
        """ Return a new WALSComputePartialLhsAndRhs object replacing specified fields with new values """
        pass

    def __getnewargs__(self): # reliably restored by inspect
        """ Return self as a plain tuple.  Used by copy and pickle. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(_cls, partial_lhs, partial_rhs): # reliably restored by inspect
        """ Create new instance of WALSComputePartialLhsAndRhs(partial_lhs, partial_rhs) """
        pass

    def __repr__(self): # reliably restored by inspect
        """ Return a nicely formatted representation string """
        pass

    partial_lhs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 0"""

    partial_rhs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 1"""


    _fields = (
        'partial_lhs',
        'partial_rhs',
    )
    _source = "from builtins import property as _property, tuple as _tuple\nfrom operator import itemgetter as _itemgetter\nfrom collections import OrderedDict\n\nclass WALSComputePartialLhsAndRhs(tuple):\n    'WALSComputePartialLhsAndRhs(partial_lhs, partial_rhs)'\n\n    __slots__ = ()\n\n    _fields = ('partial_lhs', 'partial_rhs')\n\n    def __new__(_cls, partial_lhs, partial_rhs):\n        'Create new instance of WALSComputePartialLhsAndRhs(partial_lhs, partial_rhs)'\n        return _tuple.__new__(_cls, (partial_lhs, partial_rhs))\n\n    @classmethod\n    def _make(cls, iterable, new=tuple.__new__, len=len):\n        'Make a new WALSComputePartialLhsAndRhs object from a sequence or iterable'\n        result = new(cls, iterable)\n        if len(result) != 2:\n            raise TypeError('Expected 2 arguments, got %d' % len(result))\n        return result\n\n    def _replace(_self, **kwds):\n        'Return a new WALSComputePartialLhsAndRhs object replacing specified fields with new values'\n        result = _self._make(map(kwds.pop, ('partial_lhs', 'partial_rhs'), _self))\n        if kwds:\n            raise ValueError('Got unexpected field names: %r' % list(kwds))\n        return result\n\n    def __repr__(self):\n        'Return a nicely formatted representation string'\n        return self.__class__.__name__ + '(partial_lhs=%r, partial_rhs=%r)' % self\n\n    def _asdict(self):\n        'Return a new OrderedDict which maps field names to their values.'\n        return OrderedDict(zip(self._fields, self))\n\n    def __getnewargs__(self):\n        'Return self as a plain tuple.  Used by copy and pickle.'\n        return tuple(self)\n\n    partial_lhs = _property(_itemgetter(0), doc='Alias for field number 0')\n\n    partial_rhs = _property(_itemgetter(1), doc='Alias for field number 1')\n\n"
    __slots__ = ()


# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7de2cb420>"

_wals_compute_partial_lhs_and_rhs_outputs = [
    'partial_lhs',
    'partial_rhs',
]


# encoding: utf-8
# module fd0dd98198c88491101c13c495ba1206
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def reinterpret_string_to_float(input_data, name=None): # reliably restored by inspect
    """
    Converts byte arrays represented by strings to 32-bit
    
         floating point numbers. The output numbers themselves are meaningless, and
         should only be used in == comparisons.
    
         input_data: A batch of string features as a 2-d tensor; `input_data[i][j]`
           gives the j-th feature of the i-th input.
         output_data: A tensor of the same shape as input_data but the values are
           float32.
    
      Args:
        input_data: A `Tensor` of type `string`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `float32`.
    """
    pass

def reinterpret_string_to_float_eager_fallback(input_data, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function reinterpret_string_to_float
    """
    pass

def scatter_add_ndim(input, indices, deltas, name=None): # reliably restored by inspect
    """
    Add elements in deltas to mutable input according to indices.
    
        input: A N-dimensional float tensor to mutate.
        indices:= A 2-D int32 tensor. The size of dimension 0 is the number of
          deltas, the size of dimension 1 is the rank of the input.  `indices[i]`
          gives the coordinates of input that `deltas[i]` should add to.  If
          `indices[i]` does not fully specify a location (it has less indices than
          there are dimensions in `input`), it is assumed that they are start
          indices and that deltas contains enough values to fill in the remaining
          input dimensions.
        deltas: `deltas[i]` is the value to add to input at index indices[i][:]
    
      Args:
        input: A `Tensor` of type mutable `float32`.
        indices: A `Tensor` of type `int32`.
        deltas: A `Tensor` of type `float32`.
        name: A name for the operation (optional).
    
      Returns:
        The created Operation.
    """
    pass

def scatter_add_ndim_eager_fallback(input, indices, deltas, name=None, ctx=None): # reliably restored by inspect
    # no doc
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# no classes
# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7ddc644b0>"


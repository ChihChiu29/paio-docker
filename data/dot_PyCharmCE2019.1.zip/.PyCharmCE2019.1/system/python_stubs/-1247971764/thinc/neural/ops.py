# encoding: utf-8
# module thinc.neural.ops
# from /usr/local/lib/python3.5/dist-packages/thinc/neural/ops.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import blis as blis # /usr/local/lib/python3.5/dist-packages/blis/__init__.py
import numpy as numpy # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
from thinc.neural._aligned_alloc import zeros_aligned


# Variables with simple values

cupy = None

# functions

def add_gradient_noise(*args, **kwargs): # real signature unknown
    pass

def copy_array(dst, src, casting=None, where=None): # reliably restored by inspect
    # no doc
    pass

def cpu_clip_gradient(*args, **kwargs): # real signature unknown
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def prod(a, axis=None, dtype=None, out=None, keepdims='<no value>', initial='<no value>'): # reliably restored by inspect
    """
    Return the product of array elements over a given axis.
    
        Parameters
        ----------
        a : array_like
            Input data.
        axis : None or int or tuple of ints, optional
            Axis or axes along which a product is performed.  The default,
            axis=None, will calculate the product of all the elements in the
            input array. If axis is negative it counts from the last to the
            first axis.
    
            .. versionadded:: 1.7.0
    
            If axis is a tuple of ints, a product is performed on all of the
            axes specified in the tuple instead of a single axis or all the
            axes as before.
        dtype : dtype, optional
            The type of the returned array, as well as of the accumulator in
            which the elements are multiplied.  The dtype of `a` is used by
            default unless `a` has an integer dtype of less precision than the
            default platform integer.  In that case, if `a` is signed then the
            platform integer is used while if `a` is unsigned then an unsigned
            integer of the same precision as the platform integer is used.
        out : ndarray, optional
            Alternative output array in which to place the result. It must have
            the same shape as the expected output, but the type of the output
            values will be cast if necessary.
        keepdims : bool, optional
            If this is set to True, the axes which are reduced are left in the
            result as dimensions with size one. With this option, the result
            will broadcast correctly against the input array.
    
            If the default value is passed, then `keepdims` will not be
            passed through to the `prod` method of sub-classes of
            `ndarray`, however any non-default value will be.  If the
            sub-class' method does not implement `keepdims` any
            exceptions will be raised.
        initial : scalar, optional
            The starting value for this product. See `~numpy.ufunc.reduce` for details.
    
            .. versionadded:: 1.15.0
    
        Returns
        -------
        product_along_axis : ndarray, see `dtype` parameter above.
            An array shaped as `a` but with the specified axis removed.
            Returns a reference to `out` if specified.
    
        See Also
        --------
        ndarray.prod : equivalent method
        numpy.doc.ufuncs : Section "Output arguments"
    
        Notes
        -----
        Arithmetic is modular when using integer types, and no error is
        raised on overflow.  That means that, on a 32-bit platform:
    
        >>> x = np.array([536870910, 536870910, 536870910, 536870910])
        >>> np.prod(x)  # random
        16
    
        The product of an empty array is the neutral element 1:
    
        >>> np.prod([])
        1.0
    
        Examples
        --------
        By default, calculate the product of all elements:
    
        >>> np.prod([1.,2.])
        2.0
    
        Even when the input array is two-dimensional:
    
        >>> np.prod([[1.,2.],[3.,4.]])
        24.0
    
        But we can also specify the axis over which to multiply:
    
        >>> np.prod([[1.,2.],[3.,4.]], axis=1)
        array([  2.,  12.])
    
        If the type of `x` is unsigned, then the output type is
        the unsigned platform integer:
    
        >>> x = np.array([1, 2, 3], dtype=np.uint8)
        >>> np.prod(x).dtype == np.uint
        True
    
        If `x` is of a signed integer type, then the output type
        is the default platform integer:
    
        >>> x = np.array([1, 2, 3], dtype=np.int8)
        >>> np.prod(x).dtype == int
        True
    
        You can also start the product with a value other than one:
    
        >>> np.prod([1, 2], initial=5)
        10
    """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Ops(object):
    # no doc
    def adam(self, *args, **kwargs): # real signature unknown
        pass

    def add_batch_outer(self, *args, **kwargs): # real signature unknown
        pass

    def add_sum(self, *args, **kwargs): # real signature unknown
        pass

    def affine(self, *args, **kwargs): # real signature unknown
        pass

    def allocate(self, *args, **kwargs): # real signature unknown
        pass

    def argmax(self, *args, **kwargs): # real signature unknown
        pass

    def asarray(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_lstm(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_softmax_sequences(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_take(self, *args, **kwargs): # real signature unknown
        pass

    def batch_dot(self, *args, **kwargs): # real signature unknown
        pass

    def clip_gradient(self, *args, **kwargs): # real signature unknown
        pass

    def clip_low(self, *args, **kwargs): # real signature unknown
        pass

    def dot(self, *args, **kwargs): # real signature unknown
        pass

    def dropout(self, *args, **kwargs): # real signature unknown
        pass

    def dropout_sequences(self, *args, **kwargs): # real signature unknown
        pass

    def dsigmoid(self, *args, **kwargs): # real signature unknown
        pass

    def dtanh(self, *args, **kwargs): # real signature unknown
        pass

    def expand_dims(self, *args, **kwargs): # real signature unknown
        pass

    def flatten(self, *args, **kwargs): # real signature unknown
        pass

    def get_dropout_mask(self, *args, **kwargs): # real signature unknown
        pass

    def he_normal_init(self, *args, **kwargs): # real signature unknown
        pass

    def logloss(self, *args, **kwargs): # real signature unknown
        pass

    def lstm(self, *args, **kwargs): # real signature unknown
        pass

    def norm(self, *args, **kwargs): # real signature unknown
        pass

    def normal_init(self, *args, **kwargs): # real signature unknown
        pass

    def sigmoid(self, *args, **kwargs): # real signature unknown
        pass

    def softmax(self, *args, **kwargs): # real signature unknown
        pass

    def softmax_sequences(self, *args, **kwargs): # real signature unknown
        pass

    def square_sequences(self, *args, **kwargs): # real signature unknown
        """
        Sort a batch of sequence by decreasing length, pad, and transpose
                so that the outer dimension is the timestep. Return the padded batch,
                along with an array indicating the actual length at each step, and a callback
                to reverse the transformation.
        """
        pass

    def take_which(self, *args, **kwargs): # real signature unknown
        pass

    def unflatten(self, *args, **kwargs): # real signature unknown
        pass

    def unzip(self, *args, **kwargs): # real signature unknown
        pass

    def update_averages(self, *args, **kwargs): # real signature unknown
        pass

    def xavier_uniform_init(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    device = 'cpu'
    xp = None
    __dict__ = None # (!) real value is "mappingproxy({'softmax': <cyfunction Ops.softmax at 0x7ff739363f60>, 'he_normal_init': <cyfunction Ops.he_normal_init at 0x7ff73936a778>, 'clip_gradient': <cyfunction Ops.clip_gradient at 0x7ff73936a9a0>, 'adam': <cyfunction Ops.adam at 0x7ff73936a8e8>, 'norm': <cyfunction Ops.norm at 0x7ff7393639a0>, 'affine': <cyfunction Ops.affine at 0x7ff739363b10>, 'asarray': <cyfunction Ops.asarray at 0x7ff739363778>, 'device': 'cpu', 'backprop_lstm': <cyfunction Ops.backprop_lstm at 0x7ff73936a550>, 'add_sum': <cyfunction Ops.add_sum at 0x7ff739363bc8>, 'square_sequences': <cyfunction Ops.square_sequences at 0x7ff739363498>, 'lstm': <cyfunction Ops.lstm at 0x7ff73936a498>, 'flatten': <cyfunction Ops.flatten at 0x7ff739363328>, 'backprop_softmax_sequences': <cyfunction Ops.backprop_softmax_sequences at 0x7ff73936a100>, 'unflatten': <cyfunction Ops.unflatten at 0x7ff7393633e0>, 'get_dropout_mask': <cyfunction Ops.get_dropout_mask at 0x7ff739363550>, '__module__': 'thinc.neural.ops', 'xp': None, 'argmax': <cyfunction Ops.argmax at 0x7ff739363c80>, 'update_averages': <cyfunction Ops.update_averages at 0x7ff73936a830>, 'dot': <cyfunction Ops.dot at 0x7ff739363a58>, 'dropout': <cyfunction Ops.dropout at 0x7ff739363270>, '__weakref__': <attribute '__weakref__' of 'Ops' objects>, 'softmax_sequences': <cyfunction Ops.softmax_sequences at 0x7ff73936a048>, 'dropout_sequences': <cyfunction Ops.dropout_sequences at 0x7ff7393631b8>, '__doc__': None, 'dtanh': <cyfunction Ops.dtanh at 0x7ff739363ea8>, 'sigmoid': <cyfunction Ops.sigmoid at 0x7ff739363d38>, '__dict__': <attribute '__dict__' of 'Ops' objects>, 'normal_init': <cyfunction Ops.normal_init at 0x7ff73936a6c0>, 'logloss': <cyfunction Ops.logloss at 0x7ff73936aa58>, 'clip_low': <cyfunction Ops.clip_low at 0x7ff73936a270>, 'dsigmoid': <cyfunction Ops.dsigmoid at 0x7ff739363df0>, 'xavier_uniform_init': <cyfunction Ops.xavier_uniform_init at 0x7ff73936a608>, 'backprop_take': <cyfunction Ops.backprop_take at 0x7ff73936a3e0>, '__init__': <cyfunction Ops.__init__ at 0x7ff739363100>, 'add_batch_outer': <cyfunction Ops.add_batch_outer at 0x7ff7393638e8>, 'expand_dims': <cyfunction Ops.expand_dims at 0x7ff73936a1b8>, 'unzip': <cyfunction Ops.unzip at 0x7ff7393636c0>, 'allocate': <cyfunction Ops.allocate at 0x7ff739363608>, 'batch_dot': <cyfunction Ops.batch_dot at 0x7ff739363830>, 'take_which': <cyfunction Ops.take_which at 0x7ff73936a328>})"


class CupyOps(Ops):
    # no doc
    def adam(self, *args, **kwargs): # real signature unknown
        pass

    def asarray(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_maxout(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_max_pool(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_mean_pool(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_relu(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_selu(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_seq2col(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_sum_pool(self, *args, **kwargs): # real signature unknown
        pass

    def clip_gradient(self, *args, **kwargs): # real signature unknown
        pass

    def gemm(self, *args, **kwargs): # real signature unknown
        pass

    def hash(self, *args, **kwargs): # real signature unknown
        pass

    def maxout(self, *args, **kwargs): # real signature unknown
        pass

    def max_pool(self, *args, **kwargs): # real signature unknown
        pass

    def mean_pool(self, *args, **kwargs): # real signature unknown
        pass

    def normal_init(self, *args, **kwargs): # real signature unknown
        pass

    def relu(self, *args, **kwargs): # real signature unknown
        pass

    def scatter_add(self, *args, **kwargs): # real signature unknown
        pass

    def selu(self, *args, **kwargs): # real signature unknown
        pass

    def seq2col(self, *args, **kwargs): # real signature unknown
        """
        Given an (M, N) sequence of vectors, return an (M, N*(nW*2+1)) sequence.
                The new sequence is constructed by concatenating nW preceding and succeeding
                vectors onto each column in the sequence, to extract a window of features.
        """
        pass

    def sum_pool(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    device = 'gpu'
    xp = None


class NumpyOps(Ops):
    # no doc
    def adam(self, *args, **kwargs): # real signature unknown
        pass

    def add_sum(self, *args, **kwargs): # real signature unknown
        pass

    def affine(self, *args, **kwargs): # real signature unknown
        pass

    def allocate(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_elu(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_maxout(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_max_pool(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_mean_pool(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_relu(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_selu(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_seq2col(self, *args, **kwargs): # real signature unknown
        pass

    def backprop_sum_pool(self, *args, **kwargs): # real signature unknown
        pass

    def elu(self, *args, **kwargs): # real signature unknown
        pass

    def gemm(self, *args, **kwargs): # real signature unknown
        pass

    def hash(self, *args, **kwargs): # real signature unknown
        """ Hash a sequence of 64-bit keys into a table with 4 32-bit keys """
        pass

    def increment_slices(self, *args, **kwargs): # real signature unknown
        pass

    def inplace_add(self, *args, **kwargs): # real signature unknown
        pass

    def maxout(self, *args, **kwargs): # real signature unknown
        pass

    def max_pool(self, *args, **kwargs): # real signature unknown
        pass

    def mean_pool(self, *args, **kwargs): # real signature unknown
        pass

    def ngrams(self, *args, **kwargs): # real signature unknown
        pass

    def relu(self, *args, **kwargs): # real signature unknown
        pass

    def remap_ids(self, *args, **kwargs): # real signature unknown
        pass

    def scatter_add(self, *args, **kwargs): # real signature unknown
        pass

    def selu(self, *args, **kwargs): # real signature unknown
        pass

    def seq2col(self, *args, **kwargs): # real signature unknown
        """
        Given an (M, N) sequence of vectors, return an (M, N*(nW*2+1)) sequence.
                The new sequence is constructed by concatenating nW preceding and succeeding
                vectors onto each column in the sequence, to extract a window of features.
        """
        pass

    def sum_pool(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    device = 'cpu'
    xp = None # (!) forward: numpy, real value is "<module 'numpy' from '/usr/local/lib/python3.5/dist-packages/numpy/__init__.py'>"


class Sized(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def __subclasshook__(cls, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7ff741723518>'
    _abc_negative_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7ff741723588>'
    _abc_negative_cache_version = 8
    _abc_registry = None # (!) real value is '<_weakrefset.WeakSet object at 0x7ff7417234e0>'
    __abstractmethods__ = frozenset({'__len__'})
    __slots__ = ()


# variables with complex values

integer_types = (
    int,
)

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff73b77fcc0>'

__pyx_capi__ = {
    'backprop_seq2col': None, # (!) real value is '<capsule object "void (float *, float const *, int, int, int)" at 0x7ff73b7b7ab0>'
    'cpu_backprop_max_pool': None, # (!) real value is '<capsule object "void (float *, float const *, int const *, int const *, int, int, int)" at 0x7ff73b7b7ba0>'
    'cpu_backprop_maxout': None, # (!) real value is '<capsule object "void (float *, float const *, int const *, int, int, int)" at 0x7ff73b7b7ae0>'
    'cpu_backprop_mean_pool': None, # (!) real value is '<capsule object "void (float *, float const *, int const *, int, int, int)" at 0x7ff73b7b7b40>'
    'cpu_max_pool': None, # (!) real value is '<capsule object "void (float *, int *, float const *, int const *, int, int, int)" at 0x7ff73b7b7b70>'
    'cpu_maxout': None, # (!) real value is '<capsule object "void (float *, int *, float const *, int, int, int)" at 0x7ff73b7b79f0>'
    'cpu_mean_pool': None, # (!) real value is '<capsule object "void (float *, float const *, int const *, int, int, int)" at 0x7ff73b7b7b10>'
    'seq2col': None, # (!) real value is '<capsule object "void (float *, float const *, int, int, int)" at 0x7ff74070c690>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.neural.ops', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff73b77fcc0>, origin='/usr/local/lib/python3.5/dist-packages/thinc/neural/ops.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


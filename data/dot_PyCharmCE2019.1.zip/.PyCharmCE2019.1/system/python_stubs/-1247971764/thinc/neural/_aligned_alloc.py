# encoding: utf-8
# module thinc.neural._aligned_alloc
# from /usr/local/lib/python3.5/dist-packages/thinc/neural/_aligned_alloc.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import numpy as numpy # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import warnings as warnings # /usr/lib/python3.5/warnings.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
from _bisect import bisect_left


# functions

def byte_align(array, n=None, dtype=None): # real signature unknown; restored from __doc__
    """
    byte_align(array, n=None, dtype=None)
    
        Function that takes a numpy array and checks it is aligned on an n-byte
        boundary, where ``n`` is an optional parameter. If ``n`` is not provided
        then this function will inspect the CPU to determine alignment. If the
        array is aligned then it is returned without further ado.  If it is not
        aligned then a new array is created and the data copied in, but aligned
        on the n-byte boundary.
    
        ``dtype`` is an optional argument that forces the resultant array to be
        of that dtype.
    """
    pass

def empty_aligned(shape, dtype='float32', order='C', n=None): # real signature unknown; restored from __doc__
    """
    empty_aligned(shape, dtype='float32', order='C', n=None)
    
        Function that returns an empty numpy array that is n-byte aligned,
        where ``n`` is determined by inspecting the CPU if it is not
        provided.
    
        The alignment is given by the final optional argument, ``n``. If
        ``n`` is not provided then this function will inspect the CPU to
        determine alignment. The rest of the arguments are as per
        :func:`numpy.empty`.
    """
    pass

def is_byte_aligned(*args, **kwargs): # real signature unknown
    """
    is_n_byte_aligned(array, n=None)
    
        Function that takes a numpy array and checks it is aligned on an n-byte
        boundary, where ``n`` is an optional parameter, returning ``True`` if it is,
        and ``False`` if it is not. If ``n`` is not provided then this function will
        inspect the CPU to determine alignment.
    """
    pass

def is_n_byte_aligned(array, n): # real signature unknown; restored from __doc__
    """
    is_n_byte_aligned(array, n)
        **This function is deprecated:** ``is_byte_aligned`` **should be used
        instead.**
    
        Function that takes a numpy array and checks it is aligned on an n-byte
        boundary, where ``n`` is a passed parameter, returning ``True`` if it is,
        and ``False`` if it is not.
    """
    pass

def ones_aligned(shape, dtype='float32', order='C', n=None): # real signature unknown; restored from __doc__
    """
    ones_aligned(shape, dtype='float32', order='C', n=None)
    
        Function that returns a numpy array of ones that is n-byte aligned,
        where ``n`` is determined by inspecting the CPU if it is not
        provided.
    
        The alignment is given by the final optional argument, ``n``. If
        ``n`` is not provided then this function will inspect the CPU to
        determine alignment. The rest of the arguments are as per
        :func:`numpy.ones`.
    """
    pass

def zeros_aligned(shape, dtype='float64', order='C', n=None): # real signature unknown; restored from __doc__
    """
    zeros_aligned(shape, dtype='float64', order='C', n=None)
    
        Function that returns a numpy array of zeros that is n-byte aligned,
        where ``n`` is determined by inspecting the CPU if it is not
        provided.
    
        The alignment is given by the final optional argument, ``n``. If
        ``n`` is not provided then this function will inspect the CPU to
        determine alignment. The rest of the arguments are as per
        :func:`numpy.zeros`.
    """
    pass

# no classes
# variables with complex values

_valid_simd_alignments = (
    16,
    32,
)

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8d83af00b8>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.neural._aligned_alloc', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8d83af00b8>, origin='/usr/local/lib/python3.5/dist-packages/thinc/neural/_aligned_alloc.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


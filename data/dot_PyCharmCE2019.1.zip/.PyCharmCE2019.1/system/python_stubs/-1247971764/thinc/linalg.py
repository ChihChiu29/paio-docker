# encoding: utf-8
# module thinc.linalg
# from /usr/local/lib/python3.5/dist-packages/thinc/linalg.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import blis as blis # /usr/local/lib/python3.5/dist-packages/blis/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# classes

class Mat(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f92a66ad5a0>'


class Matrix(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass


class Vec(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f92a66ad3c0>'


class VecVec(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f92a66ad510>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f92a675c048>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.linalg', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f92a675c048>, origin='/usr/local/lib/python3.5/dist-packages/thinc/linalg.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module thinc.extra.search
# from /usr/local/lib/python3.5/dist-packages/thinc/extra/search.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import math as math # <module 'math' (built-in)>
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def _softmax(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_MaxViolation(*args, **kwargs): # real signature unknown
    pass

# classes

class Beam(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    histories = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    is_done = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loss = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    min_density = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    min_score = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    probs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    score = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    scores = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f58f85d03c0>'


class MaxViolation(object):
    # no doc
    def check(self, *args, **kwargs): # real signature unknown
        pass

    def check_crf(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    gZ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    g_hist = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    g_probs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    g_score = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    p_hist = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    p_probs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    p_score = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    Z = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f58f85d0510>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f58f81a4470>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.extra.search', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f58f81a4470>, origin='/usr/local/lib/python3.5/dist-packages/thinc/extra/search.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


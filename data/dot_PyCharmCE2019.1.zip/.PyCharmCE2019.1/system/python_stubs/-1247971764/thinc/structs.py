# encoding: utf-8
# module thinc.structs
# from /usr/local/lib/python3.5/dist-packages/thinc/structs.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc115dac048>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.structs', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc115dac048>, origin='/usr/local/lib/python3.5/dist-packages/thinc/structs.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


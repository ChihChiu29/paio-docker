# encoding: utf-8
# module thinc.linear.features
# from /usr/local/lib/python3.5/dist-packages/thinc/linear/features.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# classes

class ConjunctionExtracter(object):
    """
    Extract composite features from a sequence of atomic values, according to
        the schema specified by a list of templates.
    """
    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    linear_mode = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_atom = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_embed = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_templ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7feaa988a3c0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7feaa93b1ba8>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.linear.features', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7feaa93b1ba8>, origin='/usr/local/lib/python3.5/dist-packages/thinc/linear/features.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


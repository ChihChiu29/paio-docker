# encoding: utf-8
# module thinc.linear.linear
# from /usr/local/lib/python3.5/dist-packages/thinc/linear/linear.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import thinc.describe as describe # /usr/local/lib/python3.5/dist-packages/thinc/describe.py
import thinc.describe as __thinc_describe
import thinc.neural._classes.model as __thinc_neural__classes_model


# functions

def is_cupy_array(arr): # reliably restored by inspect
    """ Check whether an array is a cupy array """
    pass

def is_numpy_array(arr): # reliably restored by inspect
    """ Check whether an array is a numpy array """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Biases(__thinc_describe.Weights):
    # no doc
    def __init__(self, text, get_shape, init=None): # reliably restored by inspect
        # no doc
        pass


class Dimension(__thinc_describe.AttributeDescription):
    # no doc
    def __get__(self, obj, type=None): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, text, value=None, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    def __set__(self, obj, value): # reliably restored by inspect
        # no doc
        pass


class Gradient(__thinc_describe.AttributeDescription):
    # no doc
    def __get__(self, obj, type=None): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, param_name): # reliably restored by inspect
        # no doc
        pass

    def __set__(self, obj, val): # reliably restored by inspect
        # no doc
        pass


class Model(object):
    """ Model base class. """
    def begin_training(self, train_X, train_y=None, **trainer_cfg): # reliably restored by inspect
        # no doc
        pass

    def begin_update(self, X, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def define_operators(cls, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        Bind operators to specified functions for the scope of the context:
        
                Example
                -------
        
                    model = Model()
                    other = Model()
                    with Model.define_operators({"+": lambda self, other: "plus"}):
                        print(model + other)
                        # "plus"
                    print(model + other)
                    # Raises TypeError --- binding limited to scope of with block.
        """
        pass

    def evaluate(self, X, y): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
                y
                    Must match expected type
        """
        pass

    def evaluate_logloss(self, X, y, minimum=None, maximum=None): # reliably restored by inspect
        # no doc
        pass

    def from_bytes(self, bytes_data): # reliably restored by inspect
        # no doc
        pass

    def from_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def pipe(self, stream, batch_size=128): # reliably restored by inspect
        # no doc
        pass

    def predict(self, X): # reliably restored by inspect
        # no doc
        pass

    def predict_one(self, x): # reliably restored by inspect
        # no doc
        pass

    def set_id(self): # reliably restored by inspect
        # no doc
        pass

    def to_bytes(self): # reliably restored by inspect
        # no doc
        pass

    def to_cpu(self): # reliably restored by inspect
        # no doc
        pass

    def to_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def to_gpu(self, device_num): # reliably restored by inspect
        # no doc
        pass

    def update(self, stream, batch_size=1000): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def use_device(cls, *args, **kwargs): # real signature unknown
        """ Change the device to execute on for the scope of the block. """
        pass

    def use_params(*args, **kwds): # reliably restored by inspect
        # no doc
        pass

    def _update_defaults(self, args, kwargs): # reliably restored by inspect
        # no doc
        pass

    def __add__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '+' operator. """
        pass

    def __and__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '&' operator. """
        pass

    def __call__(self, x): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
        """
        pass

    def __div__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __floordiv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '//' operator. """
        pass

    def __getstate__(self): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    def __lshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '<<' operator. """
        pass

    def __matmul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '@' operator. """
        pass

    def __mod__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '%' operator. """
        pass

    def __mul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '*' operator. """
        pass

    def __or__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '|' operator. """
        pass

    def __pow__(self, other, modulo=None): # reliably restored by inspect
        """ Apply the function bound to the '**' operator. """
        pass

    def __rshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '>>' operator. """
        pass

    def __setstate__(self, state_data): # reliably restored by inspect
        # no doc
        pass

    def __sub__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '-' operator. """
        pass

    def __truediv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __xor__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '^' operator. """
        pass

    input_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    descriptions = []
    drop_factor = 1.0
    id = 0
    lsuv = False
    name = 'model'
    on_data_hooks = []
    on_init_hooks = []
    Ops = None # (!) real value is "<class 'thinc.neural.ops.NumpyOps'>"
    ops = None # (!) real value is '<thinc.neural.ops.NumpyOps object at 0x7f905553b940>'
    Trainer = None # (!) real value is "<class 'thinc.neural.train.Trainer'>"
    _operators = {}
    __dict__ = None # (!) real value is "mappingproxy({'use_device': <classmethod object at 0x7f905553bb70>, 'on_data_hooks': [], '__div__': <FunctionWrapper at 0x7f904df8e250 for function at 0x7f904df8cd08>, '__getstate__': <function Model.__getstate__ at 0x7f904dd22bf8>, '__rshift__': <FunctionWrapper at 0x7f904df8e4c0 for function at 0x7f904df9a7b8>, 'on_init_hooks': [], '__doc__': 'Model base class.', '__xor__': <FunctionWrapper at 0x7f904df8e590 for function at 0x7f904df9a730>, '__module__': 'thinc.neural._classes.model', 'pipe': <function Model.pipe at 0x7f904df8c378>, 'begin_update': <FunctionWrapper at 0x7f904df8e0b0 for function at 0x7f904df8c488>, '__and__': <FunctionWrapper at 0x7f904df8e528 for function at 0x7f904df9a620>, '__lshift__': <FunctionWrapper at 0x7f904df8e458 for function at 0x7f904df9aae8>, 'evaluate': <function Model.evaluate at 0x7f904df8c620>, '__init__': <function Model.__init__ at 0x7f904dd22b70>, 'predict_one': <function Model.predict_one at 0x7f904dd22f28>, '__call__': <function Model.__call__ at 0x7f904df8c400>, 'to_cpu': <function Model.to_cpu at 0x7f904df8c598>, 'lsuv': False, 'name': 'model', 'input_shape': <property object at 0x7f9055533638>, 'to_bytes': <function Model.to_bytes at 0x7f904df9a488>, '__mod__': <FunctionWrapper at 0x7f904df8e388 for function at 0x7f904df9ad90>, 'output_shape': <property object at 0x7f904df7abd8>, '__dict__': <attribute '__dict__' of 'Model' objects>, 'from_disk': <function Model.from_disk at 0x7f904df9a158>, 'define_operators': <classmethod object at 0x7f905553b9b0>, '__setstate__': <function Model.__setstate__ at 0x7f904dd22c80>, '__add__': <FunctionWrapper at 0x7f904df8e048 for function at 0x7f904df8c8c8>, '__truediv__': <FunctionWrapper at 0x7f904df8e2b8 for function at 0x7f904df8ce18>, '__weakref__': <attribute '__weakref__' of 'Model' objects>, 'Trainer': <class 'thinc.neural.train.Trainer'>, 'ops': <thinc.neural.ops.NumpyOps object at 0x7f905553b940>, 'update': <function Model.update at 0x7f904df8c2f0>, '__matmul__': <FunctionWrapper at 0x7f904df8e1e8 for function at 0x7f904df8cbf8>, 'descriptions': [], 'from_bytes': <function Model.from_bytes at 0x7f904df9a8c8>, '__or__': <FunctionWrapper at 0x7f904df8e5f8 for function at 0x7f904df9a268>, 'to_disk': <function Model.to_disk at 0x7f904df9abf8>, '__sub__': <FunctionWrapper at 0x7f904df8e118 for function at 0x7f904df8c9d8>, 'drop_factor': 1.0, '_update_defaults': <function Model._update_defaults at 0x7f904dd22d08>, '__mul__': <FunctionWrapper at 0x7f904df8e180 for function at 0x7f904df8cae8>, 'evaluate_logloss': <function Model.evaluate_logloss at 0x7f904df8c6a8>, 'begin_training': <FunctionWrapper at 0x7f904e43df50 for function at 0x7f904df8c0d0>, 'Ops': <class 'thinc.neural.ops.NumpyOps'>, 'set_id': <function Model.set_id at 0x7f904dd22d90>, '__pow__': <FunctionWrapper at 0x7f904df8e3f0 for function at 0x7f904df9aea0>, '_operators': {}, 'predict': <function Model.predict at 0x7f904dd22ea0>, '__floordiv__': <FunctionWrapper at 0x7f904df8e320 for function at 0x7f904df8cf28>, 'use_params': <function Model.use_params at 0x7f904df8c048>, 'to_gpu': <function Model.to_gpu at 0x7f904df8c510>, 'id': 0})"


class LinearModel(__thinc_neural__classes_model.Model):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, *args, **kwargs): # real signature unknown
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def length(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def _begin_cpu_update(self, *args, **kwargs): # real signature unknown
        pass

    def _begin_gpu_update(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7f905552f860>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7f905552f8d0>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f905552f940>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f905552fa90>'
        'length': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f905552f7b8>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f905552f780>'
    }
    name = 'linear'


class Synapses(__thinc_describe.Weights):
    # no doc
    def __init__(self, text, get_shape, init=None): # reliably restored by inspect
        # no doc
        pass


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9055482ac8>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.linear.linear', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9055482ac8>, origin='/usr/local/lib/python3.5/dist-packages/thinc/linear/linear.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module retro._retro
# from /usr/local/lib/python3.5/dist-packages/retro/_retro.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" libretro bindings """

# imports
import pybind11_builtins as __pybind11_builtins


# functions

def core_path(hint=None): # real signature unknown; restored from __doc__
    """ core_path(hint: handle=None) -> str """
    return ""

def data_path(hint=None): # real signature unknown; restored from __doc__
    """ data_path(hint: handle=None) -> str """
    return ""

# classes

class GameDataGlue(__pybind11_builtins.pybind11_object):
    # no doc
    def crop_info(self, player=0): # real signature unknown; restored from __doc__
        """ crop_info(self: retro._retro.GameDataGlue, player: int=0) -> tuple """
        return ()

    def current_reward(self, player=0): # real signature unknown; restored from __doc__
        """ current_reward(self: retro._retro.GameDataGlue, player: int=0) -> float """
        return 0.0

    def delta_search(self, arg0, arg1, arg2): # real signature unknown; restored from __doc__
        """ delta_search(self: retro._retro.GameDataGlue, arg0: str, arg1: str, arg2: int) -> None """
        pass

    def filter_action(self, arg0): # real signature unknown; restored from __doc__
        """ filter_action(self: retro._retro.GameDataGlue, arg0: int) -> int """
        return 0

    def get_search(self, arg0): # real signature unknown; restored from __doc__
        """ get_search(self: retro._retro.GameDataGlue, arg0: str) -> retro._retro.Search """
        pass

    def get_variable(self, arg0): # real signature unknown; restored from __doc__
        """ get_variable(self: retro._retro.GameDataGlue, arg0: str) -> dict """
        return {}

    def is_done(self): # real signature unknown; restored from __doc__
        """ is_done(self: retro._retro.GameDataGlue) -> bool """
        return False

    def list_searches(self): # real signature unknown; restored from __doc__
        """ list_searches(self: retro._retro.GameDataGlue) -> dict """
        return {}

    def list_variables(self): # real signature unknown; restored from __doc__
        """ list_variables(self: retro._retro.GameDataGlue) -> dict """
        return {}

    def load(self, data=None, scen=None): # real signature unknown; restored from __doc__
        """ load(self: retro._retro.GameDataGlue, data: handle=None, scen: handle=None) -> bool """
        return False

    def lookup_all(self): # real signature unknown; restored from __doc__
        """ lookup_all(self: retro._retro.GameDataGlue) -> dict """
        return {}

    def lookup_value(self, arg0): # real signature unknown; restored from __doc__
        """ lookup_value(self: retro._retro.GameDataGlue, arg0: str) -> object """
        return object()

    def remove_search(self, arg0): # real signature unknown; restored from __doc__
        """ remove_search(self: retro._retro.GameDataGlue, arg0: str) -> None """
        pass

    def remove_variable(self, arg0): # real signature unknown; restored from __doc__
        """ remove_variable(self: retro._retro.GameDataGlue, arg0: str) -> None """
        pass

    def reset(self): # real signature unknown; restored from __doc__
        """ reset(self: retro._retro.GameDataGlue) -> None """
        pass

    def save(self, data=None, scen=None): # real signature unknown; restored from __doc__
        """ save(self: retro._retro.GameDataGlue, data: handle=None, scen: handle=None) -> bool """
        return False

    def search(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ search(self: retro._retro.GameDataGlue, arg0: str, arg1: int) -> None """
        pass

    def set_value(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ set_value(self: retro._retro.GameDataGlue, arg0: str, arg1: object) -> object """
        return object()

    def set_variable(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ set_variable(self: retro._retro.GameDataGlue, arg0: str, arg1: dict) -> None """
        pass

    def total_reward(self, player=0): # real signature unknown; restored from __doc__
        """ total_reward(self: retro._retro.GameDataGlue, player: int=0) -> float """
        return 0.0

    def update_ram(self): # real signature unknown; restored from __doc__
        """ update_ram(self: retro._retro.GameDataGlue) -> None """
        pass

    def valid_actions(self): # real signature unknown; restored from __doc__
        """ valid_actions(self: retro._retro.GameDataGlue) -> list """
        return []

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: retro._retro.GameDataGlue) -> None """
        pass

    memory = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class Memory(__pybind11_builtins.pybind11_object):
    # no doc
    def assign(self, address, type, value): # real signature unknown; restored from __doc__
        """ assign(self: retro._retro.Memory, address: int, type: str, value: int) -> None """
        pass

    def extract(self, address, type): # real signature unknown; restored from __doc__
        """ extract(self: retro._retro.Memory, address: int, type: str) -> int """
        return 0

    def __getitem__(self, item): # real signature unknown; restored from __doc__
        """ __getitem__(self: retro._retro.Memory, item: dict) -> int """
        return 0

    def __init__(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ __init__(self: retro._retro.Memory, arg0: Retro::AddressSpace) -> None """
        pass

    def __setitem__(self, item, value): # real signature unknown; restored from __doc__
        """ __setitem__(self: retro._retro.Memory, item: dict, value: int) -> None """
        pass

    blocks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class Movie(__pybind11_builtins.pybind11_object):
    # no doc
    def close(self): # real signature unknown; restored from __doc__
        """ close(self: retro._retro.Movie) -> None """
        pass

    def configure(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ configure(self: retro._retro.Movie, arg0: str, arg1: retro._retro.RetroEmulator) -> None """
        pass

    def get_game(self): # real signature unknown; restored from __doc__
        """ get_game(self: retro._retro.Movie) -> str """
        return ""

    def get_key(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ get_key(self: retro._retro.Movie, arg0: int, arg1: int) -> bool """
        return False

    def get_state(self): # real signature unknown; restored from __doc__
        """ get_state(self: retro._retro.Movie) -> bytes """
        return b""

    def set_key(self, arg0, arg1, arg2): # real signature unknown; restored from __doc__
        """ set_key(self: retro._retro.Movie, arg0: int, arg1: bool, arg2: int) -> None """
        pass

    def set_state(self, arg0): # real signature unknown; restored from __doc__
        """ set_state(self: retro._retro.Movie, arg0: bytes) -> None """
        pass

    def step(self): # real signature unknown; restored from __doc__
        """ step(self: retro._retro.Movie) -> bool """
        return False

    def __init__(self, path, record=False, players=1): # real signature unknown; restored from __doc__
        """ __init__(self: retro._retro.Movie, path: str, record: bool=False, players: int=1) -> None """
        pass

    players = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class RetroEmulator(__pybind11_builtins.pybind11_object):
    # no doc
    def add_cheat(self, arg0): # real signature unknown; restored from __doc__
        """ add_cheat(self: retro._retro.RetroEmulator, arg0: str) -> None """
        pass

    def clear_cheats(self): # real signature unknown; restored from __doc__
        """ clear_cheats(self: retro._retro.RetroEmulator) -> None """
        pass

    def configure_data(self, arg0): # real signature unknown; restored from __doc__
        """ configure_data(self: retro._retro.RetroEmulator, arg0: PyGameData) -> None """
        pass

    def get_audio(self): # real signature unknown; restored from __doc__
        """ get_audio(self: retro._retro.RetroEmulator) -> numpy.ndarray[int16] """
        pass

    def get_audio_rate(self): # real signature unknown; restored from __doc__
        """ get_audio_rate(self: retro._retro.RetroEmulator) -> float """
        return 0.0

    def get_resolution(self): # real signature unknown; restored from __doc__
        """ get_resolution(self: retro._retro.RetroEmulator) -> tuple """
        return ()

    def get_screen(self): # real signature unknown; restored from __doc__
        """ get_screen(self: retro._retro.RetroEmulator) -> numpy.ndarray[uint8] """
        pass

    def get_screen_rate(self): # real signature unknown; restored from __doc__
        """ get_screen_rate(self: retro._retro.RetroEmulator) -> float """
        return 0.0

    def get_state(self): # real signature unknown; restored from __doc__
        """ get_state(self: retro._retro.RetroEmulator) -> bytes """
        return b""

    def load_core_info(self, arg0): # real signature unknown; restored from __doc__
        """ load_core_info(arg0: str) -> bool """
        return False

    def set_button_mask(self, mask, uint8=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ set_button_mask(self: retro._retro.RetroEmulator, mask: numpy.ndarray[uint8], player: int=0) -> None """
        pass

    def set_state(self, arg0): # real signature unknown; restored from __doc__
        """ set_state(self: retro._retro.RetroEmulator, arg0: bytes) -> bool """
        return False

    def step(self): # real signature unknown; restored from __doc__
        """ step(self: retro._retro.RetroEmulator) -> None """
        pass

    def __init__(self, arg0): # real signature unknown; restored from __doc__
        """ __init__(self: retro._retro.RetroEmulator, arg0: str) -> None """
        pass


class Search(__pybind11_builtins.pybind11_object):
    # no doc
    def has_unique_result(self): # real signature unknown; restored from __doc__
        """ has_unique_result(self: retro._retro.Search) -> bool """
        return False

    def num_results(self): # real signature unknown; restored from __doc__
        """ num_results(self: retro._retro.Search) -> int """
        return 0

    def typed_results(self): # real signature unknown; restored from __doc__
        """ typed_results(self: retro._retro.Search) -> list """
        return []

    def unique_result(self): # real signature unknown; restored from __doc__
        """ unique_result(self: retro._retro.Search) -> dict """
        return {}

    def __init__(self, types=None): # real signature unknown; restored from __doc__
        """ __init__(self: retro._retro.Search, types: handle=None) -> None """
        pass


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8280c5e9e8>'

__spec__ = None # (!) real value is "ModuleSpec(name='retro._retro', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8280c5e9e8>, origin='/usr/local/lib/python3.5/dist-packages/retro/_retro.cpython-35m-x86_64-linux-gnu.so')"


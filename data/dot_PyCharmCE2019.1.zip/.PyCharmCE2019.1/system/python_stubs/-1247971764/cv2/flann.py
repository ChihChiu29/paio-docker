# encoding: utf-8
# module cv2.flann
# from /usr/local/lib/python3.5/dist-packages/cv2/cv2.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

FLANN_INDEX_TYPE_16S = 3
FLANN_INDEX_TYPE_16U = 2
FLANN_INDEX_TYPE_32F = 5
FLANN_INDEX_TYPE_32S = 4
FLANN_INDEX_TYPE_64F = 6
FLANN_INDEX_TYPE_8S = 1
FLANN_INDEX_TYPE_8U = 0
FLANN_INDEX_TYPE_ALGORITHM = 9
FLANN_INDEX_TYPE_BOOL = 8
FLANN_INDEX_TYPE_STRING = 7

LAST_VALUE_FLANN_INDEX_TYPE = 9

__loader__ = None

__spec__ = None

# no functions
# no classes

# encoding: utf-8
# module cv2.instr
# from /usr/local/lib/python3.5/dist-packages/cv2/cv2.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

FLAGS_EXPAND_SAME_NAMES = 2

FLAGS_MAPPING = 1
FLAGS_NONE = 0

IMPL_IPP = 1
IMPL_OPENCL = 2
IMPL_PLAIN = 0

TYPE_FUN = 3
TYPE_GENERAL = 0
TYPE_MARKER = 1
TYPE_WRAPPER = 2

__loader__ = None

__spec__ = None

# no functions
# no classes

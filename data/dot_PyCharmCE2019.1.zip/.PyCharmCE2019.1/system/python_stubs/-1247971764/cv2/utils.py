# encoding: utf-8
# module cv2.utils
# from /usr/local/lib/python3.5/dist-packages/cv2/cv2.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def dumpInputArray(argument): # real signature unknown; restored from __doc__
    """
    dumpInputArray(argument) -> retval
    .
    """
    pass

def dumpInputArrayOfArrays(argument): # real signature unknown; restored from __doc__
    """
    dumpInputArrayOfArrays(argument) -> retval
    .
    """
    pass

def dumpInputOutputArray(argument): # real signature unknown; restored from __doc__
    """
    dumpInputOutputArray(argument) -> retval, argument
    .
    """
    pass

def dumpInputOutputArrayOfArrays(argument): # real signature unknown; restored from __doc__
    """
    dumpInputOutputArrayOfArrays(argument) -> retval, argument
    .
    """
    pass

# no classes

# encoding: utf-8
# module cv2.ipp
# from /usr/local/lib/python3.5/dist-packages/cv2/cv2.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def getIppVersion(): # real signature unknown; restored from __doc__
    """
    getIppVersion() -> retval
    .
    """
    pass

def setUseIPP(flag): # real signature unknown; restored from __doc__
    """
    setUseIPP(flag) -> None
    .
    """
    pass

def setUseIPP_NotExact(flag): # real signature unknown; restored from __doc__
    """
    setUseIPP_NotExact(flag) -> None
    .
    """
    pass

def useIPP(): # real signature unknown; restored from __doc__
    """
    useIPP() -> retval
    .   proxy for hal::Cholesky
    """
    pass

def useIPP_NotExact(): # real signature unknown; restored from __doc__
    """
    useIPP_NotExact() -> retval
    .
    """
    pass

# no classes

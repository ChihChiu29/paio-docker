# encoding: utf-8
# module 211831b45150881d15d0e8f1e0ef3ee3
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def bigtable_client(project_id, instance_id, connection_pool_size, max_receive_message_size=-1, container=None, shared_name=None, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        project_id: A `string`.
        instance_id: A `string`.
        connection_pool_size: An `int`.
        max_receive_message_size: An optional `int`. Defaults to `-1`.
        container: An optional `string`. Defaults to `""`.
        shared_name: An optional `string`. Defaults to `""`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `resource`.
    """
    pass

def bigtable_client_eager_fallback(project_id, instance_id, connection_pool_size, max_receive_message_size=-1, container=None, shared_name=None, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_client
    """
    pass

def bigtable_lookup_dataset(keys_dataset, table, column_families, columns, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        keys_dataset: A `Tensor` of type `variant`.
        table: A `Tensor` of type `resource`.
        column_families: A `Tensor` of type `string`.
        columns: A `Tensor` of type `string`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `variant`.
    """
    pass

def bigtable_lookup_dataset_eager_fallback(keys_dataset, table, column_families, columns, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_lookup_dataset
    """
    pass

def bigtable_prefix_key_dataset(table, prefix, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        table: A `Tensor` of type `resource`.
        prefix: A `Tensor` of type `string`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `variant`.
    """
    pass

def bigtable_prefix_key_dataset_eager_fallback(table, prefix, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_prefix_key_dataset
    """
    pass

def bigtable_range_key_dataset(table, start_key, end_key, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        table: A `Tensor` of type `resource`.
        start_key: A `Tensor` of type `string`.
        end_key: A `Tensor` of type `string`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `variant`.
    """
    pass

def bigtable_range_key_dataset_eager_fallback(table, start_key, end_key, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_range_key_dataset
    """
    pass

def bigtable_sample_keys_dataset(table, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        table: A `Tensor` of type `resource`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `variant`.
    """
    pass

def bigtable_sample_keys_dataset_eager_fallback(table, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_sample_keys_dataset
    """
    pass

def bigtable_sample_key_pairs_dataset(table, prefix, start_key, end_key, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        table: A `Tensor` of type `resource`.
        prefix: A `Tensor` of type `string`.
        start_key: A `Tensor` of type `string`.
        end_key: A `Tensor` of type `string`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `variant`.
    """
    pass

def bigtable_sample_key_pairs_dataset_eager_fallback(table, prefix, start_key, end_key, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_sample_key_pairs_dataset
    """
    pass

def bigtable_scan_dataset(table, prefix, start_key, end_key, column_families, columns, probability, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        table: A `Tensor` of type `resource`.
        prefix: A `Tensor` of type `string`.
        start_key: A `Tensor` of type `string`.
        end_key: A `Tensor` of type `string`.
        column_families: A `Tensor` of type `string`.
        columns: A `Tensor` of type `string`.
        probability: A `Tensor` of type `float32`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `variant`.
    """
    pass

def bigtable_scan_dataset_eager_fallback(table, prefix, start_key, end_key, column_families, columns, probability, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_scan_dataset
    """
    pass

def bigtable_table(client, table_name, container=None, shared_name=None, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        client: A `Tensor` of type `resource`.
        table_name: A `string`.
        container: An optional `string`. Defaults to `""`.
        shared_name: An optional `string`. Defaults to `""`.
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `resource`.
    """
    pass

def bigtable_table_eager_fallback(client, table_name, container=None, shared_name=None, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bigtable_table
    """
    pass

def dataset_to_bigtable(table, input_dataset, column_families, columns, timestamp, name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        table: A `Tensor` of type `resource`.
        input_dataset: A `Tensor` of type `variant`.
        column_families: A `Tensor` of type `string`.
        columns: A `Tensor` of type `string`.
        timestamp: A `Tensor` of type `int64`.
        name: A name for the operation (optional).
    
      Returns:
        The created Operation.
    """
    pass

def dataset_to_bigtable_eager_fallback(table, input_dataset, column_families, columns, timestamp, name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function dataset_to_bigtable
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# no classes
# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7e443e660>"


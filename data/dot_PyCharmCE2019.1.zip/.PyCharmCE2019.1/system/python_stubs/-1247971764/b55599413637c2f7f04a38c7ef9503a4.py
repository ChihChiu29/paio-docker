# encoding: utf-8
# module b55599413637c2f7f04a38c7ef9503a4
# from /usr/local/lib/python3.5/dist-packages/tensorflow/contrib/tensorrt/_wrap_conversion.so
# by generator 1.147
"""
Python wrappers around TensorFlow ops.

This file is MACHINE GENERATED! Do not edit.
"""

# imports
import six as _six # /helpers/six.py
import tensorflow.python.framework.tensor_shape as _tensor_shape # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/tensor_shape.py
import tensorflow.core.framework.op_def_pb2 as _op_def_pb2 # /usr/local/lib/python3.5/dist-packages/tensorflow/core/framework/op_def_pb2.py
import tensorflow.python.util.dispatch as _dispatch # /usr/local/lib/python3.5/dist-packages/tensorflow/python/util/dispatch.py
import tensorflow.python.framework.ops as _ops # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/ops.py
import tensorflow.python.eager.execute as _execute # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/execute.py
import tensorflow.python.framework.op_def_registry as _op_def_registry # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_registry.py
import tensorflow.python.framework.op_def_library as _op_def_library # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/op_def_library.py
import collections as _collections # /usr/lib/python3.5/collections/__init__.py
import tensorflow.python.eager.core as _core # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/core.py
import tensorflow.python.framework.errors as _errors # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/errors.py
import tensorflow.python.eager.context as _context # /usr/local/lib/python3.5/dist-packages/tensorflow/python/eager/context.py
import tensorflow.python.pywrap_tensorflow as _pywrap_tensorflow # /usr/local/lib/python3.5/dist-packages/tensorflow/python/pywrap_tensorflow.py
import tensorflow.python.framework.common_shapes as _common_shapes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/common_shapes.py
import tensorflow.python.framework.dtypes as _dtypes # /usr/local/lib/python3.5/dist-packages/tensorflow/python/framework/dtypes.py
from tensorflow.core.framework.op_def_pb2 import OP_LIST

from tensorflow.python.framework.op_def_library import _op_def_lib

from tensorflow.python.util.deprecation import deprecated_endpoints


# Variables with simple values

__loader__ = None

__spec__ = None

# functions

def bytes_in_use(name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int64`.
    """
    pass

def bytes_in_use_eager_fallback(name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bytes_in_use
    """
    pass

def bytes_limit(name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int64`.
    """
    pass

def bytes_limit_eager_fallback(name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function bytes_limit
    """
    pass

def max_bytes_in_use(name=None): # reliably restored by inspect
    """
    TODO: add doc.
    
      Args:
        name: A name for the operation (optional).
    
      Returns:
        A `Tensor` of type `int64`.
    """
    pass

def max_bytes_in_use_eager_fallback(name=None, ctx=None): # reliably restored by inspect
    """
    This is the slowpath function for Eager mode.
      This is for function max_bytes_in_use
    """
    pass

def tf_export(*args, **kwargs): # real signature unknown
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    pass

def _InitOpDefLibrary(op_list_proto_bytes): # reliably restored by inspect
    # no doc
    pass

# no classes
# variables with complex values

LIB_HANDLE = None # (!) real value is "<Swig Object of type 'TF_Library *' at 0x7fc7dde568d0>"


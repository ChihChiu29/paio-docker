# encoding: utf-8
# module sklearn._isotonic
# from /usr/local/lib/python3.5/dist-packages/sklearn/_isotonic.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def _inplace_contiguous_isotonic_regression(*args, **kwargs): # real signature unknown
    pass

def _make_unique(*args, **kwargs): # real signature unknown
    """
    Average targets for duplicate X, drop duplicates.
    
        Aggregates duplicate X values into a single X value where
        the target y is a (sample_weighted) average of the individual
        targets.
    
        Assumes that X is ordered, so that all duplicates follow each other.
    """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f5648a60ef0>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn._isotonic', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f5648a60ef0>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/_isotonic.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module sklearn.__check_build._check_build
# from /usr/local/lib/python3.5/dist-packages/sklearn/__check_build/_check_build.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def check_build(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa399079cf8>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn.__check_build._check_build', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa399079cf8>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/__check_build/_check_build.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


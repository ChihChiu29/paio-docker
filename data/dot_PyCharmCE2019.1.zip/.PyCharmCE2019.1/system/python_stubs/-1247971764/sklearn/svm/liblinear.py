# encoding: utf-8
# module sklearn.svm.liblinear
# from /usr/local/lib/python3.5/dist-packages/sklearn/svm/liblinear.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
"""
Wrapper for liblinear

Author: fabian.pedregosa@inria.fr
"""

# imports
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def set_verbosity_wrap(*args, **kwargs): # real signature unknown
    """ Control verbosity of libsvm library """
    pass

def train_wrap(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6929080d30>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn.svm.liblinear', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6929080d30>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/svm/liblinear.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


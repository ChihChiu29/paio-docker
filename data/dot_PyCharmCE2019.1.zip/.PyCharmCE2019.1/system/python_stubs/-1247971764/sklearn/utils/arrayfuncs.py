# encoding: utf-8
# module sklearn.utils.arrayfuncs
# from /usr/local/lib/python3.5/dist-packages/sklearn/utils/arrayfuncs.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" Small collection of auxiliary functions that operate on arrays """

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py

# functions

def cholesky_delete(*args, **kwargs): # real signature unknown
    pass

def min_pos(*args, **kwargs): # real signature unknown
    """
    Find the minimum value of an array over positive values
    
       Returns a huge value if none of the values are positive
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbc8e5fea58>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn.utils.arrayfuncs', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbc8e5fea58>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/utils/arrayfuncs.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


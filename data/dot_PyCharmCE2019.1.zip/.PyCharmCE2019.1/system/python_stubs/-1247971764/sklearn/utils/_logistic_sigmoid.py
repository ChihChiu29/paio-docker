# encoding: utf-8
# module sklearn.utils._logistic_sigmoid
# from /usr/local/lib/python3.5/dist-packages/sklearn/utils/_logistic_sigmoid.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def _log_logistic_sigmoid(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f86d805da58>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn.utils._logistic_sigmoid', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f86d805da58>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/utils/_logistic_sigmoid.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


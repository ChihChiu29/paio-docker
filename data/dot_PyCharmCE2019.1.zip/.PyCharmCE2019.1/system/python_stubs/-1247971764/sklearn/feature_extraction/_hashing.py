# encoding: utf-8
# module sklearn.feature_extraction._hashing
# from /usr/local/lib/python3.5/dist-packages/sklearn/feature_extraction/_hashing.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import array as array # <module 'array' (built-in)>

# functions

def transform(*args, **kwargs): # real signature unknown
    """
    Guts of FeatureHasher.transform.
    
        Returns
        -------
        n_samples : integer
        indices, indptr, values : lists
            For constructing a scipy.sparse.csr_matrix.
    """
    pass

# no classes
# variables with complex values

sp_version = (
    1,
    2,
    1,
)

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3ed7ac9128>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn.feature_extraction._hashing', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3ed7ac9128>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/feature_extraction/_hashing.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


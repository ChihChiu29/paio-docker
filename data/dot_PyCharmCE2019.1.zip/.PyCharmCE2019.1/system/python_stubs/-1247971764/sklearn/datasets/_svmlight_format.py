# encoding: utf-8
# module sklearn.datasets._svmlight_format
# from /usr/local/lib/python3.5/dist-packages/sklearn/datasets/_svmlight_format.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import scipy.sparse as sp # /usr/local/lib/python3.5/dist-packages/scipy/sparse/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>
import array as array # <module 'array' (built-in)>

# functions

def b(s): # reliably restored by inspect
    """ Byte literal """
    pass

def _load_svmlight_file(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f47a9fc85f8>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn.datasets._svmlight_format', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f47a9fc85f8>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/datasets/_svmlight_format.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


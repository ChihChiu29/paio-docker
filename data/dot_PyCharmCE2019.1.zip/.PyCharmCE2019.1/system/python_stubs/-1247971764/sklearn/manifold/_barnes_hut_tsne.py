# encoding: utf-8
# module sklearn.manifold._barnes_hut_tsne
# from /usr/local/lib/python3.5/dist-packages/sklearn/manifold/_barnes_hut_tsne.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import sklearn.neighbors.quad_tree as quad_tree # /usr/local/lib/python3.5/dist-packages/sklearn/neighbors/quad_tree.cpython-35m-x86_64-linux-gnu.so
import numpy as np # /usr/local/lib/python3.5/dist-packages/numpy/__init__.py
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def gradient(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f82bb670eb8>'

__spec__ = None # (!) real value is "ModuleSpec(name='sklearn.manifold._barnes_hut_tsne', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f82bb670eb8>, origin='/usr/local/lib/python3.5/dist-packages/sklearn/manifold/_barnes_hut_tsne.cpython-35m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class NNSubgraph(__pybind11_builtins.pybind11_object):
    # no doc
    def addNode(self, arg0): # real signature unknown; restored from __doc__
        """ addNode(self: caffe2.python.caffe2_pybind11_state_gpu.NNSubgraph, arg0: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> None """
        pass

    def hasNode(self, arg0): # real signature unknown; restored from __doc__
        """ hasNode(self: caffe2.python.caffe2_pybind11_state_gpu.NNSubgraph, arg0: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> bool """
        return False

    def induceEdges(self): # real signature unknown; restored from __doc__
        """ induceEdges(self: caffe2.python.caffe2_pybind11_state_gpu.NNSubgraph) -> None """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state_gpu.NNSubgraph) -> None """
        pass

    def __len__(self): # real signature unknown; restored from __doc__
        """ __len__(self: caffe2.python.caffe2_pybind11_state_gpu.NNSubgraph) -> int """
        return 0

    def __repr__(self): # real signature unknown; restored from __doc__
        """ __repr__(self: caffe2.python.caffe2_pybind11_state_gpu.NNSubgraph) -> str """
        return ""

    nodes = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




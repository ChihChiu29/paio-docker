# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class OpSchema(__pybind11_builtins.pybind11_object):
    # no doc
    def CalculateOutput(self, arg0): # real signature unknown; restored from __doc__
        """ CalculateOutput(self: caffe2.python.caffe2_pybind11_state.OpSchema, arg0: int) -> int """
        return 0

    def get(self, arg0): # real signature unknown; restored from __doc__
        """ get(arg0: str) -> caffe2.python.caffe2_pybind11_state.OpSchema """
        pass

    def get_cpu_impl(self, arg0): # real signature unknown; restored from __doc__
        """ get_cpu_impl(arg0: str) -> str """
        return ""

    def get_cuda_impl(self, arg0): # real signature unknown; restored from __doc__
        """ get_cuda_impl(arg0: str) -> str """
        return ""

    def get_gradient_impl(self, arg0): # real signature unknown; restored from __doc__
        """ get_gradient_impl(arg0: str) -> str """
        return ""

    def infer_tensor(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ infer_tensor(self: caffe2.python.caffe2_pybind11_state.OpSchema, arg0: caffe2::OperatorDef, arg1: List[caffe2::TensorShape]) -> List[caffe2::TensorShape] """
        pass

    def inplace_enforced(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ inplace_enforced(self: caffe2.python.caffe2_pybind11_state.OpSchema, arg0: int, arg1: int) -> bool """
        return False

    def num_inputs_allowed(self, arg0): # real signature unknown; restored from __doc__
        """ num_inputs_allowed(self: caffe2.python.caffe2_pybind11_state.OpSchema, arg0: int) -> bool """
        return False

    def num_inputs_outputs_allowed(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ num_inputs_outputs_allowed(self: caffe2.python.caffe2_pybind11_state.OpSchema, arg0: int, arg1: int) -> bool """
        return False

    def num_outputs_allowed(self, arg0): # real signature unknown; restored from __doc__
        """ num_outputs_allowed(self: caffe2.python.caffe2_pybind11_state.OpSchema, arg0: int) -> bool """
        return False

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    args = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    file = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    inf = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    input_desc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    line = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    max_input = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    max_output = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    min_input = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    min_output = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    output_desc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    private = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    Argument = None # (!) real value is "<class 'caffe2.python.caffe2_pybind11_state.OpSchema.Argument'>"



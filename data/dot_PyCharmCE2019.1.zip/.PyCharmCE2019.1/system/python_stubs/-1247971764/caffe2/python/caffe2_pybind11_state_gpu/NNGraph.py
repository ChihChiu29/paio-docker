# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class NNGraph(__pybind11_builtins.pybind11_object):
    # no doc
    def createEdge(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ createEdge(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg1: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None """
        pass

    def createNode(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        createNode(*args, **kwargs)
        Overloaded function.
        
        1. createNode(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: nom::repr::GenericOperator) -> nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>
        
        2. createNode(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: nom::repr::Tensor) -> nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>
        
        3. createNode(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: object) -> nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>
        """
        pass

    def deleteEdge(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        deleteEdge(*args, **kwargs)
        Overloaded function.
        
        1. deleteEdge(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: nom::Edge<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None
        
        2. deleteEdge(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg1: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None
        """
        pass

    def deleteNode(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ deleteNode(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None """
        pass

    def getMutableNodes(self): # real signature unknown; restored from __doc__
        """ getMutableNodes(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph) -> List[nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>] """
        return []

    def replaceNode(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ replaceNode(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph, arg0: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg1: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ __repr__(self: caffe2.python.caffe2_pybind11_state_gpu.NNGraph) -> str """
        return ""

    nodes = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    operators = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tensors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




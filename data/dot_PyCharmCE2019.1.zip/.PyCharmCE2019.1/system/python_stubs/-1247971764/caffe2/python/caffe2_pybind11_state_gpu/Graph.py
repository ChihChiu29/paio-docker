# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class Graph(__pybind11_builtins.pybind11_object):
    # no doc
    def createEdge(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ createEdge(self: caffe2.python.caffe2_pybind11_state_gpu.Graph, arg0: caffe2.python.caffe2_pybind11_state_gpu.Node, arg1: caffe2.python.caffe2_pybind11_state_gpu.Node) -> caffe2.python.caffe2_pybind11_state_gpu.Edge """
        pass

    def createNode(self, arg0): # real signature unknown; restored from __doc__
        """ createNode(self: caffe2.python.caffe2_pybind11_state_gpu.Graph, arg0: object) -> caffe2.python.caffe2_pybind11_state_gpu.Node """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state_gpu.Graph) -> None """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ __repr__(self: caffe2.python.caffe2_pybind11_state_gpu.Graph) -> str """
        return ""



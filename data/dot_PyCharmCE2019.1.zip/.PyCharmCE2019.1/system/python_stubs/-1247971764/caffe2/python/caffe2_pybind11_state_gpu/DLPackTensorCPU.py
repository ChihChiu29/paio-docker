# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class DLPackTensorCPU(__pybind11_builtins.pybind11_object):
    # no doc
    def feed(self, arg0): # real signature unknown; restored from __doc__
        """
        feed(self: caffe2.python.caffe2_pybind11_state_gpu.DLPackTensorCPU, arg0: object) -> None
        
        Copy data from given DLPack tensor into this tensor.
        """
        pass

    def _reshape(self, arg0, p_int=None): # real signature unknown; restored from __doc__
        """ _reshape(self: caffe2.python.caffe2_pybind11_state_gpu.DLPackTensorCPU, arg0: List[int]) -> None """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    data = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Return DLPack tensor with tensor's data."""

    _shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




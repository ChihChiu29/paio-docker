# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class NNModule(__pybind11_builtins.pybind11_object):
    # no doc
    def convertToCaffe2Proto(self, arg0): # real signature unknown; restored from __doc__
        """ convertToCaffe2Proto(self: caffe2.python.caffe2_pybind11_state.NNModule, arg0: object) -> bytes """
        return b""

    def createUniqueDataNode(self, arg0): # real signature unknown; restored from __doc__
        """ createUniqueDataNode(self: caffe2.python.caffe2_pybind11_state.NNModule, arg0: str) -> nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >> """
        pass

    def dataFlow(self): # real signature unknown; restored from __doc__
        """ dataFlow(self: caffe2.python.caffe2_pybind11_state.NNModule) -> nom::Graph<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >> """
        pass

    def deleteSubgraph(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ deleteSubgraph(self: caffe2.python.caffe2_pybind11_state.NNModule, arg0: nom::Subgraph<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None """
        pass

    def getExecutionOrder(self): # real signature unknown; restored from __doc__
        """ getExecutionOrder(self: caffe2.python.caffe2_pybind11_state.NNModule) -> List[nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>] """
        return []

    def replaceSubgraph(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ replaceSubgraph(self: caffe2.python.caffe2_pybind11_state.NNModule, arg0: nom::Subgraph<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg1: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg2: List[nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>], arg3: List[nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>]) -> None """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state.NNModule) -> None """
        pass



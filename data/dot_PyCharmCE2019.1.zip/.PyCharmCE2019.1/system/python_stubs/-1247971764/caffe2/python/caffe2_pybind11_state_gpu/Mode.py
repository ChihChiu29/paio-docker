# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class Mode(__pybind11_builtins.pybind11_object):
    """
    Members:
    
      new
    
      write
    
      read
    """
    def __eq__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __eq__(*args, **kwargs)
        Overloaded function.
        
        1. __eq__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode, arg0: caffe2.python.caffe2_pybind11_state_gpu.Mode) -> bool
        
        2. __eq__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode, arg0: int) -> bool
        """
        pass

    def __getstate__(self): # real signature unknown; restored from __doc__
        """ __getstate__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode) -> tuple """
        return ()

    def __hash__(self): # real signature unknown; restored from __doc__
        """ __hash__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode) -> int """
        return 0

    def __init__(self, arg0): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode, arg0: int) -> None """
        pass

    def __int__(self): # real signature unknown; restored from __doc__
        """ __int__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode) -> int """
        return 0

    def __ne__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __ne__(*args, **kwargs)
        Overloaded function.
        
        1. __ne__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode, arg0: caffe2.python.caffe2_pybind11_state_gpu.Mode) -> bool
        
        2. __ne__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode, arg0: int) -> bool
        """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ __repr__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode) -> str """
        return ""

    def __setstate__(self, arg0): # real signature unknown; restored from __doc__
        """ __setstate__(self: caffe2.python.caffe2_pybind11_state_gpu.Mode, arg0: tuple) -> None """
        pass

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    new = Mode.new # (!) forward: new, real value is 'Mode.new'
    read = Mode.read # (!) forward: read, real value is 'Mode.read'
    write = Mode.write # (!) forward: write, real value is 'Mode.write'
    __members__ = {
        'new': '<failed to retrieve the value>',
        'read': '<failed to retrieve the value>',
        'write': '<failed to retrieve the value>',
    }



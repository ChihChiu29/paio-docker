# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class Caffe2Backend(__pybind11_builtins.pybind11_object):
    # no doc
    def convert_node(self, node_str, value_infos_bytes, bytes=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ convert_node(self: caffe2.python.caffe2_pybind11_state.Caffe2Backend, node_str: bytes, value_infos_bytes: List[bytes] = [], opset_version: int = 9) -> List[List[bytes]] """
        pass

    def prepare(self, arg0, arg1, arg2, caffe2_python_caffe2_pybind11_state_Caffe2Ops=None): # real signature unknown; restored from __doc__
        """ prepare(self: caffe2.python.caffe2_pybind11_state.Caffe2Backend, arg0: bytes, arg1: str, arg2: List[caffe2.python.caffe2_pybind11_state.Caffe2Ops]) -> caffe2.python.caffe2_pybind11_state.Caffe2BackenRep """
        pass

    def support_onnx_import(self, arg0): # real signature unknown; restored from __doc__
        """ support_onnx_import(self: caffe2.python.caffe2_pybind11_state.Caffe2Backend, arg0: str) -> bool """
        return False

    def _build_tensor_filling_op(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ _build_tensor_filling_op(self: caffe2.python.caffe2_pybind11_state.Caffe2Backend, arg0: bytes, arg1: str) -> bytes """
        return b""

    def __init__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: caffe2.python.caffe2_pybind11_state.Caffe2Backend) -> None
        
        2. __init__(self: caffe2.python.caffe2_pybind11_state.Caffe2Backend, arg0: caffe2.python.caffe2_pybind11_state.DummyName) -> None
        """
        pass



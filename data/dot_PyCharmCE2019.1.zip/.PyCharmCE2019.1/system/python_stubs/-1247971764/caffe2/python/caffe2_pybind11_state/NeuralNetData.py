# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class NeuralNetData(__pybind11_builtins.pybind11_object):
    # no doc
    def getName(self): # real signature unknown; restored from __doc__
        """ getName(self: caffe2.python.caffe2_pybind11_state.NeuralNetData) -> str """
        return ""

    def __init__(self, arg0): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state.NeuralNetData, arg0: str) -> None """
        pass



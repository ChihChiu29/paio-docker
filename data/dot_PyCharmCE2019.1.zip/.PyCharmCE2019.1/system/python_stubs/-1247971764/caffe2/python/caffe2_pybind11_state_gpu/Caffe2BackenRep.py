# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class Caffe2BackenRep(__pybind11_builtins.pybind11_object):
    # no doc
    def external_inputs(self): # real signature unknown; restored from __doc__
        """ external_inputs(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep) -> List[str] """
        return []

    def external_outputs(self): # real signature unknown; restored from __doc__
        """ external_outputs(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep) -> List[str] """
        return []

    def init_net(self): # real signature unknown; restored from __doc__
        """ init_net(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep) -> bytes """
        return b""

    def pred_net(self): # real signature unknown; restored from __doc__
        """ pred_net(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep) -> bytes """
        return b""

    def run(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        run(*args, **kwargs)
        Overloaded function.
        
        1. run(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep, arg0: Dict[str, object]) -> List[object]
        
        2. run(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep, arg0: List[object]) -> List[object]
        """
        pass

    def uninitialized_inputs(self): # real signature unknown; restored from __doc__
        """ uninitialized_inputs(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep) -> List[str] """
        return []

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state_gpu.Caffe2BackenRep) -> None """
        pass



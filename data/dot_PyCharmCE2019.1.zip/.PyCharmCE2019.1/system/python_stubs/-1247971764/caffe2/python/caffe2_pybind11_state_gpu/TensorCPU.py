# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class TensorCPU(__pybind11_builtins.pybind11_object):
    # no doc
    def feed(self, arg0): # real signature unknown; restored from __doc__
        """
        feed(self: caffe2.python.caffe2_pybind11_state_gpu.TensorCPU, arg0: object) -> None
        
        Copy data from given numpy array into this tensor.
        """
        pass

    def fetch(self): # real signature unknown; restored from __doc__
        """
        fetch(self: caffe2.python.caffe2_pybind11_state_gpu.TensorCPU) -> object
        
        Copy data from this tensor into a new numpy array.
        """
        return object()

    def init(self, arg0, p_int=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        init(self: caffe2.python.caffe2_pybind11_state_gpu.TensorCPU, arg0: List[int], arg1: int) -> None
        
        Initialize this tensor to given shape and data type. Fail if the given data type cannot be accessed from python.
        """
        pass

    def _reshape(self, arg0, p_int=None): # real signature unknown; restored from __doc__
        """ _reshape(self: caffe2.python.caffe2_pybind11_state_gpu.TensorCPU, arg0: List[int]) -> None """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    data = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Return numpy array pointing to this tensor's data if possible. Otherwise (e.g. for strings) copies the data (same as fetch)."""

    _shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class Annotation(__pybind11_builtins.pybind11_object):
    # no doc
    def getComponentLevels(self): # real signature unknown; restored from __doc__
        """ getComponentLevels(self: caffe2.python.caffe2_pybind11_state.Annotation) -> List[str] """
        return []

    def getDevice(self): # real signature unknown; restored from __doc__
        """ getDevice(self: caffe2.python.caffe2_pybind11_state.Annotation) -> str """
        return ""

    def getDeviceType(self): # real signature unknown; restored from __doc__
        """ getDeviceType(self: caffe2.python.caffe2_pybind11_state.Annotation) -> int """
        return 0

    def getKeyNode(self): # real signature unknown; restored from __doc__
        """ getKeyNode(self: caffe2.python.caffe2_pybind11_state.Annotation) -> caffe2.python.caffe2_pybind11_state.NodeRef """
        pass

    def getLengthNode(self): # real signature unknown; restored from __doc__
        """ getLengthNode(self: caffe2.python.caffe2_pybind11_state.Annotation) -> caffe2.python.caffe2_pybind11_state.NodeRef """
        pass

    def hasDeviceOption(self): # real signature unknown; restored from __doc__
        """ hasDeviceOption(self: caffe2.python.caffe2_pybind11_state.Annotation) -> bool """
        return False

    def setComponentLevels(self, arg0, p_str=None): # real signature unknown; restored from __doc__
        """ setComponentLevels(self: caffe2.python.caffe2_pybind11_state.Annotation, arg0: List[str]) -> None """
        pass

    def setDevice(self, arg0): # real signature unknown; restored from __doc__
        """ setDevice(self: caffe2.python.caffe2_pybind11_state.Annotation, arg0: str) -> None """
        pass

    def setDeviceType(self, arg0): # real signature unknown; restored from __doc__
        """ setDeviceType(self: caffe2.python.caffe2_pybind11_state.Annotation, arg0: int) -> None """
        pass

    def setKeyNode(self, arg0): # real signature unknown; restored from __doc__
        """ setKeyNode(self: caffe2.python.caffe2_pybind11_state.Annotation, arg0: caffe2.python.caffe2_pybind11_state.NodeRef) -> None """
        pass

    def setLengthNode(self, arg0): # real signature unknown; restored from __doc__
        """ setLengthNode(self: caffe2.python.caffe2_pybind11_state.Annotation, arg0: caffe2.python.caffe2_pybind11_state.NodeRef) -> None """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state.Annotation) -> None """
        pass

    device_option = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    operator_def = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




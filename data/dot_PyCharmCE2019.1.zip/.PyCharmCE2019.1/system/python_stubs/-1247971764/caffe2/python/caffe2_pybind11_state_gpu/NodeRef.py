# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state_gpu
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state_gpu.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces - GPU edition """

# imports
import pybind11_builtins as __pybind11_builtins


class NodeRef(__pybind11_builtins.pybind11_object):
    # no doc
    def getAnnotation(self): # real signature unknown; restored from __doc__
        """ getAnnotation(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> caffe2::Caffe2Annotation """
        pass

    def getConsumers(self): # real signature unknown; restored from __doc__
        """ getConsumers(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> List[caffe2.python.caffe2_pybind11_state_gpu.NodeRef] """
        return []

    def getInputs(self): # real signature unknown; restored from __doc__
        """ getInputs(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> List[caffe2.python.caffe2_pybind11_state_gpu.NodeRef] """
        return []

    def getName(self): # real signature unknown; restored from __doc__
        """ getName(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> str """
        return ""

    def getOperator(self): # real signature unknown; restored from __doc__
        """ getOperator(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> nom::repr::NeuralNetOperator """
        pass

    def getOperatorPredecessors(self): # real signature unknown; restored from __doc__
        """ getOperatorPredecessors(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> List[caffe2.python.caffe2_pybind11_state_gpu.NodeRef] """
        return []

    def getOperatorSuccessors(self): # real signature unknown; restored from __doc__
        """ getOperatorSuccessors(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> List[caffe2.python.caffe2_pybind11_state_gpu.NodeRef] """
        return []

    def getOutputs(self): # real signature unknown; restored from __doc__
        """ getOutputs(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> List[caffe2.python.caffe2_pybind11_state_gpu.NodeRef] """
        return []

    def getProducer(self): # real signature unknown; restored from __doc__
        """ getProducer(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> caffe2.python.caffe2_pybind11_state_gpu.NodeRef """
        pass

    def getTensor(self): # real signature unknown; restored from __doc__
        """ getTensor(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> nom::repr::Tensor """
        pass

    def getType(self): # real signature unknown; restored from __doc__
        """ getType(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> str """
        return ""

    def hasProducer(self): # real signature unknown; restored from __doc__
        """ hasProducer(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> bool """
        return False

    def isOperator(self): # real signature unknown; restored from __doc__
        """ isOperator(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> bool """
        return False

    def isTensor(self): # real signature unknown; restored from __doc__
        """ isTensor(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef) -> bool """
        return False

    def setAnnotation(self, arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """ setAnnotation(self: caffe2.python.caffe2_pybind11_state_gpu.NodeRef, arg0: caffe2::Caffe2Annotation) -> None """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    annotation = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    consumers = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    inputs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    operator = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    outputs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    producer = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tensor = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    type = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




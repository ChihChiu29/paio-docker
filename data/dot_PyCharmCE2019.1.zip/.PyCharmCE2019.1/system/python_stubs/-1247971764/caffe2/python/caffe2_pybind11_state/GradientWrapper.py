# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class GradientWrapper(__pybind11_builtins.pybind11_object):
    # no doc
    def is_dense(self): # real signature unknown; restored from __doc__
        """ is_dense(self: caffe2.python.caffe2_pybind11_state.GradientWrapper) -> bool """
        return False

    def is_empty(self): # real signature unknown; restored from __doc__
        """ is_empty(self: caffe2.python.caffe2_pybind11_state.GradientWrapper) -> bool """
        return False

    def is_sparse(self): # real signature unknown; restored from __doc__
        """ is_sparse(self: caffe2.python.caffe2_pybind11_state.GradientWrapper) -> bool """
        return False

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state.GradientWrapper) -> None """
        pass

    dense = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    indices = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    values = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




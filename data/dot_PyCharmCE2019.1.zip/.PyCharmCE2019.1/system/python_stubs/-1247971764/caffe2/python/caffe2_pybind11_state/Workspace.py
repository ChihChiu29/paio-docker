# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class Workspace(__pybind11_builtins.pybind11_object):
    # no doc
    def create_blob(self, arg0): # real signature unknown; restored from __doc__
        """ create_blob(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: str) -> object """
        return object()

    def fetch_blob(self, arg0): # real signature unknown; restored from __doc__
        """ fetch_blob(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: str) -> object """
        return object()

    def has_blob(self, arg0): # real signature unknown; restored from __doc__
        """ has_blob(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: str) -> bool """
        return False

    def _create_net(self, p_def, overwrite=False): # real signature unknown; restored from __doc__
        """ _create_net(self: caffe2.python.caffe2_pybind11_state.Workspace, def: bytes, overwrite: bool = False) -> object """
        return object()

    def _last_failed_op_net_position(self): # real signature unknown; restored from __doc__
        """ _last_failed_op_net_position(self: caffe2.python.caffe2_pybind11_state.Workspace) -> int """
        return 0

    def _remove_blob(self, arg0): # real signature unknown; restored from __doc__
        """ _remove_blob(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: str) -> bool_ """
        pass

    def _run_net(self, arg0): # real signature unknown; restored from __doc__
        """ _run_net(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: bytes) -> None """
        pass

    def _run_operator(self, arg0): # real signature unknown; restored from __doc__
        """ _run_operator(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: bytes) -> None """
        pass

    def _run_plan(self, arg0): # real signature unknown; restored from __doc__
        """ _run_plan(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: bytes) -> None """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: caffe2.python.caffe2_pybind11_state.Workspace) -> None
        
        2. __init__(self: caffe2.python.caffe2_pybind11_state.Workspace, arg0: caffe2.python.caffe2_pybind11_state.Workspace) -> None
        """
        pass

    blobs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nets = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    current = None # (!) real value is '<caffe2.python.caffe2_pybind11_state.Workspace object at 0x7f6b6aaf4500>'



# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


# Variables with simple values

define_caffe2_no_operator_schema = False

has_mkldnn = False

is_asan = False

use_mkldnn = True
use_trt = False

# functions

def add_observer_to_net(arg0, arg1): # real signature unknown; restored from __doc__
    """ add_observer_to_net(arg0: str, arg1: str) -> object """
    return object()

def apply_transform(arg0, arg1): # real signature unknown; restored from __doc__
    """ apply_transform(arg0: str, arg1: bytes) -> bytes """
    return b""

def apply_transform_if_faster(arg0, arg1, arg2, arg3, arg4, arg5): # real signature unknown; restored from __doc__
    """ apply_transform_if_faster(arg0: str, arg1: bytes, arg2: bytes, arg3: int, arg4: int, arg5: float) -> bytes """
    return b""

def benchmark_net(arg0, arg1, arg2, arg3): # real signature unknown; restored from __doc__
    """ benchmark_net(arg0: str, arg1: int, arg2: int, arg3: bool) -> List[float] """
    return []

def blobs(): # real signature unknown; restored from __doc__
    """ blobs() -> List[str] """
    return []

def builtin_cpu_supports_avx2(): # real signature unknown; restored from __doc__
    """ builtin_cpu_supports_avx2() -> bool """
    return False

def create_blob(arg0): # real signature unknown; restored from __doc__
    """ create_blob(arg0: str) -> bool """
    return False

def create_db(arg0, arg1, arg2): # real signature unknown; restored from __doc__
    """ create_db(arg0: str, arg1: str, arg2: caffe2.python.caffe2_pybind11_state.Mode) -> caffe2.python.caffe2_pybind11_state.DB """
    pass

def create_net(net_def, overwrite=False): # real signature unknown; restored from __doc__
    """ create_net(net_def: bytes, overwrite: bool = False) -> bool """
    return False

def current_workspace(): # real signature unknown; restored from __doc__
    """ current_workspace() -> str """
    return ""

def delete_net(arg0): # real signature unknown; restored from __doc__
    """ delete_net(arg0: str) -> bool """
    return False

def deserialize_blob(arg0, arg1): # real signature unknown; restored from __doc__
    """ deserialize_blob(arg0: str, arg1: bytes) -> None """
    pass

def export_to_onnx(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ export_to_onnx(arg0: caffe2::onnx::DummyName, arg1: bytes, arg2: Dict[str, List[int]]) -> Tuple[List[bytes], List[bytes]] """
    pass

def feed_blob(name, arg, device_option=None): # real signature unknown; restored from __doc__
    """ feed_blob(name: str, arg: object, device_option: object = None) -> bool """
    return False

def fetch_blob(arg0): # real signature unknown; restored from __doc__
    """ fetch_blob(arg0: str) -> object """
    return object()

def get_blob_numa_node(arg0): # real signature unknown; restored from __doc__
    """ get_blob_numa_node(arg0: str) -> int """
    return 0

def get_blob_size_bytes(arg0): # real signature unknown; restored from __doc__
    """ get_blob_size_bytes(arg0: str) -> int """
    return 0

def get_build_options(): # real signature unknown; restored from __doc__
    """ get_build_options() -> Dict[str, str] """
    return {}

def get_gradient_defs(arg0, arg1, caffe2_python_caffe2_pybind11_state_GradientWrapper=None): # real signature unknown; restored from __doc__
    """ get_gradient_defs(arg0: bytes, arg1: List[caffe2.python.caffe2_pybind11_state.GradientWrapper]) -> Tuple[List[bytes], List[caffe2.python.caffe2_pybind11_state.GradientWrapper]] """
    pass

def get_num_numa_nodes(): # real signature unknown; restored from __doc__
    """ get_num_numa_nodes() -> int """
    return 0

def get_operator_cost(arg0, arg1, p_str=None): # real signature unknown; restored from __doc__
    """ get_operator_cost(arg0: bytes, arg1: List[str]) -> Tuple[int, int] """
    pass

def get_stats(): # real signature unknown; restored from __doc__
    """ get_stats() -> Dict[str, int] """
    return {}

def global_init(arg0, p_str=None): # real signature unknown; restored from __doc__
    """ global_init(arg0: List[str]) -> None """
    pass

def has_blob(arg0): # real signature unknown; restored from __doc__
    """ has_blob(arg0: str) -> bool """
    return False

def infer_op_input_output_device(arg0): # real signature unknown; restored from __doc__
    """ infer_op_input_output_device(arg0: bytes) -> Tuple[List[bytes], List[bytes]] """
    pass

def infer_shapes_and_types_from_map(*args, **kwargs): # real signature unknown; restored from __doc__
    """
    infer_shapes_and_types_from_map(*args, **kwargs)
    Overloaded function.
    
    1. infer_shapes_and_types_from_map(arg0: List[bytes], arg1: Dict[str, List[int]]) -> bytes
    
    2. infer_shapes_and_types_from_map(arg0: List[bytes], arg1: Dict[str, List[int]], arg2: Dict[str, int]) -> bytes
    """
    pass

def infer_shapes_and_types_from_workspace(arg0, bytes=None): # real signature unknown; restored from __doc__
    """ infer_shapes_and_types_from_workspace(arg0: List[bytes]) -> bytes """
    return b""

def is_numa_enabled(): # real signature unknown; restored from __doc__
    """ is_numa_enabled() -> bool """
    return False

def local_blobs(): # real signature unknown; restored from __doc__
    """ local_blobs() -> List[str] """
    return []

def matchSubgraph(arg0, arg1): # real signature unknown; restored from __doc__
    """ matchSubgraph(arg0: caffe2.python.caffe2_pybind11_state.NodeRef, arg1: caffe2.python.caffe2_pybind11_state.NNMatchGraph) -> caffe2.python.caffe2_pybind11_state.NNSubgraph """
    pass

def memonger_compute_blob_recycling_for_dag(arg0, arg1, p_str=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ memonger_compute_blob_recycling_for_dag(arg0: bytes, arg1: List[str], arg2: List[int], arg3: Set[str], arg4: str, arg5: Set[str], arg6: Dict[str, List[int]]) -> bytes """
    pass

def memonger_optimize_inference_net(arg0, arg1, p_str=None): # real signature unknown; restored from __doc__
    """ memonger_optimize_inference_net(arg0: bytes, arg1: List[str]) -> bytes """
    return b""

def nearby_opnames(arg0): # real signature unknown; restored from __doc__
    """ nearby_opnames(arg0: str) -> List[str] """
    return []

def nets(): # real signature unknown; restored from __doc__
    """ nets() -> List[str] """
    return []

def NNModuleFromProtobuf(arg0): # real signature unknown; restored from __doc__
    """ NNModuleFromProtobuf(arg0: bytes) -> Tuple[nom::repr::NNModule, List[nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>]] """
    pass

def NNModuleFromProtobufDistributed(arg0, arg1, p_str=None, bytes=None): # real signature unknown; restored from __doc__
    """ NNModuleFromProtobufDistributed(arg0: bytes, arg1: Dict[str, bytes]) -> nom::repr::NNModule """
    pass

def num_observers_on_net(arg0): # real signature unknown; restored from __doc__
    """ num_observers_on_net(arg0: str) -> int """
    return 0

def onnxifi(arg0, arg1, p_str=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ onnxifi(arg0: bytes, arg1: List[str], arg2: Dict[str, List[int]], arg3: bool, arg4: bool) -> bytes """
    pass

def on_module_exit(): # real signature unknown; restored from __doc__
    """ on_module_exit() -> None """
    pass

def op_registry_key(arg0, arg1): # real signature unknown; restored from __doc__
    """ op_registry_key(arg0: str, arg1: str) -> str """
    return ""

def registered_dbs(): # real signature unknown; restored from __doc__
    """ registered_dbs() -> List[str] """
    return []

def registered_operators(): # real signature unknown; restored from __doc__
    """ registered_operators() -> List[str] """
    return []

def register_python_gradient_op(arg0, arg1): # real signature unknown; restored from __doc__
    """ register_python_gradient_op(arg0: str, arg1: object) -> None """
    pass

def register_python_op(arg0, arg1, arg2): # real signature unknown; restored from __doc__
    """ register_python_op(arg0: object, arg1: bool, arg2: str) -> str """
    return ""

def remove_observer_from_net(arg0, arg1, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ remove_observer_from_net(arg0: str, arg1: caffe2::ObserverBase<caffe2::NetBase>) -> None """
    pass

def replaceAllUsesWith(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ replaceAllUsesWith(arg0: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg1: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None """
    pass

def replaceAsConsumer(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ replaceAsConsumer(arg0: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg1: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None """
    pass

def replaceProducer(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ replaceProducer(arg0: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>, arg1: nom::Node<std::unique_ptr<nom::repr::Value, std::default_delete<nom::repr::Value> >>) -> None """
    pass

def reset_workspace(root_folder=None): # real signature unknown; restored from __doc__
    """
    reset_workspace(root_folder: object = None) -> bool
    
    Reset the workspace
    """
    return False

def root_folder(): # real signature unknown; restored from __doc__
    """ root_folder() -> str """
    return ""

def run_net(arg0, arg1, arg2): # real signature unknown; restored from __doc__
    """ run_net(arg0: str, arg1: int, arg2: bool) -> bool """
    return False

def run_net_once(arg0): # real signature unknown; restored from __doc__
    """ run_net_once(arg0: bytes) -> bool """
    return False

def run_operator_once(arg0): # real signature unknown; restored from __doc__
    """ run_operator_once(arg0: bytes) -> bool """
    return False

def run_plan(arg0): # real signature unknown; restored from __doc__
    """ run_plan(arg0: bytes) -> bool """
    return False

def run_plan_in_background(arg0): # real signature unknown; restored from __doc__
    """ run_plan_in_background(arg0: bytes) -> caffe2::python::BackgroundPlan """
    pass

def run_transform(arg0, arg1): # real signature unknown; restored from __doc__
    """ run_transform(arg0: str, arg1: bytes) -> bytes """
    return b""

def run_workspace_transform(arg0, arg1): # real signature unknown; restored from __doc__
    """ run_workspace_transform(arg0: str, arg1: bytes) -> bytes """
    return b""

def serialize_blob(arg0): # real signature unknown; restored from __doc__
    """ serialize_blob(arg0: str) -> bytes """
    return b""

def set_engine_pref(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ set_engine_pref(arg0: Dict[c10::DeviceType, Dict[str, List[str]]], arg1: Dict[c10::DeviceType, List[str]]) -> None """
    pass

def set_global_engine_pref(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ set_global_engine_pref(arg0: Dict[c10::DeviceType, List[str]]) -> None """
    pass

def set_op_engine_pref(arg0, arg1, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ set_op_engine_pref(arg0: str, arg1: Dict[c10::DeviceType, List[str]]) -> None """
    pass

def set_per_op_engine_pref(arg0, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ set_per_op_engine_pref(arg0: Dict[c10::DeviceType, Dict[str, List[str]]]) -> None """
    pass

def support_onnx_export(arg0): # real signature unknown; restored from __doc__
    """ support_onnx_export(arg0: str) -> bool """
    return False

def switch_workspace(*args, **kwargs): # real signature unknown; restored from __doc__
    """
    switch_workspace(*args, **kwargs)
    Overloaded function.
    
    1. switch_workspace(arg0: caffe2::Workspace, arg1: object) -> None
    
    2. switch_workspace(name: str, create_if_missing: object = None) -> None
    
    Switch to the specified workspace, creating if necessary
    """
    pass

def transform_addNNPACK(arg0): # real signature unknown; restored from __doc__
    """ transform_addNNPACK(arg0: bytes) -> bytes """
    return b""

def transform_exists(arg0): # real signature unknown; restored from __doc__
    """ transform_exists(arg0: str) -> bool """
    return False

def transform_fuseConvBN(arg0): # real signature unknown; restored from __doc__
    """ transform_fuseConvBN(arg0: bytes) -> bytes """
    return b""

def transform_fuseNNPACKConvRelu(arg0): # real signature unknown; restored from __doc__
    """ transform_fuseNNPACKConvRelu(arg0: bytes) -> bytes """
    return b""

def transform_optimizeForIDEEP(arg0, arg1): # real signature unknown; restored from __doc__
    """ transform_optimizeForIDEEP(arg0: bytes, arg1: bool) -> bytes """
    return b""

def transform_sinkMaxPool(arg0): # real signature unknown; restored from __doc__
    """ transform_sinkMaxPool(arg0: bytes) -> bytes """
    return b""

def workspaces(): # real signature unknown; restored from __doc__
    """ workspaces() -> List[str] """
    return []

def workspace_transform_exists(arg0): # real signature unknown; restored from __doc__
    """ workspace_transform_exists(arg0: str) -> bool """
    return False

# classes

from .Annotation import Annotation
from .BackgroundPlan import BackgroundPlan
from .Blob import Blob
from .Caffe2Backend import Caffe2Backend
from .Caffe2BackenRep import Caffe2BackenRep
from .Caffe2Ops import Caffe2Ops
from .CompilationUnit import CompilationUnit
from .Cursor import Cursor
from .DB import DB
from .DLPackTensorCPU import DLPackTensorCPU
from .DummyName import DummyName
from .Edge import Edge
from .GradientWrapper import GradientWrapper
from .Graph import Graph
from .MatchPredicateRef import MatchPredicateRef
from .Mode import Mode
from .Net import Net
from .NeuralNetData import NeuralNetData
from .NeuralNetOperator import NeuralNetOperator
from .NNGraph import NNGraph
from .NNMatchGraph import NNMatchGraph
from .NNModule import NNModule
from .NNSubgraph import NNSubgraph
from .Node import Node
from .NodeRef import NodeRef
from .Observer import Observer
from .OpSchema import OpSchema
from .Predictor import Predictor
from .TensorCPU import TensorCPU
from .Transaction import Transaction
from .Workspace import Workspace
# variables with complex values

new = None # (!) real value is 'Mode.new'

read = None # (!) real value is 'Mode.read'

write = None # (!) real value is 'Mode.write'

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6b6abe0e10>'

__spec__ = None # (!) real value is "ModuleSpec(name='caffe2.python.caffe2_pybind11_state', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6b6abe0e10>, origin='/usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so')"


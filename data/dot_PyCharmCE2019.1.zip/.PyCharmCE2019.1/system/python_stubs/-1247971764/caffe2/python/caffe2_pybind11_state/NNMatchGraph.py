# encoding: utf-8
# module caffe2.python.caffe2_pybind11_state
# from /usr/local/lib/python3.5/dist-packages/caffe2/python/caffe2_pybind11_state.cpython-35m-x86_64-linux-gnu.so
# by generator 1.147
""" pybind11 stateful interface to Caffe2 workspaces """

# imports
import pybind11_builtins as __pybind11_builtins


class NNMatchGraph(__pybind11_builtins.pybind11_object):
    # no doc
    def createEdge(self, arg0, arg1): # real signature unknown; restored from __doc__
        """ createEdge(self: caffe2.python.caffe2_pybind11_state.NNMatchGraph, arg0: caffe2.python.caffe2_pybind11_state.MatchPredicateRef, arg1: caffe2.python.caffe2_pybind11_state.MatchPredicateRef) -> None """
        pass

    def createNode(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        createNode(*args, **kwargs)
        Overloaded function.
        
        1. createNode(self: caffe2.python.caffe2_pybind11_state.NNMatchGraph, node: caffe2.python.caffe2_pybind11_state.NeuralNetOperator, strict: bool = False) -> caffe2.python.caffe2_pybind11_state.MatchPredicateRef
        
        2. createNode(self: caffe2.python.caffe2_pybind11_state.NNMatchGraph, tensor: caffe2.python.caffe2_pybind11_state.NeuralNetData, strict: bool = False) -> caffe2.python.caffe2_pybind11_state.MatchPredicateRef
        
        3. createNode(self: caffe2.python.caffe2_pybind11_state.NNMatchGraph, strict: bool = False) -> caffe2.python.caffe2_pybind11_state.MatchPredicateRef
        """
        pass

    def getMutableNodes(self): # real signature unknown; restored from __doc__
        """ getMutableNodes(self: caffe2.python.caffe2_pybind11_state.NNMatchGraph) -> List[caffe2.python.caffe2_pybind11_state.MatchPredicateRef] """
        return []

    def __init__(self): # real signature unknown; restored from __doc__
        """ __init__(self: caffe2.python.caffe2_pybind11_state.NNMatchGraph) -> None """
        pass



# encoding: utf-8
# module h5py.utils
# from /usr/local/lib/python3.6/dist-packages/h5py/utils.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def check_numpy_read(*args, **kwargs): # real signature unknown
    pass

def check_numpy_write(*args, **kwargs): # real signature unknown
    pass

def _test_emalloc(*args, **kwargs): # real signature unknown
    """ Stub to simplify unit tests """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7feb269b8828>'

__pyx_capi__ = {
    'check_numpy_read': None, # (!) real value is '<capsule object "int (PyArrayObject *, int __pyx_skip_dispatch, struct __pyx_opt_args_4h5py_5utils_check_numpy_read *__pyx_optional_args)" at 0x7feb19640090>'
    'check_numpy_write': None, # (!) real value is '<capsule object "int (PyArrayObject *, int __pyx_skip_dispatch, struct __pyx_opt_args_4h5py_5utils_check_numpy_write *__pyx_optional_args)" at 0x7feb196400c0>'
    'convert_dims': None, # (!) real value is '<capsule object "PyObject *(hsize_t *, hsize_t)" at 0x7feb19640120>'
    'convert_tuple': None, # (!) real value is '<capsule object "int (PyObject *, hsize_t *, hsize_t)" at 0x7feb196400f0>'
    'create_hsize_array': None, # (!) real value is '<capsule object "PyObject *(PyObject *)" at 0x7feb196401b0>'
    'create_numpy_hsize': None, # (!) real value is '<capsule object "PyObject *(int, hsize_t *)" at 0x7feb19640180>'
    'efree': None, # (!) real value is '<capsule object "void (void *)" at 0x7feb19640060>'
    'emalloc': None, # (!) real value is '<capsule object "void *(size_t)" at 0x7feb268ec390>'
    'require_tuple': None, # (!) real value is '<capsule object "int (PyObject *, int, int, char *)" at 0x7feb19640150>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='h5py.utils', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7feb269b8828>, origin='/usr/local/lib/python3.6/dist-packages/h5py/utils.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


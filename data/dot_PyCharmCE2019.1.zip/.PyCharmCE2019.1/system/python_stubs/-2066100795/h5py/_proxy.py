# encoding: utf-8
# module h5py._proxy
# from /usr/local/lib/python3.6/dist-packages/h5py/_proxy.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
""" Proxy functions for read/write, to work around the HDF5 bogus type issue. """

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbccc8979e8>'

__pyx_capi__ = {
    'attr_rw': None, # (!) real value is '<capsule object "herr_t (hid_t, hid_t, void *, int)" at 0x7fbccbd7b060>'
    'dset_rw': None, # (!) real value is '<capsule object "herr_t (hid_t, hid_t, hid_t, hid_t, hid_t, void *, int)" at 0x7fbccbd7b090>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='h5py._proxy', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbccc8979e8>, origin='/usr/local/lib/python3.6/dist-packages/h5py/_proxy.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


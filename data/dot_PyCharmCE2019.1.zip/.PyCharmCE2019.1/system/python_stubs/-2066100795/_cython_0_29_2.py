# encoding: utf-8
# module _cython_0_29_2
# from /usr/local/lib/python3.6/dist-packages/statsmodels/tsa/statespace/_tools.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# classes

class cython_function_or_method(object):
    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __get__(self, *args, **kwargs): # real signature unknown
        """ Return an attribute of instance, which is of type owner. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    func_closure = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_code = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_defaults = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_dict = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_globals = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __annotations__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __closure__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __code__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __defaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __globals__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __kwdefaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __self__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __dict__ = None # (!) real value is "mappingproxy({'__repr__': <slot wrapper '__repr__' of 'cython_function_or_method' objects>, '__call__': <slot wrapper '__call__' of 'cython_function_or_method' objects>, '__get__': <slot wrapper '__get__' of 'cython_function_or_method' objects>, '__reduce__': <method '__reduce__' of 'cython_function_or_method' objects>, '__module__': <member '__module__' of 'cython_function_or_method' objects>, 'func_doc': <attribute 'func_doc' of 'cython_function_or_method' objects>, '__doc__': <attribute '__doc__' of 'cython_function_or_method' objects>, 'func_name': <attribute 'func_name' of 'cython_function_or_method' objects>, '__name__': <attribute '__name__' of 'cython_function_or_method' objects>, '__qualname__': <attribute '__qualname__' of 'cython_function_or_method' objects>, '__self__': <attribute '__self__' of 'cython_function_or_method' objects>, 'func_dict': <attribute 'func_dict' of 'cython_function_or_method' objects>, '__dict__': <attribute '__dict__' of 'cython_function_or_method' objects>, 'func_globals': <attribute 'func_globals' of 'cython_function_or_method' objects>, '__globals__': <attribute '__globals__' of 'cython_function_or_method' objects>, 'func_closure': <attribute 'func_closure' of 'cython_function_or_method' objects>, '__closure__': <attribute '__closure__' of 'cython_function_or_method' objects>, 'func_code': <attribute 'func_code' of 'cython_function_or_method' objects>, '__code__': <attribute '__code__' of 'cython_function_or_method' objects>, 'func_defaults': <attribute 'func_defaults' of 'cython_function_or_method' objects>, '__defaults__': <attribute '__defaults__' of 'cython_function_or_method' objects>, '__kwdefaults__': <attribute '__kwdefaults__' of 'cython_function_or_method' objects>, '__annotations__': <attribute '__annotations__' of 'cython_function_or_method' objects>})"
    __name__ = 'cython_function_or_method'
    __qualname__ = 'cython_function_or_method'


class fused_cython_function(cython_function_or_method):
    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __get__(self, *args, **kwargs): # real signature unknown
        """ Return an attribute of instance, which is of type owner. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    func_closure = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_code = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_defaults = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_dict = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_globals = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __annotations__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __closure__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __code__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __defaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __globals__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __kwdefaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __self__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __signatures__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __dict__ = None # (!) real value is "mappingproxy({'__call__': <slot wrapper '__call__' of 'fused_cython_function' objects>, '__get__': <slot wrapper '__get__' of 'fused_cython_function' objects>, '__getitem__': <slot wrapper '__getitem__' of 'fused_cython_function' objects>, '__signatures__': <member '__signatures__' of 'fused_cython_function' objects>, 'func_doc': <attribute 'func_doc' of 'fused_cython_function' objects>, '__doc__': <attribute '__doc__' of 'fused_cython_function' objects>, 'func_name': <attribute 'func_name' of 'fused_cython_function' objects>, '__name__': <attribute '__name__' of 'fused_cython_function' objects>, '__qualname__': <attribute '__qualname__' of 'fused_cython_function' objects>, '__self__': <attribute '__self__' of 'fused_cython_function' objects>, 'func_dict': <attribute 'func_dict' of 'fused_cython_function' objects>, '__dict__': <attribute '__dict__' of 'fused_cython_function' objects>, 'func_globals': <attribute 'func_globals' of 'fused_cython_function' objects>, '__globals__': <attribute '__globals__' of 'fused_cython_function' objects>, 'func_closure': <attribute 'func_closure' of 'fused_cython_function' objects>, '__closure__': <attribute '__closure__' of 'fused_cython_function' objects>, 'func_code': <attribute 'func_code' of 'fused_cython_function' objects>, '__code__': <attribute '__code__' of 'fused_cython_function' objects>, 'func_defaults': <attribute 'func_defaults' of 'fused_cython_function' objects>, '__defaults__': <attribute '__defaults__' of 'fused_cython_function' objects>, '__kwdefaults__': <attribute '__kwdefaults__' of 'fused_cython_function' objects>, '__annotations__': <attribute '__annotations__' of 'fused_cython_function' objects>})"
    __name__ = 'fused_cython_function'
    __qualname__ = 'fused_cython_function'



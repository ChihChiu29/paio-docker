# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.6/dist-packages/torch/_C.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C.cpp as cpp # <module 'torch._C.cpp'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import pybind11_builtins as __pybind11_builtins


from .object import object

class _THCUNN(object):
    # no doc
    def CudaAbsCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaAbsCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaAbs_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaAbs_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaBCECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaBCECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaCol2Im_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaCol2Im_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDistKLDivCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDistKLDivCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleAbsCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleAbsCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleAbs_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleAbs_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleBCECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleBCECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleCol2Im_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleCol2Im_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleDistKLDivCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleDistKLDivCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleELU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleELU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleFeatureLPPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleFeatureLPPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleGatedLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleGatedLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleHardTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleHardTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleIm2Col_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleIm2Col_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleIndexLinear_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleIndexLinear_accUpdateGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleIndexLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleIndexLinear_updateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleL1Cost_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleL1Cost_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLeakyReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLeakyReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLogSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLogSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLookupTableBag_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLookupTableBag_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLookupTable_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleLookupTable_renorm(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMSECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMSECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMultiLabelMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMultiLabelMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMultiMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleMultiMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleRReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleRReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSmoothL1Criterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSmoothL1Criterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSoftMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSoftMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSoftPlus_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSoftPlus_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSoftShrink_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSoftShrink_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialConvolutionLocal_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialConvolutionLocal_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialConvolutionLocal_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialConvolutionMM_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialConvolutionMM_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialConvolutionMM_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialCrossMapLRN_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialCrossMapLRN_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDepthwiseConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDepthwiseConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDepthwiseConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialFullConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialFullConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialFullConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialSubSampling_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialSubSampling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialSubSampling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialUpSamplingBicubic_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialUpSamplingBicubic_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialUpSamplingBilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialUpSamplingBilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSpatialUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSqrt_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSqrt_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSquare_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleSquare_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalRowConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalRowConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalRowConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalUpSamplingLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalUpSamplingLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleTemporalUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricAdaptiveAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricAdaptiveAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricFullConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricFullConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricFullConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricUpSamplingTrilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaDoubleVolumetricUpSamplingTrilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaELU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaELU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaFeatureLPPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaFeatureLPPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaGatedLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaGatedLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfAbsCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfAbsCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfAbs_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfAbs_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfBCECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfBCECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfCol2Im_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfCol2Im_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfDistKLDivCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfDistKLDivCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfELU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfELU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfFeatureLPPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfFeatureLPPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfGatedLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfGatedLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfHardTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfHardTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfIm2Col_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfIm2Col_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfIndexLinear_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfIndexLinear_accUpdateGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfIndexLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfIndexLinear_updateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfL1Cost_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfL1Cost_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLeakyReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLeakyReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLogSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLogSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLookupTableBag_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLookupTableBag_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLookupTable_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfLookupTable_renorm(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMSECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMSECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMultiLabelMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMultiLabelMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMultiMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfMultiMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfRReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfRReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSmoothL1Criterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSmoothL1Criterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSoftMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSoftMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSoftPlus_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSoftPlus_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSoftShrink_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSoftShrink_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialConvolutionLocal_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialConvolutionLocal_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialConvolutionLocal_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialConvolutionMM_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialConvolutionMM_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialConvolutionMM_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialCrossMapLRN_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialCrossMapLRN_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDepthwiseConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDepthwiseConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDepthwiseConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialFullConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialFullConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialFullConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialSubSampling_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialSubSampling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialSubSampling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialUpSamplingBicubic_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialUpSamplingBicubic_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialUpSamplingBilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialUpSamplingBilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSpatialUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSqrt_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSqrt_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSquare_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfSquare_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalRowConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalRowConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalRowConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalUpSamplingLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalUpSamplingLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfTemporalUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricAdaptiveAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricAdaptiveAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricFullConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricFullConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricFullConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricUpSamplingTrilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHalfVolumetricUpSamplingTrilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHardTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaHardTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaIm2Col_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaIm2Col_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaIndexLinear_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaIndexLinear_accUpdateGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaIndexLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaIndexLinear_updateParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaL1Cost_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaL1Cost_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLeakyReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLeakyReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLogSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLogSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLookupTableBag_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLookupTableBag_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLookupTable_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaLookupTable_renorm(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMSECriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMSECriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMultiLabelMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMultiLabelMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMultiMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaMultiMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaRReLU_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaRReLU_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSigmoid_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSigmoid_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSmoothL1Criterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSmoothL1Criterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSoftMarginCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSoftMarginCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSoftPlus_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSoftPlus_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSoftShrink_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSoftShrink_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialClassNLLCriterion_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialClassNLLCriterion_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialConvolutionLocal_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialConvolutionLocal_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialConvolutionLocal_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialConvolutionMM_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialConvolutionMM_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialConvolutionMM_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialCrossMapLRN_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialCrossMapLRN_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDepthwiseConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDepthwiseConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDepthwiseConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialFullConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialFullConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialFullConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialSubSampling_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialSubSampling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialSubSampling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialUpSamplingBicubic_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialUpSamplingBicubic_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialUpSamplingBilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialUpSamplingBilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSpatialUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSqrt_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSqrt_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSquare_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaSquare_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTanh_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTanh_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalRowConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalRowConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalRowConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalUpSamplingLinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalUpSamplingLinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaTemporalUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricAdaptiveAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricAdaptiveAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricAveragePooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricAveragePooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricDilatedMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricDilatedMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricFullConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricFullConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricFullConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricFullDilatedConvolution_accGradParameters(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricFullDilatedConvolution_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricFullDilatedConvolution_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricMaxPooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricMaxPooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricMaxUnpooling_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricMaxUnpooling_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricUpSamplingNearest_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricUpSamplingNearest_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricUpSamplingTrilinear_updateGradInput(self, *args, **kwargs): # real signature unknown
        pass

    def CudaVolumetricUpSamplingTrilinear_updateOutput(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass



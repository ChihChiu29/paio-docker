# encoding: utf-8
# module torch._C
# from /usr/local/lib/python3.6/dist-packages/torch/_C.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import torch._C._onnx as _onnx # <module 'torch._C._onnx'>
import torch._C._jit_tree_views as _jit_tree_views # <module 'torch._C._jit_tree_views'>
import torch._C._nn as _nn # <module 'torch._C._nn'>
import torch._C.cpp as cpp # <module 'torch._C.cpp'>
import torch._C._functions as _functions # <module 'torch._C._functions'>
import pybind11_builtins as __pybind11_builtins


class Type(__pybind11_builtins.pybind11_object):
    # no doc
    def contiguous(self): # real signature unknown; restored from __doc__
        """ contiguous(self: torch._C.Type) -> torch._C.Type """
        pass

    def dim(self): # real signature unknown; restored from __doc__
        """ dim(self: torch._C.Type) -> int """
        return 0

    def isSubtypeOf(self, arg0): # real signature unknown; restored from __doc__
        """ isSubtypeOf(self: torch._C.Type, arg0: torch._C.Type) -> bool """
        return False

    def kind(self): # real signature unknown; restored from __doc__
        """ kind(self: torch._C.Type) -> str """
        return ""

    def scalarType(self): # real signature unknown; restored from __doc__
        """ scalarType(self: torch._C.Type) -> str """
        return ""

    def sizes(self): # real signature unknown; restored from __doc__
        """ sizes(self: torch._C.Type) -> List[int] """
        return []

    def str(self): # real signature unknown; restored from __doc__
        """ str(self: torch._C.Type) -> str """
        return ""

    def strides(self): # real signature unknown; restored from __doc__
        """ strides(self: torch._C.Type) -> List[int] """
        return []

    def __eq__(self, arg0): # real signature unknown; restored from __doc__
        """ __eq__(self: torch._C.Type, arg0: torch._C.Type) -> bool """
        return False

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ __repr__(self: torch._C.Type) -> str """
        return ""



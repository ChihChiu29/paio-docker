# encoding: utf-8
# module xxlimited
# from /usr/lib/python3.6/lib-dynload/xxlimited.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
""" This is a template module just for instruction. """
# no imports

# functions

def foo(i, j): # real signature unknown; restored from __doc__
    """
    foo(i,j)
    
    Return the sum of i and j.
    """
    pass

def new(): # real signature unknown; restored from __doc__
    """ new() -> new Xx object """
    pass

def roj(a, b): # real signature unknown; restored from __doc__
    """ roj(a,b) -> None """
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



class Null(object):
    # no doc
    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    __hash__ = None


class Str(str):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class Xxo(object):
    """ The Xxo type """
    def demo(self): # real signature unknown; restored from __doc__
        """ demo() -> None """
        pass

    def __del__(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9b4ff81630>'

__spec__ = None # (!) real value is "ModuleSpec(name='xxlimited', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9b4ff81630>, origin='/usr/lib/python3.6/lib-dynload/xxlimited.cpython-36m-x86_64-linux-gnu.so')"


# encoding: utf-8
# module numpy.core._struct_ufunc_tests
# from /usr/local/lib/python3.6/dist-packages/numpy/core/_struct_ufunc_tests.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def add_triplet(x1, x2, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    add_triplet(x1, x2, /, out=None, *, where=True, casting='same_kind', order='K', dtype=None, subok=True[, signature, extobj])
    
    add_triplet_docstring
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa13cc229b0>'

__spec__ = None # (!) real value is "ModuleSpec(name='numpy.core._struct_ufunc_tests', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa13cc229b0>, origin='/usr/local/lib/python3.6/dist-packages/numpy/core/_struct_ufunc_tests.cpython-36m-x86_64-linux-gnu.so')"


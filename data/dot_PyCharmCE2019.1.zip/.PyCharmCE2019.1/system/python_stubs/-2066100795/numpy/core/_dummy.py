# encoding: utf-8
# module numpy.core._dummy calls itself dummy
# from /usr/local/lib/python3.6/dist-packages/numpy/core/_dummy.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8e8b691358>'

__spec__ = None # (!) real value is "ModuleSpec(name='numpy.core._dummy', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8e8b691358>, origin='/usr/local/lib/python3.6/dist-packages/numpy/core/_dummy.cpython-36m-x86_64-linux-gnu.so')"


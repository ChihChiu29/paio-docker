# encoding: utf-8
# module murmurhash.mrmr
# from /usr/local/lib/python3.6/dist-packages/murmurhash/mrmr.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def hash(*args, **kwargs): # real signature unknown
    pass

def hash_bytes(*args, **kwargs): # real signature unknown
    pass

def hash_unicode(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa73512c898>'

__pyx_capi__ = {
    'hash128_x64': None, # (!) real value is '<capsule object "void (void const *, int, uint32_t, void *)" at 0x7fa7351ba5d0>'
    'hash128_x86': None, # (!) real value is '<capsule object "void (void const *, int, uint32_t, void *)" at 0x7fa7351ba6c0>'
    'hash32': None, # (!) real value is '<capsule object "uint32_t (void *, int, uint32_t)" at 0x7fa7351ba660>'
    'hash64': None, # (!) real value is '<capsule object "uint64_t (void *, int, uint64_t)" at 0x7fa7351ba630>'
    'real_hash64': None, # (!) real value is '<capsule object "uint64_t (void *, int, uint64_t)" at 0x7fa7351ba600>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='murmurhash.mrmr', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa73512c898>, origin='/usr/local/lib/python3.6/dist-packages/murmurhash/mrmr.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module grpc._cython.cygrpc
# from /usr/local/lib/python3.6/dist-packages/grpc/_cython/cygrpc.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import os as os # /usr/lib/python3.6/os.py
import sys as sys # <module 'sys' (built-in)>
import logging as logging # /usr/lib/python3.6/logging/__init__.py
import threading as threading # /usr/lib/python3.6/threading.py
import time as time # <module 'time' (built-in)>
import grpc as grpc # /usr/local/lib/python3.6/dist-packages/grpc/__init__.py
import collections as collections # /usr/lib/python3.6/collections/__init__.py
import pkgutil as pkgutil # /usr/lib/python3.6/pkgutil.py
import errno as errno # <module 'errno' (built-in)>

# Variables with simple values

gevent_event = None
gevent_g = None
gevent_hub = None
gevent_socket = None

GRPC_COMPRESSION_CHANNEL_DEFAULT_ALGORITHM = b'grpc.default_compression_algorithm'

GRPC_COMPRESSION_REQUEST_ALGORITHM_MD_KEY = b'grpc-internal-encoding-request'

g_event = None
g_pool = None

_AWAIT_THREADS_TIMEOUT_SECONDS = 5

_fork_handler_failed = False

_GRPC_ENABLE_FORK_SUPPORT = False

_INTERNAL_CALL_ERROR_MESSAGE_FORMAT = 'Internal gRPC call error %d. Please report to https://github.com/grpc/grpc/issues'

# functions

def applysockopts(*args, **kwargs): # real signature unknown
    pass

def async_callback_func(*args, **kwargs): # real signature unknown
    pass

def auth_context(*args, **kwargs): # real signature unknown
    pass

def block_if_fork_in_progress(*args, **kwargs): # real signature unknown
    pass

def build_census_context(*args, **kwargs): # real signature unknown
    pass

def channelz_get_channel(*args, **kwargs): # real signature unknown
    pass

def channelz_get_server(*args, **kwargs): # real signature unknown
    pass

def channelz_get_servers(*args, **kwargs): # real signature unknown
    pass

def channelz_get_server_sockets(*args, **kwargs): # real signature unknown
    pass

def channelz_get_socket(*args, **kwargs): # real signature unknown
    pass

def channelz_get_subchannel(*args, **kwargs): # real signature unknown
    pass

def channelz_get_top_channels(*args, **kwargs): # real signature unknown
    pass

def compression_algorithm_name(*args, **kwargs): # real signature unknown
    pass

def enter_user_request_generator(*args, **kwargs): # real signature unknown
    pass

def fork_handlers_and_grpc_init(*args, **kwargs): # real signature unknown
    pass

def fork_register_channel(*args, **kwargs): # real signature unknown
    pass

def fork_unregister_channel(*args, **kwargs): # real signature unknown
    pass

def get_deadline_from_context(*args, **kwargs): # real signature unknown
    pass

def get_fork_epoch(*args, **kwargs): # real signature unknown
    pass

def init_grpc_gevent(*args, **kwargs): # real signature unknown
    pass

def install_context_from_request_call_event(*args, **kwargs): # real signature unknown
    pass

def is_fork_support_enabled(*args, **kwargs): # real signature unknown
    pass

def peer_identities(*args, **kwargs): # real signature unknown
    pass

def peer_identity_key(*args, **kwargs): # real signature unknown
    pass

def return_from_user_request_generator(*args, **kwargs): # real signature unknown
    pass

def server_certificate_config_ssl(*args, **kwargs): # real signature unknown
    pass

def server_credentials_ssl(*args, **kwargs): # real signature unknown
    pass

def server_credentials_ssl_dynamic_cert_config(*args, **kwargs): # real signature unknown
    pass

def set_async_callback_func(*args, **kwargs): # real signature unknown
    pass

def set_census_context_on_call(*args, **kwargs): # real signature unknown
    pass

def socket_accept_async(*args, **kwargs): # real signature unknown
    pass

def socket_connect_async(*args, **kwargs): # real signature unknown
    pass

def socket_read_async(*args, **kwargs): # real signature unknown
    pass

def socket_resolve_async_python(*args, **kwargs): # real signature unknown
    pass

def socket_sendmsg(*args, **kwargs): # real signature unknown
    pass

def socket_write_async(*args, **kwargs): # real signature unknown
    pass

def uninstall_context(*args, **kwargs): # real signature unknown
    pass

def _spawn_callback_async(*args, **kwargs): # real signature unknown
    pass

def _spawn_callback_in_thread(*args, **kwargs): # real signature unknown
    pass

def _spawn_greenlet(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_CensusContext(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_ChannelCredentials(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle__Tag(*args, **kwargs): # real signature unknown
    pass

# classes

from .BatchOperationEvent import BatchOperationEvent
from .Call import Call
from .CallCredentials import CallCredentials
from .CallDetails import CallDetails
from .CallError import CallError
from .CensusContext import CensusContext
from .Channel import Channel
from .ChannelArgKey import ChannelArgKey
from .ChannelCredentials import ChannelCredentials
from .CompletionQueue import CompletionQueue
from .CompletionType import CompletionType
from .CompositeCallCredentials import CompositeCallCredentials
from .CompositeChannelCredentials import CompositeChannelCredentials
from .CompressionAlgorithm import CompressionAlgorithm
from .CompressionLevel import CompressionLevel
from .CompressionOptions import CompressionOptions
from .ConnectivityEvent import ConnectivityEvent
from .ConnectivityState import ConnectivityState
from .ForkManagedThread import ForkManagedThread
from .InitialMetadataFlags import InitialMetadataFlags
from .IntegratedCall import IntegratedCall
from .MetadataPluginCallCredentials import MetadataPluginCallCredentials
from .Operation import Operation
from .OperationType import OperationType
from .PropagationConstants import PropagationConstants
from .ReceiveCloseOnServerOperation import ReceiveCloseOnServerOperation
from .ReceiveInitialMetadataOperation import ReceiveInitialMetadataOperation
from .ReceiveMessageOperation import ReceiveMessageOperation
from .ReceiveStatusOnClientOperation import ReceiveStatusOnClientOperation
from .RequestCallEvent import RequestCallEvent
from .ResolveWrapper import ResolveWrapper
from .SegregatedCall import SegregatedCall
from .SendCloseFromClientOperation import SendCloseFromClientOperation
from .SendInitialMetadataOperation import SendInitialMetadataOperation
from .SendMessageOperation import SendMessageOperation
from .SendStatusFromServerOperation import SendStatusFromServerOperation
from .Server import Server
from .ServerCertificateConfig import ServerCertificateConfig
from .ServerCredentials import ServerCredentials
from .ServerShutdownEvent import ServerShutdownEvent
from .SocketWrapper import SocketWrapper
from .SSLChannelCredentials import SSLChannelCredentials
from .SslPemKeyCertPair import SslPemKeyCertPair
from .SSLSessionCacheLRU import SSLSessionCacheLRU
from .StatusCode import StatusCode
from .TimerWrapper import TimerWrapper
from .WriteFlag import WriteFlag
from ._ActiveThreadCount import _ActiveThreadCount
from ._Tag import _Tag
from ._BatchOperationTag import _BatchOperationTag
from ._CallState import _CallState
from ._ChannelArg import _ChannelArg
from ._ChannelArgs import _ChannelArgs
from ._ChannelState import _ChannelState
from ._ConnectivityTag import _ConnectivityTag
from ._ForkState import _ForkState
from ._GrpcArgWrapper import _GrpcArgWrapper
from ._Metadatum import _Metadatum
from ._RequestCallTag import _RequestCallTag
from ._ServerShutdownTag import _ServerShutdownTag
from ._VTable import _VTable
# variables with complex values

_fork_state = None # (!) real value is '<grpc._cython.cygrpc._ForkState object at 0x7ff6413f5198>'

_LOGGER = None # (!) real value is '<Logger grpc._cython.cygrpc (WARNING)>'

_TRUE_VALUES = [
    'yes',
    'Yes',
    'YES',
    'true',
    'True',
    'TRUE',
    '1',
]

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff640f32ef0>'

__pyx_capi__ = {
    '__postfork_child': None, # (!) real value is '<capsule object "void (void)" at 0x7ff640f2b450>'
    '__postfork_parent': None, # (!) real value is '<capsule object "void (void)" at 0x7ff640f2b420>'
    '__prefork': None, # (!) real value is '<capsule object "void (void)" at 0x7ff640f2b3f0>'
    '_check_and_raise_call_error_no_metadata': None, # (!) real value is '<capsule object "PyObject *(PyObject *)" at 0x7ff640f02840>'
    '_check_call_error': None, # (!) real value is '<capsule object "PyObject *(PyObject *, PyObject *)" at 0x7ff640f028d0>'
    '_check_call_error_no_metadata': None, # (!) real value is '<capsule object "PyObject *(PyObject *)" at 0x7ff640f02720>'
    '_compare_pointer': None, # (!) real value is '<capsule object "int (void *, void *)" at 0x7ff640f2b360>'
    '_composition': None, # (!) real value is '<capsule object "grpc_call_credentials *(PyObject *)" at 0x7ff640f2b7b0>'
    '_copy_pointer': None, # (!) real value is '<capsule object "void *(void *)" at 0x7ff640f2b300>'
    '_copy_slice': None, # (!) real value is '<capsule object "grpc_slice (grpc_slice)" at 0x7ff640f2b120>'
    '_custom_op_on_c_call': None, # (!) real value is '<capsule object "PyObject *(int, grpc_call *)" at 0x7ff640f2b3c0>'
    '_destroy': None, # (!) real value is '<capsule object "void (void *)" at 0x7ff640f02f90>'
    '_destroy_pointer': None, # (!) real value is '<capsule object "void (void *)" at 0x7ff640f2b330>'
    '_get_metadata': None, # (!) real value is '<capsule object "int (void *, grpc_auth_metadata_context, grpc_credentials_plugin_metadata_cb, void *, grpc_metadata *, size_t *, grpc_status_code *, char const **)" at 0x7ff640f02cc0>'
    '_interpret_event': None, # (!) real value is '<capsule object "PyObject *(grpc_event)" at 0x7ff640f2bae0>'
    '_metadata': None, # (!) real value is '<capsule object "PyObject *(grpc_metadata_array *)" at 0x7ff640f2b0c0>'
    '_metadatum': None, # (!) real value is '<capsule object "PyObject *(grpc_slice, grpc_slice)" at 0x7ff640f2bcc0>'
    '_next': None, # (!) real value is '<capsule object "grpc_event (grpc_completion_queue *, PyObject *)" at 0x7ff640f2b9c0>'
    '_release_c_metadata': None, # (!) real value is '<capsule object "void (grpc_metadata *, int)" at 0x7ff640f2bb40>'
    '_slice_bytes': None, # (!) real value is '<capsule object "PyObject *(grpc_slice)" at 0x7ff640f2b0f0>'
    '_slice_from_bytes': None, # (!) real value is '<capsule object "grpc_slice (PyObject *)" at 0x7ff640f2b150>'
    '_store_c_metadata': None, # (!) real value is '<capsule object "void (PyObject *, grpc_metadata **, size_t *)" at 0x7ff640f2bb10>'
    '_time_from_timespec': None, # (!) real value is '<capsule object "double (gpr_timespec)" at 0x7ff640f2b2d0>'
    '_timespec_from_time': None, # (!) real value is '<capsule object "gpr_timespec (PyObject *)" at 0x7ff640f2b2a0>'
    '_unwrap_grpc_arg': None, # (!) real value is '<capsule object "grpc_arg (PyObject *)" at 0x7ff640f026f0>'
    '_wrap_grpc_arg': None, # (!) real value is '<capsule object "PyObject *(grpc_arg)" at 0x7ff640f02b40>'
    'ssl_roots_override_callback': None, # (!) real value is '<capsule object "grpc_ssl_roots_override_result (char **)" at 0x7ff640f2b240>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='grpc._cython.cygrpc', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff640f32ef0>, origin='/usr/local/lib/python3.6/dist-packages/grpc/_cython/cygrpc.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module grpc._cython.cygrpc
# from /usr/local/lib/python3.6/dist-packages/grpc/_cython/cygrpc.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import os as os # /usr/lib/python3.6/os.py
import sys as sys # <module 'sys' (built-in)>
import logging as logging # /usr/lib/python3.6/logging/__init__.py
import threading as threading # /usr/lib/python3.6/threading.py
import time as time # <module 'time' (built-in)>
import grpc as grpc # /usr/local/lib/python3.6/dist-packages/grpc/__init__.py
import collections as collections # /usr/lib/python3.6/collections/__init__.py
import pkgutil as pkgutil # /usr/lib/python3.6/pkgutil.py
import errno as errno # <module 'errno' (built-in)>

from .object import object

class SocketWrapper(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass



# encoding: utf-8
# module grpc._cython.cygrpc
# from /usr/local/lib/python3.6/dist-packages/grpc/_cython/cygrpc.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import os as os # /usr/lib/python3.6/os.py
import sys as sys # <module 'sys' (built-in)>
import logging as logging # /usr/lib/python3.6/logging/__init__.py
import threading as threading # /usr/lib/python3.6/threading.py
import time as time # <module 'time' (built-in)>
import grpc as grpc # /usr/local/lib/python3.6/dist-packages/grpc/__init__.py
import collections as collections # /usr/lib/python3.6/collections/__init__.py
import pkgutil as pkgutil # /usr/lib/python3.6/pkgutil.py
import errno as errno # <module 'errno' (built-in)>

from .tuple import tuple

class _Metadatum(tuple):
    """ _Metadatum(key, value) """
    def _asdict(self): # reliably restored by inspect
        """ Return a new OrderedDict which maps field names to their values. """
        pass

    @classmethod
    def _make(cls, *args, **kwargs): # real signature unknown
        """ Make a new _Metadatum object from a sequence or iterable """
        pass

    def _replace(_self, **kwds): # reliably restored by inspect
        """ Return a new _Metadatum object replacing specified fields with new values """
        pass

    def __getnewargs__(self): # reliably restored by inspect
        """ Return self as a plain tuple.  Used by copy and pickle. """
        pass

    def __init__(self, key, value): # real signature unknown; restored from __doc__
        pass

    @staticmethod # known case of __new__
    def __new__(_cls, key, value): # reliably restored by inspect
        """ Create new instance of _Metadatum(key, value) """
        pass

    def __repr__(self): # reliably restored by inspect
        """ Return a nicely formatted representation string """
        pass

    key = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 0"""

    value = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Alias for field number 1"""


    _fields = (
        'key',
        'value',
    )
    _source = "from builtins import property as _property, tuple as _tuple\nfrom operator import itemgetter as _itemgetter\nfrom collections import OrderedDict\n\nclass _Metadatum(tuple):\n    '_Metadatum(key, value)'\n\n    __slots__ = ()\n\n    _fields = ('key', 'value')\n\n    def __new__(_cls, key, value):\n        'Create new instance of _Metadatum(key, value)'\n        return _tuple.__new__(_cls, (key, value))\n\n    @classmethod\n    def _make(cls, iterable, new=tuple.__new__, len=len):\n        'Make a new _Metadatum object from a sequence or iterable'\n        result = new(cls, iterable)\n        if len(result) != 2:\n            raise TypeError('Expected 2 arguments, got %d' % len(result))\n        return result\n\n    def _replace(_self, **kwds):\n        'Return a new _Metadatum object replacing specified fields with new values'\n        result = _self._make(map(kwds.pop, ('key', 'value'), _self))\n        if kwds:\n            raise ValueError('Got unexpected field names: %r' % list(kwds))\n        return result\n\n    def __repr__(self):\n        'Return a nicely formatted representation string'\n        return self.__class__.__name__ + '(key=%r, value=%r)' % self\n\n    def _asdict(self):\n        'Return a new OrderedDict which maps field names to their values.'\n        return OrderedDict(zip(self._fields, self))\n\n    def __getnewargs__(self):\n        'Return self as a plain tuple.  Used by copy and pickle.'\n        return tuple(self)\n\n    key = _property(_itemgetter(0), doc='Alias for field number 0')\n\n    value = _property(_itemgetter(1), doc='Alias for field number 1')\n\n"
    __slots__ = ()



# encoding: utf-8
# module typing.re
# from /usr/local/lib/python3.6/dist-packages/statsmodels/tsa/statespace/_tools.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
""" Wrapper namespace for re type aliases. """
# no imports

# functions

def Match(*args, **kwargs): # real signature unknown
    """
    Internal helper class for defining generic variants of concrete types.
    
        Note that this is not a type; let's call it a pseudo-type.  It cannot
        be used in instance and subclass checks in parameterized form, i.e.
        ``isinstance(42, Match[str])`` raises ``TypeError`` instead of returning
        ``False``.
    """
    pass

def Pattern(*args, **kwargs): # real signature unknown
    """
    Internal helper class for defining generic variants of concrete types.
    
        Note that this is not a type; let's call it a pseudo-type.  It cannot
        be used in instance and subclass checks in parameterized form, i.e.
        ``isinstance(42, Match[str])`` raises ``TypeError`` instead of returning
        ``False``.
    """
    pass

# no classes
# variables with complex values

__all__ = [
    'Pattern',
    'Match',
]

__weakref__ = None # (!) real value is "<attribute '__weakref__' of 'typing.re' objects>"


# encoding: utf-8
# module typing.io
# from /usr/local/lib/python3.6/dist-packages/statsmodels/tsa/statespace/_tools.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
""" Wrapper namespace for IO generic classes. """

# imports
import typing as __typing


# no functions
# classes

class IO(__typing.Generic):
    """
    Generic base class for TextIO and BinaryIO.
    
        This is an abstract, generic version of the return of open().
    
        NOTE: This does not distinguish between the different possible
        classes (text vs. binary, read vs. write vs. read/write,
        append-only, unbuffered).  The TextIO and BinaryIO subclasses
        below capture the distinctions between text vs. binary, which is
        pervasive in the interface; however we currently do not offer a
        way to track the other distinctions in the type system.
    """
# Error generating skeleton for function close: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function closed: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function fileno: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function flush: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function isatty: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function read: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function readable: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function readline: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function readlines: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function seek: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function seekable: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function tell: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function truncate: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function writable: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function write: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function writelines: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function __enter__: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function __exit__: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    mode = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    _abc_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa7961bdba8>'
    _abc_generic_negative_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa7961bdda0>'
    _abc_generic_negative_cache_version = 44
    _abc_registry = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa7961bdb70>'
    _gorg = typing.IO # (!) forward: IO, real value is 'typing.IO'
    __abstractmethods__ = frozenset({'readline', 'flush', 'name', 'closed', 'tell', 'isatty', 'seek', '__exit__', 'fileno', 'read', 'writelines', 'close', 'mode', 'readlines', '__enter__', 'truncate', 'seekable', 'write', 'writable', 'readable'})
    __args__ = None
    __extra__ = None
    __next_in_mro__ = object
    __origin__ = None
    __orig_bases__ = (
        typing.Generic[~AnyStr],
    )
    __parameters__ = (
        None, # (!) real value is '~AnyStr'
    )
    __slots__ = ()
    __tree_hash__ = -9223372036853141461


class BinaryIO(__typing.IO):
    """ Typed version of the return of open() in binary mode. """
# Error generating skeleton for function write: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

# Error generating skeleton for function __enter__: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa79614d048>'
    _abc_generic_negative_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa79614d080>'
    _abc_generic_negative_cache_version = 44
    _abc_registry = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa7961bdfd0>'
    _gorg = typing.BinaryIO # (!) forward: BinaryIO, real value is 'typing.BinaryIO'
    __abstractmethods__ = frozenset({'readline', 'flush', 'name', 'closed', 'tell', 'isatty', 'seek', '__exit__', 'fileno', 'read', 'writelines', 'close', 'mode', 'readlines', '__enter__', 'truncate', 'seekable', 'write', 'writable', 'readable'})
    __args__ = None
    __extra__ = None
    __next_in_mro__ = object
    __origin__ = None
    __orig_bases__ = (
        typing.IO[bytes],
    )
    __parameters__ = ()
    __slots__ = ()
    __tree_hash__ = -9223372036853141601


class TextIO(__typing.IO):
    """ Typed version of the return of open() in text mode. """
# Error generating skeleton for function __enter__: Function has keyword-only parameters or annotations, use getfullargspec() API which can support them

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    buffer = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    encoding = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    errors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    line_buffering = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    newlines = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    _abc_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa79614d2b0>'
    _abc_generic_negative_cache = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa79614d2e8>'
    _abc_generic_negative_cache_version = 44
    _abc_registry = None # (!) real value is '<_weakrefset.WeakSet object at 0x7fa79614d278>'
    _gorg = typing.TextIO # (!) forward: TextIO, real value is 'typing.TextIO'
    __abstractmethods__ = frozenset({'readline', 'buffer', 'errors', 'flush', 'name', 'closed', 'tell', 'isatty', 'seek', 'newlines', '__exit__', 'fileno', 'read', 'writelines', 'close', 'mode', 'readlines', '__enter__', 'truncate', 'seekable', 'encoding', 'line_buffering', 'write', 'writable', 'readable'})
    __args__ = None
    __extra__ = None
    __next_in_mro__ = object
    __origin__ = None
    __orig_bases__ = (
        typing.IO[str],
    )
    __parameters__ = ()
    __slots__ = ()
    __tree_hash__ = -9223372036853140879


# variables with complex values

__all__ = [
    'IO',
    'TextIO',
    'BinaryIO',
]

__weakref__ = None # (!) real value is "<attribute '__weakref__' of 'typing.io' objects>"


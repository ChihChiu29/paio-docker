# encoding: utf-8
# module cryptography.hazmat.bindings._constant_time
# from /usr/lib/python3/dist-packages/cryptography/hazmat/bindings/_constant_time.abi3.so
# by generator 1.147
# no doc
# no imports

# no functions
# no classes
# variables with complex values

ffi = None # (!) real value is '<CompiledFFI object at 0x7ff9b82ddb28>'

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff9b78eedd8>'

__spec__ = None # (!) real value is "ModuleSpec(name='cryptography.hazmat.bindings._constant_time', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff9b78eedd8>, origin='/usr/lib/python3/dist-packages/cryptography/hazmat/bindings/_constant_time.abi3.so')"


# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
from gobject import (GBoxed, GEnum, GFlags, GInterface, GParamSpec, GPointer, 
    GType, Warning)

import gi as __gi
import gobject as __gobject


class TypeInfo(__gi.BaseInfo):
    # no doc
    def get_array_fixed_size(self, *args, **kwargs): # real signature unknown
        pass

    def get_array_length(self, *args, **kwargs): # real signature unknown
        pass

    def get_array_type(self, *args, **kwargs): # real signature unknown
        pass

    def get_interface(self, *args, **kwargs): # real signature unknown
        pass

    def get_param_type(self, *args, **kwargs): # real signature unknown
        pass

    def get_tag(self, *args, **kwargs): # real signature unknown
        pass

    def get_tag_as_string(self, *args, **kwargs): # real signature unknown
        pass

    def is_pointer(self, *args, **kwargs): # real signature unknown
        pass

    def is_zero_terminated(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass



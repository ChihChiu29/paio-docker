# encoding: utf-8
# module spacy.lexeme
# from /usr/local/lib/python3.6/dist-packages/spacy/lexeme.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py
from spacy.attrs import intify_attrs


# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def user_warning(message): # reliably restored by inspect
    # no doc
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Lexeme(object):
    """
    Lexeme(Vocab vocab, attr_t orth)
    An entry in the vocabulary. A `Lexeme` has no string context – it's a
        word-type, as opposed to a word token.  It therefore has no part-of-speech
        tag, dependency parse, or lemma (lemmatization depends on the
        part-of-speech tag).
    
        DOCS: https://spacy.io/api/lexeme
    """
    def check_flag(self, attr_id_t_flag_id): # real signature unknown; restored from __doc__
        """
        Lexeme.check_flag(self, attr_id_t flag_id)
        Check the value of a boolean flag.
        
                flag_id (int): The attribute ID of the flag to query.
                RETURNS (bool): The value of the flag.
        """
        pass

    def from_bytes(self, bytes_byte_string): # real signature unknown; restored from __doc__
        """ Lexeme.from_bytes(self, bytes byte_string) """
        pass

    def set_attrs(self, **attrs): # real signature unknown; restored from __doc__
        """ Lexeme.set_attrs(self, **attrs) """
        pass

    def set_flag(self, attr_id_t_flag_id, bool_value): # real signature unknown; restored from __doc__
        """
        Lexeme.set_flag(self, attr_id_t flag_id, bool value)
        Change the value of a boolean flag.
        
                flag_id (int): The attribute ID of the flag to set.
                value (bool): The new value of the flag.
        """
        pass

    def similarity(self, other): # real signature unknown; restored from __doc__
        """
        Lexeme.similarity(self, other)
        Compute a semantic similarity estimate. Defaults to cosine over
                vectors.
        
                other (object): The object to compare with. By default, accepts `Doc`,
                    `Span`, `Token` and `Lexeme` objects.
                RETURNS (float): A scalar similarity score. Higher is more similar.
        """
        pass

    def to_bytes(self): # real signature unknown; restored from __doc__
        """ Lexeme.to_bytes(self) """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create a Lexeme object.
        
                vocab (Vocab): The parent vocabulary
                orth (uint64): The orth id of the lexeme.
                Returns (Lexeme): The newly constructd object.
        """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Lexeme.__reduce_cython__(self) """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        """ Lexeme.__setstate_cython__(self, __pyx_state) """
        pass

    cluster = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (int): Brown cluster ID."""

    flags = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): Container of the lexeme's binary flags."""

    has_vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether a word vector is associated with the object.
        """

    is_alpha = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme consists of alphanumeric
            characters. Equivalent to `lexeme.text.isalpha()`.
        """

    is_ascii = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme consists of ASCII characters.
            Equivalent to `[any(ord(c) >= 128 for c in lexeme.text)]`.
        """

    is_bracket = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is a bracket."""

    is_currency = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is a currency symbol, e.g. $, €."""

    is_digit = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme consists of digits. Equivalent
            to `lexeme.text.isdigit()`.
        """

    is_left_punct = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is left punctuation, e.g. )."""

    is_lower = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is in lowercase. Equivalent to
            `lexeme.text.islower()`.
        """

    is_oov = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is out-of-vocabulary."""

    is_punct = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is punctuation."""

    is_quote = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is a quotation mark."""

    is_right_punct = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is right punctuation, e.g. )."""

    is_space = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme consist of whitespace characters.
            Equivalent to `lexeme.text.isspace()`.
        """

    is_stop = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is a stop word."""

    is_title = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is in titlecase. Equivalent to
            `lexeme.text.istitle()`.
        """

    is_upper = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme is in uppercase. Equivalent to
            `lexeme.text.isupper()`.
        """

    lang = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): Language of the parent vocabulary."""

    lang_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Language of the parent vocabulary."""

    like_email = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme resembles an email address."""

    like_num = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme represents a number, e.g. "10.9",
            "10", "ten", etc.
        """

    like_url = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (bool): Whether the lexeme resembles a URL."""

    lower = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Lowercase form of the lexeme."""

    lower_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Lowercase form of the word."""

    norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): The lexemes's norm, i.e. a normalised form of the
            lexeme text.
        """

    norm_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The lexemes's norm, i.e. a normalised form of the
            lexeme text.
        """

    orth = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    orth_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The original verbatim text of the lexeme
            (identical to `Lexeme.text`). Exists mostly for consistency with
            the other attributes."""

    prefix = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): Length-N substring from the start of the word.
            Defaults to `N=1`.
        """

    prefix_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Length-N substring from the start of the word.
            Defaults to `N=1`.
        """

    prob = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (float): Smoothed log probability estimate of the lexeme's
            type."""

    rank = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Sequential ID of the lexemes's lexical type, used
            to index into tables, e.g. for word vectors."""

    sentiment = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (float): A scalar value indicating the positivity or
            negativity of the lexeme."""

    shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): Transform of the word's string, to show
            orthographic features.
        """

    shape_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Transform of the word's string, to show
            orthographic features.
        """

    suffix = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): Length-N substring from the end of the word.
            Defaults to `N=3`.
        """

    suffix_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): Length-N substring from the end of the word.
            Defaults to `N=3`.
        """

    text = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The original verbatim text of the lexeme."""

    vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A real-valued meaning representation.

        RETURNS (numpy.ndarray[ndim=1, dtype='float32']): A 1D numpy array
            representing the lexeme's semantics.
        """

    vector_norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (float): The L2 norm of the vector representation."""

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fba2112b1b0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fba2077f710>'

__pyx_capi__ = {
    'EMPTY_LEXEME': None, # (!) real value is '<capsule object "struct __pyx_t_5spacy_7structs_LexemeC" at 0x7fba2112b180>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.lexeme', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fba2077f710>, origin='/usr/local/lib/python3.6/dist-packages/spacy/lexeme.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


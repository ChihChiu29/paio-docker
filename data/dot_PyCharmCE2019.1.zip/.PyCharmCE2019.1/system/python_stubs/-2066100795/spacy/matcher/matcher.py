# encoding: utf-8
# module spacy.matcher.matcher
# from /usr/local/lib/python3.6/dist-packages/spacy/matcher/matcher.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import re as re # /usr/lib/python3.6/re.py
import srsly as srsly # /usr/local/lib/python3.6/dist-packages/srsly/__init__.py
from spacy.strings import get_string_id


# functions

def deprecation_warning(message): # reliably restored by inspect
    # no doc
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_json_validator(schema): # reliably restored by inspect
    # no doc
    pass

def unpickle_matcher(*args, **kwargs): # real signature unknown
    pass

def validate_json(data, validator): # reliably restored by inspect
    """
    Validate data against a given JSON schema (see https://json-schema.org).
    
        data: JSON-serializable data to validate.
        validator (jsonschema.DraftXValidator): The validator.
        RETURNS (list): A list of error messages, if available.
    """
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def _get_attr_values(*args, **kwargs): # real signature unknown
    pass

def _get_extensions(*args, **kwargs): # real signature unknown
    pass

def _get_extension_extra_predicates(*args, **kwargs): # real signature unknown
    pass

def _get_extra_predicates(*args, **kwargs): # real signature unknown
    pass

def _get_operators(*args, **kwargs): # real signature unknown
    pass

def _preprocess_pattern(*args, **kwargs): # real signature unknown
    """
    This function interprets the pattern, converting the various bits of
        syntactic sugar before we compile it into a struct with init_pattern.
    
        We need to split the pattern up into three parts:
        * Normal attribute/value pairs, which are stored on either the token or lexeme,
            can be handled directly.
        * Extension attributes are handled specially, as we need to prefetch the
            values from Python for the doc before we begin matching.
        * Extra predicates also call Python functions, so we have to create the
            functions and store them. So we store these specially as well.
        * Extension attributes that have extra predicates are stored within the
            extra_predicates.
    """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Matcher(object):
    """
    Match sequences of tokens, based on pattern rules.
    
        DOCS: https://spacy.io/api/matcher
        USAGE: https://spacy.io/usage/rule-based-matching
    """
    def add(self, *args, **kwargs): # real signature unknown
        """
        Add a match-rule to the matcher. A match-rule consists of: an ID
                key, an on_match callback, and one or more patterns.
        
                If the key exists, the patterns are appended to the previous ones, and
                the previous on_match callback is replaced. The `on_match` callback
                will receive the arguments `(matcher, doc, i, matches)`. You can also
                set `on_match` to `None` to not perform any actions.
        
                A pattern consists of one or more `token_specs`, where a `token_spec`
                is a dictionary mapping attribute IDs to values, and optionally a
                quantifier operator under the key "op". The available quantifiers are:
        
                '!': Negate the pattern, by requiring it to match exactly 0 times.
                '?': Make the pattern optional, by allowing it to match 0 or 1 times.
                '+': Require the pattern to match 1 or more times.
                '*': Allow the pattern to zero or more times.
        
                The + and * operators are usually interpretted "greedily", i.e. longer
                matches are returned where possible. However, if you specify two '+'
                and '*' patterns in a row and their matches overlap, the first
                operator will behave non-greedily. This quirk in the semantics makes
                the matcher more efficient, by avoiding the need for back-tracking.
        
                key (unicode): The match ID.
                on_match (callable): Callback executed on match.
                *patterns (list): List of token descriptions.
        """
        pass

    def get(self, *args, **kwargs): # real signature unknown
        """
        Retrieve the pattern stored for a key.
        
                key (unicode or int): The key to retrieve.
                RETURNS (tuple): The rule, as an (on_match, patterns) tuple.
        """
        pass

    def has_key(self, *args, **kwargs): # real signature unknown
        """
        Check whether the matcher has a rule with a given key.
        
                key (string or int): The key to check.
                RETURNS (bool): Whether the matcher has the rule.
        """
        pass

    def pipe(self, *args, **kwargs): # real signature unknown
        """
        Match a stream of documents, yielding them in turn.
        
                docs (iterable): A stream of documents.
                batch_size (int): Number of documents to accumulate into a working set.
                YIELDS (Doc): Documents, in order.
        """
        pass

    def remove(self, *args, **kwargs): # real signature unknown
        """
        Remove a rule from the matcher. A KeyError is raised if the key does
                not exist.
        
                key (unicode): The ID of the match rule.
        """
        pass

    def _normalize_key(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """
        Find all token sequences matching the supplied pattern.
        
                doc (Doc): The document to match over.
                RETURNS (list): A list of `(key, start, end)` tuples,
                    describing the matches. A match tuple describes a span
                    `doc[start:end]`. The `label_id` and `key` are both integers.
        """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """
        Check whether the matcher contains rules for a match ID.
        
                key (unicode): The match ID.
                RETURNS (bool): Whether the matcher contains rules for this match ID.
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create the Matcher.
        
                vocab (Vocab): The vocabulary object, which must be shared with the
                    documents the matcher will operate on.
                RETURNS (Matcher): The newly constructed object.
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        Get the number of rules added to the matcher. Note that this only
                returns the number of rules (identical with the number of IDs), not the
                number of individual patterns.
        
                RETURNS (int): The number of rules.
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    validator = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _callbacks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _extensions = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _extra_predicates = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _patterns = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class MatchPatternError(ValueError):
    # no doc
    def __init__(self, key, errors): # reliably restored by inspect
        """
        Custom error for validating match patterns.
        
                key (unicode): The name of the matcher rule.
                errors (dict): Validation errors (sequence of strings) mapped to pattern
                    ID, i.e. the index of the added pattern.
        """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



class _ComparisonPredicate(object):
    # no doc
    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    operators = (
        '==',
        '!=',
        '>=',
        '<=',
        '>',
        '<',
    )
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.matcher.matcher', 'operators': ('==', '!=', '>=', '<=', '>', '<'), '__init__': <cyfunction _ComparisonPredicate.__init__ at 0x7f224717a270>, '__call__': <cyfunction _ComparisonPredicate.__call__ at 0x7f224717a328>, '__dict__': <attribute '__dict__' of '_ComparisonPredicate' objects>, '__weakref__': <attribute '__weakref__' of '_ComparisonPredicate' objects>, '__doc__': None})"


class _RegexPredicate(object):
    # no doc
    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    operators = (
        'REGEX',
    )
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.matcher.matcher', 'operators': ('REGEX',), '__init__': <cyfunction _RegexPredicate.__init__ at 0x7f228df91df0>, '__call__': <cyfunction _RegexPredicate.__call__ at 0x7f2247a2af60>, '__dict__': <attribute '__dict__' of '_RegexPredicate' objects>, '__weakref__': <attribute '__weakref__' of '_RegexPredicate' objects>, '__doc__': None})"


class _SetMemberPredicate(object):
    # no doc
    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    operators = (
        'IN',
        'NOT_IN',
    )
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.matcher.matcher', 'operators': ('IN', 'NOT_IN'), '__init__': <cyfunction _SetMemberPredicate.__init__ at 0x7f224717a048>, '__call__': <cyfunction _SetMemberPredicate.__call__ at 0x7f224717a100>, '__repr__': <cyfunction _SetMemberPredicate.__repr__ at 0x7f224717a1b8>, '__dict__': <attribute '__dict__' of '_SetMemberPredicate' objects>, '__weakref__': <attribute '__weakref__' of '_SetMemberPredicate' objects>, '__doc__': None})"


# variables with complex values

IDS = {
    '': 0,
    'CLUSTER': 72,
    'DEP': 76,
    'ENT_IOB': 77,
    'ENT_KB_ID': 452,
    'ENT_TYPE': 78,
    'FLAG19': 19,
    'FLAG20': 20,
    'FLAG21': 21,
    'FLAG22': 22,
    'FLAG23': 23,
    'FLAG24': 24,
    'FLAG25': 25,
    'FLAG26': 26,
    'FLAG27': 27,
    'FLAG28': 28,
    'FLAG29': 29,
    'FLAG30': 30,
    'FLAG31': 31,
    'FLAG32': 32,
    'FLAG33': 33,
    'FLAG34': 34,
    'FLAG35': 35,
    'FLAG36': 36,
    'FLAG37': 37,
    'FLAG38': 38,
    'FLAG39': 39,
    'FLAG40': 40,
    'FLAG41': 41,
    'FLAG42': 42,
    'FLAG43': 43,
    'FLAG44': 44,
    'FLAG45': 45,
    'FLAG46': 46,
    'FLAG47': 47,
    'FLAG48': 48,
    'FLAG49': 49,
    'FLAG50': 50,
    'FLAG51': 51,
    'FLAG52': 52,
    'FLAG53': 53,
    'FLAG54': 54,
    'FLAG55': 55,
    'FLAG56': 56,
    'FLAG57': 57,
    'FLAG58': 58,
    'FLAG59': 59,
    'FLAG60': 60,
    'FLAG61': 61,
    'FLAG62': 62,
    'FLAG63': 63,
    'HEAD': 79,
    'ID': 64,
    'IS_ALPHA': 1,
    'IS_ASCII': 2,
    'IS_BRACKET': 14,
    'IS_CURRENCY': 18,
    'IS_DIGIT': 3,
    'IS_LEFT_PUNCT': 16,
    'IS_LOWER': 4,
    'IS_OOV': 13,
    'IS_PUNCT': 5,
    'IS_QUOTE': 15,
    'IS_RIGHT_PUNCT': 17,
    'IS_SPACE': 6,
    'IS_STOP': 12,
    'IS_TITLE': 7,
    'IS_UPPER': 8,
    'LANG': 83,
    'LEMMA': 73,
    'LENGTH': 71,
    'LIKE_EMAIL': 11,
    'LIKE_NUM': 10,
    'LIKE_URL': 9,
    'LOWER': 66,
    'NORM': 67,
    'ORTH': 65,
    'POS': 74,
    'PREFIX': 69,
    'PROB': 82,
    'SENT_START': 80,
    'SHAPE': 68,
    'SPACY': 81,
    'SUFFIX': 70,
    'TAG': 75,
}

TOKEN_PATTERN_SCHEMA = {
    '$schema': 'http://json-schema.org/draft-06/schema',
    'definitions': {
        'boolean_value': {
            'type': 'boolean',
        },
        'integer_value': {
            'anyOf': [
                {
                    'type': 'integer',
                },
                {
                    'additionalProperties': False,
                    'properties': {
                        '<': '<value is a self-reference, replaced by this string>',
                        '<=': '<value is a self-reference, replaced by this string>',
                        '==': '<value is a self-reference, replaced by this string>',
                        '>': '<value is a self-reference, replaced by this string>',
                        '>=': '<value is a self-reference, replaced by this string>',
                        'IN': {
                            'items': '<value is a self-reference, replaced by this string>',
                            'type': 'array',
                        },
                        'NOT_IN': '<value is a self-reference, replaced by this string>',
                        'REGEX': {
                            'type': 'string',
                        },
                    },
                    'type': 'object',
                },
            ],
        },
        'string_value': {
            'anyOf': [
                '<value is a self-reference, replaced by this string>',
                {
                    'additionalProperties': False,
                    'properties': {
                        'IN': {
                            'items': '<value is a self-reference, replaced by this string>',
                            'type': 'array',
                        },
                        'NOT_IN': '<value is a self-reference, replaced by this string>',
                        'REGEX': '<value is a self-reference, replaced by this string>',
                    },
                    'type': 'object',
                },
            ],
        },
        'underscore_value': {
            'anyOf': [
                {
                    'type': [
                        'string',
                        'integer',
                        'number',
                        'array',
                        'boolean',
                        'null',
                    ],
                },
                {
                    'additionalProperties': False,
                    'properties': {
                        '<': '<value is a self-reference, replaced by this string>',
                        '<=': '<value is a self-reference, replaced by this string>',
                        '==': '<value is a self-reference, replaced by this string>',
                        '>': '<value is a self-reference, replaced by this string>',
                        '>=': '<value is a self-reference, replaced by this string>',
                        'IN': {
                            'items': {
                                'type': [
                                    'string',
                                    'integer',
                                ],
                            },
                            'type': 'array',
                        },
                        'NOT_IN': '<value is a self-reference, replaced by this string>',
                        'REGEX': '<value is a self-reference, replaced by this string>',
                    },
                    'type': 'object',
                },
            ],
        },
    },
    'items': {
        'additionalProperties': False,
        'properties': {
            'DEP': {
                '$ref': '#/definitions/string_value',
                'title': 'Dependency label',
            },
            'ENT_TYPE': {
                '$ref': '#/definitions/string_value',
                'title': 'Entity label of single token',
            },
            'IS_ALPHA': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token consists of alphanumeric characters',
            },
            'IS_ASCII': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token consists of ASCII characters',
            },
            'IS_DIGIT': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token consists of digits',
            },
            'IS_LOWER': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token is lowercase',
            },
            'IS_PUNCT': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token is punctuation',
            },
            'IS_SPACE': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token is whitespace',
            },
            'IS_STOP': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token is stop word',
            },
            'IS_TITLE': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token  is titlecase',
            },
            'IS_UPPER': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token is uppercase',
            },
            'LEMMA': {
                '$ref': '#/definitions/string_value',
                'title': 'Lemma (base form)',
            },
            'LENGTH': {
                '$ref': '#/definitions/integer_value',
                'title': 'Token character length',
            },
            'LIKE_EMAIL': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token resembles an email address',
            },
            'LIKE_NUM': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token resembles a number',
            },
            'LIKE_URL': {
                '$ref': '#/definitions/boolean_value',
                'title': 'Token resembles a URL',
            },
            'LOWER': {
                '$ref': '#/definitions/string_value',
                'title': 'Lowercase form of token text',
            },
            'OP': {
                'enum': [
                    '+',
                    '*',
                    '?',
                    '!',
                ],
                'title': 'Operators / quantifiers',
                'type': 'string',
            },
            'ORTH': {
                '$ref': '#/definitions/string_value',
                'title': 'Verbatim token text',
            },
            'POS': {
                '$ref': '#/definitions/string_value',
                'title': 'Coarse-grained part-of-speech tag',
            },
            'SHAPE': {
                '$ref': '#/definitions/string_value',
                'title': 'Abstract token shape',
            },
            'TAG': {
                '$ref': '#/definitions/string_value',
                'title': 'Fine-grained part-of-speech tag',
            },
            'TEXT': {
                '$ref': '#/definitions/string_value',
                'title': 'Verbatim token text (spaCy v2.1+)',
            },
            '_': {
                'patternProperties': {
                    '^.*$': {
                        '$ref': '#/definitions/underscore_value',
                    },
                },
                'title': 'Custom extension token attributes (token._.)',
                'type': 'object',
            },
        },
        'type': 'object',
    },
    'type': 'array',
}

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f224716e5f8>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.matcher.matcher', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f224716e5f8>, origin='/usr/local/lib/python3.6/dist-packages/spacy/matcher/matcher.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


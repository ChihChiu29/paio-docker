# encoding: utf-8
# module spacy.matcher.dependencymatcher
# from /usr/local/lib/python3.6/dist-packages/spacy/matcher/dependencymatcher.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py
from spacy.matcher.matcher import unpickle_matcher


# Variables with simple values

DELIMITER = '||'

INDEX_HEAD = 1
INDEX_RELOP = 0

# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class DependencyMatcher(object):
    """ Match dependency parse tree based on pattern rules. """
    def add(self, *args, **kwargs): # real signature unknown
        pass

    def dep(self, *args, **kwargs): # real signature unknown
        pass

    def dep_chain(self, *args, **kwargs): # real signature unknown
        pass

    def get(self, *args, **kwargs): # real signature unknown
        """
        Retrieve the pattern stored for a key.
        
                key (unicode or int): The key to retrieve.
                RETURNS (tuple): The rule, as an (on_match, patterns) tuple.
        """
        pass

    def get_node_operator_map(self, *args, **kwargs): # real signature unknown
        pass

    def gov(self, *args, **kwargs): # real signature unknown
        pass

    def gov_chain(self, *args, **kwargs): # real signature unknown
        pass

    def has_key(self, *args, **kwargs): # real signature unknown
        """
        Check whether the matcher has a rule with a given key.
        
                key (string or int): The key to check.
                RETURNS (bool): Whether the matcher has the rule.
        """
        pass

    def imm_left_sib(self, *args, **kwargs): # real signature unknown
        pass

    def imm_precede(self, *args, **kwargs): # real signature unknown
        pass

    def imm_right_sib(self, *args, **kwargs): # real signature unknown
        pass

    def left_sib(self, *args, **kwargs): # real signature unknown
        pass

    def recurse(self, *args, **kwargs): # real signature unknown
        pass

    def retrieve_tree(self, *args, **kwargs): # real signature unknown
        pass

    def right_sib(self, *args, **kwargs): # real signature unknown
        pass

    def validateInput(self, *args, **kwargs): # real signature unknown
        pass

    def _normalize_key(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """
        Check whether the matcher contains rules for a match ID.
        
                key (unicode): The match ID.
                RETURNS (bool): Whether the matcher contains rules for this match ID.
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create the DependencyMatcher.
        
                vocab (Vocab): The vocabulary object, which must be shared with the
                    documents the matcher will operate on.
                RETURNS (DependencyMatcher): The newly constructed object.
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        Get the number of rules, which are edges, added to the dependency
                tree matcher.
        
                RETURNS (int): The number of rules.
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    token_matcher = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _callbacks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _entities = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _keys_to_token = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _nodes = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _patterns = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _root = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _tree = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f17a2717b00>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.matcher.dependencymatcher', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f17a2717b00>, origin='/usr/local/lib/python3.6/dist-packages/spacy/matcher/dependencymatcher.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


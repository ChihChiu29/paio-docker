# encoding: utf-8
# module spacy.tokens.span
# from /usr/local/lib/python3.6/dist-packages/spacy/tokens/span.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py

# functions

def deprecation_warning(message): # reliably restored by inspect
    # no doc
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def get_ext_args(**kwargs): # reliably restored by inspect
    """ Validate and convert arguments. Reused in Doc, Token and Span. """
    pass

def is_config(python2=None, python3=None, windows=None, linux=None, osx=None): # reliably restored by inspect
    """
    Check if a specific configuration of Python version and operating system
        matches the user's setup. Mostly used to display targeted error messages.
    
        python2 (bool): spaCy is executed with Python 2.x.
        python3 (bool): spaCy is executed with Python 3.x.
        windows (bool): spaCy is executed on Windows.
        linux (bool): spaCy is executed on Linux.
        osx (bool): spaCy is executed on OS X or macOS.
        RETURNS (bool): Whether the configuration matches the user's platform.
    
        DOCS: https://spacy.io/api/top-level#compat.is_config
    """
    pass

def models_warning(message): # reliably restored by inspect
    # no doc
    pass

def normalize_slice(length, start, stop, step=None): # reliably restored by inspect
    # no doc
    pass

def TempErrors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def user_warning(message): # reliably restored by inspect
    # no doc
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class basestring_(object):
    """
    str(object='') -> str
    str(bytes_or_buffer[, encoding[, errors]]) -> str
    
    Create a new string object from the given object. If encoding or
    errors is specified, then the object must expose a data buffer
    that will be decoded using the given encoding and error handler.
    Otherwise, returns the result of object.__str__() (if defined)
    or repr(object).
    encoding defaults to sys.getdefaultencoding().
    errors defaults to 'strict'.
    """
    def capitalize(self): # real signature unknown; restored from __doc__
        """
        S.capitalize() -> str
        
        Return a capitalized version of S, i.e. make the first character
        have upper case and the rest lower case.
        """
        return ""

    def casefold(self): # real signature unknown; restored from __doc__
        """
        S.casefold() -> str
        
        Return a version of S suitable for caseless comparisons.
        """
        return ""

    def center(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.center(width[, fillchar]) -> str
        
        Return S centered in a string of length width. Padding is
        done using the specified fill character (default is a space)
        """
        return ""

    def count(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.count(sub[, start[, end]]) -> int
        
        Return the number of non-overlapping occurrences of substring sub in
        string S[start:end].  Optional arguments start and end are
        interpreted as in slice notation.
        """
        return 0

    def encode(self, encoding='utf-8', errors='strict'): # real signature unknown; restored from __doc__
        """
        S.encode(encoding='utf-8', errors='strict') -> bytes
        
        Encode S using the codec registered for encoding. Default encoding
        is 'utf-8'. errors may be given to set a different error
        handling scheme. Default is 'strict' meaning that encoding errors raise
        a UnicodeEncodeError. Other possible values are 'ignore', 'replace' and
        'xmlcharrefreplace' as well as any other name registered with
        codecs.register_error that can handle UnicodeEncodeErrors.
        """
        return b""

    def endswith(self, suffix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.endswith(suffix[, start[, end]]) -> bool
        
        Return True if S ends with the specified suffix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        suffix can also be a tuple of strings to try.
        """
        return False

    def expandtabs(self, tabsize=8): # real signature unknown; restored from __doc__
        """
        S.expandtabs(tabsize=8) -> str
        
        Return a copy of S where all tab characters are expanded using spaces.
        If tabsize is not given, a tab size of 8 characters is assumed.
        """
        return ""

    def find(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.find(sub[, start[, end]]) -> int
        
        Return the lowest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def format(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        S.format(*args, **kwargs) -> str
        
        Return a formatted version of S, using substitutions from args and kwargs.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def format_map(self, mapping): # real signature unknown; restored from __doc__
        """
        S.format_map(mapping) -> str
        
        Return a formatted version of S, using substitutions from mapping.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def index(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.index(sub[, start[, end]]) -> int
        
        Return the lowest index in S where substring sub is found, 
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Raises ValueError when the substring is not found.
        """
        return 0

    def isalnum(self): # real signature unknown; restored from __doc__
        """
        S.isalnum() -> bool
        
        Return True if all characters in S are alphanumeric
        and there is at least one character in S, False otherwise.
        """
        return False

    def isalpha(self): # real signature unknown; restored from __doc__
        """
        S.isalpha() -> bool
        
        Return True if all characters in S are alphabetic
        and there is at least one character in S, False otherwise.
        """
        return False

    def isdecimal(self): # real signature unknown; restored from __doc__
        """
        S.isdecimal() -> bool
        
        Return True if there are only decimal characters in S,
        False otherwise.
        """
        return False

    def isdigit(self): # real signature unknown; restored from __doc__
        """
        S.isdigit() -> bool
        
        Return True if all characters in S are digits
        and there is at least one character in S, False otherwise.
        """
        return False

    def isidentifier(self): # real signature unknown; restored from __doc__
        """
        S.isidentifier() -> bool
        
        Return True if S is a valid identifier according
        to the language definition.
        
        Use keyword.iskeyword() to test for reserved identifiers
        such as "def" and "class".
        """
        return False

    def islower(self): # real signature unknown; restored from __doc__
        """
        S.islower() -> bool
        
        Return True if all cased characters in S are lowercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def isnumeric(self): # real signature unknown; restored from __doc__
        """
        S.isnumeric() -> bool
        
        Return True if there are only numeric characters in S,
        False otherwise.
        """
        return False

    def isprintable(self): # real signature unknown; restored from __doc__
        """
        S.isprintable() -> bool
        
        Return True if all characters in S are considered
        printable in repr() or S is empty, False otherwise.
        """
        return False

    def isspace(self): # real signature unknown; restored from __doc__
        """
        S.isspace() -> bool
        
        Return True if all characters in S are whitespace
        and there is at least one character in S, False otherwise.
        """
        return False

    def istitle(self): # real signature unknown; restored from __doc__
        """
        S.istitle() -> bool
        
        Return True if S is a titlecased string and there is at least one
        character in S, i.e. upper- and titlecase characters may only
        follow uncased characters and lowercase characters only cased ones.
        Return False otherwise.
        """
        return False

    def isupper(self): # real signature unknown; restored from __doc__
        """
        S.isupper() -> bool
        
        Return True if all cased characters in S are uppercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def join(self, iterable): # real signature unknown; restored from __doc__
        """
        S.join(iterable) -> str
        
        Return a string which is the concatenation of the strings in the
        iterable.  The separator between elements is S.
        """
        return ""

    def ljust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.ljust(width[, fillchar]) -> str
        
        Return S left-justified in a Unicode string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def lower(self): # real signature unknown; restored from __doc__
        """
        S.lower() -> str
        
        Return a copy of the string S converted to lowercase.
        """
        return ""

    def lstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.lstrip([chars]) -> str
        
        Return a copy of the string S with leading whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def maketrans(self, *args, **kwargs): # real signature unknown
        """
        Return a translation table usable for str.translate().
        
        If there is only one argument, it must be a dictionary mapping Unicode
        ordinals (integers) or characters to Unicode ordinals, strings or None.
        Character keys will be then converted to ordinals.
        If there are two arguments, they must be strings of equal length, and
        in the resulting dictionary, each character in x will be mapped to the
        character at the same position in y. If there is a third argument, it
        must be a string, whose characters will be mapped to None in the result.
        """
        pass

    def partition(self, sep): # real signature unknown; restored from __doc__
        """
        S.partition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, and return the part before it,
        the separator itself, and the part after it.  If the separator is not
        found, return S and two empty strings.
        """
        pass

    def replace(self, old, new, count=None): # real signature unknown; restored from __doc__
        """
        S.replace(old, new[, count]) -> str
        
        Return a copy of S with all occurrences of substring
        old replaced by new.  If the optional argument count is
        given, only the first count occurrences are replaced.
        """
        return ""

    def rfind(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rfind(sub[, start[, end]]) -> int
        
        Return the highest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def rindex(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rindex(sub[, start[, end]]) -> int
        
        Return the highest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Raises ValueError when the substring is not found.
        """
        return 0

    def rjust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.rjust(width[, fillchar]) -> str
        
        Return S right-justified in a string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def rpartition(self, sep): # real signature unknown; restored from __doc__
        """
        S.rpartition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, starting at the end of S, and return
        the part before it, the separator itself, and the part after it.  If the
        separator is not found, return two empty strings and S.
        """
        pass

    def rsplit(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.rsplit(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string, starting at the end of the string and
        working to the front.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified, any whitespace string
        is a separator.
        """
        return []

    def rstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.rstrip([chars]) -> str
        
        Return a copy of the string S with trailing whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def split(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.split(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified or is None, any
        whitespace string is a separator and empty strings are
        removed from the result.
        """
        return []

    def splitlines(self, keepends=None): # real signature unknown; restored from __doc__
        """
        S.splitlines([keepends]) -> list of strings
        
        Return a list of the lines in S, breaking at line boundaries.
        Line breaks are not included in the resulting list unless keepends
        is given and true.
        """
        return []

    def startswith(self, prefix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.startswith(prefix[, start[, end]]) -> bool
        
        Return True if S starts with the specified prefix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        prefix can also be a tuple of strings to try.
        """
        return False

    def strip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.strip([chars]) -> str
        
        Return a copy of the string S with leading and trailing
        whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def swapcase(self): # real signature unknown; restored from __doc__
        """
        S.swapcase() -> str
        
        Return a copy of S with uppercase characters converted to lowercase
        and vice versa.
        """
        return ""

    def title(self): # real signature unknown; restored from __doc__
        """
        S.title() -> str
        
        Return a titlecased version of S, i.e. words start with title case
        characters, all remaining cased characters have lower case.
        """
        return ""

    def translate(self, table): # real signature unknown; restored from __doc__
        """
        S.translate(table) -> str
        
        Return a copy of the string S in which each character has been mapped
        through the given translation table. The table must implement
        lookup/indexing via __getitem__, for instance a dictionary or list,
        mapping Unicode ordinals to Unicode ordinals, strings, or None. If
        this operation raises LookupError, the character is left untouched.
        Characters mapped to None are deleted.
        """
        return ""

    def upper(self): # real signature unknown; restored from __doc__
        """
        S.upper() -> str
        
        Return a copy of S converted to uppercase.
        """
        return ""

    def zfill(self, width): # real signature unknown; restored from __doc__
        """
        S.zfill(width) -> str
        
        Pad a numeric string S with zeros on the left, to fill a field
        of the specified width. The string S is never truncated.
        """
        return ""

    def __add__(self, *args, **kwargs): # real signature unknown
        """ Return self+value. """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """ Return key in self. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __format__(self, format_spec): # real signature unknown; restored from __doc__
        """
        S.__format__(format_spec) -> str
        
        Return a formatted version of S as described by format_spec.
        """
        return ""

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __getnewargs__(self, *args, **kwargs): # real signature unknown
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __mod__(self, *args, **kwargs): # real signature unknown
        """ Return self%value. """
        pass

    def __mul__(self, *args, **kwargs): # real signature unknown
        """ Return self*value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __rmod__(self, *args, **kwargs): # real signature unknown
        """ Return value%self. """
        pass

    def __rmul__(self, *args, **kwargs): # real signature unknown
        """ Return value*self. """
        pass

    def __sizeof__(self): # real signature unknown; restored from __doc__
        """ S.__sizeof__() -> size of S in memory, in bytes """
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """ Return str(self). """
        pass


class defaultdict(dict):
    """
    defaultdict(default_factory[, ...]) --> dict with default factory
    
    The default factory is called without arguments to produce
    a new value when a key is not present, in __getitem__ only.
    A defaultdict compares equal to a dict with the same items.
    All remaining arguments are treated the same as if they were
    passed to the dict constructor, including keyword arguments.
    """
    def copy(self): # real signature unknown; restored from __doc__
        """ D.copy() -> a shallow copy of D. """
        pass

    def __copy__(self, *args, **kwargs): # real signature unknown
        """ D.copy() -> a shallow copy of D. """
        pass

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __init__(self, default_factory, *some): # real signature unknown; restored from __doc__
        pass

    def __missing__(self, key): # real signature unknown; restored from __doc__
        """
        __missing__(key) # Called by __getitem__ for missing key; pseudo-code:
          if self.default_factory is None: raise KeyError((key,))
          self[key] = value = self.default_factory()
          return value
        """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling. """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    default_factory = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Factory for default value called by __missing__()."""



class Span(object):
    """
    A slice from a Doc object.
    
        DOCS: https://spacy.io/api/span
    """
    def as_doc(self, *args, **kwargs): # real signature unknown
        """
        Create a `Doc` object with a copy of the `Span`'s data.
        
                RETURNS (Doc): The `Doc` copy of the span.
        
                DOCS: https://spacy.io/api/span#as_doc
        """
        pass

    @classmethod
    def get_extension(cls, *args, **kwargs): # real signature unknown
        """
        Look up a previously registered extension by name.
        
                name (unicode): Name of the extension.
                RETURNS (tuple): A `(default, method, getter, setter)` tuple.
        
                DOCS: https://spacy.io/api/span#get_extension
        """
        pass

    def get_lca_matrix(self, *args, **kwargs): # real signature unknown
        """
        Calculates a matrix of Lowest Common Ancestors (LCA) for a given
                `Span`, where LCA[i, j] is the index of the lowest common ancestor among
                the tokens span[i] and span[j]. If they have no common ancestor within
                the span, LCA[i, j] will be -1.
        
                RETURNS (np.array[ndim=2, dtype=numpy.int32]): LCA matrix with shape
                    (n, n), where n = len(self).
        
                DOCS: https://spacy.io/api/span#get_lca_matrix
        """
        pass

    @classmethod
    def has_extension(cls, *args, **kwargs): # real signature unknown
        """
        Check whether an extension has been registered.
        
                name (unicode): Name of the extension.
                RETURNS (bool): Whether the extension has been registered.
        
                DOCS: https://spacy.io/api/span#has_extension
        """
        pass

    def merge(self, *args, **kwargs): # real signature unknown
        """
        Retokenize the document, such that the span is merged into a single
                token.
        
                **attributes: Attributes to assign to the merged token. By default,
                    attributes are inherited from the syntactic root token of the span.
                RETURNS (Token): The newly merged token.
        """
        pass

    @classmethod
    def remove_extension(cls, *args, **kwargs): # real signature unknown
        """
        Remove a previously registered extension.
        
                name (unicode): Name of the extension.
                RETURNS (tuple): A `(default, method, getter, setter)` tuple of the
                    removed extension.
        
                DOCS: https://spacy.io/api/span#remove_extension
        """
        pass

    @classmethod
    def set_extension(cls, *args, **kwargs): # real signature unknown
        """
        Define a custom attribute which becomes available as `Span._`.
        
                name (unicode): Name of the attribute to set.
                default: Optional default value of the attribute.
                getter (callable): Optional getter function.
                setter (callable): Optional setter function.
                method (callable): Optional method for method extension.
                force (bool): Force overwriting existing attribute.
        
                DOCS: https://spacy.io/api/span#set_extension
                USAGE: https://spacy.io/usage/processing-pipelines#custom-components-attributes
        """
        pass

    def similarity(self, *args, **kwargs): # real signature unknown
        """
        Make a semantic similarity estimate. The default estimate is cosine
                similarity using an average of word vectors.
        
                other (object): The object to compare with. By default, accepts `Doc`,
                    `Span`, `Token` and `Lexeme` objects.
                RETURNS (float): A scalar similarity score. Higher is more similar.
        
                DOCS: https://spacy.io/api/span#similarity
        """
        pass

    def to_array(self, *args, **kwargs): # real signature unknown
        """
        Given a list of M attribute IDs, export the tokens to a numpy
                `ndarray` of shape `(N, M)`, where `N` is the length of the document.
                The values will be 32-bit integers.
        
                attr_ids (list[int]): A list of attribute ID ints.
                RETURNS (numpy.ndarray[long, ndim=2]): A feature matrix, with one row
                    per word, and one column per attribute indicated in the input
                    `attr_ids`.
        """
        pass

    def _recalculate_indices(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """
        Get a `Token` or a `Span` object
        
                i (int or tuple): The index of the token within the span, or slice of
                    the span to get.
                RETURNS (Token or Span): The token at `span[i]`.
        
                DOCS: https://spacy.io/api/span#getitem
        """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """
        Iterate over `Token` objects.
        
                YIELDS (Token): A `Token` object.
        
                DOCS: https://spacy.io/api/span#iter
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        Get the number of tokens in the span.
        
                RETURNS (int): The number of tokens in the span.
        
                DOCS: https://spacy.io/api/span#len
        """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    conjuncts = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Tokens that are conjoined to the span's root.

        RETURNS (tuple): A tuple of Token objects.

        DOCS: https://spacy.io/api/span#lefts
        """

    doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    end = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    end_char = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    ents = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The named entities in the span. Returns a tuple of named entity
        `Span` objects, if the entity recognizer has been applied.

        RETURNS (tuple): Entities in the span, one `Span` per entity.

        DOCS: https://spacy.io/api/span#ents
        """

    ent_id = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): The entity ID."""

    ent_id_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The (string) entity ID."""

    has_vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A boolean value indicating whether a word vector is associated with
        the object.

        RETURNS (bool): Whether a word vector is associated with the object.

        DOCS: https://spacy.io/api/span#has_vector
        """

    kb_id = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    kb_id_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The named entity's KB ID."""

    label = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    label_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The span's label."""

    lefts = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Tokens that are to the left of the span, whose head is within the
        `Span`.

        YIELDS (Token):A left-child of a token of the span.

        DOCS: https://spacy.io/api/span#lefts
        """

    lemma_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The span's lemma."""

    lower_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Deprecated. Use `Span.text.lower()` instead."""

    noun_chunks = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Yields base noun-phrase `Span` objects, if the document has been
        syntactically parsed. A base noun phrase, or "NP chunk", is a noun
        phrase that does not permit other NPs to be nested within it – so no
        NP-level coordination, no prepositional phrases, and no relative
        clauses.

        YIELDS (Span): Base noun-phrase `Span` objects.

        DOCS: https://spacy.io/api/span#noun_chunks
        """

    n_lefts = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The number of tokens that are to the left of the span, whose
        heads are within the span.

        RETURNS (int): The number of leftward immediate children of the
            span, in the syntactic dependency parse.

        DOCS: https://spacy.io/api/span#n_lefts
        """

    n_rights = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The number of tokens that are to the right of the span, whose
        heads are within the span.

        RETURNS (int): The number of rightward immediate children of the
            span, in the syntactic dependency parse.

        DOCS: https://spacy.io/api/span#n_rights
        """

    orth_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Verbatim text content (identical to `Span.text`). Exists mostly for
        consistency with other attributes.

        RETURNS (unicode): The span's text."""

    rights = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Tokens that are to the right of the Span, whose head is within the
        `Span`.

        YIELDS (Token): A right-child of a token of the span.

        DOCS: https://spacy.io/api/span#rights
        """

    root = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The token with the shortest path to the root of the
        sentence (or the root itself). If multiple tokens are equally
        high in the tree, the first token is taken.

        RETURNS (Token): The root token.

        DOCS: https://spacy.io/api/span#root
        """

    sent = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (Span): The sentence span that the span is a part of."""

    sentiment = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (float): A scalar value indicating the positivity or
            negativity of the span.
        """

    start = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    start_char = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    string = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Deprecated: Use `Span.text_with_ws` instead."""

    subtree = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Tokens within the span and tokens which descend from them.

        YIELDS (Token): A token within the span, or a descendant from it.

        DOCS: https://spacy.io/api/span#subtree
        """

    text = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): The original verbatim text of the span."""

    text_with_ws = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The text content of the span with a trailing whitespace character if
        the last token has one.

        RETURNS (unicode): The text content of the span (with trailing
            whitespace).
        """

    upper_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Deprecated. Use `Span.text.upper()` instead."""

    vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A real-valued meaning representation. Defaults to an average of the
        token vectors.

        RETURNS (numpy.ndarray[ndim=1, dtype='float32']): A 1D numpy array
            representing the span's semantics.

        DOCS: https://spacy.io/api/span#vector
        """

    vector_norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The L2 norm of the span's vector representation.

        RETURNS (float): The L2 norm of the vector representation.

        DOCS: https://spacy.io/api/span#vector_norm
        """

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (Vocab): The Span's Doc's vocab."""

    _ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Custom extension attributes registered via `set_extension`."""

    _vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _vector_norm = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fa0a46565d0>'


class Underscore(object):
    # no doc
    def get(self, name): # reliably restored by inspect
        # no doc
        pass

    def has(self, name): # reliably restored by inspect
        # no doc
        pass

    def set(self, name, value): # reliably restored by inspect
        # no doc
        pass

    def _get_key(self, name): # reliably restored by inspect
        # no doc
        pass

    def __dir__(self): # reliably restored by inspect
        # no doc
        pass

    def __getattr__(self, name): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, extensions, obj, start=None, end=None): # reliably restored by inspect
        # no doc
        pass

    def __setattr__(self, name, value): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    doc_extensions = {}
    mutable_types = (
        dict,
        list,
        set,
    )
    span_extensions = {}
    token_extensions = {}
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.tokens.underscore', 'mutable_types': (<class 'dict'>, <class 'list'>, <class 'set'>), 'doc_extensions': {}, 'span_extensions': {}, 'token_extensions': {}, '__init__': <function Underscore.__init__ at 0x7fa0a464dd08>, '__dir__': <function Underscore.__dir__ at 0x7fa0a464dd90>, '__getattr__': <function Underscore.__getattr__ at 0x7fa0a464de18>, '__setattr__': <function Underscore.__setattr__ at 0x7fa0a464dea0>, 'set': <function Underscore.set at 0x7fa0a464df28>, 'get': <function Underscore.get at 0x7fa0a3f34048>, 'has': <function Underscore.has at 0x7fa0a3f340d0>, '_get_key': <function Underscore._get_key at 0x7fa0a3f34158>, '__dict__': <attribute '__dict__' of 'Underscore' objects>, '__weakref__': <attribute '__weakref__' of 'Underscore' objects>, '__doc__': None})"


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa0a3f1f358>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.tokens.span', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa0a3f1f358>, origin='/usr/local/lib/python3.6/dist-packages/spacy/tokens/span.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


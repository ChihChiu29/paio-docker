# encoding: utf-8
# module spacy.vectors
# from /usr/local/lib/python3.6/dist-packages/spacy/vectors.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import functools as functools # /usr/lib/python3.6/functools.py
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py
import srsly as srsly # /usr/local/lib/python3.6/dist-packages/srsly/__init__.py
import spacy.util as util # /usr/local/lib/python3.6/dist-packages/spacy/util.py
from spacy.strings import get_string_id


# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def path2str(path): # reliably restored by inspect
    # no doc
    pass

def unpickle_vectors(*args, **kwargs): # real signature unknown
    pass

# classes

class basestring_(object):
    """
    str(object='') -> str
    str(bytes_or_buffer[, encoding[, errors]]) -> str
    
    Create a new string object from the given object. If encoding or
    errors is specified, then the object must expose a data buffer
    that will be decoded using the given encoding and error handler.
    Otherwise, returns the result of object.__str__() (if defined)
    or repr(object).
    encoding defaults to sys.getdefaultencoding().
    errors defaults to 'strict'.
    """
    def capitalize(self): # real signature unknown; restored from __doc__
        """
        S.capitalize() -> str
        
        Return a capitalized version of S, i.e. make the first character
        have upper case and the rest lower case.
        """
        return ""

    def casefold(self): # real signature unknown; restored from __doc__
        """
        S.casefold() -> str
        
        Return a version of S suitable for caseless comparisons.
        """
        return ""

    def center(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.center(width[, fillchar]) -> str
        
        Return S centered in a string of length width. Padding is
        done using the specified fill character (default is a space)
        """
        return ""

    def count(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.count(sub[, start[, end]]) -> int
        
        Return the number of non-overlapping occurrences of substring sub in
        string S[start:end].  Optional arguments start and end are
        interpreted as in slice notation.
        """
        return 0

    def encode(self, encoding='utf-8', errors='strict'): # real signature unknown; restored from __doc__
        """
        S.encode(encoding='utf-8', errors='strict') -> bytes
        
        Encode S using the codec registered for encoding. Default encoding
        is 'utf-8'. errors may be given to set a different error
        handling scheme. Default is 'strict' meaning that encoding errors raise
        a UnicodeEncodeError. Other possible values are 'ignore', 'replace' and
        'xmlcharrefreplace' as well as any other name registered with
        codecs.register_error that can handle UnicodeEncodeErrors.
        """
        return b""

    def endswith(self, suffix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.endswith(suffix[, start[, end]]) -> bool
        
        Return True if S ends with the specified suffix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        suffix can also be a tuple of strings to try.
        """
        return False

    def expandtabs(self, tabsize=8): # real signature unknown; restored from __doc__
        """
        S.expandtabs(tabsize=8) -> str
        
        Return a copy of S where all tab characters are expanded using spaces.
        If tabsize is not given, a tab size of 8 characters is assumed.
        """
        return ""

    def find(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.find(sub[, start[, end]]) -> int
        
        Return the lowest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def format(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        S.format(*args, **kwargs) -> str
        
        Return a formatted version of S, using substitutions from args and kwargs.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def format_map(self, mapping): # real signature unknown; restored from __doc__
        """
        S.format_map(mapping) -> str
        
        Return a formatted version of S, using substitutions from mapping.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def index(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.index(sub[, start[, end]]) -> int
        
        Return the lowest index in S where substring sub is found, 
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Raises ValueError when the substring is not found.
        """
        return 0

    def isalnum(self): # real signature unknown; restored from __doc__
        """
        S.isalnum() -> bool
        
        Return True if all characters in S are alphanumeric
        and there is at least one character in S, False otherwise.
        """
        return False

    def isalpha(self): # real signature unknown; restored from __doc__
        """
        S.isalpha() -> bool
        
        Return True if all characters in S are alphabetic
        and there is at least one character in S, False otherwise.
        """
        return False

    def isdecimal(self): # real signature unknown; restored from __doc__
        """
        S.isdecimal() -> bool
        
        Return True if there are only decimal characters in S,
        False otherwise.
        """
        return False

    def isdigit(self): # real signature unknown; restored from __doc__
        """
        S.isdigit() -> bool
        
        Return True if all characters in S are digits
        and there is at least one character in S, False otherwise.
        """
        return False

    def isidentifier(self): # real signature unknown; restored from __doc__
        """
        S.isidentifier() -> bool
        
        Return True if S is a valid identifier according
        to the language definition.
        
        Use keyword.iskeyword() to test for reserved identifiers
        such as "def" and "class".
        """
        return False

    def islower(self): # real signature unknown; restored from __doc__
        """
        S.islower() -> bool
        
        Return True if all cased characters in S are lowercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def isnumeric(self): # real signature unknown; restored from __doc__
        """
        S.isnumeric() -> bool
        
        Return True if there are only numeric characters in S,
        False otherwise.
        """
        return False

    def isprintable(self): # real signature unknown; restored from __doc__
        """
        S.isprintable() -> bool
        
        Return True if all characters in S are considered
        printable in repr() or S is empty, False otherwise.
        """
        return False

    def isspace(self): # real signature unknown; restored from __doc__
        """
        S.isspace() -> bool
        
        Return True if all characters in S are whitespace
        and there is at least one character in S, False otherwise.
        """
        return False

    def istitle(self): # real signature unknown; restored from __doc__
        """
        S.istitle() -> bool
        
        Return True if S is a titlecased string and there is at least one
        character in S, i.e. upper- and titlecase characters may only
        follow uncased characters and lowercase characters only cased ones.
        Return False otherwise.
        """
        return False

    def isupper(self): # real signature unknown; restored from __doc__
        """
        S.isupper() -> bool
        
        Return True if all cased characters in S are uppercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def join(self, iterable): # real signature unknown; restored from __doc__
        """
        S.join(iterable) -> str
        
        Return a string which is the concatenation of the strings in the
        iterable.  The separator between elements is S.
        """
        return ""

    def ljust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.ljust(width[, fillchar]) -> str
        
        Return S left-justified in a Unicode string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def lower(self): # real signature unknown; restored from __doc__
        """
        S.lower() -> str
        
        Return a copy of the string S converted to lowercase.
        """
        return ""

    def lstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.lstrip([chars]) -> str
        
        Return a copy of the string S with leading whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def maketrans(self, *args, **kwargs): # real signature unknown
        """
        Return a translation table usable for str.translate().
        
        If there is only one argument, it must be a dictionary mapping Unicode
        ordinals (integers) or characters to Unicode ordinals, strings or None.
        Character keys will be then converted to ordinals.
        If there are two arguments, they must be strings of equal length, and
        in the resulting dictionary, each character in x will be mapped to the
        character at the same position in y. If there is a third argument, it
        must be a string, whose characters will be mapped to None in the result.
        """
        pass

    def partition(self, sep): # real signature unknown; restored from __doc__
        """
        S.partition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, and return the part before it,
        the separator itself, and the part after it.  If the separator is not
        found, return S and two empty strings.
        """
        pass

    def replace(self, old, new, count=None): # real signature unknown; restored from __doc__
        """
        S.replace(old, new[, count]) -> str
        
        Return a copy of S with all occurrences of substring
        old replaced by new.  If the optional argument count is
        given, only the first count occurrences are replaced.
        """
        return ""

    def rfind(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rfind(sub[, start[, end]]) -> int
        
        Return the highest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def rindex(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rindex(sub[, start[, end]]) -> int
        
        Return the highest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Raises ValueError when the substring is not found.
        """
        return 0

    def rjust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.rjust(width[, fillchar]) -> str
        
        Return S right-justified in a string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def rpartition(self, sep): # real signature unknown; restored from __doc__
        """
        S.rpartition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, starting at the end of S, and return
        the part before it, the separator itself, and the part after it.  If the
        separator is not found, return two empty strings and S.
        """
        pass

    def rsplit(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.rsplit(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string, starting at the end of the string and
        working to the front.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified, any whitespace string
        is a separator.
        """
        return []

    def rstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.rstrip([chars]) -> str
        
        Return a copy of the string S with trailing whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def split(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.split(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified or is None, any
        whitespace string is a separator and empty strings are
        removed from the result.
        """
        return []

    def splitlines(self, keepends=None): # real signature unknown; restored from __doc__
        """
        S.splitlines([keepends]) -> list of strings
        
        Return a list of the lines in S, breaking at line boundaries.
        Line breaks are not included in the resulting list unless keepends
        is given and true.
        """
        return []

    def startswith(self, prefix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.startswith(prefix[, start[, end]]) -> bool
        
        Return True if S starts with the specified prefix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        prefix can also be a tuple of strings to try.
        """
        return False

    def strip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.strip([chars]) -> str
        
        Return a copy of the string S with leading and trailing
        whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def swapcase(self): # real signature unknown; restored from __doc__
        """
        S.swapcase() -> str
        
        Return a copy of S with uppercase characters converted to lowercase
        and vice versa.
        """
        return ""

    def title(self): # real signature unknown; restored from __doc__
        """
        S.title() -> str
        
        Return a titlecased version of S, i.e. words start with title case
        characters, all remaining cased characters have lower case.
        """
        return ""

    def translate(self, table): # real signature unknown; restored from __doc__
        """
        S.translate(table) -> str
        
        Return a copy of the string S in which each character has been mapped
        through the given translation table. The table must implement
        lookup/indexing via __getitem__, for instance a dictionary or list,
        mapping Unicode ordinals to Unicode ordinals, strings, or None. If
        this operation raises LookupError, the character is left untouched.
        Characters mapped to None are deleted.
        """
        return ""

    def upper(self): # real signature unknown; restored from __doc__
        """
        S.upper() -> str
        
        Return a copy of S converted to uppercase.
        """
        return ""

    def zfill(self, width): # real signature unknown; restored from __doc__
        """
        S.zfill(width) -> str
        
        Pad a numeric string S with zeros on the left, to fill a field
        of the specified width. The string S is never truncated.
        """
        return ""

    def __add__(self, *args, **kwargs): # real signature unknown
        """ Return self+value. """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """ Return key in self. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __format__(self, format_spec): # real signature unknown; restored from __doc__
        """
        S.__format__(format_spec) -> str
        
        Return a formatted version of S as described by format_spec.
        """
        return ""

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __getnewargs__(self, *args, **kwargs): # real signature unknown
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __mod__(self, *args, **kwargs): # real signature unknown
        """ Return self%value. """
        pass

    def __mul__(self, *args, **kwargs): # real signature unknown
        """ Return self*value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __rmod__(self, *args, **kwargs): # real signature unknown
        """ Return value%self. """
        pass

    def __rmul__(self, *args, **kwargs): # real signature unknown
        """ Return value*self. """
        pass

    def __sizeof__(self): # real signature unknown; restored from __doc__
        """ S.__sizeof__() -> size of S in memory, in bytes """
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """ Return str(self). """
        pass


class GlobalRegistry(object):
    """ Global store of vectors, to avoid repeatedly loading the data. """
    @classmethod
    def get(cls, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def register(cls, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    data = {}
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.vectors', '__doc__': 'Global store of vectors, to avoid repeatedly loading the data.', 'data': {}, 'register': <classmethod object at 0x7f280bc510b8>, 'get': <classmethod object at 0x7f280bc51048>, '__dict__': <attribute '__dict__' of 'GlobalRegistry' objects>, '__weakref__': <attribute '__weakref__' of 'GlobalRegistry' objects>})"


class Model(object):
    """ Model base class. """
    def begin_training(self, train_X, train_y=None, **trainer_cfg): # reliably restored by inspect
        # no doc
        pass

    def begin_update(self, X, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def define_operators(cls, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        Bind operators to specified functions for the scope of the context:
        
                Example
                -------
        
                    model = Model()
                    other = Model()
                    with Model.define_operators({"+": lambda self, other: "plus"}):
                        print(model + other)
                        # "plus"
                    print(model + other)
                    # Raises TypeError --- binding limited to scope of with block.
        """
        pass

    def evaluate(self, X, y): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
                y
                    Must match expected type
        """
        pass

    def evaluate_logloss(self, X, y, minimum=None, maximum=None): # reliably restored by inspect
        # no doc
        pass

    def from_bytes(self, bytes_data): # reliably restored by inspect
        # no doc
        pass

    def from_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def pipe(self, stream, batch_size=128): # reliably restored by inspect
        # no doc
        pass

    def predict(self, X): # reliably restored by inspect
        # no doc
        pass

    def predict_one(self, x): # reliably restored by inspect
        # no doc
        pass

    def set_id(self): # reliably restored by inspect
        # no doc
        pass

    def to_bytes(self): # reliably restored by inspect
        # no doc
        pass

    def to_cpu(self): # reliably restored by inspect
        # no doc
        pass

    def to_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def to_gpu(self, device_num): # reliably restored by inspect
        # no doc
        pass

    def update(self, stream, batch_size=1000): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def use_device(cls, *args, **kwargs): # real signature unknown
        """ Change the device to execute on for the scope of the block. """
        pass

    def use_params(*args, **kwds): # reliably restored by inspect
        # no doc
        pass

    def _update_defaults(self, args, kwargs): # reliably restored by inspect
        # no doc
        pass

    def __add__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '+' operator. """
        pass

    def __and__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '&' operator. """
        pass

    def __call__(self, x): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
        """
        pass

    def __div__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __floordiv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '//' operator. """
        pass

    def __getstate__(self): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    def __lshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '<<' operator. """
        pass

    def __matmul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '@' operator. """
        pass

    def __mod__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '%' operator. """
        pass

    def __mul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '*' operator. """
        pass

    def __or__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '|' operator. """
        pass

    def __pow__(self, other, modulo=None): # reliably restored by inspect
        """ Apply the function bound to the '**' operator. """
        pass

    def __rshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '>>' operator. """
        pass

    def __setstate__(self, state_data): # reliably restored by inspect
        # no doc
        pass

    def __sub__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '-' operator. """
        pass

    def __truediv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __xor__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '^' operator. """
        pass

    input_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    descriptions = []
    drop_factor = 1.0
    id = 11
    lsuv = False
    name = 'model'
    on_data_hooks = []
    on_init_hooks = []
    ops = None # (!) real value is '<thinc.neural.ops.NumpyOps object at 0x7f2853f9cb00>'
    Ops = util.NumpyOps
    Trainer = None # (!) real value is "<class 'thinc.neural.train.Trainer'>"
    _operators = {}
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'thinc.neural._classes.model', '__doc__': 'Model base class.', 'name': 'model', 'id': 11, 'lsuv': False, 'ops': <thinc.neural.ops.NumpyOps object at 0x7f2853f9cb00>, 'Ops': <class 'thinc.neural.ops.NumpyOps'>, 'Trainer': <class 'thinc.neural.train.Trainer'>, 'drop_factor': 1.0, 'descriptions': [], 'on_data_hooks': [], 'on_init_hooks': [], '_operators': {}, 'define_operators': <classmethod object at 0x7f2853f9cb38>, 'use_device': <classmethod object at 0x7f2853f9cc18>, 'input_shape': <property object at 0x7f28505cc958>, 'output_shape': <property object at 0x7f2850390c78>, '__init__': <function Model.__init__ at 0x7f2850399598>, '__getstate__': <function Model.__getstate__ at 0x7f2850399620>, '__setstate__': <function Model.__setstate__ at 0x7f28503996a8>, '_update_defaults': <function Model._update_defaults at 0x7f2850399730>, 'set_id': <function Model.set_id at 0x7f28503997b8>, 'begin_training': <FunctionWrapper at 0x7f2850381528 for function at 0x7f2850399a60>, 'begin_update': <FunctionWrapper at 0x7f2850381800 for function at 0x7f2850399e18>, 'predict': <function Model.predict at 0x7f2850399ae8>, 'predict_one': <function Model.predict_one at 0x7f28503998c8>, 'use_params': <function Model.use_params at 0x7f28503999d8>, '__call__': <function Model.__call__ at 0x7f2850399d90>, 'pipe': <function Model.pipe at 0x7f2850399d08>, 'update': <function Model.update at 0x7f2850399c80>, 'to_gpu': <function Model.to_gpu at 0x7f2850399ea0>, 'to_cpu': <function Model.to_cpu at 0x7f2850399f28>, 'evaluate': <function Model.evaluate at 0x7f285039a048>, 'evaluate_logloss': <function Model.evaluate_logloss at 0x7f285039a0d0>, '__add__': <FunctionWrapper at 0x7f2850381798 for function at 0x7f285039a2f0>, '__sub__': <FunctionWrapper at 0x7f2850381868 for function at 0x7f285039a400>, '__mul__': <FunctionWrapper at 0x7f28503818d0 for function at 0x7f285039a510>, '__matmul__': <FunctionWrapper at 0x7f2850381938 for function at 0x7f285039a620>, '__div__': <FunctionWrapper at 0x7f28503819a0 for function at 0x7f285039a730>, '__truediv__': <FunctionWrapper at 0x7f2850381a08 for function at 0x7f285039a840>, '__floordiv__': <FunctionWrapper at 0x7f2850381a70 for function at 0x7f285039a950>, '__mod__': <FunctionWrapper at 0x7f2850381ad8 for function at 0x7f285039aa60>, '__pow__': <FunctionWrapper at 0x7f2850381b40 for function at 0x7f285039ab70>, '__lshift__': <FunctionWrapper at 0x7f2850381ba8 for function at 0x7f285039ac80>, '__rshift__': <FunctionWrapper at 0x7f2850381c10 for function at 0x7f285039ad90>, '__and__': <FunctionWrapper at 0x7f2850381c78 for function at 0x7f285039aea0>, '__xor__': <FunctionWrapper at 0x7f2850381ce0 for function at 0x7f285039c048>, '__or__': <FunctionWrapper at 0x7f2850381d48 for function at 0x7f285039c158>, 'to_bytes': <function Model.to_bytes at 0x7f285039a1e0>, 'from_bytes': <function Model.from_bytes at 0x7f285039c0d0>, 'to_disk': <function Model.to_disk at 0x7f285039c1e0>, 'from_disk': <function Model.from_disk at 0x7f285039c268>, '__dict__': <attribute '__dict__' of 'Model' objects>, '__weakref__': <attribute '__weakref__' of 'Model' objects>})"


class OrderedDict(dict):
    """ Dictionary that remembers insertion order """
    def clear(self): # real signature unknown; restored from __doc__
        """ od.clear() -> None.  Remove all items from od. """
        pass

    def copy(self): # real signature unknown; restored from __doc__
        """ od.copy() -> a shallow copy of od """
        pass

    @classmethod
    def fromkeys(cls, S, v=None): # real signature unknown; restored from __doc__
        """
        OD.fromkeys(S[, v]) -> New ordered dictionary with keys from S.
                If not specified, the value defaults to None.
        """
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def move_to_end(self, *args, **kwargs): # real signature unknown
        """
        Move an existing element to the end (or beginning if last==False).
        
                Raises KeyError if the element does not exist.
                When last=True, acts like a fast version of self[key]=self.pop(key).
        """
        pass

    def pop(self, k, d=None): # real signature unknown; restored from __doc__
        """
        od.pop(k[,d]) -> v, remove specified key and return the corresponding
                value.  If key is not found, d is returned if given, otherwise KeyError
                is raised.
        """
        pass

    def popitem(self, *args, **kwargs): # real signature unknown
        """
        Remove and return a (key, value) pair from the dictionary.
        
        Pairs are returned in LIFO order if last is true or FIFO order if false.
        """
        pass

    def setdefault(self, k, d=None): # real signature unknown; restored from __doc__
        """ od.setdefault(k[,d]) -> od.get(k,d), also set od[k]=d if k not in od """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __reversed__(self): # real signature unknown; restored from __doc__
        """ od.__reversed__() <==> reversed(od) """
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """ Set self[key] to value. """
        pass

    def __sizeof__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is "mappingproxy({'__repr__': <slot wrapper '__repr__' of 'collections.OrderedDict' objects>, '__lt__': <slot wrapper '__lt__' of 'collections.OrderedDict' objects>, '__le__': <slot wrapper '__le__' of 'collections.OrderedDict' objects>, '__eq__': <slot wrapper '__eq__' of 'collections.OrderedDict' objects>, '__ne__': <slot wrapper '__ne__' of 'collections.OrderedDict' objects>, '__gt__': <slot wrapper '__gt__' of 'collections.OrderedDict' objects>, '__ge__': <slot wrapper '__ge__' of 'collections.OrderedDict' objects>, '__iter__': <slot wrapper '__iter__' of 'collections.OrderedDict' objects>, '__init__': <slot wrapper '__init__' of 'collections.OrderedDict' objects>, '__setitem__': <slot wrapper '__setitem__' of 'collections.OrderedDict' objects>, '__delitem__': <slot wrapper '__delitem__' of 'collections.OrderedDict' objects>, 'fromkeys': <method 'fromkeys' of 'collections.OrderedDict' objects>, '__sizeof__': <method '__sizeof__' of 'collections.OrderedDict' objects>, '__reduce__': <method '__reduce__' of 'collections.OrderedDict' objects>, 'setdefault': <method 'setdefault' of 'collections.OrderedDict' objects>, 'pop': <method 'pop' of 'collections.OrderedDict' objects>, 'popitem': <method 'popitem' of 'collections.OrderedDict' objects>, 'keys': <method 'keys' of 'collections.OrderedDict' objects>, 'values': <method 'values' of 'collections.OrderedDict' objects>, 'items': <method 'items' of 'collections.OrderedDict' objects>, 'update': <method 'update' of 'collections.OrderedDict' objects>, 'clear': <method 'clear' of 'collections.OrderedDict' objects>, 'copy': <method 'copy' of 'collections.OrderedDict' objects>, '__reversed__': <method '__reversed__' of 'collections.OrderedDict' objects>, 'move_to_end': <method 'move_to_end' of 'collections.OrderedDict' objects>, '__dict__': <attribute '__dict__' of 'collections.OrderedDict' objects>, '__doc__': 'Dictionary that remembers insertion order', '__hash__': None})"
    __hash__ = None


class Vectors(object):
    """
    Store, save and load word vectors.
    
        Vectors data is kept in the vectors.data attribute, which should be an
        instance of numpy.ndarray (for CPU vectors) or cupy.ndarray
        (for GPU vectors). `vectors.key2row` is a dictionary mapping word hashes to
        rows in the vectors.data table.
    
        Multiple keys can be mapped to the same vector, and not all of the rows in
        the table need to be assigned - so len(list(vectors.keys())) may be
        greater or smaller than vectors.shape[0].
    
        DOCS: https://spacy.io/api/vectors
    """
    def add(self, *args, **kwargs): # real signature unknown
        """
        Add a key to the table. Keys can be mapped to an existing vector
                by setting `row`, or a new vector can be added.
        
                key (int): The key to add.
                vector (ndarray / None): A vector to add for the key.
                row (int / None): The row number of a vector to map the key to.
                RETURNS (int): The row the vector was added to.
        
                DOCS: https://spacy.io/api/vectors#add
        """
        pass

    def find(self, *args, **kwargs): # real signature unknown
        """
        Look up one or more keys by row, or vice versa.
        
                key (unicode / int): Find the row that the given key points to.
                    Returns int, -1 if missing.
                keys (iterable): Find rows that the keys point to.
                    Returns ndarray.
                row (int): Find the first key that points to the row.
                    Returns int.
                rows (iterable): Find the keys that point to the rows.
                    Returns ndarray.
                RETURNS: The requested key, keys, row or rows.
        """
        pass

    def from_bytes(self, *args, **kwargs): # real signature unknown
        """
        Load state from a binary string.
        
                data (bytes): The data to load from.
                exclude (list): String names of serialization fields to exclude.
                RETURNS (Vectors): The `Vectors` object.
        
                DOCS: https://spacy.io/api/vectors#from_bytes
        """
        pass

    def from_disk(self, *args, **kwargs): # real signature unknown
        """
        Loads state from a directory. Modifies the object in place and
                returns it.
        
                path (unicode / Path): Directory path, string or Path-like object.
                RETURNS (Vectors): The modified object.
        
                DOCS: https://spacy.io/api/vectors#from_disk
        """
        pass

    def from_glove(self, *args, **kwargs): # real signature unknown
        """
        Load GloVe vectors from a directory. Assumes binary format,
                that the vocab is in a vocab.txt, and that vectors are named
                vectors.{size}.[fd].bin, e.g. vectors.128.f.bin for 128d float32
                vectors, vectors.300.d.bin for 300d float64 (double) vectors, etc.
                By default GloVe outputs 64-bit vectors.
        
                path (unicode / Path): The path to load the GloVe vectors from.
                RETURNS: A `StringStore` object, holding the key-to-string mapping.
        
                DOCS: https://spacy.io/api/vectors#from_glove
        """
        pass

    def items(self, *args, **kwargs): # real signature unknown
        """
        Iterate over `(key, vector)` pairs.
        
                YIELDS (tuple): A key/vector pair.
        
                DOCS: https://spacy.io/api/vectors#items
        """
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        """ RETURNS (iterable): A sequence of keys in the table. """
        pass

    def most_similar(self, *args, **kwargs): # real signature unknown
        """
        For each of the given vectors, find the single entry most similar
                to it, by cosine.
        
                Queries are by vector. Results are returned as a `(keys, best_rows,
                scores)` tuple. If `queries` is large, the calculations are performed in
                chunks, to avoid consuming too much memory. You can set the `batch_size`
                to control the size/space trade-off during the calculations.
        
                queries (ndarray): An array with one or more vectors.
                batch_size (int): The batch size to use.
                RETURNS (tuple): The most similar entry as a `(keys, best_rows, scores)`
                    tuple.
        """
        pass

    def resize(self, *args, **kwargs): # real signature unknown
        """
        Resize the underlying vectors array. If inplace=True, the memory
                is reallocated. This may cause other references to the data to become
                invalid, so only use inplace=True if you're sure that's what you want.
        
                If the number of vectors is reduced, keys mapped to rows that have been
                deleted are removed. These removed items are returned as a list of
                `(key, row)` tuples.
        
                shape (tuple): A `(rows, dims)` tuple.
                inplace (bool): Reallocate the memory.
                RETURNS (list): The removed items as a list of `(key, row)` tuples.
        
                DOCS: https://spacy.io/api/vectors#resize
        """
        pass

    def to_bytes(self, *args, **kwargs): # real signature unknown
        """
        Serialize the current state to a binary string.
        
                exclude (list): String names of serialization fields to exclude.
                RETURNS (bytes): The serialized form of the `Vectors` object.
        
                DOCS: https://spacy.io/api/vectors#to_bytes
        """
        pass

    def to_disk(self, *args, **kwargs): # real signature unknown
        """
        Save the current state to a directory.
        
                path (unicode / Path): A path to a directory, which will be created if
                    it doesn't exists.
        
                DOCS: https://spacy.io/api/vectors#to_disk
        """
        pass

    def values(self, *args, **kwargs): # real signature unknown
        """
        Iterate over vectors that have been assigned to at least one key.
        
                Note that some vectors may be unassigned, so the number of vectors
                returned may be less than the length of the vectors table.
        
                YIELDS (ndarray): A vector in the table.
        
                DOCS: https://spacy.io/api/vectors#values
        """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """
        Check whether a key has been mapped to a vector entry in the table.
        
                key (int): The key to check.
                RETURNS (bool): Whether the key has a vector entry.
        
                DOCS: https://spacy.io/api/vectors#contains
        """
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """
        Get a vector by key. If the key is not found, a KeyError is raised.
        
                key (int): The key to get the vector for.
                RETURNS (ndarray): The vector for the key.
        
                DOCS: https://spacy.io/api/vectors#getitem
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create a new vector store.
        
                shape (tuple): Size of the table, as (# entries, # columns)
                data (numpy.ndarray): The vector data.
                keys (iterable): A sequence of keys, aligned with the data.
                name (string): A name to identify the vectors table.
                RETURNS (Vectors): The newly created object.
        
                DOCS: https://spacy.io/api/vectors#init
        """
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """
        Iterate over the keys in the table.
        
                YIELDS (int): A key in the table.
        
                DOCS: https://spacy.io/api/vectors#iter
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        Return the number of vectors in the table.
        
                RETURNS (int): The number of vectors in the data.
        
                DOCS: https://spacy.io/api/vectors#len
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """
        Set a vector for the given key.
        
                key (int): The key to set the vector for.
                vector (ndarray): The vector to set.
        
                DOCS: https://spacy.io/api/vectors#setitem
        """
        pass

    data = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    is_full = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Whether the vectors table is full.

        RETURNS (bool): `True` if no slots are available for new keys.

        DOCS: https://spacy.io/api/vectors#is_full
        """

    key2row = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    n_keys = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Get the number of keys in the table. Note that this is the number
        of all keys, not just unique vectors.

        RETURNS (int): The number of keys in the table.

        DOCS: https://spacy.io/api/vectors#n_keys
        """

    shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Get `(rows, dims)` tuples of number of rows and number of dimensions
        in the vector table.

        RETURNS (tuple): A `(rows, dims)` pair.

        DOCS: https://spacy.io/api/vectors#shape
        """

    size = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """The vector size i,e. rows * dims.

        RETURNS (int): The vector size.

        DOCS: https://spacy.io/api/vectors#size
        """



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f280bc45ba8>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.vectors', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f280bc45ba8>, origin='/usr/local/lib/python3.6/dist-packages/spacy/vectors.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


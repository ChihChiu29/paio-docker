# encoding: utf-8
# module spacy.kb
# from /usr/local/lib/python3.6/dist-packages/spacy/kb.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import posixpath as path # /usr/lib/python3.6/posixpath.py
import pathlib as __pathlib


# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def user_warning(message): # reliably restored by inspect
    # no doc
    pass

def Warnings(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def __pyx_unpickle_Candidate(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_KnowledgeBase(*args, **kwargs): # real signature unknown
    pass

# classes

class Candidate(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    alias = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): hash of the alias"""

    alias_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): ID of the original alias"""

    entity = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): hash of the entity's KB ID/name"""

    entity_ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (unicode): ID/name of this entity in the KB"""

    entity_freq = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    entity_vector = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    kb = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    prior_prob = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class KnowledgeBase(object):
    # no doc
    def add_alias(self, *args, **kwargs): # real signature unknown
        """
        For a given alias, add its potential entities and prior probabilies to the KB.
                Return the alias_hash at the end
        """
        pass

    def add_entity(self, *args, **kwargs): # real signature unknown
        """
        Add an entity to the KB, optionally specifying its log probability based on corpus frequency
                Return the hash of the entity ID/name at the end.
        """
        pass

    def dump(self, *args, **kwargs): # real signature unknown
        pass

    def get_alias_strings(self, *args, **kwargs): # real signature unknown
        pass

    def get_candidates(self, *args, **kwargs): # real signature unknown
        pass

    def get_entity_strings(self, *args, **kwargs): # real signature unknown
        pass

    def get_size_aliases(self, *args, **kwargs): # real signature unknown
        pass

    def get_size_entities(self, *args, **kwargs): # real signature unknown
        pass

    def load_bulk(self, *args, **kwargs): # real signature unknown
        pass

    def set_entities(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    entity_vector_length = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """RETURNS (uint64): length of the entity vectors"""

    vocab = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fa4c5ca0600>'


class Path(__pathlib.PurePath):
    """
    PurePath subclass that can make system calls.
    
        Path represents a filesystem path but unlike PurePath, also offers
        methods to do system calls on path objects. Depending on your system,
        instantiating a Path will return either a PosixPath or a WindowsPath
        object. You can also instantiate a PosixPath or WindowsPath directly,
        but cannot instantiate a WindowsPath on a POSIX system or vice versa.
    """
    def absolute(self): # reliably restored by inspect
        """
        Return an absolute version of this path.  This function works
                even if the path doesn't point to anything.
        
                No normalization is done, i.e. all '.' and '..' will be kept along.
                Use resolve() to get the canonical path to a file.
        """
        pass

    def chmod(self, mode): # reliably restored by inspect
        """ Change the permissions of the path, like os.chmod(). """
        pass

    @classmethod
    def cwd(cls): # real signature unknown; restored from __doc__
        """
        Return a new path pointing to the current working directory
                (as returned by os.getcwd()).
        """
        pass

    def exists(self): # reliably restored by inspect
        """ Whether this path exists. """
        pass

    def expanduser(self): # reliably restored by inspect
        """
        Return a new path with expanded ~ and ~user constructs
                (as returned by os.path.expanduser)
        """
        pass

    def glob(self, pattern): # reliably restored by inspect
        """
        Iterate over this subtree and yield all existing files (of any
                kind, including directories) matching the given pattern.
        """
        pass

    def group(self): # reliably restored by inspect
        """ Return the group name of the file gid. """
        pass

    @classmethod
    def home(cls, *args, **kwargs): # real signature unknown
        """
        Return a new path pointing to the user's home directory (as
                returned by os.path.expanduser('~')).
        """
        pass

    def is_block_device(self): # reliably restored by inspect
        """ Whether this path is a block device. """
        pass

    def is_char_device(self): # reliably restored by inspect
        """ Whether this path is a character device. """
        pass

    def is_dir(self): # reliably restored by inspect
        """ Whether this path is a directory. """
        pass

    def is_fifo(self): # reliably restored by inspect
        """ Whether this path is a FIFO. """
        pass

    def is_file(self): # reliably restored by inspect
        """
        Whether this path is a regular file (also True for symlinks pointing
                to regular files).
        """
        pass

    def is_socket(self): # reliably restored by inspect
        """ Whether this path is a socket. """
        pass

    def is_symlink(self): # reliably restored by inspect
        """ Whether this path is a symbolic link. """
        pass

    def iterdir(self): # reliably restored by inspect
        """
        Iterate over the files in this directory.  Does not yield any
                result for the special paths '.' and '..'.
        """
        pass

    def lchmod(self, mode): # reliably restored by inspect
        """
        Like chmod(), except if the path points to a symlink, the symlink's
                permissions are changed, rather than its target's.
        """
        pass

    def lstat(self): # reliably restored by inspect
        """
        Like stat(), except if the path points to a symlink, the symlink's
                status information is returned, rather than its target's.
        """
        pass

    def mkdir(self, mode=511, parents=False, exist_ok=False): # reliably restored by inspect
        """ Create a new directory at this given path. """
        pass

    def open(self, mode=None, buffering=-1, encoding=None, errors=None, newline=None): # reliably restored by inspect
        """
        Open the file pointed by this path and return a file object, as
                the built-in open() function does.
        """
        pass

    def owner(self): # reliably restored by inspect
        """ Return the login name of the file owner. """
        pass

    def read_bytes(self): # reliably restored by inspect
        """ Open the file in bytes mode, read it, and close the file. """
        pass

    def read_text(self, encoding=None, errors=None): # reliably restored by inspect
        """ Open the file in text mode, read it, and close the file. """
        pass

    def rename(self, target): # reliably restored by inspect
        """ Rename this path to the given path. """
        pass

    def replace(self, target): # reliably restored by inspect
        """
        Rename this path to the given path, clobbering the existing
                destination if it exists.
        """
        pass

    def resolve(self, strict=False): # reliably restored by inspect
        """
        Make the path absolute, resolving all symlinks on the way and also
                normalizing it (for example turning slashes into backslashes under
                Windows).
        """
        pass

    def rglob(self, pattern): # reliably restored by inspect
        """
        Recursively yield all existing files (of any kind, including
                directories) matching the given pattern, anywhere in this subtree.
        """
        pass

    def rmdir(self): # reliably restored by inspect
        """ Remove this directory.  The directory must be empty. """
        pass

    def samefile(self, other_path): # reliably restored by inspect
        """
        Return whether other_path is the same or not as this file
                (as returned by os.path.samefile()).
        """
        pass

    def stat(self): # reliably restored by inspect
        """
        Return the result of the stat() system call on this path, like
                os.stat() does.
        """
        pass

    def symlink_to(self, target, target_is_directory=False): # reliably restored by inspect
        """
        Make this path a symlink pointing to the given path.
                Note the order of arguments (self, target) is the reverse of os.symlink's.
        """
        pass

    def touch(self, mode=438, exist_ok=True): # reliably restored by inspect
        """ Create this file with the given access mode, if it doesn't exist. """
        pass

    def unlink(self): # reliably restored by inspect
        """
        Remove this file or link.
                If the path is a directory, use rmdir() instead.
        """
        pass

    def write_bytes(self, data): # reliably restored by inspect
        """ Open the file in bytes mode, write to it, and close the file. """
        pass

    def write_text(self, data, encoding=None, errors=None): # reliably restored by inspect
        """ Open the file in text mode, write to it, and close the file. """
        pass

    def _init(self, template=None): # reliably restored by inspect
        # no doc
        pass

    def _make_child_relpath(self, part): # reliably restored by inspect
        # no doc
        pass

    def _opener(self, name, flags, mode=438): # reliably restored by inspect
        # no doc
        pass

    def _raise_closed(self): # reliably restored by inspect
        # no doc
        pass

    def _raw_open(self, flags, mode=511): # reliably restored by inspect
        """
        Open the file pointed by this path and return a file descriptor,
                as os.open() does.
        """
        pass

    def __enter__(self): # reliably restored by inspect
        # no doc
        pass

    def __exit__(self, t, v, tb): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(cls, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    _accessor = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    _closed = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __slots__ = (
        '_accessor',
        '_closed',
    )


class Reader(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fa4c5ca0660>'


class Writer(object):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fa4c5ca0630>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa51b59e978>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.kb', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa51b59e978>, origin='/usr/local/lib/python3.6/dist-packages/spacy/kb.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


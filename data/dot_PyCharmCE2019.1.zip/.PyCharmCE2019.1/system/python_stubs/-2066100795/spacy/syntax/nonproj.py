# encoding: utf-8
# module spacy.syntax.nonproj
# from /usr/local/lib/python3.6/dist-packages/spacy/syntax/nonproj.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
"""
Implements the projectivize/deprojectivize mechanism in Nivre & Nilsson 2005
for doing pseudo-projective parsing implementation uses the HEAD decoration
scheme.
"""

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values

DELIMITER = '||'

# functions

def ancestors(*args, **kwargs): # real signature unknown
    pass

def contains_cycle(*args, **kwargs): # real signature unknown
    pass

def copy(x): # reliably restored by inspect
    """
    Shallow copy operation on arbitrary Python objects.
    
        See the module's __doc__ string for more info.
    """
    pass

def count_decorated_labels(*args, **kwargs): # real signature unknown
    pass

def decompose(*args, **kwargs): # real signature unknown
    pass

def deprojectivize(*args, **kwargs): # real signature unknown
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def is_decorated(*args, **kwargs): # real signature unknown
    pass

def is_nonproj_arc(*args, **kwargs): # real signature unknown
    pass

def is_nonproj_tree(*args, **kwargs): # real signature unknown
    pass

def preprocess_training_data(*args, **kwargs): # real signature unknown
    pass

def projectivize(*args, **kwargs): # real signature unknown
    pass

def _decorate(*args, **kwargs): # real signature unknown
    pass

def _filter_labels(*args, **kwargs): # real signature unknown
    pass

def _find_new_head(*args, **kwargs): # real signature unknown
    pass

def _get_smallest_nonproj_arc(*args, **kwargs): # real signature unknown
    pass

def _lift(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9e2acb0908>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.syntax.nonproj', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9e2acb0908>, origin='/usr/local/lib/python3.6/dist-packages/spacy/syntax/nonproj.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


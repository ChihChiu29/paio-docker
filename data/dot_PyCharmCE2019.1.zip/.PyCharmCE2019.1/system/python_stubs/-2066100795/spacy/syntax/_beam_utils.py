# encoding: utf-8
# module spacy.syntax._beam_utils
# from /usr/local/lib/python3.6/dist-packages/spacy/syntax/_beam_utils.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py

# Variables with simple values

nr_update = 0

# functions

def cleanup_beam(*args, **kwargs): # real signature unknown
    pass

def collect_states(*args, **kwargs): # real signature unknown
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_gradient(*args, **kwargs): # real signature unknown
    """
    The global model assigns a loss to each parse. The beam scores
        are additive, so the same gradient is applied to each action
        in the history. This gives the gradient of a single *action*
        for a beam state -- so we have "the gradient of loss for taking
        action i given history H."
    
        Histories: Each hitory is a list of actions
        Each candidate has a history
        Each beam has multiple candidates
        Each batch has multiple beams
        So history is list of lists of lists of ints
    """
    pass

def get_states(*args, **kwargs): # real signature unknown
    pass

def get_token_ids(*args, **kwargs): # real signature unknown
    pass

def update_beam(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_ParserBeam(*args, **kwargs): # real signature unknown
    pass

# classes

class ParserBeam(object):
    # no doc
    def advance(self, *args, **kwargs): # real signature unknown
        pass

    def _set_costs(self, *args, **kwargs): # real signature unknown
        pass

    def _set_scores(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    beams = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    dones = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    golds = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    is_done = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    moves = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    states = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f0f596f3780>'

__pyx_capi__ = {
    'check_final_state': None, # (!) real value is '<capsule object "int (void *, void *)" at 0x7f0f596ea540>'
    'hash_state': None, # (!) real value is '<capsule object "__pyx_t_5thinc_8typedefs_hash_t (void *, void *)" at 0x7f0f596ea570>'
    'transition_state': None, # (!) real value is '<capsule object "int (void *, void *, __pyx_t_5thinc_8typedefs_class_t, void *)" at 0x7f0f596ea510>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.syntax._beam_utils', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f0f596f3780>, origin='/usr/local/lib/python3.6/dist-packages/spacy/syntax/_beam_utils.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


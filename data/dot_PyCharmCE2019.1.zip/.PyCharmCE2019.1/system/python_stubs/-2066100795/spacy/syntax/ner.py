# encoding: utf-8
# module spacy.syntax.ner
# from /usr/local/lib/python3.6/dist-packages/spacy/syntax/ner.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import spacy.syntax.transition_system as __spacy_syntax_transition_system


# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def __pyx_unpickle_Begin(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_In(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Last(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Missing(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Out(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Unit(*args, **kwargs): # real signature unknown
    pass

# classes

class Begin(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f187a5e8660>'


class BiluoPushDown(__spacy_syntax_transition_system.TransitionSystem):
    # no doc
    def add_action(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def get_actions(cls, *args, **kwargs): # real signature unknown
        pass

    def get_beam_annot(self, *args, **kwargs): # real signature unknown
        pass

    def get_beam_parses(self, *args, **kwargs): # real signature unknown
        pass

    def has_gold(self, *args, **kwargs): # real signature unknown
        pass

    def move_name(self, *args, **kwargs): # real signature unknown
        pass

    def preprocess_gold(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce_cython__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate_cython__(self, *args, **kwargs): # real signature unknown
        pass

    action_types = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f187a5e8600>'


class Counter(dict):
    """
    Dict subclass for counting hashable items.  Sometimes called a bag
        or multiset.  Elements are stored as dictionary keys and their counts
        are stored as dictionary values.
    
        >>> c = Counter('abcdeabcdabcaba')  # count elements from a string
    
        >>> c.most_common(3)                # three most common elements
        [('a', 5), ('b', 4), ('c', 3)]
        >>> sorted(c)                       # list all unique elements
        ['a', 'b', 'c', 'd', 'e']
        >>> ''.join(sorted(c.elements()))   # list elements with repetitions
        'aaaaabbbbcccdde'
        >>> sum(c.values())                 # total of all counts
        15
    
        >>> c['a']                          # count of letter 'a'
        5
        >>> for elem in 'shazam':           # update counts from an iterable
        ...     c[elem] += 1                # by adding 1 to each element's count
        >>> c['a']                          # now there are seven 'a'
        7
        >>> del c['b']                      # remove all 'b'
        >>> c['b']                          # now there are zero 'b'
        0
    
        >>> d = Counter('simsalabim')       # make another counter
        >>> c.update(d)                     # add in the second counter
        >>> c['a']                          # now there are nine 'a'
        9
    
        >>> c.clear()                       # empty the counter
        >>> c
        Counter()
    
        Note:  If a count is set to zero or reduced to zero, it will remain
        in the counter until the entry is deleted or the counter is cleared:
    
        >>> c = Counter('aaabbc')
        >>> c['b'] -= 2                     # reduce the count of 'b' by two
        >>> c.most_common()                 # 'b' is still in, but its count is zero
        [('a', 3), ('c', 1), ('b', 0)]
    """
    def copy(self): # reliably restored by inspect
        """ Return a shallow copy. """
        pass

    def elements(self): # reliably restored by inspect
        """
        Iterator over elements repeating each as many times as its count.
        
                >>> c = Counter('ABCABC')
                >>> sorted(c.elements())
                ['A', 'A', 'B', 'B', 'C', 'C']
        
                # Knuth's example for prime factors of 1836:  2**2 * 3**3 * 17**1
                >>> prime_factors = Counter({2: 2, 3: 3, 17: 1})
                >>> product = 1
                >>> for factor in prime_factors.elements():     # loop over factors
                ...     product *= factor                       # and multiply them
                >>> product
                1836
        
                Note, if an element's count has been set to zero or is a negative
                number, elements() will ignore it.
        """
        pass

    @classmethod
    def fromkeys(cls, *args, **kwargs): # real signature unknown
        pass

    def most_common(self, n=None): # reliably restored by inspect
        """
        List the n most common elements and their counts from the most
                common to the least.  If n is None, then list all element counts.
        
                >>> Counter('abcdeabcdabcaba').most_common(3)
                [('a', 5), ('b', 4), ('c', 3)]
        """
        pass

    def subtract(*args, **kwds): # reliably restored by inspect
        """
        Like dict.update() but subtracts counts instead of replacing them.
                Counts can be reduced below zero.  Both the inputs and outputs are
                allowed to contain zero and negative counts.
        
                Source can be an iterable, a dictionary, or another Counter instance.
        
                >>> c = Counter('which')
                >>> c.subtract('witch')             # subtract elements from another iterable
                >>> c.subtract(Counter('watch'))    # subtract elements from another counter
                >>> c['h']                          # 2 in which, minus 1 in witch, minus 1 in watch
                0
                >>> c['w']                          # 1 in which, minus 1 in witch, minus 1 in watch
                -1
        """
        pass

    def update(*args, **kwds): # reliably restored by inspect
        """
        Like dict.update() but add counts instead of replacing them.
        
                Source can be an iterable, a dictionary, or another Counter instance.
        
                >>> c = Counter('which')
                >>> c.update('witch')           # add elements from another iterable
                >>> d = Counter('watch')
                >>> c.update(d)                 # add elements from another counter
                >>> c['h']                      # four 'h' in which, witch, and watch
                4
        """
        pass

    def _keep_positive(self): # reliably restored by inspect
        """ Internal method to strip elements with a negative or zero count """
        pass

    def __add__(self, other): # reliably restored by inspect
        """
        Add counts from two counters.
        
                >>> Counter('abbb') + Counter('bcc')
                Counter({'b': 4, 'c': 2, 'a': 1})
        """
        pass

    def __and__(self, other): # reliably restored by inspect
        """
        Intersection is the minimum of corresponding counts.
        
                >>> Counter('abbb') & Counter('bcc')
                Counter({'b': 1})
        """
        pass

    def __delitem__(self, elem): # reliably restored by inspect
        """ Like dict.__delitem__() but does not raise KeyError for missing values. """
        pass

    def __iadd__(self, other): # reliably restored by inspect
        """
        Inplace add from another counter, keeping only positive counts.
        
                >>> c = Counter('abbb')
                >>> c += Counter('bcc')
                >>> c
                Counter({'b': 4, 'c': 2, 'a': 1})
        """
        pass

    def __iand__(self, other): # reliably restored by inspect
        """
        Inplace intersection is the minimum of corresponding counts.
        
                >>> c = Counter('abbb')
                >>> c &= Counter('bcc')
                >>> c
                Counter({'b': 1})
        """
        pass

    def __init__(*args, **kwds): # reliably restored by inspect
        """
        Create a new, empty Counter object.  And if given, count elements
                from an input iterable.  Or, initialize the count from another mapping
                of elements to their counts.
        
                >>> c = Counter()                           # a new, empty counter
                >>> c = Counter('gallahad')                 # a new counter from an iterable
                >>> c = Counter({'a': 4, 'b': 2})           # a new counter from a mapping
                >>> c = Counter(a=4, b=2)                   # a new counter from keyword args
        """
        pass

    def __ior__(self, other): # reliably restored by inspect
        """
        Inplace union is the maximum of value from either counter.
        
                >>> c = Counter('abbb')
                >>> c |= Counter('bcc')
                >>> c
                Counter({'b': 3, 'c': 2, 'a': 1})
        """
        pass

    def __isub__(self, other): # reliably restored by inspect
        """
        Inplace subtract counter, but keep only results with positive counts.
        
                >>> c = Counter('abbbc')
                >>> c -= Counter('bccd')
                >>> c
                Counter({'b': 2, 'a': 1})
        """
        pass

    def __missing__(self, key): # reliably restored by inspect
        """ The count of elements not in the Counter is zero. """
        pass

    def __neg__(self): # reliably restored by inspect
        """
        Subtracts from an empty counter.  Strips positive and zero counts,
                and flips the sign on negative counts.
        """
        pass

    def __or__(self, other): # reliably restored by inspect
        """
        Union is the maximum of value in either of the input counters.
        
                >>> Counter('abbb') | Counter('bcc')
                Counter({'b': 3, 'c': 2, 'a': 1})
        """
        pass

    def __pos__(self): # reliably restored by inspect
        """ Adds an empty counter, effectively stripping negative and zero counts """
        pass

    def __reduce__(self): # reliably restored by inspect
        # no doc
        pass

    def __repr__(self): # reliably restored by inspect
        # no doc
        pass

    def __sub__(self, other): # reliably restored by inspect
        """
        Subtract count, but keep only results with positive counts.
        
                >>> Counter('abbbc') - Counter('bccd')
                Counter({'b': 2, 'a': 1})
        """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is 'mappingproxy({\'__module__\': \'collections\', \'__doc__\': "Dict subclass for counting hashable items.  Sometimes called a bag\\n    or multiset.  Elements are stored as dictionary keys and their counts\\n    are stored as dictionary values.\\n\\n    >>> c = Counter(\'abcdeabcdabcaba\')  # count elements from a string\\n\\n    >>> c.most_common(3)                # three most common elements\\n    [(\'a\', 5), (\'b\', 4), (\'c\', 3)]\\n    >>> sorted(c)                       # list all unique elements\\n    [\'a\', \'b\', \'c\', \'d\', \'e\']\\n    >>> \'\'.join(sorted(c.elements()))   # list elements with repetitions\\n    \'aaaaabbbbcccdde\'\\n    >>> sum(c.values())                 # total of all counts\\n    15\\n\\n    >>> c[\'a\']                          # count of letter \'a\'\\n    5\\n    >>> for elem in \'shazam\':           # update counts from an iterable\\n    ...     c[elem] += 1                # by adding 1 to each element\'s count\\n    >>> c[\'a\']                          # now there are seven \'a\'\\n    7\\n    >>> del c[\'b\']                      # remove all \'b\'\\n    >>> c[\'b\']                          # now there are zero \'b\'\\n    0\\n\\n    >>> d = Counter(\'simsalabim\')       # make another counter\\n    >>> c.update(d)                     # add in the second counter\\n    >>> c[\'a\']                          # now there are nine \'a\'\\n    9\\n\\n    >>> c.clear()                       # empty the counter\\n    >>> c\\n    Counter()\\n\\n    Note:  If a count is set to zero or reduced to zero, it will remain\\n    in the counter until the entry is deleted or the counter is cleared:\\n\\n    >>> c = Counter(\'aaabbc\')\\n    >>> c[\'b\'] -= 2                     # reduce the count of \'b\' by two\\n    >>> c.most_common()                 # \'b\' is still in, but its count is zero\\n    [(\'a\', 3), (\'c\', 1), (\'b\', 0)]\\n\\n    ", \'__init__\': <function Counter.__init__ at 0x7f18d090a048>, \'__missing__\': <function Counter.__missing__ at 0x7f18d090a0d0>, \'most_common\': <function Counter.most_common at 0x7f18d090a158>, \'elements\': <function Counter.elements at 0x7f18d090a1e0>, \'fromkeys\': <classmethod object at 0x7f18d097bcc0>, \'update\': <function Counter.update at 0x7f18d090a2f0>, \'subtract\': <function Counter.subtract at 0x7f18d090a378>, \'copy\': <function Counter.copy at 0x7f18d090a400>, \'__reduce__\': <function Counter.__reduce__ at 0x7f18d090a488>, \'__delitem__\': <function Counter.__delitem__ at 0x7f18d090a510>, \'__repr__\': <function Counter.__repr__ at 0x7f18d090a598>, \'__add__\': <function Counter.__add__ at 0x7f18d090a620>, \'__sub__\': <function Counter.__sub__ at 0x7f18d090a6a8>, \'__or__\': <function Counter.__or__ at 0x7f18d090a730>, \'__and__\': <function Counter.__and__ at 0x7f18d090a7b8>, \'__pos__\': <function Counter.__pos__ at 0x7f18d090a840>, \'__neg__\': <function Counter.__neg__ at 0x7f18d090a8c8>, \'_keep_positive\': <function Counter._keep_positive at 0x7f18d090a950>, \'__iadd__\': <function Counter.__iadd__ at 0x7f18d090a9d8>, \'__isub__\': <function Counter.__isub__ at 0x7f18d090aa60>, \'__ior__\': <function Counter.__ior__ at 0x7f18d090aae8>, \'__iand__\': <function Counter.__iand__ at 0x7f18d090ab70>, \'__dict__\': <attribute \'__dict__\' of \'Counter\' objects>, \'__weakref__\': <attribute \'__weakref__\' of \'Counter\' objects>})'


class In(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f187a5e8690>'


class Last(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f187a5e86c0>'


class Missing(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f187a5e8630>'


class OrderedDict(dict):
    """ Dictionary that remembers insertion order """
    def clear(self): # real signature unknown; restored from __doc__
        """ od.clear() -> None.  Remove all items from od. """
        pass

    def copy(self): # real signature unknown; restored from __doc__
        """ od.copy() -> a shallow copy of od """
        pass

    @classmethod
    def fromkeys(cls, S, v=None): # real signature unknown; restored from __doc__
        """
        OD.fromkeys(S[, v]) -> New ordered dictionary with keys from S.
                If not specified, the value defaults to None.
        """
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def move_to_end(self, *args, **kwargs): # real signature unknown
        """
        Move an existing element to the end (or beginning if last==False).
        
                Raises KeyError if the element does not exist.
                When last=True, acts like a fast version of self[key]=self.pop(key).
        """
        pass

    def pop(self, k, d=None): # real signature unknown; restored from __doc__
        """
        od.pop(k[,d]) -> v, remove specified key and return the corresponding
                value.  If key is not found, d is returned if given, otherwise KeyError
                is raised.
        """
        pass

    def popitem(self, *args, **kwargs): # real signature unknown
        """
        Remove and return a (key, value) pair from the dictionary.
        
        Pairs are returned in LIFO order if last is true or FIFO order if false.
        """
        pass

    def setdefault(self, k, d=None): # real signature unknown; restored from __doc__
        """ od.setdefault(k[,d]) -> od.get(k,d), also set od[k]=d if k not in od """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __reversed__(self): # real signature unknown; restored from __doc__
        """ od.__reversed__() <==> reversed(od) """
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """ Set self[key] to value. """
        pass

    def __sizeof__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is "mappingproxy({'__repr__': <slot wrapper '__repr__' of 'collections.OrderedDict' objects>, '__lt__': <slot wrapper '__lt__' of 'collections.OrderedDict' objects>, '__le__': <slot wrapper '__le__' of 'collections.OrderedDict' objects>, '__eq__': <slot wrapper '__eq__' of 'collections.OrderedDict' objects>, '__ne__': <slot wrapper '__ne__' of 'collections.OrderedDict' objects>, '__gt__': <slot wrapper '__gt__' of 'collections.OrderedDict' objects>, '__ge__': <slot wrapper '__ge__' of 'collections.OrderedDict' objects>, '__iter__': <slot wrapper '__iter__' of 'collections.OrderedDict' objects>, '__init__': <slot wrapper '__init__' of 'collections.OrderedDict' objects>, '__setitem__': <slot wrapper '__setitem__' of 'collections.OrderedDict' objects>, '__delitem__': <slot wrapper '__delitem__' of 'collections.OrderedDict' objects>, 'fromkeys': <method 'fromkeys' of 'collections.OrderedDict' objects>, '__sizeof__': <method '__sizeof__' of 'collections.OrderedDict' objects>, '__reduce__': <method '__reduce__' of 'collections.OrderedDict' objects>, 'setdefault': <method 'setdefault' of 'collections.OrderedDict' objects>, 'pop': <method 'pop' of 'collections.OrderedDict' objects>, 'popitem': <method 'popitem' of 'collections.OrderedDict' objects>, 'keys': <method 'keys' of 'collections.OrderedDict' objects>, 'values': <method 'values' of 'collections.OrderedDict' objects>, 'items': <method 'items' of 'collections.OrderedDict' objects>, 'update': <method 'update' of 'collections.OrderedDict' objects>, 'clear': <method 'clear' of 'collections.OrderedDict' objects>, 'copy': <method 'copy' of 'collections.OrderedDict' objects>, '__reversed__': <method '__reversed__' of 'collections.OrderedDict' objects>, 'move_to_end': <method 'move_to_end' of 'collections.OrderedDict' objects>, '__dict__': <attribute '__dict__' of 'collections.OrderedDict' objects>, '__doc__': 'Dictionary that remembers insertion order', '__hash__': None})"
    __hash__ = None


class Out(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f187a5e8720>'


class Unit(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f187a5e86f0>'


# variables with complex values

MOVE_NAMES = [
    'M',
    'B',
    'I',
    'L',
    'U',
    'O',
    'x',
]

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f18cfda4f60>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.syntax.ner', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f18cfda4f60>, origin='/usr/local/lib/python3.6/dist-packages/spacy/syntax/ner.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


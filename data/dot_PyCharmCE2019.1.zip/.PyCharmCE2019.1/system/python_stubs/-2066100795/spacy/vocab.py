# encoding: utf-8
# module spacy.vocab
# from /usr/local/lib/python3.6/dist-packages/spacy/vocab.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py
import srsly as srsly # /usr/local/lib/python3.6/dist-packages/srsly/__init__.py
import copyreg as copy_reg # /usr/lib/python3.6/copyreg.py
import spacy.util as util # /usr/local/lib/python3.6/dist-packages/spacy/util.py
from spacy.attrs import intify_attrs

from spacy.vectors import Vectors


# Variables with simple values

NORM = 67

# functions

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def link_vectors_to_models(vocab): # reliably restored by inspect
    # no doc
    pass

def pickle_vocab(*args, **kwargs): # real signature unknown
    pass

def unpickle_vocab(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Vocab(*args, **kwargs): # real signature unknown
    pass

# classes

class basestring_(object):
    """
    str(object='') -> str
    str(bytes_or_buffer[, encoding[, errors]]) -> str
    
    Create a new string object from the given object. If encoding or
    errors is specified, then the object must expose a data buffer
    that will be decoded using the given encoding and error handler.
    Otherwise, returns the result of object.__str__() (if defined)
    or repr(object).
    encoding defaults to sys.getdefaultencoding().
    errors defaults to 'strict'.
    """
    def capitalize(self): # real signature unknown; restored from __doc__
        """
        S.capitalize() -> str
        
        Return a capitalized version of S, i.e. make the first character
        have upper case and the rest lower case.
        """
        return ""

    def casefold(self): # real signature unknown; restored from __doc__
        """
        S.casefold() -> str
        
        Return a version of S suitable for caseless comparisons.
        """
        return ""

    def center(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.center(width[, fillchar]) -> str
        
        Return S centered in a string of length width. Padding is
        done using the specified fill character (default is a space)
        """
        return ""

    def count(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.count(sub[, start[, end]]) -> int
        
        Return the number of non-overlapping occurrences of substring sub in
        string S[start:end].  Optional arguments start and end are
        interpreted as in slice notation.
        """
        return 0

    def encode(self, encoding='utf-8', errors='strict'): # real signature unknown; restored from __doc__
        """
        S.encode(encoding='utf-8', errors='strict') -> bytes
        
        Encode S using the codec registered for encoding. Default encoding
        is 'utf-8'. errors may be given to set a different error
        handling scheme. Default is 'strict' meaning that encoding errors raise
        a UnicodeEncodeError. Other possible values are 'ignore', 'replace' and
        'xmlcharrefreplace' as well as any other name registered with
        codecs.register_error that can handle UnicodeEncodeErrors.
        """
        return b""

    def endswith(self, suffix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.endswith(suffix[, start[, end]]) -> bool
        
        Return True if S ends with the specified suffix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        suffix can also be a tuple of strings to try.
        """
        return False

    def expandtabs(self, tabsize=8): # real signature unknown; restored from __doc__
        """
        S.expandtabs(tabsize=8) -> str
        
        Return a copy of S where all tab characters are expanded using spaces.
        If tabsize is not given, a tab size of 8 characters is assumed.
        """
        return ""

    def find(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.find(sub[, start[, end]]) -> int
        
        Return the lowest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def format(self, *args, **kwargs): # real signature unknown; restored from __doc__
        """
        S.format(*args, **kwargs) -> str
        
        Return a formatted version of S, using substitutions from args and kwargs.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def format_map(self, mapping): # real signature unknown; restored from __doc__
        """
        S.format_map(mapping) -> str
        
        Return a formatted version of S, using substitutions from mapping.
        The substitutions are identified by braces ('{' and '}').
        """
        return ""

    def index(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.index(sub[, start[, end]]) -> int
        
        Return the lowest index in S where substring sub is found, 
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Raises ValueError when the substring is not found.
        """
        return 0

    def isalnum(self): # real signature unknown; restored from __doc__
        """
        S.isalnum() -> bool
        
        Return True if all characters in S are alphanumeric
        and there is at least one character in S, False otherwise.
        """
        return False

    def isalpha(self): # real signature unknown; restored from __doc__
        """
        S.isalpha() -> bool
        
        Return True if all characters in S are alphabetic
        and there is at least one character in S, False otherwise.
        """
        return False

    def isdecimal(self): # real signature unknown; restored from __doc__
        """
        S.isdecimal() -> bool
        
        Return True if there are only decimal characters in S,
        False otherwise.
        """
        return False

    def isdigit(self): # real signature unknown; restored from __doc__
        """
        S.isdigit() -> bool
        
        Return True if all characters in S are digits
        and there is at least one character in S, False otherwise.
        """
        return False

    def isidentifier(self): # real signature unknown; restored from __doc__
        """
        S.isidentifier() -> bool
        
        Return True if S is a valid identifier according
        to the language definition.
        
        Use keyword.iskeyword() to test for reserved identifiers
        such as "def" and "class".
        """
        return False

    def islower(self): # real signature unknown; restored from __doc__
        """
        S.islower() -> bool
        
        Return True if all cased characters in S are lowercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def isnumeric(self): # real signature unknown; restored from __doc__
        """
        S.isnumeric() -> bool
        
        Return True if there are only numeric characters in S,
        False otherwise.
        """
        return False

    def isprintable(self): # real signature unknown; restored from __doc__
        """
        S.isprintable() -> bool
        
        Return True if all characters in S are considered
        printable in repr() or S is empty, False otherwise.
        """
        return False

    def isspace(self): # real signature unknown; restored from __doc__
        """
        S.isspace() -> bool
        
        Return True if all characters in S are whitespace
        and there is at least one character in S, False otherwise.
        """
        return False

    def istitle(self): # real signature unknown; restored from __doc__
        """
        S.istitle() -> bool
        
        Return True if S is a titlecased string and there is at least one
        character in S, i.e. upper- and titlecase characters may only
        follow uncased characters and lowercase characters only cased ones.
        Return False otherwise.
        """
        return False

    def isupper(self): # real signature unknown; restored from __doc__
        """
        S.isupper() -> bool
        
        Return True if all cased characters in S are uppercase and there is
        at least one cased character in S, False otherwise.
        """
        return False

    def join(self, iterable): # real signature unknown; restored from __doc__
        """
        S.join(iterable) -> str
        
        Return a string which is the concatenation of the strings in the
        iterable.  The separator between elements is S.
        """
        return ""

    def ljust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.ljust(width[, fillchar]) -> str
        
        Return S left-justified in a Unicode string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def lower(self): # real signature unknown; restored from __doc__
        """
        S.lower() -> str
        
        Return a copy of the string S converted to lowercase.
        """
        return ""

    def lstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.lstrip([chars]) -> str
        
        Return a copy of the string S with leading whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def maketrans(self, *args, **kwargs): # real signature unknown
        """
        Return a translation table usable for str.translate().
        
        If there is only one argument, it must be a dictionary mapping Unicode
        ordinals (integers) or characters to Unicode ordinals, strings or None.
        Character keys will be then converted to ordinals.
        If there are two arguments, they must be strings of equal length, and
        in the resulting dictionary, each character in x will be mapped to the
        character at the same position in y. If there is a third argument, it
        must be a string, whose characters will be mapped to None in the result.
        """
        pass

    def partition(self, sep): # real signature unknown; restored from __doc__
        """
        S.partition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, and return the part before it,
        the separator itself, and the part after it.  If the separator is not
        found, return S and two empty strings.
        """
        pass

    def replace(self, old, new, count=None): # real signature unknown; restored from __doc__
        """
        S.replace(old, new[, count]) -> str
        
        Return a copy of S with all occurrences of substring
        old replaced by new.  If the optional argument count is
        given, only the first count occurrences are replaced.
        """
        return ""

    def rfind(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rfind(sub[, start[, end]]) -> int
        
        Return the highest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Return -1 on failure.
        """
        return 0

    def rindex(self, sub, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.rindex(sub[, start[, end]]) -> int
        
        Return the highest index in S where substring sub is found,
        such that sub is contained within S[start:end].  Optional
        arguments start and end are interpreted as in slice notation.
        
        Raises ValueError when the substring is not found.
        """
        return 0

    def rjust(self, width, fillchar=None): # real signature unknown; restored from __doc__
        """
        S.rjust(width[, fillchar]) -> str
        
        Return S right-justified in a string of length width. Padding is
        done using the specified fill character (default is a space).
        """
        return ""

    def rpartition(self, sep): # real signature unknown; restored from __doc__
        """
        S.rpartition(sep) -> (head, sep, tail)
        
        Search for the separator sep in S, starting at the end of S, and return
        the part before it, the separator itself, and the part after it.  If the
        separator is not found, return two empty strings and S.
        """
        pass

    def rsplit(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.rsplit(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string, starting at the end of the string and
        working to the front.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified, any whitespace string
        is a separator.
        """
        return []

    def rstrip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.rstrip([chars]) -> str
        
        Return a copy of the string S with trailing whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def split(self, sep=None, maxsplit=-1): # real signature unknown; restored from __doc__
        """
        S.split(sep=None, maxsplit=-1) -> list of strings
        
        Return a list of the words in S, using sep as the
        delimiter string.  If maxsplit is given, at most maxsplit
        splits are done. If sep is not specified or is None, any
        whitespace string is a separator and empty strings are
        removed from the result.
        """
        return []

    def splitlines(self, keepends=None): # real signature unknown; restored from __doc__
        """
        S.splitlines([keepends]) -> list of strings
        
        Return a list of the lines in S, breaking at line boundaries.
        Line breaks are not included in the resulting list unless keepends
        is given and true.
        """
        return []

    def startswith(self, prefix, start=None, end=None): # real signature unknown; restored from __doc__
        """
        S.startswith(prefix[, start[, end]]) -> bool
        
        Return True if S starts with the specified prefix, False otherwise.
        With optional start, test S beginning at that position.
        With optional end, stop comparing S at that position.
        prefix can also be a tuple of strings to try.
        """
        return False

    def strip(self, chars=None): # real signature unknown; restored from __doc__
        """
        S.strip([chars]) -> str
        
        Return a copy of the string S with leading and trailing
        whitespace removed.
        If chars is given and not None, remove characters in chars instead.
        """
        return ""

    def swapcase(self): # real signature unknown; restored from __doc__
        """
        S.swapcase() -> str
        
        Return a copy of S with uppercase characters converted to lowercase
        and vice versa.
        """
        return ""

    def title(self): # real signature unknown; restored from __doc__
        """
        S.title() -> str
        
        Return a titlecased version of S, i.e. words start with title case
        characters, all remaining cased characters have lower case.
        """
        return ""

    def translate(self, table): # real signature unknown; restored from __doc__
        """
        S.translate(table) -> str
        
        Return a copy of the string S in which each character has been mapped
        through the given translation table. The table must implement
        lookup/indexing via __getitem__, for instance a dictionary or list,
        mapping Unicode ordinals to Unicode ordinals, strings, or None. If
        this operation raises LookupError, the character is left untouched.
        Characters mapped to None are deleted.
        """
        return ""

    def upper(self): # real signature unknown; restored from __doc__
        """
        S.upper() -> str
        
        Return a copy of S converted to uppercase.
        """
        return ""

    def zfill(self, width): # real signature unknown; restored from __doc__
        """
        S.zfill(width) -> str
        
        Pad a numeric string S with zeros on the left, to fill a field
        of the specified width. The string S is never truncated.
        """
        return ""

    def __add__(self, *args, **kwargs): # real signature unknown
        """ Return self+value. """
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """ Return key in self. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __format__(self, format_spec): # real signature unknown; restored from __doc__
        """
        S.__format__(format_spec) -> str
        
        Return a formatted version of S as described by format_spec.
        """
        return ""

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __getnewargs__(self, *args, **kwargs): # real signature unknown
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        """ Return hash(self). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __mod__(self, *args, **kwargs): # real signature unknown
        """ Return self%value. """
        pass

    def __mul__(self, *args, **kwargs): # real signature unknown
        """ Return self*value. """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __rmod__(self, *args, **kwargs): # real signature unknown
        """ Return value%self. """
        pass

    def __rmul__(self, *args, **kwargs): # real signature unknown
        """ Return value*self. """
        pass

    def __sizeof__(self): # real signature unknown; restored from __doc__
        """ S.__sizeof__() -> size of S in memory, in bytes """
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """ Return str(self). """
        pass


class Lemmatizer(object):
    """
    The Lemmatizer supports simple part-of-speech-sensitive suffix rules and
        lookup tables.
    
        DOCS: https://spacy.io/api/lemmatizer
    """
    def adj(self, string, morphology=None): # reliably restored by inspect
        # no doc
        pass

    def is_base_form(self, univ_pos, morphology=None): # reliably restored by inspect
        """
        Check whether we're dealing with an uninflected paradigm, so we can
                avoid lemmatization entirely.
        """
        pass

    @classmethod
    def load(cls, *args, **kwargs): # real signature unknown
        pass

    def lookup(self, string): # reliably restored by inspect
        # no doc
        pass

    def noun(self, string, morphology=None): # reliably restored by inspect
        # no doc
        pass

    def punct(self, string, morphology=None): # reliably restored by inspect
        # no doc
        pass

    def verb(self, string, morphology=None): # reliably restored by inspect
        # no doc
        pass

    def __call__(self, string, univ_pos, morphology=None): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, index=None, exceptions=None, rules=None, lookup=None): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.lemmatizer', '__doc__': '\\n    The Lemmatizer supports simple part-of-speech-sensitive suffix rules and\\n    lookup tables.\\n\\n    DOCS: https://spacy.io/api/lemmatizer\\n    ', 'load': <classmethod object at 0x7ff0f1a84a20>, '__init__': <function Lemmatizer.__init__ at 0x7ff0f219fb70>, '__call__': <function Lemmatizer.__call__ at 0x7ff0f1a852f0>, 'is_base_form': <function Lemmatizer.is_base_form at 0x7ff0f1a85378>, 'noun': <function Lemmatizer.noun at 0x7ff0f1a85400>, 'verb': <function Lemmatizer.verb at 0x7ff0f1a85488>, 'adj': <function Lemmatizer.adj at 0x7ff0f1a85510>, 'punct': <function Lemmatizer.punct at 0x7ff0f1a85598>, 'lookup': <function Lemmatizer.lookup at 0x7ff0f1a85620>, '__dict__': <attribute '__dict__' of 'Lemmatizer' objects>, '__weakref__': <attribute '__weakref__' of 'Lemmatizer' objects>})"


class OrderedDict(dict):
    """ Dictionary that remembers insertion order """
    def clear(self): # real signature unknown; restored from __doc__
        """ od.clear() -> None.  Remove all items from od. """
        pass

    def copy(self): # real signature unknown; restored from __doc__
        """ od.copy() -> a shallow copy of od """
        pass

    @classmethod
    def fromkeys(cls, S, v=None): # real signature unknown; restored from __doc__
        """
        OD.fromkeys(S[, v]) -> New ordered dictionary with keys from S.
                If not specified, the value defaults to None.
        """
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def move_to_end(self, *args, **kwargs): # real signature unknown
        """
        Move an existing element to the end (or beginning if last==False).
        
                Raises KeyError if the element does not exist.
                When last=True, acts like a fast version of self[key]=self.pop(key).
        """
        pass

    def pop(self, k, d=None): # real signature unknown; restored from __doc__
        """
        od.pop(k[,d]) -> v, remove specified key and return the corresponding
                value.  If key is not found, d is returned if given, otherwise KeyError
                is raised.
        """
        pass

    def popitem(self, *args, **kwargs): # real signature unknown
        """
        Remove and return a (key, value) pair from the dictionary.
        
        Pairs are returned in LIFO order if last is true or FIFO order if false.
        """
        pass

    def setdefault(self, k, d=None): # real signature unknown; restored from __doc__
        """ od.setdefault(k[,d]) -> od.get(k,d), also set od[k]=d if k not in od """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __reversed__(self): # real signature unknown; restored from __doc__
        """ od.__reversed__() <==> reversed(od) """
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """ Set self[key] to value. """
        pass

    def __sizeof__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is "mappingproxy({'__repr__': <slot wrapper '__repr__' of 'collections.OrderedDict' objects>, '__lt__': <slot wrapper '__lt__' of 'collections.OrderedDict' objects>, '__le__': <slot wrapper '__le__' of 'collections.OrderedDict' objects>, '__eq__': <slot wrapper '__eq__' of 'collections.OrderedDict' objects>, '__ne__': <slot wrapper '__ne__' of 'collections.OrderedDict' objects>, '__gt__': <slot wrapper '__gt__' of 'collections.OrderedDict' objects>, '__ge__': <slot wrapper '__ge__' of 'collections.OrderedDict' objects>, '__iter__': <slot wrapper '__iter__' of 'collections.OrderedDict' objects>, '__init__': <slot wrapper '__init__' of 'collections.OrderedDict' objects>, '__setitem__': <slot wrapper '__setitem__' of 'collections.OrderedDict' objects>, '__delitem__': <slot wrapper '__delitem__' of 'collections.OrderedDict' objects>, 'fromkeys': <method 'fromkeys' of 'collections.OrderedDict' objects>, '__sizeof__': <method '__sizeof__' of 'collections.OrderedDict' objects>, '__reduce__': <method '__reduce__' of 'collections.OrderedDict' objects>, 'setdefault': <method 'setdefault' of 'collections.OrderedDict' objects>, 'pop': <method 'pop' of 'collections.OrderedDict' objects>, 'popitem': <method 'popitem' of 'collections.OrderedDict' objects>, 'keys': <method 'keys' of 'collections.OrderedDict' objects>, 'values': <method 'values' of 'collections.OrderedDict' objects>, 'items': <method 'items' of 'collections.OrderedDict' objects>, 'update': <method 'update' of 'collections.OrderedDict' objects>, 'clear': <method 'clear' of 'collections.OrderedDict' objects>, 'copy': <method 'copy' of 'collections.OrderedDict' objects>, '__reversed__': <method '__reversed__' of 'collections.OrderedDict' objects>, 'move_to_end': <method 'move_to_end' of 'collections.OrderedDict' objects>, '__dict__': <attribute '__dict__' of 'collections.OrderedDict' objects>, '__doc__': 'Dictionary that remembers insertion order', '__hash__': None})"
    __hash__ = None


class Vocab(object):
    """
    A look-up table that allows you to access `Lexeme` objects. The `Vocab`
        instance also provides access to the `StringStore`, and owns underlying
        C-data that is shared between `Doc` objects.
    
        DOCS: https://spacy.io/api/vocab
    """
    def add_flag(self, *args, **kwargs): # real signature unknown
        """
        Set a new boolean flag to words in the vocabulary.
        
                The flag_getter function will be called over the words currently in the
                vocab, and then applied to new words as they occur. You'll then be able
                to access the flag value on each token using token.check_flag(flag_id).
                See also: `Lexeme.set_flag`, `Lexeme.check_flag`, `Token.set_flag`,
                `Token.check_flag`.
        
                flag_getter (callable): A function `f(unicode) -> bool`, to get the
                    flag value.
                flag_id (int): An integer between 1 and 63 (inclusive), specifying
                    the bit at which the flag will be stored. If -1, the lowest
                    available bit will be chosen.
                RETURNS (int): The integer ID by which the flag value can be checked.
        
                DOCS: https://spacy.io/api/vocab#add_flag
        """
        pass

    def from_bytes(self, *args, **kwargs): # real signature unknown
        """
        Load state from a binary string.
        
                bytes_data (bytes): The data to load from.
                exclude (list): String names of serialization fields to exclude.
                RETURNS (Vocab): The `Vocab` object.
        
                DOCS: https://spacy.io/api/vocab#from_bytes
        """
        pass

    def from_disk(self, *args, **kwargs): # real signature unknown
        """
        Loads state from a directory. Modifies the object in place and
                returns it.
        
                path (unicode or Path): A path to a directory.
                exclude (list): String names of serialization fields to exclude.
                RETURNS (Vocab): The modified `Vocab` object.
        
                DOCS: https://spacy.io/api/vocab#to_disk
        """
        pass

    def get_vector(self, *args, **kwargs): # real signature unknown
        """
        Retrieve a vector for a word in the vocabulary. Words can be looked
                up by string or int ID. If no vectors data is loaded, ValueError is
                raised.
        
                RETURNS (numpy.ndarray): A word vector. Size
                    and shape determined by the `vocab.vectors` instance. Usually, a
                    numpy ndarray of shape (300,) and dtype float32.
        
                DOCS: https://spacy.io/api/vocab#get_vector
        """
        pass

    def has_vector(self, *args, **kwargs): # real signature unknown
        """
        Check whether a word has a vector. Returns False if no vectors have
                been loaded. Words can be looked up by string or int ID.
        
                orth (int / unicode): The word.
                RETURNS (bool): Whether the word has a vector.
        
                DOCS: https://spacy.io/api/vocab#has_vector
        """
        pass

    def lexemes_from_bytes(self, *args, **kwargs): # real signature unknown
        """ Load the binary vocabulary data from the given string. """
        pass

    def lexemes_to_bytes(self, *args, **kwargs): # real signature unknown
        pass

    def prune_vectors(self, *args, **kwargs): # real signature unknown
        """
        Reduce the current vector table to `nr_row` unique entries. Words
                mapped to the discarded vectors will be remapped to the closest vector
                among those remaining.
        
                For example, suppose the original table had vectors for the words:
                ['sat', 'cat', 'feline', 'reclined']. If we prune the vector table to,
                two rows, we would discard the vectors for 'feline' and 'reclined'.
                These words would then be remapped to the closest remaining vector
                -- so "feline" would have the same vector as "cat", and "reclined"
                would have the same vector as "sat".
        
                The similarities are judged by cosine. The original vectors may
                be large, so the cosines are calculated in minibatches, to reduce
                memory usage.
        
                nr_row (int): The number of rows to keep in the vector table.
                batch_size (int): Batch of vectors for calculating the similarities.
                    Larger batch sizes might be faster, while temporarily requiring
                    more memory.
                RETURNS (dict): A dictionary keyed by removed words mapped to
                    `(string, score)` tuples, where `string` is the entry the removed
                    word was mapped to, and `score` the similarity score between the
                    two words.
        
                DOCS: https://spacy.io/api/vocab#prune_vectors
        """
        pass

    def reset_vectors(self, *args, **kwargs): # real signature unknown
        """
        Drop the current vector table. Because all vectors must be the same
                width, you have to call this to change the size of the vectors.
        """
        pass

    def set_vector(self, *args, **kwargs): # real signature unknown
        """
        Set a vector for a word in the vocabulary. Words can be referenced
                by string or int ID.
        
                orth (int / unicode): The word.
                vector (numpy.ndarray[ndim=1, dtype='float32']): The vector to set.
        
                DOCS: https://spacy.io/api/vocab#set_vector
        """
        pass

    def to_bytes(self, *args, **kwargs): # real signature unknown
        """
        Serialize the current state to a binary string.
        
                exclude (list): String names of serialization fields to exclude.
                RETURNS (bytes): The serialized form of the `Vocab` object.
        
                DOCS: https://spacy.io/api/vocab#to_bytes
        """
        pass

    def to_disk(self, *args, **kwargs): # real signature unknown
        """
        Save the current state to a directory.
        
                path (unicode or Path): A path to a directory, which will be created if
                    it doesn't exist.
                exclude (list): String names of serialization fields to exclude.
        
                DOCS: https://spacy.io/api/vocab#to_disk
        """
        pass

    def _reset_cache(self, *args, **kwargs): # real signature unknown
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """
        Check whether the string or int key has an entry in the vocabulary.
        
                string (unicode): The ID string.
                RETURNS (bool) Whether the string has an entry in the vocabulary.
        
                DOCS: https://spacy.io/api/vocab#contains
        """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """
        Retrieve a lexeme, given an int ID or a unicode string. If a
                previously unseen unicode string is given, a new lexeme is created and
                stored.
        
                id_or_string (int or unicode): The integer ID of a word, or its unicode
                    string. If `int >= Lexicon.size`, `IndexError` is raised. If
                    `id_or_string` is neither an int nor a unicode string, `ValueError`
                    is raised.
                RETURNS (Lexeme): The lexeme indicated by the given ID.
        
                EXAMPLE:
                    >>> apple = nlp.vocab.strings["apple"]
                    >>> assert nlp.vocab[apple] == nlp.vocab[u"apple"]
        
                DOCS: https://spacy.io/api/vocab#getitem
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create the vocabulary.
        
                lex_attr_getters (dict): A dictionary mapping attribute IDs to
                    functions to compute them. Defaults to `None`.
                tag_map (dict): Dictionary mapping fine-grained tags to coarse-grained
                    parts-of-speech, and optionally morphological attributes.
                lemmatizer (object): A lemmatizer. Defaults to `None`.
                strings (StringStore): StringStore that maps strings to integers, and
                    vice versa.
                RETURNS (Vocab): The newly constructed object.
        """
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """
        Iterate over the lexemes in the vocabulary.
        
                YIELDS (Lexeme): An entry in the vocabulary.
        
                DOCS: https://spacy.io/api/vocab#iter
        """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """
        The current number of lexemes stored.
        
                RETURNS (int): The current number of lexemes stored.
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    cfg = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    data_dir = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    lang = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    length = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    lex_attr_getters = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    morphology = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    strings = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    vectors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    vectors_length = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    writing_system = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """A dict with information about the language's writing system. To get
        the data, we use the vocab.lang property to fetch the Language class.
        If the Language class is not loaded, an empty dict is returned.
        """


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7ff0f21a70c0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff0f21a49e8>'

__pyx_capi__ = {
    'EMPTY_LEXEME': None, # (!) real value is '<capsule object "struct __pyx_t_5spacy_7structs_LexemeC" at 0x7ff0f21a7090>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.vocab', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7ff0f21a49e8>, origin='/usr/local/lib/python3.6/dist-packages/spacy/vocab.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {
    'Vocab.__getitem__ (line 215)': 'Retrieve a lexeme, given an int ID or a unicode string. If a\n        previously unseen unicode string is given, a new lexeme is created and\n        stored.\n\n        id_or_string (int or unicode): The integer ID of a word, or its unicode\n            string. If `int >= Lexicon.size`, `IndexError` is raised. If\n            `id_or_string` is neither an int nor a unicode string, `ValueError`\n            is raised.\n        RETURNS (Lexeme): The lexeme indicated by the given ID.\n\n        EXAMPLE:\n            >>> apple = nlp.vocab.strings["apple"]\n            >>> assert nlp.vocab[apple] == nlp.vocab[u"apple"]\n\n        DOCS: https://spacy.io/api/vocab#getitem\n        ',
}


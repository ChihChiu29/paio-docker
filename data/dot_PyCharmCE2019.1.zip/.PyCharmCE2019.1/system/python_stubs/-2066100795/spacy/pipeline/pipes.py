# encoding: utf-8
# module spacy.pipeline.pipes
# from /usr/local/lib/python3.6/dist-packages/spacy/pipeline/pipes.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py
import srsly as srsly # /usr/local/lib/python3.6/dist-packages/srsly/__init__.py
import random as random # /usr/lib/python3.6/random.py
import spacy.syntax.nonproj as nonproj # /usr/local/lib/python3.6/dist-packages/spacy/syntax/nonproj.cpython-36m-x86_64-linux-gnu.so
import spacy.util as util # /usr/local/lib/python3.6/dist-packages/spacy/util.py
from spacy.cli.pretrain import get_cossim_loss

from spacy.kb import KnowledgeBase

import spacy.syntax.nn_parser as __spacy_syntax_nn_parser
import thinc.neural._classes.affine as __thinc_neural__classes_affine
import thinc.neural._classes.model as __thinc_neural__classes_model


# Variables with simple values

ID = 64

POS = 74
X = 101

# functions

def build_bow_text_classifier(nr_class, ngram_size=1, exclusive_classes=False, no_output_layer=False, **cfg): # reliably restored by inspect
    # no doc
    pass

def build_nel_encoder(embed_width, hidden_width, ner_types, **cfg): # reliably restored by inspect
    # no doc
    pass

def build_simple_cnn_text_classifier(tok2vec, nr_class, exclusive_classes=False, **cfg): # reliably restored by inspect
    """
    Build a simple CNN text classifier, given a token-to-vector model as inputs.
        If exclusive_classes=True, a softmax non-linearity is applied, so that the
        outputs sum to 1. If exclusive_classes=False, a logistic non-linearity
        is applied instead, so that outputs are in the range [0, 1].
    """
    pass

def build_tagger_model(nr_class, **cfg): # reliably restored by inspect
    # no doc
    pass

def build_text_classifier(nr_class, width=64, **cfg): # reliably restored by inspect
    # no doc
    pass

def chain(*layers): # reliably restored by inspect
    """
    Compose two models `f` and `g` such that they become layers of a single
        feed-forward model that computes `g(f(x))`.
    
        Raises exception if their dimensions don't match.
    """
    pass

def cosine(vec1, vec2): # reliably restored by inspect
    # no doc
    pass

def create_default_optimizer(ops, **cfg): # reliably restored by inspect
    # no doc
    pass

def Errors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def flatten(*args, **kwargs): # real signature unknown
    """
    Wrap functions into weightless Model instances, for use as network
        components.
    """
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def link_vectors_to_models(vocab): # reliably restored by inspect
    # no doc
    pass

def masked_language_model(vocab, model, mask_prob=0.15): # reliably restored by inspect
    """ Convert a model into a BERT-style masked language model """
    pass

def merge_subtokens(doc, label=None): # reliably restored by inspect
    """
    Merge subtokens into a single token.
    
        doc (Doc): The Doc object.
        label (unicode): The subtoken dependency label.
        RETURNS (Doc): The Doc object with merged subtokens.
    
        DOCS: https://spacy.io/api/pipeline-functions#merge_subtokens
    """
    pass

def TempErrors(*args, **kwargs): # real signature unknown
    """ [__doc__] None """
    pass

def Tok2Vec(width, embed_size, **kwargs): # reliably restored by inspect
    # no doc
    pass

def to_categorical(y, nb_classes=None): # reliably restored by inspect
    # no doc
    pass

def zero_init(model): # reliably restored by inspect
    # no doc
    pass

def _load_cfg(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Affine(__thinc_neural__classes_model.Model):
    """ Computes the linear transform Y = (W @ X) + b. """
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, input__BI, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def nB(self, *args, **kwargs): # real signature unknown
        pass

    def nI(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, input__BI): # reliably restored by inspect
        # no doc
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, nO=None, nI=None, **kwargs): # reliably restored by inspect
        # no doc
        pass

    input_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7f63dc2c0cf8>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7f63dc2c0d30>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63dc2c0dd8>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63dc245c18>'
        'nB': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc2c0c18>'
        'nI': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc2c0c50>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc2c0cc0>'
    }
    name = 'affine'
    on_data_hooks = [
        None, # (!) real value is '<function _set_dimensions_if_needed at 0x7f63dc2aa510>'
    ]


class Pipe(object):
    """
    This class is not instantiated directly. Components inherit from it, and
        it defines the interface that components should follow to function as
        components in a spaCy analysis pipeline.
    """
    def add_label(self, *args, **kwargs): # real signature unknown
        """
        Add an output label, to be predicted by the model.
        
                It's possible to extend pre-trained models with new labels,
                but care should be taken to avoid the "catastrophic forgetting"
                problem.
        """
        pass

    def begin_training(self, *args, **kwargs): # real signature unknown
        """
        Initialize the pipe for training, using data exampes if available.
                If no model has been initialized yet, the model is added.
        """
        pass

    def create_optimizer(self, *args, **kwargs): # real signature unknown
        pass

    def from_bytes(self, *args, **kwargs): # real signature unknown
        """ Load the pipe from a bytestring. """
        pass

    def from_disk(self, *args, **kwargs): # real signature unknown
        """ Load the pipe from disk. """
        pass

    def get_loss(self, *args, **kwargs): # real signature unknown
        """
        Find the loss and gradient of loss for the batch of
                documents and their predicted scores.
        """
        pass

    @classmethod
    def Model(cls, *args, **kwargs): # real signature unknown
        """ Initialize a model for the pipe. """
        pass

    def pipe(self, *args, **kwargs): # real signature unknown
        """
        Apply the pipe to a stream of documents.
        
                Both __call__ and pipe should delegate to the `predict()`
                and `set_annotations()` methods.
        """
        pass

    def predict(self, *args, **kwargs): # real signature unknown
        """
        Apply the pipeline's model to a batch of docs, without
                modifying them.
        """
        pass

    def rehearse(self, *args, **kwargs): # real signature unknown
        pass

    def require_model(self, *args, **kwargs): # real signature unknown
        """ Raise an error if the component's model is not initialized. """
        pass

    def set_annotations(self, *args, **kwargs): # real signature unknown
        """ Modify a batch of documents, using pre-computed scores. """
        pass

    def to_bytes(self, *args, **kwargs): # real signature unknown
        """
        Serialize the pipe to a bytestring.
        
                exclude (list): String names of serialization fields to exclude.
                RETURNS (bytes): The serialized object.
        """
        pass

    def to_disk(self, *args, **kwargs): # real signature unknown
        """ Serialize the pipe to disk. """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        """
        Learn from a batch of documents and gold-standard information,
                updating the pipe's model.
        
                Delegates to predict() and get_loss().
        """
        pass

    def use_params(self, *args, **kwargs): # real signature unknown
        """ Modify the pipe's model, to use the given parameter values. """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """
        Apply the pipe to one document. The document is
                modified in-place, and returned.
        
                Both __call__ and pipe should delegate to the `predict()`
                and `set_annotations()` methods.
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """ Create a new pipe instance. """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    name = None
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.pipeline.pipes', '__doc__': 'This class is not instantiated directly. Components inherit from it, and\\n    it defines the interface that components should follow to function as\\n    components in a spaCy analysis pipeline.\\n    ', 'name': None, 'Model': <classmethod object at 0x7f6395ddaac8>, '__init__': <cyfunction Pipe.__init__ at 0x7f6394eb0100>, '__call__': <cyfunction Pipe.__call__ at 0x7f6394eb01b8>, 'require_model': <cyfunction Pipe.require_model at 0x7f6394eb0270>, 'pipe': <cyfunction Pipe.pipe at 0x7f6394eb0328>, 'predict': <cyfunction Pipe.predict at 0x7f6394eb03e0>, 'set_annotations': <cyfunction Pipe.set_annotations at 0x7f6394eb0498>, 'update': <cyfunction Pipe.update at 0x7f6394eb0550>, 'rehearse': <cyfunction Pipe.rehearse at 0x7f6394eb0608>, 'get_loss': <cyfunction Pipe.get_loss at 0x7f6394eb06c0>, 'add_label': <cyfunction Pipe.add_label at 0x7f6394eb0778>, 'create_optimizer': <cyfunction Pipe.create_optimizer at 0x7f6394eb0830>, 'begin_training': <cyfunction Pipe.begin_training at 0x7f6394eb08e8>, 'use_params': <cyfunction Pipe.use_params at 0x7f6394eb0a58>, 'to_bytes': <cyfunction Pipe.to_bytes at 0x7f6394eb0b10>, 'from_bytes': <cyfunction Pipe.from_bytes at 0x7f6394eb0bc8>, 'to_disk': <cyfunction Pipe.to_disk at 0x7f6394eb0c80>, 'from_disk': <cyfunction Pipe.from_disk at 0x7f6394eb0d38>, '__dict__': <attribute '__dict__' of 'Pipe' objects>, '__weakref__': <attribute '__weakref__' of 'Pipe' objects>})"


class ClozeMultitask(Pipe):
    # no doc
    def begin_training(self, *args, **kwargs): # real signature unknown
        pass

    def get_loss(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def Model(cls, *args, **kwargs): # real signature unknown
        pass

    def predict(self, *args, **kwargs): # real signature unknown
        pass

    def rehearse(self, *args, **kwargs): # real signature unknown
        pass

    def set_annotations(self, *args, **kwargs): # real signature unknown
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DependencyParser(__spacy_syntax_nn_parser.Parser):
    """
    Pipeline component for dependency parsing.
    
        DOCS: https://spacy.io/api/dependencyparser
    """
    def add_multitask_objective(self, *args, **kwargs): # real signature unknown
        pass

    def init_multitask_objectives(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create a Parser.
        
                vocab (Vocab): The vocabulary object. Must be shared with documents
                    to be processed. The value is set to the `.vocab` attribute.
                moves (TransitionSystem): Defines how the parse-state is created,
                    updated and evaluated. The value is set to the .moves attribute
                    unless True (default), in which case a new instance is created with
                    `Parser.Moves()`.
                model (object): Defines how the parse-state is created, updated and
                    evaluated. The value is set to the .model attribute. If set to True
                    (default), a new instance will be created with `Parser.Model()`
                    in parser.begin_training(), parser.from_disk() or parser.from_bytes().
                **cfg: Arbitrary configuration parameters. Set to the `.cfg` attribute
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    labels = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    postprocesses = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    name = 'parser'
    TransitionSystem = None # (!) real value is "<class 'spacy.syntax.arc_eager.ArcEager'>"
    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f6396698f30>'


class EntityLinker(Pipe):
    """
    Pipeline component for named entity linking.
    
        DOCS: TODO
    """
    def add_label(self, *args, **kwargs): # real signature unknown
        pass

    def begin_training(self, *args, **kwargs): # real signature unknown
        pass

    def from_disk(self, *args, **kwargs): # real signature unknown
        pass

    def get_loss(self, *args, **kwargs): # real signature unknown
        pass

    def get_loss_old(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def Model(cls, *args, **kwargs): # real signature unknown
        pass

    def pipe(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, *args, **kwargs): # real signature unknown
        pass

    def rehearse(self, *args, **kwargs): # real signature unknown
        pass

    def require_kb(self, *args, **kwargs): # real signature unknown
        pass

    def require_model(self, *args, **kwargs): # real signature unknown
        pass

    def set_annotations(self, *args, **kwargs): # real signature unknown
        pass

    def set_kb(self, *args, **kwargs): # real signature unknown
        pass

    def to_disk(self, *args, **kwargs): # real signature unknown
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    name = 'entity_linker'


class EntityRecognizer(__spacy_syntax_nn_parser.Parser):
    """
    Pipeline component for named entity recognition.
    
        DOCS: https://spacy.io/api/entityrecognizer
    """
    def add_multitask_objective(self, *args, **kwargs): # real signature unknown
        pass

    def init_multitask_objectives(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create a Parser.
        
                vocab (Vocab): The vocabulary object. Must be shared with documents
                    to be processed. The value is set to the `.vocab` attribute.
                moves (TransitionSystem): Defines how the parse-state is created,
                    updated and evaluated. The value is set to the .moves attribute
                    unless True (default), in which case a new instance is created with
                    `Parser.Moves()`.
                model (object): Defines how the parse-state is created, updated and
                    evaluated. The value is set to the .model attribute. If set to True
                    (default), a new instance will be created with `Parser.Model()`
                    in parser.begin_training(), parser.from_disk() or parser.from_bytes().
                **cfg: Arbitrary configuration parameters. Set to the `.cfg` attribute
        """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    labels = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    name = 'ner'
    nr_feature = 6
    TransitionSystem = None # (!) real value is "<class 'spacy.syntax.ner.BiluoPushDown'>"
    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f6396698f60>'


class LayerNorm(__thinc_neural__classes_model.Model):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, X, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_G(self, *args, **kwargs): # real signature unknown
        pass

    def G(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, X): # reliably restored by inspect
        # no doc
        pass

    def _begin_update_scale_shift(self, input__BI): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, child=None, **kwargs): # reliably restored by inspect
        # no doc
        pass

    descriptions = {
        'G': None, # (!) real value is '<thinc.describe.Weights object at 0x7f63db994e80>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7f63db994eb8>'
        'd_G': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63db994f28>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63db994f60>'
    }
    name = 'layernorm'
    on_data_hooks = [
        None, # (!) real value is '<function _run_child_hooks at 0x7f63db993bf8>'
    ]


class Maxout(__thinc_neural__classes_model.Model):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, X__bi, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def nI(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def nP(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, X__BI): # reliably restored by inspect
        # no doc
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, nO=None, nI=None, pieces=2, **kwargs): # reliably restored by inspect
        # no doc
        pass

    describe_input = (
        'nI',
    )
    describe_output = (
        'nO',
    )
    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7f63dc24d5c0>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7f63dc24d5f8>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63dc24d630>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63dc24d668>'
        'nI': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc24d518>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc24d588>'
        'nP': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc24d550>'
    }
    name = 'maxout'
    on_data_hooks = [
        None, # (!) real value is '<function _set_dimensions_if_needed at 0x7f63dc2491e0>'
    ]


class Tagger(Pipe):
    """
    Pipeline component for part-of-speech tagging.
    
        DOCS: https://spacy.io/api/tagger
    """
    def add_label(self, *args, **kwargs): # real signature unknown
        pass

    def begin_training(self, *args, **kwargs): # real signature unknown
        pass

    def from_bytes(self, *args, **kwargs): # real signature unknown
        pass

    def from_disk(self, *args, **kwargs): # real signature unknown
        pass

    def get_loss(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def Model(cls, *args, **kwargs): # real signature unknown
        pass

    def pipe(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, *args, **kwargs): # real signature unknown
        pass

    def rehearse(self, *args, **kwargs): # real signature unknown
        """
        Perform a 'rehearsal' update, where we try to match the output of
                an initial model.
        """
        pass

    def set_annotations(self, *args, **kwargs): # real signature unknown
        pass

    def to_bytes(self, *args, **kwargs): # real signature unknown
        pass

    def to_disk(self, *args, **kwargs): # real signature unknown
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def use_params(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    labels = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tok2vec = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    name = 'tagger'


class MultitaskObjective(Tagger):
    """
    Experimental: Assist training of a parser or tagger, by training a
        side-objective.
    """
    def begin_training(self, *args, **kwargs): # real signature unknown
        pass

    def get_loss(self, *args, **kwargs): # real signature unknown
        pass

    def make_dep(self, *args, **kwargs): # real signature unknown
        pass

    def make_dep_tag_offset(self, *args, **kwargs): # real signature unknown
        pass

    def make_ent(self, *args, **kwargs): # real signature unknown
        pass

    def make_ent_tag(self, *args, **kwargs): # real signature unknown
        pass

    def make_sent_start(self, *args, **kwargs): # real signature unknown
        """
        A multi-task objective for representing sentence boundaries,
                using BILU scheme. (O is impossible)
        
                The implementation of this method uses an internal cache that relies
                on the identity of the heads array, to avoid requiring a new piece
                of gold data. You can pass cache=False if you know the cache will
                do the wrong thing.
        """
        pass

    def make_tag(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def Model(cls, *args, **kwargs): # real signature unknown
        pass

    def predict(self, *args, **kwargs): # real signature unknown
        pass

    def set_annotations(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    labels = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    name = 'nn_labeller'


class OrderedDict(dict):
    """ Dictionary that remembers insertion order """
    def clear(self): # real signature unknown; restored from __doc__
        """ od.clear() -> None.  Remove all items from od. """
        pass

    def copy(self): # real signature unknown; restored from __doc__
        """ od.copy() -> a shallow copy of od """
        pass

    @classmethod
    def fromkeys(cls, S, v=None): # real signature unknown; restored from __doc__
        """
        OD.fromkeys(S[, v]) -> New ordered dictionary with keys from S.
                If not specified, the value defaults to None.
        """
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def move_to_end(self, *args, **kwargs): # real signature unknown
        """
        Move an existing element to the end (or beginning if last==False).
        
                Raises KeyError if the element does not exist.
                When last=True, acts like a fast version of self[key]=self.pop(key).
        """
        pass

    def pop(self, k, d=None): # real signature unknown; restored from __doc__
        """
        od.pop(k[,d]) -> v, remove specified key and return the corresponding
                value.  If key is not found, d is returned if given, otherwise KeyError
                is raised.
        """
        pass

    def popitem(self, *args, **kwargs): # real signature unknown
        """
        Remove and return a (key, value) pair from the dictionary.
        
        Pairs are returned in LIFO order if last is true or FIFO order if false.
        """
        pass

    def setdefault(self, k, d=None): # real signature unknown; restored from __doc__
        """ od.setdefault(k[,d]) -> od.get(k,d), also set od[k]=d if k not in od """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        """ Return self==value. """
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        """ Return self>=value. """
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        """ Return self>value. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        """ Return self<=value. """
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        """ Return self<value. """
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        """ Return self!=value. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    def __reversed__(self): # real signature unknown; restored from __doc__
        """ od.__reversed__() <==> reversed(od) """
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """ Set self[key] to value. """
        pass

    def __sizeof__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is "mappingproxy({'__repr__': <slot wrapper '__repr__' of 'collections.OrderedDict' objects>, '__lt__': <slot wrapper '__lt__' of 'collections.OrderedDict' objects>, '__le__': <slot wrapper '__le__' of 'collections.OrderedDict' objects>, '__eq__': <slot wrapper '__eq__' of 'collections.OrderedDict' objects>, '__ne__': <slot wrapper '__ne__' of 'collections.OrderedDict' objects>, '__gt__': <slot wrapper '__gt__' of 'collections.OrderedDict' objects>, '__ge__': <slot wrapper '__ge__' of 'collections.OrderedDict' objects>, '__iter__': <slot wrapper '__iter__' of 'collections.OrderedDict' objects>, '__init__': <slot wrapper '__init__' of 'collections.OrderedDict' objects>, '__setitem__': <slot wrapper '__setitem__' of 'collections.OrderedDict' objects>, '__delitem__': <slot wrapper '__delitem__' of 'collections.OrderedDict' objects>, 'fromkeys': <method 'fromkeys' of 'collections.OrderedDict' objects>, '__sizeof__': <method '__sizeof__' of 'collections.OrderedDict' objects>, '__reduce__': <method '__reduce__' of 'collections.OrderedDict' objects>, 'setdefault': <method 'setdefault' of 'collections.OrderedDict' objects>, 'pop': <method 'pop' of 'collections.OrderedDict' objects>, 'popitem': <method 'popitem' of 'collections.OrderedDict' objects>, 'keys': <method 'keys' of 'collections.OrderedDict' objects>, 'values': <method 'values' of 'collections.OrderedDict' objects>, 'items': <method 'items' of 'collections.OrderedDict' objects>, 'update': <method 'update' of 'collections.OrderedDict' objects>, 'clear': <method 'clear' of 'collections.OrderedDict' objects>, 'copy': <method 'copy' of 'collections.OrderedDict' objects>, '__reversed__': <method '__reversed__' of 'collections.OrderedDict' objects>, 'move_to_end': <method 'move_to_end' of 'collections.OrderedDict' objects>, '__dict__': <attribute '__dict__' of 'collections.OrderedDict' objects>, '__doc__': 'Dictionary that remembers insertion order', '__hash__': None})"
    __hash__ = None


class Sentencizer(object):
    """
    Segment the Doc into sentences using a rule-based strategy.
    
        DOCS: https://spacy.io/api/sentencizer
    """
    def from_bytes(self, *args, **kwargs): # real signature unknown
        """
        Load the sentencizer from a bytestring.
        
                bytes_data (bytes): The data to load.
                returns (Sentencizer): The loaded object.
        
                DOCS: https://spacy.io/api/sentencizer#from_bytes
        """
        pass

    def from_disk(self, *args, **kwargs): # real signature unknown
        """
        Load the sentencizer from disk.
        
                DOCS: https://spacy.io/api/sentencizer#from_disk
        """
        pass

    def to_bytes(self, *args, **kwargs): # real signature unknown
        """
        Serialize the sentencizer to a bytestring.
        
                RETURNS (bytes): The serialized object.
        
                DOCS: https://spacy.io/api/sentencizer#to_bytes
        """
        pass

    def to_disk(self, *args, **kwargs): # real signature unknown
        """
        Serialize the sentencizer to disk.
        
                DOCS: https://spacy.io/api/sentencizer#to_disk
        """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """
        Apply the sentencizer to a Doc and set Token.is_sent_start.
        
                doc (Doc): The document to process.
                RETURNS (Doc): The processed Doc.
        
                DOCS: https://spacy.io/api/sentencizer#call
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initialize the sentencizer.
        
                punct_chars (list): Punctuation characters to split on. Will be
                    serialized with the nlp object.
                RETURNS (Sentencizer): The sentencizer component.
        
                DOCS: https://spacy.io/api/sentencizer#init
        """
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    default_punct_chars = [
        '.',
        '!',
        '?',
    ]
    name = 'sentencizer'
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'spacy.pipeline.pipes', '__doc__': 'Segment the Doc into sentences using a rule-based strategy.\\n\\n    DOCS: https://spacy.io/api/sentencizer\\n    ', 'name': 'sentencizer', 'default_punct_chars': ['.', '!', '?'], '__init__': <cyfunction Sentencizer.__init__ at 0x7f6394eb4d38>, '__call__': <cyfunction Sentencizer.__call__ at 0x7f6394eb4df0>, 'to_bytes': <cyfunction Sentencizer.to_bytes at 0x7f6394eb4ea8>, 'from_bytes': <cyfunction Sentencizer.from_bytes at 0x7f6394eb4f60>, 'to_disk': <cyfunction Sentencizer.to_disk at 0x7f6394eb5048>, 'from_disk': <cyfunction Sentencizer.from_disk at 0x7f6394eb5100>, '__dict__': <attribute '__dict__' of 'Sentencizer' objects>, '__weakref__': <attribute '__weakref__' of 'Sentencizer' objects>})"


class Softmax(__thinc_neural__classes_affine.Affine):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, input__BI, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def nB(self, *args, **kwargs): # real signature unknown
        pass

    def nI(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, input__BI): # reliably restored by inspect
        # no doc
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, nO=None, nI=None, **kwargs): # reliably restored by inspect
        # no doc
        pass

    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7f63dc24d908>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7f63dc2c0d30>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63dc2c0dd8>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f63dc245c18>'
        'nB': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc2c0c18>'
        'nI': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc2c0c50>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f63dc2c0cc0>'
    }
    name = 'softmax'


class Tensorizer(Pipe):
    """ Pre-train position-sensitive vectors for tokens. """
    def begin_training(self, *args, **kwargs): # real signature unknown
        """
        Allocate models, pre-process training data and acquire an
                optimizer.
        
                gold_tuples (iterable): Gold-standard training data.
                pipeline (list): The pipeline the model is part of.
        """
        pass

    def get_loss(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def Model(cls, *args, **kwargs): # real signature unknown
        """
        Create a new statistical model for the class.
        
                width (int): Output size of the model.
                embed_size (int): Number of vectors in the embedding table.
                **cfg: Config parameters.
                RETURNS (Model): A `thinc.neural.Model` or similar instance.
        """
        pass

    def pipe(self, *args, **kwargs): # real signature unknown
        """
        Process `Doc` objects as a stream.
        
                stream (iterator): A sequence of `Doc` objects to process.
                batch_size (int): Number of `Doc` objects to group.
                YIELDS (iterator): A sequence of `Doc` objects, in order of input.
        """
        pass

    def predict(self, *args, **kwargs): # real signature unknown
        """
        Return a single tensor for a batch of documents.
        
                docs (iterable): A sequence of `Doc` objects.
                RETURNS (object): Vector representations for each token in the docs.
        """
        pass

    def set_annotations(self, *args, **kwargs): # real signature unknown
        """
        Set the tensor attribute for a batch of documents.
        
                docs (iterable): A sequence of `Doc` objects.
                tensors (object): Vector representation for each token in the docs.
        """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        """
        Update the model.
        
                docs (iterable): A batch of `Doc` objects.
                golds (iterable): A batch of `GoldParse` objects.
                drop (float): The dropout rate.
                sgd (callable): An optimizer.
                RETURNS (dict): Results from the update.
        """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """
        Add context-sensitive vectors to a `Doc`, e.g. from a CNN or LSTM
                model. Vectors are set to the `Doc.tensor` attribute.
        
                docs (Doc or iterable): One or more documents to add vectors to.
                RETURNS (dict or None): Intermediate computations.
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Construct a new statistical model. Weights are not allocated on
                initialisation.
        
                vocab (Vocab): A `Vocab` instance. The model must share the same
                    `Vocab` instance with the `Doc` objects it will process.
                model (Model): A `Model` instance or `True` to allocate one later.
                **cfg: Config parameters.
        
                EXAMPLE:
                    >>> from spacy.pipeline import TokenVectorEncoder
                    >>> tok2vec = TokenVectorEncoder(nlp.vocab)
                    >>> tok2vec.model = tok2vec.Model(128, 5000)
        """
        pass

    name = 'tensorizer'


class TextCategorizer(Pipe):
    """
    Pipeline component for text classification.
    
        DOCS: https://spacy.io/api/textcategorizer
    """
    def add_label(self, *args, **kwargs): # real signature unknown
        pass

    def begin_training(self, *args, **kwargs): # real signature unknown
        pass

    def get_loss(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def Model(cls, *args, **kwargs): # real signature unknown
        pass

    def pipe(self, *args, **kwargs): # real signature unknown
        pass

    def predict(self, *args, **kwargs): # real signature unknown
        pass

    def rehearse(self, *args, **kwargs): # real signature unknown
        pass

    def require_labels(self, *args, **kwargs): # real signature unknown
        """ Raise an error if the component's model has no labels defined. """
        pass

    def set_annotations(self, *args, **kwargs): # real signature unknown
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    labels = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    tok2vec = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    name = 'textcat'


# variables with complex values

__all__ = [
    'Tagger',
    'DependencyParser',
    'EntityRecognizer',
    'Tensorizer',
    'TextCategorizer',
    'EntityLinker',
    'Sentencizer',
]

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6395dc05f8>'

__spec__ = None # (!) real value is "ModuleSpec(name='spacy.pipeline.pipes', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6395dc05f8>, origin='/usr/local/lib/python3.6/dist-packages/spacy/pipeline/pipes.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {
    'Tensorizer.__init__ (line 228)': 'Construct a new statistical model. Weights are not allocated on\n        initialisation.\n\n        vocab (Vocab): A `Vocab` instance. The model must share the same\n            `Vocab` instance with the `Doc` objects it will process.\n        model (Model): A `Model` instance or `True` to allocate one later.\n        **cfg: Config parameters.\n\n        EXAMPLE:\n            >>> from spacy.pipeline import TokenVectorEncoder\n            >>> tok2vec = TokenVectorEncoder(nlp.vocab)\n            >>> tok2vec.model = tok2vec.Model(128, 5000)\n        ',
}


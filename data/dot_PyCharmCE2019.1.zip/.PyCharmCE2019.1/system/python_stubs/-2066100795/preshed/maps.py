# encoding: utf-8
# module preshed.maps
# from /usr/local/lib/python3.6/dist-packages/preshed/maps.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values

__path__ = None

# no functions
# classes

class PreshMap(object):
    """
    Hash map that assumes keys come pre-hashed. Maps uint64_t --> uint64_t.
        Uses open addressing with linear probing.
    
        Usage
            map = PreshMap() # Create a table
            map = PreshMap(initial_size=1024) # Create with initial size (efficiency)
            map[key] = value # Set a value to a key
            value = map[key] # Get a value given a key
            for key, value in map.items(): # Iterate over items
            len(map) # Get number of inserted keys
    """
    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def pop(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        """ Return key in self. """
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        """ Delete self[key]. """
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __init__(self): # real signature unknown; restored from __doc__
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        """ Set self[key] to value. """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    capacity = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f8d49f5a690>'


class PreshMapArray(object):
    """
    An array of hash tables that assume keys come pre-hashed.  Each table
        uses open addressing with linear probing.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f8d49f5a6f0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8d49ea0d30>'

__pyx_capi__ = {
    'map_bulk_get': None, # (!) real value is '<capsule object "void *(struct __pyx_t_7preshed_4maps_MapStruct const *, __pyx_t_7preshed_4maps_key_t const *, void **, int)" at 0x7f8d49f5a630>'
    'map_get': None, # (!) real value is '<capsule object "void *(struct __pyx_t_7preshed_4maps_MapStruct const *, __pyx_t_7preshed_4maps_key_t const )" at 0x7f8d49f5a660>'
    'map_init': None, # (!) real value is '<capsule object "void (struct __pyx_obj_5cymem_5cymem_Pool *, struct __pyx_t_7preshed_4maps_MapStruct *, size_t)" at 0x7f8d49f5a6c0>'
    'map_iter': None, # (!) real value is '<capsule object "int (struct __pyx_t_7preshed_4maps_MapStruct const *, int *, __pyx_t_7preshed_4maps_key_t *, void **)" at 0x7f8d49f5a5d0>'
    'map_set': None, # (!) real value is '<capsule object "void (struct __pyx_obj_5cymem_5cymem_Pool *, struct __pyx_t_7preshed_4maps_MapStruct *, __pyx_t_7preshed_4maps_key_t, void *)" at 0x7f8d49f5a600>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='preshed.maps', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8d49ea0d30>, origin='/usr/local/lib/python3.6/dist-packages/preshed/maps.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


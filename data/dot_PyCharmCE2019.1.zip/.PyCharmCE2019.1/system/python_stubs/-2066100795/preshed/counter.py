# encoding: utf-8
# module preshed.counter
# from /usr/local/lib/python3.6/dist-packages/preshed/counter.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
""" Count occurrences of uint64-valued keys. """

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# Variables with simple values

__path__ = None

# no functions
# classes

class GaleSmoother(object):
    # no doc
    def count_count(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    cutoff = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    total = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class PreshCounter(object):
    # no doc
    def inc(self, *args, **kwargs): # real signature unknown
        pass

    def prob(self, *args, **kwargs): # real signature unknown
        pass

    def smooth(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    smoother = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    total = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f5944605660>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f594454bd30>'

__spec__ = None # (!) real value is "ModuleSpec(name='preshed.counter', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f594454bd30>, origin='/usr/local/lib/python3.6/dist-packages/preshed/counter.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


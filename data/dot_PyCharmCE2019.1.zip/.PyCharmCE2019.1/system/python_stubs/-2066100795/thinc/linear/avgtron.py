# encoding: utf-8
# module thinc.linear.avgtron
# from /usr/local/lib/python3.6/dist-packages/thinc/linear/avgtron.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import posixpath as path # /usr/lib/python3.6/posixpath.py

# functions

def __pyx_unpickle_AveragedPerceptron(*args, **kwargs): # real signature unknown
    pass

# classes

class AveragedPerceptron(object):
    """
    A linear model for online supervised classification.
        Expected use is via Cython --- the Python API is impoverished and inefficient.
    
        Emphasis is on efficiency for multi-class classification, where the number
        of classes is in the dozens or low hundreds.
    """
    def apply_owed_L1(self, *args, **kwargs): # real signature unknown
        pass

    def dump(self, *args, **kwargs): # real signature unknown
        pass

    def end_training(self, *args, **kwargs): # real signature unknown
        pass

    def load(self, *args, **kwargs): # real signature unknown
        pass

    def resume_training(self, *args, **kwargs): # real signature unknown
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def update_weight(self, *args, **kwargs): # real signature unknown
        pass

    def update_weight_ftrl(self, *args, **kwargs): # real signature unknown
        pass

    def with_averages(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    averages = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    L1 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    l1_penalty = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    lasso_ledger = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    learn_rate = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    mem = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    momentum = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_active_feat = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_feat = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_weight = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    time = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    weights = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f6ecc335660>'


class _AverageHelper(object):
    # no doc
    def __enter__(self, *args, **kwargs): # real signature unknown
        pass

    def __exit__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'thinc.linear.avgtron', '__init__': <cyfunction _AverageHelper.__init__ at 0x7f6ebde5e9a0>, '__enter__': <cyfunction _AverageHelper.__enter__ at 0x7f6ebde5ea58>, '__exit__': <cyfunction _AverageHelper.__exit__ at 0x7f6ebde5eb10>, '__dict__': <attribute '__dict__' of '_AverageHelper' objects>, '__weakref__': <attribute '__weakref__' of '_AverageHelper' objects>, '__doc__': None})"


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6ecc1bb550>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.linear.avgtron', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f6ecc1bb550>, origin='/usr/local/lib/python3.6/dist-packages/thinc/linear/avgtron.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


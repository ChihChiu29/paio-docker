# encoding: utf-8
# module thinc.linear.serialize
# from /usr/local/lib/python3.6/dist-packages/thinc/linear/serialize.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import posixpath as path # /usr/lib/python3.6/posixpath.py

# no functions
# classes

class Reader(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    nr_feat = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f25959612a0>'


class Writer(object):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f25a1386660>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f25a120ce10>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.linear.serialize', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f25a120ce10>, origin='/usr/local/lib/python3.6/dist-packages/thinc/linear/serialize.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


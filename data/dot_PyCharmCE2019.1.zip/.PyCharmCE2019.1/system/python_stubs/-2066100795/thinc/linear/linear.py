# encoding: utf-8
# module thinc.linear.linear
# from /usr/local/lib/python3.6/dist-packages/thinc/linear/linear.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import thinc.describe as describe # /usr/local/lib/python3.6/dist-packages/thinc/describe.py
import thinc.describe as __thinc_describe
import thinc.neural._classes.model as __thinc_neural__classes_model


# functions

def is_cupy_array(arr): # reliably restored by inspect
    """ Check whether an array is a cupy array """
    pass

def is_numpy_array(arr): # reliably restored by inspect
    """ Check whether an array is a numpy array """
    pass

def _get_bias_shape(*args, **kwargs): # real signature unknown
    pass

def _get_W_shape(*args, **kwargs): # real signature unknown
    pass

def _init_W(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class Biases(__thinc_describe.Weights):
    # no doc
    def __init__(self, text, get_shape, init=None): # reliably restored by inspect
        # no doc
        pass


class Dimension(__thinc_describe.AttributeDescription):
    # no doc
    def __get__(self, obj, type=None): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, text, value=None, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    def __set__(self, obj, value): # reliably restored by inspect
        # no doc
        pass


class Gradient(__thinc_describe.AttributeDescription):
    # no doc
    def __get__(self, obj, type=None): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, param_name): # reliably restored by inspect
        # no doc
        pass

    def __set__(self, obj, val): # reliably restored by inspect
        # no doc
        pass


class Model(object):
    """ Model base class. """
    def begin_training(self, train_X, train_y=None, **trainer_cfg): # reliably restored by inspect
        # no doc
        pass

    def begin_update(self, X, drop=0.0): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def define_operators(cls, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
        """
        Bind operators to specified functions for the scope of the context:
        
                Example
                -------
        
                    model = Model()
                    other = Model()
                    with Model.define_operators({"+": lambda self, other: "plus"}):
                        print(model + other)
                        # "plus"
                    print(model + other)
                    # Raises TypeError --- binding limited to scope of with block.
        """
        pass

    def evaluate(self, X, y): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
                y
                    Must match expected type
        """
        pass

    def evaluate_logloss(self, X, y, minimum=None, maximum=None): # reliably restored by inspect
        # no doc
        pass

    def from_bytes(self, bytes_data): # reliably restored by inspect
        # no doc
        pass

    def from_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def pipe(self, stream, batch_size=128): # reliably restored by inspect
        # no doc
        pass

    def predict(self, X): # reliably restored by inspect
        # no doc
        pass

    def predict_one(self, x): # reliably restored by inspect
        # no doc
        pass

    def set_id(self): # reliably restored by inspect
        # no doc
        pass

    def to_bytes(self): # reliably restored by inspect
        # no doc
        pass

    def to_cpu(self): # reliably restored by inspect
        # no doc
        pass

    def to_disk(self, path): # reliably restored by inspect
        # no doc
        pass

    def to_gpu(self, device_num): # reliably restored by inspect
        # no doc
        pass

    def update(self, stream, batch_size=1000): # reliably restored by inspect
        # no doc
        pass

    @classmethod
    def use_device(cls, *args, **kwargs): # real signature unknown
        """ Change the device to execute on for the scope of the block. """
        pass

    def use_params(*args, **kwds): # reliably restored by inspect
        # no doc
        pass

    def _update_defaults(self, args, kwargs): # reliably restored by inspect
        # no doc
        pass

    def __add__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '+' operator. """
        pass

    def __and__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '&' operator. """
        pass

    def __call__(self, x): # reliably restored by inspect
        """
        x
                    Must match expected type
                    Must match expected shape
        """
        pass

    def __div__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __floordiv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '//' operator. """
        pass

    def __getstate__(self): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    def __lshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '<<' operator. """
        pass

    def __matmul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '@' operator. """
        pass

    def __mod__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '%' operator. """
        pass

    def __mul__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '*' operator. """
        pass

    def __or__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '|' operator. """
        pass

    def __pow__(self, other, modulo=None): # reliably restored by inspect
        """ Apply the function bound to the '**' operator. """
        pass

    def __rshift__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '>>' operator. """
        pass

    def __setstate__(self, state_data): # reliably restored by inspect
        # no doc
        pass

    def __sub__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '-' operator. """
        pass

    def __truediv__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '/' operator. """
        pass

    def __xor__(self, other): # reliably restored by inspect
        """ Apply the function bound to the '^' operator. """
        pass

    input_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    output_shape = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    descriptions = []
    drop_factor = 1.0
    id = 0
    lsuv = False
    name = 'model'
    on_data_hooks = []
    on_init_hooks = []
    ops = None # (!) real value is '<thinc.neural.ops.NumpyOps object at 0x7f06a80085c0>'
    Ops = None # (!) real value is "<class 'thinc.neural.ops.NumpyOps'>"
    Trainer = None # (!) real value is "<class 'thinc.neural.train.Trainer'>"
    _operators = {}
    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'thinc.neural._classes.model', '__doc__': 'Model base class.', 'name': 'model', 'id': 0, 'lsuv': False, 'ops': <thinc.neural.ops.NumpyOps object at 0x7f06a80085c0>, 'Ops': <class 'thinc.neural.ops.NumpyOps'>, 'Trainer': <class 'thinc.neural.train.Trainer'>, 'drop_factor': 1.0, 'descriptions': [], 'on_data_hooks': [], 'on_init_hooks': [], '_operators': {}, 'define_operators': <classmethod object at 0x7f06a80085f8>, 'use_device': <classmethod object at 0x7f06a80087b8>, 'input_shape': <property object at 0x7f06a44003b8>, 'output_shape': <property object at 0x7f06a41c06d8>, '__init__': <function Model.__init__ at 0x7f06a41c5488>, '__getstate__': <function Model.__getstate__ at 0x7f06a41c5510>, '__setstate__': <function Model.__setstate__ at 0x7f06a41c5598>, '_update_defaults': <function Model._update_defaults at 0x7f06a41c5620>, 'set_id': <function Model.set_id at 0x7f06a41c56a8>, 'begin_training': <FunctionWrapper at 0x7f06a41a9730 for function at 0x7f06a41c5950>, 'begin_update': <FunctionWrapper at 0x7f06a41a9a08 for function at 0x7f06a41c5d08>, 'predict': <function Model.predict at 0x7f06a41c59d8>, 'predict_one': <function Model.predict_one at 0x7f06a41c57b8>, 'use_params': <function Model.use_params at 0x7f06a41c58c8>, '__call__': <function Model.__call__ at 0x7f06a41c5c80>, 'pipe': <function Model.pipe at 0x7f06a41c5bf8>, 'update': <function Model.update at 0x7f06a41c5b70>, 'to_gpu': <function Model.to_gpu at 0x7f06a41c5d90>, 'to_cpu': <function Model.to_cpu at 0x7f06a41c5e18>, 'evaluate': <function Model.evaluate at 0x7f06a41c5ea0>, 'evaluate_logloss': <function Model.evaluate_logloss at 0x7f06a41c5f28>, '__add__': <FunctionWrapper at 0x7f06a41a99a0 for function at 0x7f06a41c71e0>, '__sub__': <FunctionWrapper at 0x7f06a41a9a70 for function at 0x7f06a41c72f0>, '__mul__': <FunctionWrapper at 0x7f06a41a9ad8 for function at 0x7f06a41c7400>, '__matmul__': <FunctionWrapper at 0x7f06a41a9b40 for function at 0x7f06a41c7510>, '__div__': <FunctionWrapper at 0x7f06a41a9ba8 for function at 0x7f06a41c7620>, '__truediv__': <FunctionWrapper at 0x7f06a41a9c10 for function at 0x7f06a41c7730>, '__floordiv__': <FunctionWrapper at 0x7f06a41a9c78 for function at 0x7f06a41c7840>, '__mod__': <FunctionWrapper at 0x7f06a41a9ce0 for function at 0x7f06a41c7950>, '__pow__': <FunctionWrapper at 0x7f06a41a9d48 for function at 0x7f06a41c7a60>, '__lshift__': <FunctionWrapper at 0x7f06a41a9db0 for function at 0x7f06a41c7b70>, '__rshift__': <FunctionWrapper at 0x7f06a41a9e18 for function at 0x7f06a41c7c80>, '__and__': <FunctionWrapper at 0x7f06a41a9e80 for function at 0x7f06a41c7d90>, '__xor__': <FunctionWrapper at 0x7f06a41a9ee8 for function at 0x7f06a41c7ea0>, '__or__': <FunctionWrapper at 0x7f06a41a9f50 for function at 0x7f06a41c9048>, 'to_bytes': <function Model.to_bytes at 0x7f06a41c7f28>, 'from_bytes': <function Model.from_bytes at 0x7f06a41c70d0>, 'to_disk': <function Model.to_disk at 0x7f06a41c90d0>, 'from_disk': <function Model.from_disk at 0x7f06a41c9158>, '__dict__': <attribute '__dict__' of 'Model' objects>, '__weakref__': <attribute '__weakref__' of 'Model' objects>})"


class LinearModel(__thinc_neural__classes_model.Model):
    # no doc
    def b(self, *args, **kwargs): # real signature unknown
        pass

    def begin_update(self, *args, **kwargs): # real signature unknown
        pass

    def d_b(self, *args, **kwargs): # real signature unknown
        pass

    def d_W(self, *args, **kwargs): # real signature unknown
        pass

    def length(self, *args, **kwargs): # real signature unknown
        pass

    def nO(self, *args, **kwargs): # real signature unknown
        pass

    def W(self, *args, **kwargs): # real signature unknown
        pass

    def _begin_cpu_update(self, *args, **kwargs): # real signature unknown
        pass

    def _begin_gpu_update(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    descriptions = {
        'W': None, # (!) real value is '<thinc.describe.Synapses object at 0x7f06a7ffb320>'
        'b': None, # (!) real value is '<thinc.describe.Biases object at 0x7f06a7ffb358>'
        'd_W': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f06a7ffb3c8>'
        'd_b': None, # (!) real value is '<thinc.describe.Gradient object at 0x7f06a7ffb518>'
        'length': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f06a7ffb278>'
        'nO': None, # (!) real value is '<thinc.describe.Dimension object at 0x7f06a7ffb240>'
    }
    name = 'linear'


class Synapses(__thinc_describe.Weights):
    # no doc
    def __init__(self, text, get_shape, init=None): # reliably restored by inspect
        # no doc
        pass


class _finish_linear_update(object):
    """
    Move this out of a closure, into its own callable object, to avoid
        pickling errors :(.
    """
    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'thinc.linear.linear', '__doc__': 'Move this out of a closure, into its own callable object, to avoid\\n    pickling errors :(.', '__init__': <cyfunction _finish_linear_update.__init__ at 0x7f06a41cc270>, '__call__': <cyfunction _finish_linear_update.__call__ at 0x7f06a41cc328>, '__dict__': <attribute '__dict__' of '_finish_linear_update' objects>, '__weakref__': <attribute '__weakref__' of '_finish_linear_update' objects>})"


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f06b388a550>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.linear.linear', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f06b388a550>, origin='/usr/local/lib/python3.6/dist-packages/thinc/linear/linear.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


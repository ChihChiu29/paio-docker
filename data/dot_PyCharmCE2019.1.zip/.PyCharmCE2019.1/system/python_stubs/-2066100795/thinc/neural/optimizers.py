# encoding: utf-8
# module thinc.neural.optimizers
# from /usr/local/lib/python3.6/dist-packages/thinc/neural/optimizers.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as numpy # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py
from thinc.neural.ops import CupyOps, NumpyOps, add_gradient_noise


# functions

def Adam(*args, **kwargs): # real signature unknown
    pass

def anneal(*args, **kwargs): # real signature unknown
    pass

def get_array_module(_): # reliably restored by inspect
    # no doc
    pass

def linear_decay(*args, **kwargs): # real signature unknown
    pass

def SGD(*args, **kwargs): # real signature unknown
    pass

# classes

class defaultdict(dict):
    """
    defaultdict(default_factory[, ...]) --> dict with default factory
    
    The default factory is called without arguments to produce
    a new value when a key is not present, in __getitem__ only.
    A defaultdict compares equal to a dict with the same items.
    All remaining arguments are treated the same as if they were
    passed to the dict constructor, including keyword arguments.
    """
    def copy(self): # real signature unknown; restored from __doc__
        """ D.copy() -> a shallow copy of D. """
        pass

    def __copy__(self, *args, **kwargs): # real signature unknown
        """ D.copy() -> a shallow copy of D. """
        pass

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __init__(self, default_factory, *some): # real signature unknown; restored from __doc__
        pass

    def __missing__(self, key): # real signature unknown; restored from __doc__
        """
        __missing__(key) # Called by __getitem__ for missing key; pseudo-code:
          if self.default_factory is None: raise KeyError((key,))
          self[key] = value = self.default_factory()
          return value
        """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling. """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return repr(self). """
        pass

    default_factory = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """Factory for default value called by __missing__()."""



class Optimizer(object):
    """
    Do various flavours of stochastic gradient descent, with first and
        second order momentum.
        
        Examples
        
        * beta1=0., beta2=0.: "vanilla" SGD
        * beta1=0.9, beta2=0.: "Classic momentum"
        * beta1=0.0, beta2=0.2: RMS prop
        * b1=0.999, b2=0.9: Adam
    """
    def lr(self, *args, **kwargs): # real signature unknown
        pass

    def to_cpu(self, *args, **kwargs): # real signature unknown
        pass

    def to_gpu(self, *args, **kwargs): # real signature unknown
        pass

    def _adam(self, *args, **kwargs): # real signature unknown
        pass

    def _nesterov(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is 'mappingproxy({\'__module__\': \'thinc.neural.optimizers\', \'__doc__\': \'Do various flavours of stochastic gradient descent, with first and\\n    second order momentum.\\n    \\n    Examples\\n    \\n    * beta1=0., beta2=0.: "vanilla" SGD\\n    * beta1=0.9, beta2=0.: "Classic momentum"\\n    * beta1=0.0, beta2=0.2: RMS prop\\n    * b1=0.999, b2=0.9: Adam\\n    \', \'__init__\': <cyfunction Optimizer.__init__ at 0x7fec075788e8>, \'to_gpu\': <cyfunction Optimizer.to_gpu at 0x7fec075789a0>, \'to_cpu\': <cyfunction Optimizer.to_cpu at 0x7fec07578a58>, \'lr\': <cyfunction Optimizer.lr at 0x7fec07578b10>, \'__call__\': <cyfunction Optimizer.__call__ at 0x7fec07578bc8>, \'_nesterov\': <cyfunction Optimizer._nesterov at 0x7fec07578c80>, \'_adam\': <cyfunction Optimizer._adam at 0x7fec07578d38>, \'__dict__\': <attribute \'__dict__\' of \'Optimizer\' objects>, \'__weakref__\': <attribute \'__weakref__\' of \'Optimizer\' objects>})'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fec0a602f28>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.neural.optimizers', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fec0a602f28>, origin='/usr/local/lib/python3.6/dist-packages/thinc/neural/optimizers.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


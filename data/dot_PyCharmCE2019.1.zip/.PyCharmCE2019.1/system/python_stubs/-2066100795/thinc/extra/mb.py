# encoding: utf-8
# module thinc.extra.mb
# from /usr/local/lib/python3.6/dist-packages/thinc/extra/mb.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# classes

class Minibatch(object):
    # no doc
    def best(self, *args, **kwargs): # real signature unknown
        pass

    def guess(self, *args, **kwargs): # real signature unknown
        pass

    def loss(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        """ Return self[key]. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        """ Implement iter(self). """
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        """ Return len(self). """
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    nr_class = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    widths = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f1ae3baa630>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1ad81d7e48>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.extra.mb', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f1ad81d7e48>, origin='/usr/local/lib/python3.6/dist-packages/thinc/extra/mb.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


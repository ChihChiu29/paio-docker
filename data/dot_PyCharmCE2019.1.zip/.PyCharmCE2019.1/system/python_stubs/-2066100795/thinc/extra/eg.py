# encoding: utf-8
# module thinc.extra.eg
# from /usr/local/lib/python3.6/dist-packages/thinc/extra/eg.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# classes

class Example(object):
    # no doc
    def fill_atoms(self, *args, **kwargs): # real signature unknown
        pass

    def fill_costs(self, *args, **kwargs): # real signature unknown
        pass

    def fill_features(self, *args, **kwargs): # real signature unknown
        pass

    def fill_is_valid(self, *args, **kwargs): # real signature unknown
        pass

    def fill_scores(self, *args, **kwargs): # real signature unknown
        pass

    def reset(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    best = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    cost = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    costs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    features = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    guess = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    is_valid = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    loss = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_atom = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_class = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    nr_feat = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    scores = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7fc4dc12d630>'


# variables with complex values

integer_types = (
    int,
)

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc4d069ceb8>'

__spec__ = None # (!) real value is "ModuleSpec(name='thinc.extra.eg', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fc4d069ceb8>, origin='/usr/local/lib/python3.6/dist-packages/thinc/extra/eg.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


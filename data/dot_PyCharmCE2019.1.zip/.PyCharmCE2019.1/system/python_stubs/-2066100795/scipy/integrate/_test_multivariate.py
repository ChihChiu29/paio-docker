# encoding: utf-8
# module scipy.integrate._test_multivariate
# from /usr/local/lib/python3.6/dist-packages/scipy/integrate/_test_multivariate.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

_multivariate_indefinite = 140135868770752
_multivariate_sin = 140135868770736
_multivariate_typical = 140135868770832

_sin_0 = 140135868770720
_sin_1 = 140135868770704
_sin_2 = 140135868770688
_sin_3 = 140135868770672

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f73f4b08cc0>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.integrate._test_multivariate', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f73f4b08cc0>, origin='/usr/local/lib/python3.6/dist-packages/scipy/integrate/_test_multivariate.cpython-36m-x86_64-linux-gnu.so')"


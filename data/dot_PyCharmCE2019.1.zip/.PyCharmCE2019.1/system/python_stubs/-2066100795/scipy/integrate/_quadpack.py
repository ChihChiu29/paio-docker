# encoding: utf-8
# module scipy.integrate._quadpack
# from /usr/local/lib/python3.6/dist-packages/scipy/integrate/_quadpack.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__version__ = ' 1.13 '

# functions

def _qagie(fun, bound, inf, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ [result,abserr,infodict,ier] = _qagie(fun, bound, inf, | args, full_output, epsabs, epsrel, limit) """
    pass

def _qagpe(fun, a, b, points, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ [result,abserr,infodict,ier] = _qagpe(fun, a, b, points, | args, full_output, epsabs, epsrel, limit) """
    pass

def _qagse(fun, a, b, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ [result,abserr,infodict,ier] = _qagse(fun, a, b, | args, full_output, epsabs, epsrel, limit) """
    pass

def _qawce(fun, a, b, c, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ [result,abserr,infodict,ier] = _qawce(fun, a, b, c, | args, full_output, epsabs, epsrel, limit) """
    pass

def _qawfe(fun, a, omega, integr, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ [result,abserr,infodict,ier] = _qawfe(fun, a, omega, integr, | args, full_output, epsabs, limlst, limit, maxp1) """
    pass

def _qawoe(fun, a, b, omega, integr, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ [result,abserr,infodict,ier] = _qawoe(fun, a, b, omega, integr, | args, full_output, epsabs, epsrel, limit, maxp1, icall, momcom, chebmo) """
    pass

def _qawse(fun, a, b, (alfa, beta), integr, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ [result,abserr,infodict,ier] = _qawse(fun, a, b, (alfa, beta), integr, | args, full_output, epsabs, epsrel, limit) """
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f08bf8c4710>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.integrate._quadpack', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f08bf8c4710>, origin='/usr/local/lib/python3.6/dist-packages/scipy/integrate/_quadpack.cpython-36m-x86_64-linux-gnu.so')"


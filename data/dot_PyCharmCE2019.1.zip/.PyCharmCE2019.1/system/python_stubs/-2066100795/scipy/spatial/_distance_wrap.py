# encoding: utf-8
# module scipy.spatial._distance_wrap
# from /usr/local/lib/python3.6/dist-packages/scipy/spatial/_distance_wrap.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def cdist_braycurtis_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_canberra_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_chebyshev_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_cityblock_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_correlation_double_wrap(XA, XB, dm, **kwargs): # reliably restored by inspect
    # no doc
    pass

def cdist_cosine_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_dice_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_euclidean_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_hamming_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_hamming_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_jaccard_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_jaccard_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_jensenshannon_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_kulsinski_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_mahalanobis_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_minkowski_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_rogerstanimoto_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_russellrao_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_seuclidean_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_sokalmichener_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_sokalsneath_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_sqeuclidean_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_wminkowski_double_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_yule_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_braycurtis_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_canberra_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_chebyshev_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_cityblock_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_correlation_double_wrap(X, dm, **kwargs): # reliably restored by inspect
    # no doc
    pass

def pdist_cosine_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_dice_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_euclidean_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_hamming_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_hamming_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_jaccard_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_jaccard_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_jensenshannon_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_kulsinski_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_mahalanobis_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_minkowski_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_rogerstanimoto_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_russellrao_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_seuclidean_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_sokalmichener_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_sokalsneath_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_sqeuclidean_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_wminkowski_double_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_yule_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def to_squareform_from_vector_wrap(*args, **kwargs): # real signature unknown
    pass

def to_vector_from_squareform_wrap(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb11720c390>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.spatial._distance_wrap', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb11720c390>, origin='/usr/local/lib/python3.6/dist-packages/scipy/spatial/_distance_wrap.cpython-36m-x86_64-linux-gnu.so')"


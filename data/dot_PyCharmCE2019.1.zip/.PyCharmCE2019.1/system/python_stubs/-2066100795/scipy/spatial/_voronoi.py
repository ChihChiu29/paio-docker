# encoding: utf-8
# module scipy.spatial._voronoi
# from /usr/local/lib/python3.6/dist-packages/scipy/spatial/_voronoi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
"""
Spherical Voronoi Cython Code

.. versionadded:: 0.19.0
"""

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py

# functions

def sort_vertices_of_regions(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__all__ = [
    'sort_vertices_of_regions',
]

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb6cf2da7f0>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.spatial._voronoi', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb6cf2da7f0>, origin='/usr/local/lib/python3.6/dist-packages/scipy/spatial/_voronoi.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


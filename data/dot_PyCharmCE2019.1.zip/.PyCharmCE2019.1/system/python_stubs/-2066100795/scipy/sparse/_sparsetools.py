# encoding: utf-8
# module scipy.sparse._sparsetools
# from /usr/local/lib/python3.6/dist-packages/scipy/sparse/_sparsetools.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def bsr_diagonal(*args, **kwargs): # real signature unknown
    pass

def bsr_eldiv_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_elmul_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_ge_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_gt_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_le_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_lt_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_matmat_pass2(*args, **kwargs): # real signature unknown
    pass

def bsr_matvec(*args, **kwargs): # real signature unknown
    pass

def bsr_matvecs(*args, **kwargs): # real signature unknown
    pass

def bsr_maximum_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_minimum_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_minus_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_ne_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_plus_bsr(*args, **kwargs): # real signature unknown
    pass

def bsr_scale_columns(*args, **kwargs): # real signature unknown
    pass

def bsr_scale_rows(*args, **kwargs): # real signature unknown
    pass

def bsr_sort_indices(*args, **kwargs): # real signature unknown
    pass

def bsr_tocsr(*args, **kwargs): # real signature unknown
    pass

def bsr_transpose(*args, **kwargs): # real signature unknown
    pass

def coo_matvec(*args, **kwargs): # real signature unknown
    pass

def coo_tocsr(*args, **kwargs): # real signature unknown
    pass

def coo_todense(*args, **kwargs): # real signature unknown
    pass

def csc_diagonal(*args, **kwargs): # real signature unknown
    pass

def csc_eldiv_csc(*args, **kwargs): # real signature unknown
    pass

def csc_elmul_csc(*args, **kwargs): # real signature unknown
    pass

def csc_ge_csc(*args, **kwargs): # real signature unknown
    pass

def csc_gt_csc(*args, **kwargs): # real signature unknown
    pass

def csc_le_csc(*args, **kwargs): # real signature unknown
    pass

def csc_lt_csc(*args, **kwargs): # real signature unknown
    pass

def csc_matmat_pass1(*args, **kwargs): # real signature unknown
    pass

def csc_matmat_pass2(*args, **kwargs): # real signature unknown
    pass

def csc_matvec(*args, **kwargs): # real signature unknown
    pass

def csc_matvecs(*args, **kwargs): # real signature unknown
    pass

def csc_maximum_csc(*args, **kwargs): # real signature unknown
    pass

def csc_minimum_csc(*args, **kwargs): # real signature unknown
    pass

def csc_minus_csc(*args, **kwargs): # real signature unknown
    pass

def csc_ne_csc(*args, **kwargs): # real signature unknown
    pass

def csc_plus_csc(*args, **kwargs): # real signature unknown
    pass

def csc_tocsr(*args, **kwargs): # real signature unknown
    pass

def csr_column_index1(*args, **kwargs): # real signature unknown
    pass

def csr_column_index2(*args, **kwargs): # real signature unknown
    pass

def csr_count_blocks(*args, **kwargs): # real signature unknown
    pass

def csr_diagonal(*args, **kwargs): # real signature unknown
    pass

def csr_eldiv_csr(*args, **kwargs): # real signature unknown
    pass

def csr_eliminate_zeros(*args, **kwargs): # real signature unknown
    pass

def csr_elmul_csr(*args, **kwargs): # real signature unknown
    pass

def csr_ge_csr(*args, **kwargs): # real signature unknown
    pass

def csr_gt_csr(*args, **kwargs): # real signature unknown
    pass

def csr_has_canonical_format(*args, **kwargs): # real signature unknown
    pass

def csr_has_sorted_indices(*args, **kwargs): # real signature unknown
    pass

def csr_le_csr(*args, **kwargs): # real signature unknown
    pass

def csr_lt_csr(*args, **kwargs): # real signature unknown
    pass

def csr_matmat_pass1(*args, **kwargs): # real signature unknown
    pass

def csr_matmat_pass2(*args, **kwargs): # real signature unknown
    pass

def csr_matvec(*args, **kwargs): # real signature unknown
    pass

def csr_matvecs(*args, **kwargs): # real signature unknown
    pass

def csr_maximum_csr(*args, **kwargs): # real signature unknown
    pass

def csr_minimum_csr(*args, **kwargs): # real signature unknown
    pass

def csr_minus_csr(*args, **kwargs): # real signature unknown
    pass

def csr_ne_csr(*args, **kwargs): # real signature unknown
    pass

def csr_plus_csr(*args, **kwargs): # real signature unknown
    pass

def csr_row_index(*args, **kwargs): # real signature unknown
    pass

def csr_row_slice(*args, **kwargs): # real signature unknown
    pass

def csr_sample_offsets(*args, **kwargs): # real signature unknown
    pass

def csr_sample_values(*args, **kwargs): # real signature unknown
    pass

def csr_scale_columns(*args, **kwargs): # real signature unknown
    pass

def csr_scale_rows(*args, **kwargs): # real signature unknown
    pass

def csr_sort_indices(*args, **kwargs): # real signature unknown
    pass

def csr_sum_duplicates(*args, **kwargs): # real signature unknown
    pass

def csr_tobsr(*args, **kwargs): # real signature unknown
    pass

def csr_tocsc(*args, **kwargs): # real signature unknown
    pass

def csr_todense(*args, **kwargs): # real signature unknown
    pass

def cs_graph_components(*args, **kwargs): # real signature unknown
    pass

def dia_matvec(*args, **kwargs): # real signature unknown
    pass

def expandptr(*args, **kwargs): # real signature unknown
    pass

def get_csr_submatrix(*args, **kwargs): # real signature unknown
    pass

def test_throw_error(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f903d494b38>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.sparse._sparsetools', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f903d494b38>, origin='/usr/local/lib/python3.6/dist-packages/scipy/sparse/_sparsetools.cpython-36m-x86_64-linux-gnu.so')"


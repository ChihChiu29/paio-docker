# encoding: utf-8
# module scipy.stats._stats
# from /usr/local/lib/python3.6/dist-packages/scipy/stats/_stats.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py
import scipy as scipy # /usr/local/lib/python3.6/dist-packages/scipy/__init__.py

# functions

def von_mises_cdf(*args, **kwargs): # real signature unknown
    pass

def _kendall_dis(*args, **kwargs): # real signature unknown
    pass

def _toint64(*args, **kwargs): # real signature unknown
    pass

def _weightedrankedtau(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f57b6ec39b0>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.stats._stats', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f57b6ec39b0>, origin='/usr/local/lib/python3.6/dist-packages/scipy/stats/_stats.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


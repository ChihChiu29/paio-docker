# encoding: utf-8
# module scipy.special._test_round
# from /usr/local/lib/python3.6/dist-packages/scipy/special/_test_round.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py

# functions

def assert_(val, msg=None): # reliably restored by inspect
    """
    Assert that works in release mode.
        Accepts callable msg to allow deferring evaluation until failure.
    
        The Python built-in ``assert`` does not work when executing code in
        optimized mode (the ``-O`` flag) - no byte-code is generated for it.
    
        For documentation on usage, refer to the Python documentation.
    """
    pass

def have_fenv(*args, **kwargs): # real signature unknown
    pass

def random_double(*args, **kwargs): # real signature unknown
    pass

def test_add_round(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f5bd9db6400>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.special._test_round', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f5bd9db6400>, origin='/usr/local/lib/python3.6/dist-packages/scipy/special/_test_round.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


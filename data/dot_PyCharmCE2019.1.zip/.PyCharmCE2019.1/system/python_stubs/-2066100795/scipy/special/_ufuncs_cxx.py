# encoding: utf-8
# module scipy.special._ufuncs_cxx
# from /usr/local/lib/python3.6/dist-packages/scipy/special/_ufuncs_cxx.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb30dfc0f98>'

__pyx_capi__ = {
    '_export_faddeeva_dawsn': None, # (!) real value is '<capsule object "void *" at 0x7fb30df92420>'
    '_export_faddeeva_dawsn_complex': None, # (!) real value is '<capsule object "void *" at 0x7fb30df92720>'
    '_export_faddeeva_erf': None, # (!) real value is '<capsule object "void *" at 0x7fb30df926f0>'
    '_export_faddeeva_erfc': None, # (!) real value is '<capsule object "void *" at 0x7fb30df926c0>'
    '_export_faddeeva_erfcx': None, # (!) real value is '<capsule object "void *" at 0x7fb30df92750>'
    '_export_faddeeva_erfcx_complex': None, # (!) real value is '<capsule object "void *" at 0x7fb30df92780>'
    '_export_faddeeva_erfi': None, # (!) real value is '<capsule object "void *" at 0x7fb30df927b0>'
    '_export_faddeeva_erfi_complex': None, # (!) real value is '<capsule object "void *" at 0x7fb30df927e0>'
    '_export_faddeeva_log_ndtr': None, # (!) real value is '<capsule object "void *" at 0x7fb30df92810>'
    '_export_faddeeva_ndtr': None, # (!) real value is '<capsule object "void *" at 0x7fb30df92840>'
    '_export_faddeeva_w': None, # (!) real value is '<capsule object "void *" at 0x7fb30df92870>'
    '_export_wrightomega': None, # (!) real value is '<capsule object "void *" at 0x7fb30df928a0>'
    '_set_action': None, # (!) real value is '<capsule object "void (sf_error_t, sf_action_t)" at 0x7fb30df928d0>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.special._ufuncs_cxx', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fb30dfc0f98>, origin='/usr/local/lib/python3.6/dist-packages/scipy/special/_ufuncs_cxx.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


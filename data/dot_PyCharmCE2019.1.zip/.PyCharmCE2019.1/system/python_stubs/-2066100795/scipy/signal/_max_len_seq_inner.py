# encoding: utf-8
# module scipy.signal._max_len_seq_inner
# from /usr/local/lib/python3.6/dist-packages/scipy/signal/_max_len_seq_inner.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py

# functions

def _max_len_seq_inner(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f83ee4536a0>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.signal._max_len_seq_inner', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f83ee4536a0>, origin='/usr/local/lib/python3.6/dist-packages/scipy/signal/_max_len_seq_inner.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


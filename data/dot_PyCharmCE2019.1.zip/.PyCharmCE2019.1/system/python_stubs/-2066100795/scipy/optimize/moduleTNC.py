# encoding: utf-8
# module scipy.optimize.moduleTNC
# from /usr/local/lib/python3.6/dist-packages/scipy/optimize/moduleTNC.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def minimize(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8b8f4a5c88>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.optimize.moduleTNC', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8b8f4a5c88>, origin='/usr/local/lib/python3.6/dist-packages/scipy/optimize/moduleTNC.cpython-36m-x86_64-linux-gnu.so')"


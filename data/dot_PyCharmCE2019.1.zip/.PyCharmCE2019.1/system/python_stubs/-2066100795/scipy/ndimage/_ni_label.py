# encoding: utf-8
# module scipy.ndimage._ni_label
# from /usr/local/lib/python3.6/dist-packages/scipy/ndimage/_ni_label.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import numpy as np # /usr/local/lib/python3.6/dist-packages/numpy/__init__.py

# functions

def get_nonzero_line(*args, **kwargs): # real signature unknown
    pass

def get_read_line(*args, **kwargs): # real signature unknown
    pass

def get_write_line(*args, **kwargs): # real signature unknown
    pass

def _label(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_Enum(*args, **kwargs): # real signature unknown
    pass

# classes

class NeedMoreBits(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3c6280f9b0>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.ndimage._ni_label', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f3c6280f9b0>, origin='/usr/local/lib/python3.6/dist-packages/scipy/ndimage/_ni_label.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


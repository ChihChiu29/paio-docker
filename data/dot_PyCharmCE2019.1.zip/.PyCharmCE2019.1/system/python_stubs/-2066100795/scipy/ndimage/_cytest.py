# encoding: utf-8
# module scipy.ndimage._cytest
# from /usr/local/lib/python3.6/dist-packages/scipy/ndimage/_cytest.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>

# functions

def filter1d(*args, **kwargs): # real signature unknown
    pass

def filter1d_capsule(*args, **kwargs): # real signature unknown
    pass

def filter2d(*args, **kwargs): # real signature unknown
    pass

def filter2d_capsule(*args, **kwargs): # real signature unknown
    pass

def transform(*args, **kwargs): # real signature unknown
    pass

def transform_capsule(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbb1aaee7b8>'

__pyx_capi__ = {
    '_filter1d': None, # (!) real value is '<capsule object "int (double *, npy_intp, double *, npy_intp, void *)" at 0x7fbb1b627de0>'
    '_filter2d': None, # (!) real value is '<capsule object "int (double *, npy_intp, double *, void *)" at 0x7fbb1b627e10>'
    '_transform': None, # (!) real value is '<capsule object "int (npy_intp *, double *, int, int, void *)" at 0x7fbb1b627e40>'
}

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.ndimage._cytest', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fbb1aaee7b8>, origin='/usr/local/lib/python3.6/dist-packages/scipy/ndimage/_cytest.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}


# encoding: utf-8
# module scipy.ndimage._ctest_oldapi
# from /usr/local/lib/python3.6/dist-packages/scipy/ndimage/_ctest_oldapi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def filter1d(*args, **kwargs): # real signature unknown
    pass

def filter2d(*args, **kwargs): # real signature unknown
    pass

def transform(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7ffb9708cb38>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy.ndimage._ctest_oldapi', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7ffb9708cb38>, origin='/usr/local/lib/python3.6/dist-packages/scipy/ndimage/_ctest_oldapi.cpython-36m-x86_64-linux-gnu.so')"


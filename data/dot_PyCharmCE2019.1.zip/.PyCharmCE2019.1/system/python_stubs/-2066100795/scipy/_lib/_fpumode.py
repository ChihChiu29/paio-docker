# encoding: utf-8
# module scipy._lib._fpumode
# from /usr/local/lib/python3.6/dist-packages/scipy/_lib/_fpumode.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def get_fpu_mode(): # real signature unknown; restored from __doc__
    """
    get_fpu_mode()
    
    Get the current FPU control word, in a platform-dependent format.
    Returns None if not implemented on current platform.
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f70af68aa90>'

__spec__ = None # (!) real value is "ModuleSpec(name='scipy._lib._fpumode', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f70af68aa90>, origin='/usr/local/lib/python3.6/dist-packages/scipy/_lib/_fpumode.cpython-36m-x86_64-linux-gnu.so')"


# encoding: utf-8
# module tensorflow.lite.python.optimize._tensorflow_lite_wrap_calibration_wrapper
# from /usr/local/lib/python3.6/dist-packages/tensorflow/lite/python/optimize/_tensorflow_lite_wrap_calibration_wrapper.so
# by generator 1.147
# no doc
# no imports

# functions

def CalibrationWrapper_CreateWrapperCPPFromBuffer(*args, **kwargs): # real signature unknown
    pass

def CalibrationWrapper_FeedTensor(*args, **kwargs): # real signature unknown
    pass

def CalibrationWrapper_Prepare(*args, **kwargs): # real signature unknown
    pass

def CalibrationWrapper_QuantizeModel(*args, **kwargs): # real signature unknown
    pass

def CalibrationWrapper_swigregister(*args, **kwargs): # real signature unknown
    pass

def delete_CalibrationWrapper(*args, **kwargs): # real signature unknown
    pass

def SWIG_PyInstanceMethod_New(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f31fa30c630>'

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.lite.python.optimize._tensorflow_lite_wrap_calibration_wrapper', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f31fa30c630>, origin='/usr/local/lib/python3.6/dist-packages/tensorflow/lite/python/optimize/_tensorflow_lite_wrap_calibration_wrapper.so')"


# encoding: utf-8
# module tensorflow.lite.python.interpreter_wrapper._tensorflow_wrap_interpreter_wrapper
# from /usr/local/lib/python3.6/dist-packages/tensorflow/lite/python/interpreter_wrapper/_tensorflow_wrap_interpreter_wrapper.so
# by generator 1.147
# no doc
# no imports

# functions

def delete_InterpreterWrapper(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_AllocateTensors(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_CreateWrapperCPPFromBuffer(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_CreateWrapperCPPFromFile(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_GetTensor(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_InputIndices(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_Invoke(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_NumTensors(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_OutputIndices(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_ResetVariableTensors(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_ResizeInputTensor(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_SetTensor(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_swigregister(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_tensor(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_TensorName(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_TensorQuantization(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_TensorSize(*args, **kwargs): # real signature unknown
    pass

def InterpreterWrapper_TensorType(*args, **kwargs): # real signature unknown
    pass

def SWIG_PyInstanceMethod_New(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8af317a198>'

__spec__ = None # (!) real value is "ModuleSpec(name='tensorflow.lite.python.interpreter_wrapper._tensorflow_wrap_interpreter_wrapper', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f8af317a198>, origin='/usr/local/lib/python3.6/dist-packages/tensorflow/lite/python/interpreter_wrapper/_tensorflow_wrap_interpreter_wrapper.so')"


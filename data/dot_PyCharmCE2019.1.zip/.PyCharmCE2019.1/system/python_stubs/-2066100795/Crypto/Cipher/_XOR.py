# encoding: utf-8
# module Crypto.Cipher._XOR
# from /usr/lib/python3/dist-packages/Crypto/Cipher/_XOR.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

block_size = 1

error = '_XOR.error'

key_size = 0

# functions

def new(*args, **kwargs): # real signature unknown
    """ Return a new _XOR encryption object. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa457353b38>'

__spec__ = None # (!) real value is "ModuleSpec(name='Crypto.Cipher._XOR', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7fa457353b38>, origin='/usr/lib/python3/dist-packages/Crypto/Cipher/_XOR.cpython-36m-x86_64-linux-gnu.so')"


# encoding: utf-8
# module Crypto.Cipher._ARC4
# from /usr/lib/python3/dist-packages/Crypto/Cipher/_ARC4.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

block_size = 1

error = '_ARC4.error'

key_size = 0

# functions

def new(*args, **kwargs): # real signature unknown
    """ Return a new _ARC4 encryption object. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f0deb1b7ba8>'

__spec__ = None # (!) real value is "ModuleSpec(name='Crypto.Cipher._ARC4', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f0deb1b7ba8>, origin='/usr/lib/python3/dist-packages/Crypto/Cipher/_ARC4.cpython-36m-x86_64-linux-gnu.so')"

